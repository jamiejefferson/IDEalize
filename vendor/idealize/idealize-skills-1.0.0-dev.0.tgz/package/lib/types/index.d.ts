/**
 * @idealize/skills — the person's own skills folder as product settings.
 *
 * JJ (15 Sep 2026) asked for "a pre-defined skills folder, visible in files,
 * like projects and documentation", captured in setup and referenced from a
 * chat's + menu. This plugin owns the folder: settings section
 * `idealize-skills` keeps `skillsFolder`. The folder holds `.skill` packages
 * (zip archives with a SKILL.md at the root, the format skills are shared
 * in) and unpacked skill folders (a folder holding a SKILL.md, the layout
 * Claude Code and Codex keep), directly or in one level of subfolders, one per
 * model (JJ, 15 Sep 2026: "i need subdirectories for the models to use"). An
 * unpacked folder is accepted when no package beside it has the same name;
 * the package wins a clash (JJ, 16 Nov 2026, narrowing the 15 Sep rule that
 * ignored every unpacked folder). While the folder is a readable directory
 * the plugin stages each package and each accepted folder under
 * `unpackFolder` (one subfolder each, under the source subfolder's name when
 * it has one, staged again when the source changes, removed when the source
 * goes) and mounts one `skill-filesystem` provider over the unpack folder and
 * each of its subfolders (`includeDefaultRoots: false`, watching) into the
 * host skill registry's global layer. The registry keeps one skill per name,
 * so a name that appears in two subfolders resolves to the first subfolder by
 * name. The skills folder itself is watched, so a package or folder dropped
 * in or replaced reaches the catalogue without a restart. A changed folder or
 * a new subfolder re-mounts the provider; an unset or unreadable folder mounts
 * nothing. The `idealizeSkills` service answers the folder's catalogue,
 * grouped by subfolder, for the composer's skill selector.
 *
 * Two more registrations decide which skills one chat is offered. A registry
 * view filter keeps, for a chat whose brain's `preset.yml` carries a `skills`
 * list, only the listed skills of the person's folder ({@link brainSkillFilter}).
 * A second provider lists the `playbooks/` folder of the chat's project inside
 * the documentation folder ({@link PlaybooksProvider}).
 *
 * The plugin also closes the loop from use back to the skill. The
 * `skill_learning` tool appends what an agent learned about a skill to
 * `Reference/playbook-learnings/<skill>.md` in the documentation folder, a
 * standing prompt line says when to call it, and the `fold-learnings` skill
 * shipped in this package's `skills/` directory drafts a revision from those
 * lines for the person to review.
 *
 * `@idealize/setup` writes the folder when the `skills` alias is captured;
 * `@idealize/ui-bar`'s Files pane shows the folder as its Skills tab and its
 * Skills & Commands submenu lists the catalogue.
 *
 * @module @idealize/skills
 */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
export { brainSkillFilter, presetOfScope } from './brain-filter.ts';
export { appendLearning, BUILT_IN_SKILLS_PROVIDER_NAME, builtInSkillsDir, LEARNING_MAX_LENGTH, learningAuthor, LEARNINGS_FOLDER, LEARNINGS_GUIDANCE, LEARNINGS_SECTION_NAME, LEARNINGS_SECTION_ORDER, SKILL_LEARNING_TOOL, skillLearningTool, } from './learnings.ts';
export type { LearningInput, LearningRecord } from './learnings.ts';
export { PLAYBOOK_RANK, PLAYBOOK_SOURCE, PLAYBOOKS_FOLDER, PLAYBOOKS_PROVIDER_NAME, PlaybooksProvider, projectRootOf, } from './playbooks.ts';
export declare const name = "idealize-skills";
declare module '@deepseek-ai/cordis' {
    interface Context {
        /** The skills folder's catalogue, grouped by subfolder. */
        idealizeSkills: IdealizeSkillsService;
    }
}
/** One package or unpacked folder in the catalogue: what its manifest says, or its file name when the manifest cannot be read. */
export interface CatalogueSkill {
    /** The package's file name without its extension, or the unpacked folder's name. */
    readonly package: string;
    /** The manifest's `name`, or the package name when the manifest is missing or unreadable. */
    readonly name: string;
    /** The manifest's `description`, empty when it is missing or unreadable. */
    readonly description: string;
    /** Whether the manifest was read; false leaves the package listed but not offered. */
    readonly manifest: boolean;
}
/** One folder of the catalogue: the skills folder itself (`folder` empty) or one of its subfolders. */
export interface CatalogueGroup {
    /** The subfolder name; empty for packages directly in the skills folder. */
    readonly folder: string;
    /** The folder's packages and accepted unpacked folders, sorted by name. */
    readonly skills: readonly CatalogueSkill[];
}
/** The service face: the folder's packages and accepted unpacked folders as they sit on disk, whether or not the registry accepted them. */
export interface IdealizeSkillsService {
    /**
     * The catalogue: the skills folder's own entries first, then each subfolder by name.
     * @returns the groups; empty when no folder is set or readable.
     */
    catalogue(): Promise<readonly CatalogueGroup[]>;
}
/** The settings namespace this plugin owns. */
export declare const SKILLS_SETTINGS_NAMESPACE = "idealize-skills";
/** The provider name the mounted `skill-filesystem` registers under. */
export declare const SKILLS_PROVIDER_NAME = "idealize-skills";
/** The file extension of a skill package: a zip archive with a SKILL.md at its root. */
export declare const SKILL_PACKAGE_EXTENSION = ".skill";
/** Plugin config, mirrored by the `idealize-skills` settings section. */
export interface SkillsConfig {
    /** Absolute directory holding the person's `.skill` packages and unpacked skill folders. */
    skillsFolder?: string;
    /** Where packages are unpacked and folders copied for the provider to read; `<dsh home>/idealize/skill-packages` when unset. */
    unpackFolder?: string;
}
export declare const Config: z<SkillsConfig>;
/**
 * The unpack folder for a config: the stored one, else the harness home default.
 * @param config - the plugin's settings.
 * @returns the absolute folder.
 */
export declare function resolveUnpackFolder(config: SkillsConfig): string;
/**
 * The archive entries to write for one package, keyed by their path under
 * the unpack subfolder. The SKILL.md may sit at the archive root or under one
 * top-level folder; entries outside that folder, directory entries, and any
 * path that escapes the subfolder are dropped.
 * @param archive - the package bytes.
 * @returns the files, or undefined when the archive holds no SKILL.md.
 */
export declare function packageFiles(archive: Uint8Array): ReadonlyMap<string, Uint8Array> | undefined;
/** What a sync leaves behind. */
export interface SyncResult {
    /** The packages and folders that could not be staged, with the reason. */
    readonly failures: readonly {
        id: string;
        reason: string;
    }[];
    /** The subfolders holding at least one skill source, by name: the provider's roots beside the unpack folder itself. */
    readonly groups: readonly string[];
}
/**
 * Bring the unpack folder in step with the skills folder: stage new or changed
 * packages and accepted unpacked folders, leave unchanged ones alone, and
 * remove staged subfolders whose source is gone. Only subfolders carrying the
 * marker are ever removed; a group folder goes once it holds nothing and its
 * source subfolder has no skill sources. A source that cannot be staged leaves
 * no partial copy behind.
 * @param folder - the skills folder holding the `.skill` packages and unpacked skill folders.
 * @param unpackFolder - where each source is staged, one subfolder each.
 * @returns the failures and the group folders in use.
 */
export declare function syncPackages(folder: string, unpackFolder: string): Promise<SyncResult>;
/**
 * The folder's catalogue from the skill sources on disk and their staged
 * manifests: the folder's own entries first (`folder` empty), then each
 * subfolder by name, each group's entries sorted by name. A source whose
 * staged manifest is missing or unreadable is listed by its file or folder
 * name with `manifest: false`.
 * @param folder - the skills folder.
 * @param unpackFolder - where the sources are staged.
 * @returns the groups, omitting a subfolder without skill sources.
 */
export declare function readCatalogue(folder: string, unpackFolder: string): Promise<CatalogueGroup[]>;
export declare function apply(ctx: Context, config: SkillsConfig): void;
//# sourceMappingURL=index.d.ts.map