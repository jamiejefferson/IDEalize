/**
 * @idealize/skills — the person's own skills folder as product settings.
 *
 * JJ (15 Sep 2026) asked for "a pre-defined skills folder, visible in files,
 * like projects and documentation", captured in setup and referenced from a
 * chat's + menu. This plugin owns the folder: settings section
 * `idealize-skills` keeps `skillsFolder`. The folder holds `.skill` packages
 * (zip archives with a SKILL.md at the root, the format skills are shared
 * in), directly or in one level of subfolders, one per model (JJ, later on
 * 15 Sep: "i need subdirectories for the models to use"); anything else,
 * including unpacked copies of the same skills, is ignored (JJ: "the folders
 * in skills should be ignored as they aren't the actual skill files - they're
 * the unpackaged skills"). While the folder is a readable directory the
 * plugin unpacks each package into `unpackFolder` (one subfolder per package,
 * under the package's own subfolder name when it has one, re-extracted when
 * the package's size or mtime changes, removed when the package goes) and
 * mounts one `skill-filesystem` provider over the unpack folder and each of
 * its subfolders (`includeDefaultRoots: false`, watching) into the host
 * skill registry's global layer, which every agent's catalogue and
 * `skill.list` read. The registry keeps one skill per name, so a name that
 * appears in two subfolders resolves to the first subfolder by name. The
 * skills folder itself is watched, so a package dropped in or replaced
 * reaches the catalogue without a restart. A changed folder or a new
 * subfolder re-mounts the provider; an unset or unreadable folder mounts
 * nothing. The `idealizeSkills` service answers the folder's catalogue,
 * grouped by subfolder, package by package, for the composer's skill
 * selector.
 *
 * `@idealize/setup` writes the folder when the `skills` alias is captured;
 * `@idealize/ui-bar`'s Files pane shows the folder as its Skills tab and its
 * Skills & Commands submenu lists the catalogue.
 *
 * @module @idealize/skills
 */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
export declare const name = "idealize-skills";
declare module '@deepseek-ai/cordis' {
    interface Context {
        /** The skills folder's catalogue, grouped by subfolder. */
        idealizeSkills: IdealizeSkillsService;
    }
}
/** One package in the catalogue: what its manifest says, or its file name when the manifest cannot be read. */
export interface CatalogueSkill {
    /** The package's file name without its extension. */
    readonly package: string;
    /** The manifest's `name`, or the package name when the manifest is missing or unreadable. */
    readonly name: string;
    /** The manifest's `description`, empty when it is missing or unreadable. */
    readonly description: string;
    /** Whether the manifest was read; false leaves the package listed but not offered. */
    readonly manifest: boolean;
}
/** One folder of the catalogue: the skills folder itself (`folder` empty) or one of its subfolders. */
export interface CatalogueGroup {
    /** The subfolder name; empty for packages directly in the skills folder. */
    readonly folder: string;
    /** The folder's packages, sorted by name. */
    readonly skills: readonly CatalogueSkill[];
}
/** The service face: the folder's packages as they sit on disk, whether or not the registry accepted them. */
export interface IdealizeSkillsService {
    /**
     * The catalogue: packages in the skills folder first, then each subfolder by name.
     * @returns the groups; empty when no folder is set or readable.
     */
    catalogue(): Promise<readonly CatalogueGroup[]>;
}
/** The settings namespace this plugin owns. */
export declare const SKILLS_SETTINGS_NAMESPACE = "idealize-skills";
/** The provider name the mounted `skill-filesystem` registers under. */
export declare const SKILLS_PROVIDER_NAME = "idealize-skills";
/** The file extension of a skill package: a zip archive with a SKILL.md at its root. */
export declare const SKILL_PACKAGE_EXTENSION = ".skill";
/** Plugin config, mirrored by the `idealize-skills` settings section. */
export interface SkillsConfig {
    /** Absolute directory holding the person's `.skill` packages. */
    skillsFolder?: string;
    /** Where the packages are unpacked for the provider to read; `<dsh home>/idealize/skill-packages` when unset. */
    unpackFolder?: string;
}
export declare const Config: z<SkillsConfig>;
/**
 * The unpack folder for a config: the stored one, else the harness home default.
 * @param config - the plugin's settings.
 * @returns the absolute folder.
 */
export declare function resolveUnpackFolder(config: SkillsConfig): string;
/**
 * The archive entries to write for one package, keyed by their path under
 * the unpack subfolder. The SKILL.md may sit at the archive root or under one
 * top-level folder; entries outside that folder, directory entries, and any
 * path that escapes the subfolder are dropped.
 * @param archive - the package bytes.
 * @returns the files, or undefined when the archive holds no SKILL.md.
 */
export declare function packageFiles(archive: Uint8Array): ReadonlyMap<string, Uint8Array> | undefined;
/** What a sync leaves behind. */
export interface SyncResult {
    /** The packages that could not be unpacked, with the reason. */
    readonly failures: readonly {
        id: string;
        reason: string;
    }[];
    /** The subfolders holding at least one package, by name: the provider's roots beside the unpack folder itself. */
    readonly groups: readonly string[];
}
/**
 * Bring the unpack folder in step with the packages: extract new or changed
 * packages, leave unchanged ones alone, and remove unpacked subfolders whose
 * package is gone. Only subfolders carrying the marker are ever removed; a
 * group folder goes once it holds nothing and its source subfolder has no
 * packages.
 * @param folder - the skills folder holding the `.skill` packages.
 * @param unpackFolder - where each package unpacks to, one subfolder per package.
 * @returns the failures and the group folders in use.
 */
export declare function syncPackages(folder: string, unpackFolder: string): Promise<SyncResult>;
/**
 * The folder's catalogue from the packages on disk and their unpacked
 * manifests: the folder's own packages first (`folder` empty), then each
 * subfolder by name, each group's packages sorted by name. A package whose
 * unpacked manifest is missing or unreadable is listed by its file name with
 * `manifest: false`.
 * @param folder - the skills folder.
 * @param unpackFolder - where the packages are unpacked.
 * @returns the groups, omitting a subfolder without packages.
 */
export declare function readCatalogue(folder: string, unpackFolder: string): Promise<CatalogueGroup[]>;
export declare function apply(ctx: Context, config: SkillsConfig): void;
//# sourceMappingURL=index.d.ts.map