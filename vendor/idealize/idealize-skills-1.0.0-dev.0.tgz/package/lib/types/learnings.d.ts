/**
 * Skill learnings: what agents learn about a skill while using it.
 *
 * A learning is one dated line an agent appends to
 * `Reference/playbook-learnings/<skill>.md` inside the user's documentation
 * folder, through the `skill_learning` tool. Nothing here rewrites a line once
 * it is written: a model that rewrites a whole context each round erodes its
 * detail, while small itemised additions keep it (JJ approved the append-only
 * rule and the folder on 16 Nov 2026). The `fold-learnings` skill this package
 * ships turns a file of learnings into a proposed revision for the person to
 * review.
 * @module @idealize/skills/learnings
 */
import type { Context } from '@deepseek-ai/cordis';
import { type PresetBearingSession } from '@deepseek-ai/dsh-agent-presets';
import { type ToolDefinition } from '@deepseek-ai/dsh-tools';
/** The model-facing tool that records one learning. */
export declare const SKILL_LEARNING_TOOL = "skill_learning";
/** The folder of learnings files, as path segments under the documentation folder. */
export declare const LEARNINGS_FOLDER: readonly ["Reference", "playbook-learnings"];
/** The longest learning the tool accepts, in characters, after whitespace is collapsed. */
export declare const LEARNING_MAX_LENGTH = 500;
/** Section name of the standing prompt line. */
export declare const LEARNINGS_SECTION_NAME = "idealize:skill-learnings";
/** Order of the standing prompt line: straight after `idealize:documentation` (122). */
export declare const LEARNINGS_SECTION_ORDER = 123;
/** The standing prompt line, verbatim. */
export declare const LEARNINGS_GUIDANCE: string;
/** The provider name the skills this package ships register under. */
export declare const BUILT_IN_SKILLS_PROVIDER_NAME = "idealize-built-in-skills";
/**
 * The directory of skills this package ships (`skills/<name>/SKILL.md`, one level above both `src/` and `lib/`).
 * @returns the absolute directory path.
 */
export declare function builtInSkillsDir(): string;
/** One learning to record. */
export interface LearningInput {
    /** The documentation folder. */
    readonly folder: string;
    /** The skill the learning is about; must be a valid skill name. */
    readonly skill: string;
    /** The brain (agent preset id) of the chat that learned it. */
    readonly brain: string;
    /** The model that learned it. */
    readonly model: string;
    /** The learning, already one line. */
    readonly text: string;
    /** The moment of recording; the line carries its local calendar date. */
    readonly now: Date;
}
/** Where a learning went. */
export interface LearningRecord {
    /** The learnings file, relative to the documentation folder, with `/` separators. */
    readonly path: string;
    /** The line appended, without its line ending. */
    readonly line: string;
}
/**
 * Append one learning to its skill's file, creating the file with `type: log`
 * frontmatter when it is missing. The only write to an existing file is an
 * append: a file whose last line has no line ending gains one first, so the
 * new line never joins an earlier one.
 * @param input - the folder, the skill, who learned it, the text and the moment.
 * @returns the file and the line written.
 * @throws when `input.skill` is not a valid skill name, which keeps the file inside the learnings folder.
 */
export declare function appendLearning(input: LearningInput): Promise<LearningRecord>;
/**
 * Who a chat's learning is attributed to: the brain its log records (else the
 * preset it runs on) and the model of its latest request.
 * @param session - the calling chat's header and event log; `undefined` for a call outside a chat.
 * @returns the brain and model labels, `unknown` where the log names none, with whitespace and brackets
 *   replaced so the line keeps its format.
 */
export declare function learningAuthor(session: PresetBearingSession | undefined): {
    brain: string;
    model: string;
};
/**
 * The `skill_learning` tool. It records a learning only for a skill the
 * calling chat is offered, and only appends; with no documentation folder set
 * it says so and writes nothing.
 * @param ctx - a context carrying `docPolicy` and `skills`.
 * @param now - the clock; tests pass a fixed one.
 * @returns the tool definition to register.
 */
export declare function skillLearningTool(ctx: Context, now?: () => Date): ToolDefinition;
//# sourceMappingURL=learnings.d.ts.map