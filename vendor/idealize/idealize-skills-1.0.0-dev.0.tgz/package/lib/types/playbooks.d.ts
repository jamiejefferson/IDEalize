/**
 * A project's playbooks as skills.
 *
 * A project's folder inside the documentation folder may hold `playbooks/`:
 * skills written for that project (`playbooks/<name>/SKILL.md`, or a flat
 * `playbooks/<name>.md`). This provider lists them for a chat whose working
 * directory belongs to the project, and for no other chat: the lookup is keyed
 * by the chat's working directory, the way the filesystem provider's project
 * roots are.
 * @module @idealize/skills/playbooks
 */
import type { Context } from '@deepseek-ai/cordis';
import type { SkillCandidate, SkillDefinition, SkillLookupOptions, SkillProvider, SkillProviderControl, SkillProviderObservation } from '@deepseek-ai/dsh-skill';
/** The provider name playbooks register under. */
export declare const PLAYBOOKS_PROVIDER_NAME = "idealize-playbooks";
/** The folder inside a project's documentation folder that holds its playbooks. */
export declare const PLAYBOOKS_FOLDER = "playbooks";
/** The `source` every playbook carries. */
export declare const PLAYBOOK_SOURCE = "project-playbooks";
/**
 * The rank every playbook carries: between the filesystem provider's project
 * roots (100, 200) and its custom roots (300), so a playbook wins a name over
 * a skill from the person's skills folder in the same registry layer.
 */
export declare const PLAYBOOK_RANK = 150;
/**
 * The project a working directory belongs to: the nearest folder at or above
 * it that holds a `.git` entry, the rule the filesystem provider's project
 * roots follow.
 * @param cwd - an absolute working directory.
 * @returns the project's folder, or `cwd` itself outside every repository.
 */
export declare function projectRootOf(cwd: string): Promise<string>;
/**
 * Lists the playbooks of the project a lookup's working directory belongs to.
 * It keeps one filesystem provider per playbooks folder it has been asked
 * about, each watching that folder (present or not yet created) and
 * invalidating this registration when it changes.
 */
export declare class PlaybooksProvider implements SkillProvider {
    private readonly ctx;
    private readonly control;
    private readonly playbooksFolder;
    readonly name = "idealize-playbooks";
    /** One filesystem provider per playbooks folder, keyed by the folder's path. */
    private readonly folders;
    /** Loads a listed playbook's body; it scans and watches nothing. */
    private readonly loader;
    /**
     * @param ctx - the context the wrapped filesystem providers read and log through.
     * @param control - this registration's lifecycle and invalidation control.
     * @param playbooksFolder - the playbooks folder for a working directory, or `undefined` when the
     *   directory belongs to no documented project.
     */
    constructor(ctx: Context, control: SkillProviderControl, playbooksFolder: (cwd: string) => Promise<string | undefined>);
    /**
     * The playbooks for the lookup's working directory.
     * @param options - lookup options; `cwd` selects the project, `signal` cancels discovery.
     * @returns the project's playbooks, or none without a working directory or a documented project.
     */
    list(options: SkillLookupOptions): Promise<SkillCandidate[] | SkillProviderObservation>;
    /**
     * Load one listed playbook's body.
     * @param candidate - a candidate this provider listed.
     * @param options - lookup options whose signal cancels the read.
     * @returns the playbook, or `undefined` when its file has gone.
     */
    get(candidate: SkillCandidate, options: SkillLookupOptions): Promise<SkillDefinition | undefined>;
    /**
     * Close every folder watcher.
     * @returns a promise that settles when every wrapped provider has closed its watchers.
     */
    dispose(): Promise<void>;
    private providerOver;
}
//# sourceMappingURL=playbooks.d.ts.map