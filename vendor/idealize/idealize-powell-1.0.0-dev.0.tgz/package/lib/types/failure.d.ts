/**
 * Turn a failed turn's provider error into one plain line for the bubble,
 * plus a link when there is somewhere to go and fix it. Powell used to say
 * "Something went wrong" for every failure, so running out of OpenRouter
 * credit looked like a broken app.
 */
/** The parts of an `LlmFailure` this reads. */
export interface FailureLike {
    message?: string;
    code?: string;
    status?: number;
}
/** What the bubble shows. */
export interface ExplainedFailure {
    text: string;
    /** Where the person fixes it, opened by the bubble's first button. */
    link?: {
        label: string;
        url: string;
    };
}
/**
 * Explain a failed turn in one or two short sentences.
 * @param failure - the turn's error, when the session recorded one.
 * @param provider - the provider id Powell's chat runs on.
 * @returns the bubble line and an optional fix-it link.
 */
export declare function explainFailure(failure: FailureLike | undefined, provider?: string): ExplainedFailure;
//# sourceMappingURL=failure.d.ts.map