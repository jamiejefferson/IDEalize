/**
 * @idealize/powell — the host half of MiniMode's desk buddy (2.0.0).
 *
 * Powell is one workspace-level agent (JJ, 2 Oct 2026: a separate agent, not
 * the Studio coordinator). This plugin owns its session: it starts or resumes
 * it on the `powell` Activity Agent, holds the active project as explicit
 * state, turns the session's events into the owl's seven states and its
 * spoken sentences, answers permission prompts for Powell's own session in
 * the speech bubble, and serves the speech providers so no key reaches the
 * window.
 *
 * HTTP (loopback; mutating routes need `x-idealize-auth: 1`):
 * - `GET  /idealize/powell/events` — SSE of {@link PowellStreamEvent}.
 * - `POST /idealize/powell/say` `{text, modality}` — a message from the person.
 * - `POST /idealize/powell/stop` — cancel Powell and anything it started.
 * - `POST /idealize/powell/choose` `{choice}` — a bubble button.
 * - `POST /idealize/powell/hear` (WAV body) — speech to text.
 * - `GET  /idealize/powell/speak?text=` — text to streamed MP3.
 * - `GET  /idealize/powell/voice` — the acknowledgement manifest; `GET /idealize/powell/clip/<id>` one clip.
 * - `GET|POST /idealize/powell/project` — read or set the active project.
 * - `GET  /idealize/powell/owl.json` — the owl's run-cycle frames.
 * - `POST /idealize/powell/open-app` — show the full IDEalize window.
 * @module @idealize/powell
 */
import { Context, Service } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import type { Agent } from '@deepseek-ai/dsh-agent';
import type { Session, SessionEvent } from '@deepseek-ai/dsh-session';
import { type ProjectEntry } from './projects.ts';
import { VoiceCache, type SpeechToTextProvider, type TextToSpeechProvider } from './speech.ts';
import type { PowellChoice, PowellProject, PowellStreamEvent, PowellView } from './types.ts';
export * from './types.ts';
export { ACK_LIBRARY, clipFor, isActionable, parseReply, pickAck, SentenceStream, tidy, wantsDetail } from './speech-text.ts';
export { appOfTool, statusOfTool } from './status.ts';
export { mergeProjects, projectKey, readProjectSwitch, resolveProject } from './projects.ts';
export { powellContext, powellGuide } from './guide.ts';
export { wavOf } from './speech.ts';
declare module '@deepseek-ai/cordis' {
    interface Context {
        idealizePowell: PowellService;
    }
}
export declare const name = "idealize-powell";
/** Powell's settings (`idealize-powell:` in settings.yaml). */
export interface Config {
    /** `provider/model` for Powell's brain; empty uses the app's default model. */
    model: string;
    /** The ElevenLabs voice. */
    voice: string;
    /** fal text-to-speech endpoints in preference order. */
    speechModels: string[];
    /** fal speech-to-text endpoint. */
    hearingModel: string;
    /** How long a finished reply stays up before Powell settles, in ms. */
    doneMs: number;
}
export declare const Config: z<Config>;
/** The preset id Powell's chat runs on. */
export declare const POWELL_PRESET = "powell";
/** Settings sections Powell reads, structurally. */
interface FolderSettings {
    projectsRoot?: string;
    documentationFolder?: string;
}
/** Powell: the service behind the owl. */
export declare class PowellService extends Service {
    readonly config: Config;
    private view;
    private readonly listeners;
    private state;
    private agent;
    private starting;
    private stream;
    private budget;
    /** Sentences already spoken this turn: the budget is per turn, not per step. */
    private spoken;
    /**
     * A step's first sentence, held until the step shows what it is: a second
     * sentence or the step's end means a reply (speak it), a tool call means
     * narration before work ("I'll list the projects…"), which is dropped.
     */
    private held;
    /** This step called a tool, so its text is narration and stays silent. */
    private stepActs;
    private stepSpoken;
    private lastStepText;
    private lastUserText;
    /**
     * The running turn answers something said to the owl. A turn woken by
     * Studio mail (Powell is the Studio manager) answers in the Studio, so the
     * owl shows it working but neither speaks nor raises a bubble.
     */
    private fromOwl;
    private settle;
    private readonly approvals;
    /** Chats Powell started this turn, cancelled by Stop with it. */
    private readonly delegates;
    readonly hearing: SpeechToTextProvider;
    readonly voice: TextToSpeechProvider;
    readonly clips: VoiceCache;
    private readonly stateFile;
    constructor(ctx: Context, config: Config);
    start(): Promise<void>;
    private save;
    /** The current view. */
    snapshot(): PowellView;
    /**
     * Subscribe to the owl's stream.
     * @param listener - receives every event.
     * @returns the unsubscribe function.
     */
    subscribe(listener: (event: PowellStreamEvent) => void): () => void;
    private emit;
    private setView;
    private speak;
    private offer;
    private voiceLine;
    /** Whether a session is Powell's. */
    isPowell(session: Session | undefined): boolean;
    /** The active project, when set. */
    project(): PowellProject | undefined;
    /** The folders the guide names, from the vault and docs settings. */
    folders(): FolderSettings;
    /** The model picked for Powell in the Brains pane (`idealize-activity-pills.models.powell`), when one is. */
    brainsModel(): {
        provider: string;
        model: string;
    } | undefined;
    /** Connected apps: MCP servers with tools registered right now. */
    apps(): string[];
    /** Every project Powell can switch to. */
    projects(): Promise<ProjectEntry[]>;
    /**
     * Set the active project.
     * @param said - a name, or an absolute folder.
     * @returns the project, or the candidates when the name is ambiguous.
     */
    setProject(said: string): Promise<{
        project?: PowellProject;
        candidates: string[];
    }>;
    /**
     * Record the voice consent or the mute switch.
     * @param prefs - the fields to change.
     */
    setPrefs(prefs: {
        voiceConsent?: boolean;
        muted?: boolean;
    }): Promise<void>;
    /**
     * Give one agent context Powell's guide, its live context block and the
     * project tool. Called from the session's setup, so all three are scoped to
     * Powell's own agent: no other chat's prompt or tool list carries them.
     * @param agentCtx - the agent's context.
     */
    private scope;
    /**
     * Keep the model router off Powell's chat: its brain was picked for speed,
     * and a routing decision would add a model call to every message. The
     * router reads its own lock event, so Powell writes that event rather than
     * importing the router (absent the router, the event is inert).
     * @param agent - Powell's live agent.
     */
    private lockRouting;
    /** Start, resume or return Powell's live agent. */
    ensureAgent(): Promise<Agent>;
    private launch;
    /**
     * A message from the person, typed or spoken.
     * @param text - the words.
     * @param modality - how they arrived.
     */
    say(said: string, modality: 'text' | 'voice'): Promise<void>;
    /** Stop Powell and every chat it started this turn. */
    stop(): void;
    /**
     * A bubble button.
     * @param choice - what was pressed.
     */
    choose(choice: PowellChoice): Promise<void>;
    /**
     * Open a destination for the person: a folder or file in its app, or a URL in the browser.
     * @param target - absolute path or URL.
     */
    open(target: string): Promise<void>;
    /** Show the full app. */
    openApp(): Promise<void>;
    /**
     * Answer without the model: a bubble and its line, spoken.
     * @param text - the line.
     * @param choices - tap answers, when it asks.
     * @param asking - whether Powell waits for an answer.
     */
    private reply;
    private problem;
    /**
     * Fold one event from Powell's session into the view and the voice.
     * @param event - the session event.
     */
    observe(event: SessionEvent): void;
    private finish;
    /**
     * Ask the person to allow one tool call, in the bubble.
     * @param toolName - the tool asking.
     * @param reason - why it asks.
     * @param signal - withdraws the ask.
     * @returns the decision.
     */
    ask(toolName: string, reason: string | undefined, signal: AbortSignal | undefined): Promise<'allowed-once' | 'rejected' | 'cancelled'>;
}
export declare function apply(ctx: Context, config: Config): void;
//# sourceMappingURL=index.d.ts.map