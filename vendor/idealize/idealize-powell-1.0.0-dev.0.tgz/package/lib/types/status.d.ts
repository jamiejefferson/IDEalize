/**
 * The words on Powell's status tag while it works. The tag names the
 * surface, never the tool call (spec §16): "Working in Paper", not
 * `mcp__paper__write_html`.
 * @module @idealize/powell/status
 */
/**
 * The display name for an MCP server, from a tool name like
 * `mcp__paper__get_basic_info` or `mcp__claude_ai_Figma__use_figma`.
 * @param tool - the tool name.
 * @returns the app's name, or undefined when the tool is not an MCP tool.
 */
export declare function appOfTool(tool: string): string | undefined;
/**
 * The status tag for one tool call.
 * @param tool - the tool's name.
 * @param args - the call's JSON arguments, as streamed.
 * @param project - the active project's name, for search wording.
 * @returns the tag text.
 */
export declare function statusOfTool(tool: string, args: string, project: string | undefined): string;
//# sourceMappingURL=status.d.ts.map