/**
 * Powell's speech providers. Both sit behind small interfaces (spec §6, §13)
 * so the vendor can change without touching the orchestration. The first
 * implementations call fal with the key from the app's credential store, on
 * the host, so no key ever reaches the owl window.
 *
 * Measured on 2 Oct 2026 (one sentence, from London): ElevenLabs v4 Turbo
 * streamed its first audio after about 1.0 s and Turbo v2.5 after about
 * 0.8 s; Scribe v2 transcribed a five-second clip in about 2.1 s.
 * @module @idealize/powell/speech
 */
import type { PowellVoiceManifest } from './types.ts';
/** Turns one finished recording into text. */
export interface SpeechToTextProvider {
    /**
     * @param wav - a 16 kHz mono PCM WAV recording.
     * @param keyterms - words to bias recognition toward (project names).
     * @param signal - cancels the request.
     * @returns the transcript, trimmed; empty for silence.
     */
    transcribe(wav: Buffer, keyterms: readonly string[], signal?: AbortSignal): Promise<string>;
}
/** Turns one sentence into streamed audio. */
export interface TextToSpeechProvider {
    /** What a cache keyed on this voice must change with. */
    readonly identity: {
        voice: string;
        model: string;
    };
    /**
     * @param text - the sentence.
     * @param signal - cancels the request (an interruption).
     * @returns the MP3 body as it arrives.
     */
    stream(text: string, signal?: AbortSignal): Promise<ReadableStream<Uint8Array>>;
}
/** Resolves the fal key per call (credentials must not be cached across operations). */
export type KeySource = () => Promise<string | undefined>;
/** The fal request failed or no key is set. */
export declare class SpeechError extends Error {
    readonly code: 'no-key' | 'failed' | 'aborted';
    constructor(message: string, code: 'no-key' | 'failed' | 'aborted');
}
/**
 * Build a WAV file around mono 16-bit PCM.
 * @param pcm - little-endian 16-bit samples.
 * @param rate - the sample rate.
 * @returns the WAV bytes.
 */
export declare function wavOf(pcm: Buffer, rate: number): Buffer;
/** ElevenLabs Scribe through fal. */
export declare class FalScribe implements SpeechToTextProvider {
    private readonly key;
    private readonly model;
    constructor(key: KeySource, model?: string);
    transcribe(wav: Buffer, keyterms: readonly string[], signal?: AbortSignal): Promise<string>;
}
/** ElevenLabs text-to-speech through fal's streaming endpoint, with a fallback model. */
export declare class FalElevenTts implements TextToSpeechProvider {
    private readonly key;
    readonly voice: string;
    private readonly models;
    readonly identity: {
        voice: string;
        model: string;
    };
    /**
     * @param key - the fal key source.
     * @param voice - the ElevenLabs voice name.
     * @param models - fal endpoints in preference order (addendum §2: v4 Turbo, then Turbo v2.5).
     */
    constructor(key: KeySource, voice: string, models: readonly string[]);
    stream(text: string, signal?: AbortSignal): Promise<ReadableStream<Uint8Array>>;
}
/**
 * Read a whole stream into one buffer.
 * @param stream - the body.
 * @returns the bytes.
 */
export declare function drain(stream: ReadableStream<Uint8Array>): Promise<Buffer>;
/**
 * The pre-generated acknowledgement clips (addendum §1, §6), one folder per
 * voice so changing the voice regenerates them and never mixes two voices.
 */
export declare class VoiceCache {
    private readonly root;
    private readonly tts;
    private generating;
    /**
     * @param root - the cache root (`<DSH home>/idealize/powell/voice`).
     * @param tts - the provider whose voice the clips use.
     */
    constructor(root: string, tts: TextToSpeechProvider);
    /** The folder for the current voice. */
    folder(): string;
    /**
     * The manifest the owl preloads.
     * @param urlOf - maps a clip id to its route.
     * @returns the manifest (clips listed whether or not generated yet; a missing one falls back to live speech).
     */
    manifest(urlOf: (id: string) => string): PowellVoiceManifest;
    /**
     * One clip's audio, generating it on first ask.
     * @param id - the clip id.
     * @returns the MP3 bytes, or undefined for an unknown id or a failed generation.
     */
    clip(id: string): Promise<Buffer | undefined>;
    /**
     * Generate every missing clip, in the background, once per voice.
     * @returns resolves when the library is complete (or as complete as fal allowed).
     */
    warm(): Promise<void>;
}
//# sourceMappingURL=speech.d.ts.map