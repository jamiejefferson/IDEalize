/**
 * What Powell's Open button may reach. The target comes from a model's reply, or
 * from a provider's error text, and a hidden instruction in a page can put
 * anything there: `[open: /path/x.command]` would run a script, and any URL
 * scheme could hand the link to another app. So the button opens https pages,
 * and files or folders inside a project, and nothing that runs when opened.
 * @module @idealize/powell/open-target
 */
/** A target that passed, in the form to open. */
export type OpenTarget = {
    kind: 'url';
    url: string;
} | {
    kind: 'path';
    path: string;
};
/**
 * Decide whether Powell may open a target.
 * @param target - the URL or absolute path from a reply.
 * @param roots - the project folders a path may sit in.
 * @returns the target to open; undefined when it is refused.
 */
export declare function checkOpenTarget(target: string, roots: readonly string[]): Promise<OpenTarget | undefined>;
/**
 * The button's words, naming where it goes.
 * @param target - the URL or path.
 * @returns "Open example.com", or "Open notes.md".
 */
export declare function openButtonLabel(target: string): string;
//# sourceMappingURL=open-target.d.ts.map