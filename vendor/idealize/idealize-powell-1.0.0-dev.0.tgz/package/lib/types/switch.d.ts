/**
 * Reading a project switch out of a message. Pure, so the owl window and the
 * host share it: the host switches before the model runs, and the window
 * skips the acknowledgement because the answer is instant.
 * @module @idealize/powell/switch
 */
/** A request that only names the project to work on, and what is left after it. */
export interface ProjectSwitch {
    /** The project as the person said it. */
    said: string;
    /** The rest of the message, empty when the message was only the switch. */
    rest: string;
}
/**
 * Read a project switch out of a message ("We're working on JACQ today.",
 * "Switch to Hatch. Open the brief."), so the switch happens before the model
 * runs and never depends on it remembering to call a tool.
 * @param text - the person's message.
 * @returns the switch, or undefined when the message does not open with one.
 */
export declare function readProjectSwitch(text: string): ProjectSwitch | undefined;
//# sourceMappingURL=switch.d.ts.map