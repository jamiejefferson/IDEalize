/**
 * The text side of Powell's voice: cutting a streaming reply into sentences
 * the moment each one is complete, keeping the spoken budget short, reading
 * the reply's markers (choices and an open target), and picking the instant
 * acknowledgement for a request. Pure functions, so every rule here is
 * pinned by a spec rather than by listening.
 * @module @idealize/powell/speech-text
 */
/** The acknowledgement library (latency addendum §1): small on purpose. */
export declare const ACK_LIBRARY: readonly {
    id: string;
    text: string;
}[];
/**
 * Clips safe to play before any work has happened: none of them claims an
 * outcome (addendum §5). `done`, `saved` and `updated` play only as the
 * reply's own words, after the work.
 */
export declare const PRE_ACTION_ACKS: readonly string[];
/** Sentences Powell speaks per turn unless the person asked for detail. */
export declare const SPOKEN_BUDGET = 2;
/** Sentences Powell may speak when the person asked it to explain. */
export declare const EXPLAIN_BUDGET = 8;
/**
 * Normalise a sentence for matching against the clip library: lower case,
 * curly quotes straightened, trailing punctuation and spaces dropped.
 * @param text - the sentence.
 * @returns the key form.
 */
export declare function clipKey(text: string): string;
/**
 * The cached clip that says exactly this sentence, so it plays with no
 * synthesis at all.
 * @param sentence - one spoken sentence.
 * @returns the clip id, or undefined when live speech is needed.
 */
export declare function clipFor(sentence: string): string | undefined;
/**
 * Whether a request reads as a clear instruction, which earns an instant
 * acknowledgement while the work starts (addendum §5). Questions and chat
 * get none: the answer itself is the first thing Powell says.
 * @param text - the person's message.
 * @returns true for an actionable instruction.
 */
export declare function isActionable(text: string): boolean;
/**
 * Pick the acknowledgement for an instruction. It rotates through the safe
 * set so Powell does not repeat itself every time.
 * @param turn - a counter that advances per request.
 * @returns the clip id.
 */
export declare function pickAck(turn: number): string;
/**
 * Whether the person asked for a longer spoken answer (spec §7: the user can
 * relax the speech budget).
 * @param text - the person's message.
 * @returns true when detail was asked for.
 */
export declare function wantsDetail(text: string): boolean;
/** What Powell's finished reply carries. */
export interface ParsedReply {
    /** The words shown and spoken, markers removed. */
    text: string;
    /** Tap answers from a `[choices: A | B]` line. */
    choices: string[];
    /** A destination from an `[open: path-or-url]` line. */
    open?: string;
}
/**
 * Split Powell's reply into its words and its markers.
 * @param reply - the assistant text of the turn's last step.
 * @returns the parsed reply.
 */
export declare function parseReply(reply: string): ParsedReply;
/**
 * Plain words for the bubble and the voice: markdown emphasis, headings,
 * bullets, links and code fences removed, whitespace collapsed.
 * @param text - model text.
 * @returns the plain text.
 */
export declare function tidy(text: string): string;
/**
 * Cuts a streaming reply into complete sentences as they arrive, so the first
 * one can go to synthesis before the model has finished writing (addendum §2).
 * Marker lines never reach the voice.
 */
export declare class SentenceStream {
    private readonly budget;
    private buffer;
    private spoken;
    private stopped;
    /** @param budget - how many sentences may be spoken this turn. */
    constructor(budget?: number);
    /**
     * Add streamed text.
     * @param delta - the next chunk of assistant text.
     * @returns the sentences that became complete, within the budget.
     */
    push(delta: string): string[];
    /**
     * End of the reply: whatever is left is the last sentence.
     * @returns the remaining sentence, within the budget.
     */
    flush(): string[];
    /**
     * Speak one cut piece, unless it is a marker line or over budget, which
     * stop speech for the turn (the rest is for the screen).
     * @returns false once speech has stopped.
     */
    private take;
    /** Index just past the first complete sentence in the buffer, or -1. */
    private boundary;
}
//# sourceMappingURL=speech-text.d.ts.map