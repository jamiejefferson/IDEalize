/**
 * The project index Powell switches between (spec §4: active project is
 * explicit state). Three sources merge by name: the projects IDEalize has
 * opened (the workspace registry), the folders under the projects root, and
 * the project notes in the documentation vault. A project keeps its working
 * folder and its notes folder side by side, so "the Idealize docs" and "the
 * Idealize repo" resolve to the same entry.
 * @module @idealize/powell/projects
 */
/** One project Powell can set as active. */
export interface ProjectEntry {
    /** Display name. */
    name: string;
    /** The working folder (repository or project folder), when one is known. */
    path?: string;
    /** The project's notes folder in the documentation vault, when it has one. */
    notes?: string;
}
/**
 * The matching key for a project name: lower case, letters and digits only.
 * @param name - a project or folder name, or what the user said.
 * @returns the key.
 */
export declare function projectKey(name: string): string;
/**
 * Merge the three sources into one list, by name.
 * @param known - folders IDEalize has opened as projects.
 * @param rootFolders - folders under the projects root.
 * @param noteFolders - project folders in the vault's `Projects/`.
 * @returns entries sorted by name.
 */
export declare function mergeProjects(known: readonly string[], rootFolders: readonly string[], noteFolders: readonly string[]): ProjectEntry[];
/**
 * Find the project a spoken or typed name means. Exact key first, then a
 * unique prefix, then a unique substring; speech recognisers drop and merge
 * words ("idea lies" for IDEalize), so spaces never matter.
 * @param projects - the index.
 * @param said - what the user called it.
 * @returns the match, the candidates when it is ambiguous, or nothing.
 */
export declare function resolveProject(projects: readonly ProjectEntry[], said: string): {
    match?: ProjectEntry;
    candidates: ProjectEntry[];
};
/**
 * Levenshtein distance between two keys.
 * @param a - one key.
 * @param b - the other.
 * @returns the number of single-character edits between them.
 */
export declare function editDistance(a: string, b: string): number;
/**
 * The subfolders of a folder, absolute; nothing when it cannot be read.
 * @param folder - the parent.
 * @returns absolute child folder paths.
 */
export declare function subfolders(folder: string | undefined): Promise<string[]>;
export { readProjectSwitch, type ProjectSwitch } from './switch.ts';
//# sourceMappingURL=projects.d.ts.map