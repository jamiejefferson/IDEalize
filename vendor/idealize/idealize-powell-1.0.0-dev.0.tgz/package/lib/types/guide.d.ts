/**
 * Powell's standing instructions: the response policy from the MiniMode
 * spec (§2, §7–§10, §15) written for the model, plus the live context block
 * (active project, folders, connected apps) that rides after the history so
 * switching project never rewrites the cached prompt prefix.
 * @module @idealize/powell/guide
 */
/** Where Powell's work can land, as the guide names it. */
export interface GuideFolders {
    /** The projects root (`idealize-vault.projectsRoot`), when set. */
    projectsRoot?: string;
    /** The documentation vault (`idealize-docs.documentationFolder`), when set. */
    documentationFolder?: string;
}
/** The persona row Powell's preset carries. */
export declare const POWELL_PERSONA: string;
/**
 * The guide section (static, so it stays in the cached prefix).
 * @returns the guide text.
 */
export declare function powellGuide(): string;
/**
 * The live context block, refreshed every assembly: it travels after the
 * history, so a project switch reaches the next step without touching the
 * cached prefix.
 * @param project - the active project, when one is set.
 * @param folders - where projects and documentation live.
 * @param apps - connected app names (MCP servers with tools right now).
 * @param peek - lists a folder's entries (a seam for tests).
 * @returns the context text.
 */
export declare function powellContext(project: {
    name: string;
    path: string;
    notes?: string;
} | undefined, folders: GuideFolders, apps: readonly string[], peek?: (folder: string) => string[]): string;
/**
 * The project's notes folder in the vault, when it exists: `Projects/<name>`,
 * matched by name with case and punctuation ignored.
 * @param name - the project's name.
 * @param documentationFolder - the vault, when set.
 * @returns the absolute folder, or undefined.
 */
export declare function notesFolder(name: string, documentationFolder: string | undefined): string | undefined;
/**
 * A folder's visible entries, folders marked with a trailing slash; empty when unreadable.
 * @param folder - the folder.
 * @returns entry names, sorted.
 */
export declare function listFolder(folder: string): string[];
//# sourceMappingURL=guide.d.ts.map