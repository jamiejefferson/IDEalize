/**
 * The owl's three gestures on one pointer (MiniMode plan, interaction model):
 * a press that moves more than 4 px is a drag; a press held 250 ms without
 * moving is push-to-talk; anything shorter is a click, and two clicks inside
 * 300 ms are a double-click. Pure state with an injected clock, so every
 * boundary is pinned by a spec.
 * @module @idealize/powell/client/gestures
 */
/** Thresholds, in ms and px. */
export declare const HOLD_MS = 250;
export declare const DRAG_PX = 4;
export declare const DOUBLE_MS = 300;
/** What the owl should do. */
export type GestureEffect = {
    kind: 'hold-start';
} | {
    kind: 'hold-end';
} | {
    kind: 'drag-start';
} | {
    kind: 'drag-end';
} | {
    kind: 'click';
} | {
    kind: 'double-click';
};
/** Timer seam: the real one is setTimeout. */
export interface Timers {
    set(callback: () => void, ms: number): unknown;
    clear(handle: unknown): void;
    now(): number;
}
/** Tracks one pointer through press, move and release. */
export declare class Gestures {
    private readonly emit;
    private readonly timers;
    private phase;
    private origin;
    private holdTimer;
    private lastClick;
    /**
     * @param emit - receives each gesture.
     * @param timers - the clock.
     */
    constructor(emit: (effect: GestureEffect) => void, timers?: Timers);
    down(x: number, y: number): void;
    move(x: number, y: number): void;
    up(): void;
    /** The pointer was lost (window blur, capture lost): end whatever was running. */
    cancel(): void;
    private cancelTimers;
}
//# sourceMappingURL=gestures.d.ts.map