/**
 * The owl's live view: one SSE stream from the host, whose `say` and `hush`
 * events go straight to the mouth and whose `view` events feed React.
 * @module @idealize/powell/client/store
 */
import type { PowellView } from '../types.ts';
import type { Mouth } from './voice.ts';
/** A subscribable snapshot of the host's view. */
export interface PowellStore {
    getSnapshot(): PowellView;
    subscribe(listener: () => void): () => void;
    /** Whether the stream is connected. */
    connected(): boolean;
    stop(): void;
}
/**
 * Connect to the host's stream.
 * @param mouth - plays `say` lines.
 * @returns the store.
 */
export declare function startStore(mouth: Mouth): PowellStore;
//# sourceMappingURL=store.d.ts.map