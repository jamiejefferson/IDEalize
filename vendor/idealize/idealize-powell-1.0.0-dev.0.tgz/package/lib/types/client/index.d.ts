/**
 * @idealize/powell — browser half. In the desktop shell's floating window
 * (the `dsh-desktop-mode=askbar` marker the Askbar column used; Powell
 * replaced the column on 2 Oct 2026 and kept the window, so every guard
 * that keeps that page from minting chats still holds) the owl takes the
 * root slot and the page becomes Powell. Every other window gets nothing.
 * @module @idealize/powell/client
 */
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
export { PowellRoot } from './PowellRoot.tsx';
export type { PowellRootInjected } from './PowellRoot.tsx';
export { Gestures, DOUBLE_MS, DRAG_PX, HOLD_MS } from './gestures.ts';
export type { GestureEffect, Timers } from './gestures.ts';
export { encodeWav, Mouth } from './voice.ts';
export { POSES } from './owl.ts';
/** Services the owl reads. */
export declare const inject: string[];
/**
 * Seat the owl in the floating window.
 * @param ctx - browser Cordis context.
 */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map