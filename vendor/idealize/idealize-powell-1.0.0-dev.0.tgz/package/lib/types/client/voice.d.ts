/**
 * The owl's ears and mouth.
 *
 * Ears: the microphone is read as 16 kHz PCM straight from an AudioContext
 * (no recorder container to decode afterwards). While the person holds
 * Powell, every pause after a couple of seconds of speech cuts a segment and
 * sends it for transcription at once, so on release only the last few
 * seconds are still in flight (latency plan: segmented speech-to-text).
 *
 * Mouth: a queue of sentences. A sentence that matches a cached clip plays
 * from memory with no network at all; any other sentence streams from the
 * host's speech route, and the next sentence's audio starts loading while
 * the current one plays, so there is no gap between them.
 * @module @idealize/powell/client/voice
 */
/** The rate speech-to-text receives. */
export declare const SAMPLE_RATE = 16000;
/** Why the microphone could not open. */
export declare class MicError extends Error {
    readonly refusal: 'denied' | 'no-microphone' | 'unsupported';
    constructor(refusal: 'denied' | 'no-microphone' | 'unsupported', message: string);
}
/** Little-endian 16-bit WAV around mono float samples. */
export declare function encodeWav(samples: Float32Array, rate?: number): ArrayBuffer;
/** What the host's speech-to-text answered for one segment. */
export type Heard = {
    ok: true;
    text: string;
} | {
    ok: false;
    code: string;
    error: string;
};
/**
 * Send one segment to the host.
 * @param samples - mono 16 kHz samples.
 * @returns the transcript or the failure.
 */
export declare function hear(samples: Float32Array): Promise<Heard>;
/** One listening session. */
export interface Listening {
    /** Stop and return the whole transcript (segments joined in order). */
    finish(): Promise<Heard>;
    /** Stop and throw everything away. */
    cancel(): void;
}
/** Options for {@link listen}. */
export interface ListenOptions {
    /** Microphone level, 0–1, about thirty times a second. */
    onLevel?: (level: number) => void;
    /** Hands-free: called once when the person has stopped talking. */
    onEnd?: () => void;
    /** The first block of microphone audio arrived: from here on, speech is captured. */
    onReady?: () => void;
}
/**
 * Build the audio context and load the tap now, ahead of the first press.
 * @returns the ready context.
 */
export declare function warmEars(): Promise<AudioContext>;
/**
 * Open the microphone and start listening.
 * @param options - level and end callbacks.
 * @returns the listening session.
 * @throws MicError when the microphone cannot open.
 */
export declare function listen(options?: ListenOptions): Promise<Listening>;
/** Plays Powell's lines in order, interruptibly. */
export declare class Mouth {
    private readonly clips;
    private queue;
    private current;
    private muted;
    private readonly listeners;
    /**
     * Load every acknowledgement clip into memory so it plays instantly.
     * @returns resolves once the manifest's clips are fetched (missing ones are skipped).
     */
    preload(): Promise<void>;
    /** Whether a clip is ready in memory. */
    has(clip: string): boolean;
    /** Follow speaking on/off (the owl's beak). */
    onSpeaking(listener: (speaking: boolean) => void): () => void;
    setMuted(muted: boolean): void;
    /**
     * Queue a line.
     * @param id - the line's id.
     * @param text - the words.
     * @param clip - the cached clip that says them, when one does.
     */
    say(id: string, text: string, clip?: string): void;
    /** Stop talking and drop the queue. */
    hush(): void;
    private element;
    private next;
    private emit;
}
/**
 * A short rising two-note cue: the microphone is open, speak now. Synthesised,
 * so it needs no file and plays the instant audio starts flowing.
 */
export declare function readyCue(): void;
//# sourceMappingURL=voice.d.ts.map