/**
 * Powell's whole window: the owl, the thought pill above it for typing, the
 * speech bubble for replies, and the status tag underneath (the three-part
 * rule from the Paper sketches: no coloured edges, one dark and one grey
 * button at most, red only for a problem).
 * @module @idealize/powell/client/PowellRoot
 */
import React from 'react';
import type { PowellStore } from './store.ts';
import { type Mouth } from './voice.ts';
/** What the slot hands the root. */
export interface PowellRootInjected {
    store: PowellStore;
    mouth: Mouth;
}
/**
 * Render Powell.
 * @param props - the injected store and mouth.
 * @returns the owl surface.
 */
export declare function PowellRoot({ store, mouth }: PowellRootInjected): React.JSX.Element;
//# sourceMappingURL=PowellRoot.d.ts.map