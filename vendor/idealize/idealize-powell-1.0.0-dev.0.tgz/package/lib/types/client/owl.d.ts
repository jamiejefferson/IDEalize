/**
 * Which run-cycle frames the owl shows in each pose (JJ, 2 Oct 2026: use the
 * animated frames already made). The 42 frames run side-on turn (0–6), wing
 * lift and blink (7–13), front-facing calm (14–20), blink into wing raise
 * (21–27), both wings out (28–34) and settle (35–41).
 * @module @idealize/powell/client/owl
 */
/** One pose: frames, frames per second, and whether it loops. */
export interface Pose {
    frames: readonly number[];
    fps: number;
    loop: boolean;
}
/** The pose for each thing the owl can be doing. */
export declare const POSES: {
    /** Still and front-facing; a blink plays now and then. */
    readonly idle: {
        readonly frames: readonly [16];
        readonly fps: 1;
        readonly loop: false;
    };
    readonly blink: {
        readonly frames: readonly [16, 23, 24, 23, 16];
        readonly fps: 14;
        readonly loop: false;
    };
    /** Attentive: leans in (CSS) on the front frame. */
    readonly listening: {
        readonly frames: readonly [17];
        readonly fps: 1;
        readonly loop: false;
    };
    /** A small head bob on the calm frames. */
    readonly thinking: {
        readonly frames: readonly number[];
        readonly fps: 7;
        readonly loop: true;
    };
    /** The full run-cycle while it works. */
    readonly acting: {
        readonly frames: number[];
        readonly fps: 12;
        readonly loop: true;
    };
    /** Wings out, flapping, while it is dragged (JJ: "the owl should flap when moved"). */
    readonly flap: {
        readonly frames: readonly [28, 29, 30, 31, 32, 33, 34, 33, 32, 31, 30, 29];
        readonly fps: 18;
        readonly loop: true;
    };
    /** Wings up and settle once: the work landed. */
    readonly done: {
        readonly frames: readonly number[];
        readonly fps: 16;
        readonly loop: false;
    };
    /** Holds on the front frame with the bubble up. */
    readonly waiting: {
        readonly frames: readonly [18];
        readonly fps: 1;
        readonly loop: false;
    };
    /** Eyes squeezed: something went wrong. */
    readonly problem: {
        readonly frames: readonly [12];
        readonly fps: 1;
        readonly loop: false;
    };
};
export type PoseName = keyof typeof POSES;
/**
 * Little things the owl does by itself while idle, and when the pointer
 * comes over it (JJ, 2 Oct 2026: "the owl should look more alive"). Each
 * starts and ends on the resting frame, so it slots in anywhere.
 */
export declare const AMBIENT: {
    readonly blink: {
        readonly frames: readonly [16, 23, 24, 23, 16];
        readonly fps: 14;
        readonly loop: false;
    };
    /** A glance to the side and back. */
    readonly look: {
        readonly frames: readonly [16, 15, 14, 6, 5, 4, 3, 3, 3, 3, 3, 4, 5, 6, 14, 15, 16];
        readonly fps: 12;
        readonly loop: false;
    };
    /** A slow wing stretch. */
    readonly stretch: {
        readonly frames: readonly [16, 21, 22, 25, 26, 27, 28, 29, 30, 30, 30, 29, 28, 27, 26, 25, 22, 21, 16];
        readonly fps: 12;
        readonly loop: false;
    };
    /** A small sway on its feet. */
    readonly sway: {
        readonly frames: readonly [16, 17, 18, 19, 20, 20, 19, 18, 17, 16];
        readonly fps: 9;
        readonly loop: false;
    };
    /** The pointer arrived: a quick, pleased flutter. */
    readonly perk: {
        readonly frames: readonly [16, 21, 26, 27, 28, 29, 28, 27, 26, 21, 16];
        readonly fps: 18;
        readonly loop: false;
    };
};
export type AmbientName = keyof typeof AMBIENT;
/** How often each idle move is picked; blinks are the commonest. */
export declare const AMBIENT_WEIGHTS: readonly (readonly [Exclude<AmbientName, 'perk'>, number])[];
/**
 * Pick an idle move.
 * @param roll - a number in [0, 1).
 * @returns the move.
 */
export declare function pickAmbient(roll: number): Exclude<AmbientName, 'perk'>;
//# sourceMappingURL=owl.d.ts.map