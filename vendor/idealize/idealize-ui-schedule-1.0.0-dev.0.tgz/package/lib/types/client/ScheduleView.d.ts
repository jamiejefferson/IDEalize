import type { SessionBinding } from '@deepseek-ai/dsh-client-runtime/client';
import type { PropsLocale, SnapshotSelectorHook } from '@deepseek-ai/dsh-client-ui-slots';
import type { TaskDraft, TaskView } from './schedule-model.ts';
import type { ScheduleGrain, ScheduleMode, ScheduleViewState } from './store.ts';
/** Service-side face (client/index.ts): the view's own state plus the workspace and session plumbing. */
export interface ScheduleViewInjected {
    /** The view's position: a bound selector hook over the plugin's store. */
    useSchedule: SnapshotSelectorHook<ScheduleViewState>;
    /** Navigate to a day (epoch milliseconds), or to today with null. */
    setDate: (dateMs: number | null) => void;
    /** Open the calendar, the editor, or Create-with-chat. */
    setMode: (mode: ScheduleMode) => void;
    /** Switch between the Day lane and the Week grid. */
    setGrain: (grain: ScheduleGrain) => void;
    /** Registered project folders, for the SAVE TO row and the default run folder. */
    workspaces: () => {
        name: string;
        path: string;
    }[];
    /** The current chat's working directory (the default for a new task), or undefined without one. */
    currentCwd: () => string | undefined;
    /** Create/find the workspace for a path and bind a session in it (the Create-with-chat session). */
    ensureSession: (path: string) => Promise<SessionBinding | null>;
}
/** Full Schedule view props: the wired face plus the locale seat. */
export type ScheduleViewProps = ScheduleViewInjected & PropsLocale<'idealize-schedule'>;
/**
 * Save (create or update) one task through the cron service.
 * @param draft - the task to persist.
 * @returns the saved task, or an error message.
 */
export declare function saveTask(draft: TaskDraft): Promise<{
    ok: true;
    task: TaskView;
} | {
    ok: false;
    error: string;
}>;
/**
 * Render the Schedule view.
 * @param props - the wired face and `t`.
 * @returns the view's element tree.
 */
export declare function ScheduleView(props: ScheduleViewProps): import("react").JSX.Element;
//# sourceMappingURL=ScheduleView.d.ts.map