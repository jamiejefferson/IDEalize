/**
 * The Schedule view, browser half. It provides one thing — the
 * `scheduleSection` service: the calendar component plus its wired face — so
 * the consuming surface (`@idealize/ui-bar`'s drawer pane) renders it without
 * a value import, which the client bundle purity gate forbids across plugins.
 * Same seam as `modelsSettingsSection`, `agentPresetSection` and
 * `trajectorySection` (FORK.md).
 *
 * Schedule data belongs to `@idealize/cron` and travels over its own loopback
 * routes, so this half owns no records, no ids and no permissions — it is a
 * client of that service exactly as the ring view was.
 * @module @idealize/ui-schedule/client
 */
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
import type { PropsLocale } from '@deepseek-ai/dsh-client-ui-slots';
import { ScheduleView } from './ScheduleView.tsx';
import type { ScheduleViewInjected } from './ScheduleView.tsx';
export { ScheduleView, saveTask } from './ScheduleView.tsx';
export type { ScheduleViewInjected, ScheduleViewProps } from './ScheduleView.tsx';
export { ScheduleEditor } from './ScheduleEditor.tsx';
export { ScheduleCreateChat } from './ScheduleCreateChat.tsx';
export { createScheduleStore } from './store.ts';
export type { ScheduleGrain, ScheduleMode, ScheduleStore, ScheduleViewState } from './store.ts';
export type { ScheduleKey } from './locales.ts';
export type { ParsedDraft, Schedule, ScheduleTranslate, TaskDraft, TaskView, } from './schedule-model.ts';
/** Required services: copy, session rows, and the workspace registry. */
export declare const inject: string[];
/**
 * The calendar as a service (IDEalize fork seam): Schedule left the
 * conversation view ring for a tool-rail drawer pane, and the client bundle
 * purity gate forbids cross-plugin value imports, so the consuming surface
 * takes the component and its wired face through the Context.
 */
export interface ScheduleSectionHost {
    /** The calendar component, rendered by the consuming surface. */
    Component: typeof ScheduleView;
    /**
     * Wire the calendar: the store-bound selector hook, its writers, the
     * workspace/session plumbing, and the bound translate. One calendar serves
     * every chat, so the face takes no session.
     * @returns the wired face.
     */
    face: () => ScheduleSectionFace;
}
/**
 * The wired face: every prop the calendar needs. The store-bound hook is
 * stable because the store is, so the consuming surface may call face() on
 * each render.
 */
export type ScheduleSectionFace = ScheduleViewInjected & PropsLocale<'idealize-schedule'>;
declare module '@deepseek-ai/cordis' {
    interface Context {
        scheduleSection: ScheduleSectionHost;
    }
}
/**
 * Client plugin body: register the dictionaries and publish the calendar.
 * @param ctx - client root context.
 */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map