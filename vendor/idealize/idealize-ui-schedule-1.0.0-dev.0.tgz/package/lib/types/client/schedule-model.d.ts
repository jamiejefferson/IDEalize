/**
 * Pure helpers behind the Schedule view: the cron task wire fields, the copy
 * derived from a schedule (repeat badges, sentences), the week the calendar
 * shows, and the task-draft parser the Create-with-chat state reads from an
 * assistant reply.
 * @module @idealize/ui-schedule/client/schedule-model
 */
import type { ScheduleKey } from './locales.ts';
/** Translate seat the schedule copy helpers read (the `idealize-schedule` namespace's bound `t`). */
export type ScheduleTranslate = (key: ScheduleKey, params?: Record<string, unknown>) => string;
/** Schedule union, restated from @idealize/cron's wire fields; `at` is a one-off ISO-8601 instant. */
export type Schedule = {
    kind: 'at';
    at: string;
} | {
    kind: 'every';
    seconds: number;
} | {
    kind: 'daily';
    at: string;
    timeZone: string;
} | {
    kind: 'weekly';
    at: string;
    timeZone: string;
    days: number[];
};
/** A task as `GET /idealize/cron/tasks` reports it. */
export interface TaskView {
    id: string;
    name: string;
    schedule: Schedule;
    prompt: string;
    cwd: string;
    provider?: string;
    model?: string;
    /** Raise a desktop notification at each fire. */
    remind?: boolean;
    /** The instant a one-off fired; a done task stays listed and never fires again. */
    done?: string;
    enabled: boolean;
    createdAt: string;
    nextFireAt?: string;
    running: boolean;
}
/** The editable fields of a task: an existing one (id set) or a draft. */
export interface TaskDraft {
    id?: string;
    name: string;
    schedule: Schedule;
    prompt: string;
    cwd: string;
    provider?: string;
    model?: string;
    remind?: boolean;
    done?: string;
    enabled: boolean;
}
/** Monday to Friday (0 = Sunday). */
export declare const WEEKDAYS: readonly number[];
/**
 * The short day label for a `Date.getDay()` index.
 * @param day - day index, 0 = Sunday.
 * @param t - the schedule namespace's bound translate.
 * @returns the localised short label (en "SUN" … "SAT").
 */
export declare function dayShort(day: number, t: ScheduleTranslate): string;
/**
 * The full day name for a `Date.getDay()` index.
 * @param day - day index, 0 = Sunday.
 * @param t - the schedule namespace's bound translate.
 * @returns the localised day name (en "Sunday" … "Saturday").
 */
export declare function dayName(day: number, t: ScheduleTranslate): string;
/**
 * The browser's zone, the default for new tasks.
 * @returns the IANA zone name.
 */
export declare function localTimeZone(): string;
/**
 * The uppercase badge on a task block: WEEKDAYS, TUE + THU, THURSDAY, DAILY, EVERY 30 MIN.
 * @param schedule - the task's schedule.
 * @param t - the schedule namespace's bound translate.
 * @returns the localised badge.
 */
export declare function repeatBadge(schedule: Schedule, t: ScheduleTranslate): string;
/**
 * The REPEAT row sentence: Every weekday, Every day, Tuesdays and Thursdays, Every 30 minutes.
 * @param schedule - the task's schedule.
 * @param t - the schedule namespace's bound translate.
 * @returns the localised sentence.
 */
export declare function repeatSentence(schedule: Schedule, t: ScheduleTranslate): string;
/**
 * Minutes since midnight of an `HH:mm` time.
 * @param at - the time, e.g. `"09:00"`.
 * @returns the minute count.
 */
export declare function minutesOf(at: string): number;
/**
 * The browser-local `HH:mm` of an ISO-8601 instant (a one-off's time of day).
 * @param iso - the instant.
 * @returns the zero-padded local time.
 */
export declare function localTimeOf(iso: string): string;
/**
 * `HH:mm` for minutes since midnight (clamped to the day).
 * @param minutes - minutes since midnight.
 * @returns the zero-padded time.
 */
export declare function timeOf(minutes: number): string;
/**
 * Snap minutes to the nearest step (a drag lands on the quarter hour, a tap on the half hour).
 * @param minutes - minutes since midnight.
 * @param step - the grid step in minutes.
 * @returns the snapped minutes, inside the day.
 */
export declare function snapMinutes(minutes: number, step: number): number;
/** Height of one hour in the Day lane, the wireframe's 72px row. */
export declare const HOUR_PX = 72;
/** Height of a task block in the Day lane (the wireframe's 54–62px blocks). */
export declare const BLOCK_PX = 56;
/**
 * The hour span the Day lane draws: the wireframe's 08:00–14:00 widened until
 * every timed task of the day fits, with an hour of air below the last.
 * @param minutes - the start minutes of the day's timed tasks.
 * @returns the first and last labelled hours (the last is exclusive of a row).
 */
export declare function laneHours(minutes: readonly number[]): {
    start: number;
    end: number;
};
/**
 * Lay the day's timed tasks in the lane: blocks whose starts fall inside an
 * earlier block step one column right, as the wireframe's overlapping blocks do.
 * @param tasks - the day's timed tasks, any order.
 * @param startHour - the lane's first hour.
 * @returns each task with its top (px) and column index.
 */
export declare function laneBlocks<T extends {
    schedule: Schedule;
}>(tasks: readonly T[], startHour: number): {
    task: T;
    top: number;
    column: number;
}[];
/**
 * The `HH:mm` a schedule starts at on its day: a one-off's local time, a
 * time-of-day rule's `at`, and midnight for an interval (which has no time).
 * @param schedule - the task's schedule.
 * @returns the start time.
 */
export declare function startOf(schedule: Schedule): string;
/**
 * The same schedule at another time of day; interval schedules have no time
 * and return unchanged, a one-off keeps its day and moves its clock time.
 * @param schedule - the task's schedule.
 * @param at - the new `HH:mm`.
 * @returns the rescheduled schedule.
 */
export declare function withTime(schedule: Schedule, at: string): Schedule;
/**
 * The block's detail line: "09:00 · Codex · Briefs" (time, the model or Default, the run folder).
 * @param task - the task.
 * @param t - the schedule namespace's bound translate.
 * @returns the line.
 */
export declare function detailLine(task: Pick<TaskView, 'schedule' | 'provider' | 'model' | 'cwd'>, t: ScheduleTranslate): string;
/**
 * Whether a schedule has a fire on the given local calendar day: a one-off on
 * its own day only, a weekly rule on its listed weekdays, the rest every day.
 * @param schedule - the task's schedule.
 * @param date - the local calendar day.
 * @returns true when the schedule fires that day.
 */
export declare function occursOn(schedule: Schedule, date: Date): boolean;
/**
 * The schedule a calendar tap drafts: a weekly task on the tapped day at the
 * tapped time, so the editor opens showing exactly the slot that was clicked.
 * @param day - the calendar day the tap landed on.
 * @param at - the tapped "HH:mm" (a week column's default).
 * @param timeZone - the zone stamped on the draft.
 * @returns the weekly schedule.
 */
export declare function tappedSchedule(day: Date, at: string, timeZone: string): Schedule;
/**
 * The Monday-first week containing `date`.
 * @param date - any local date in the week.
 * @returns seven local dates at midnight, Monday first.
 */
export declare function weekOf(date: Date): Date[];
/**
 * The calendar grid for a date's month: whole weeks, Monday first, so the
 * month's first and last weeks are filled out with the adjacent months' days.
 * Six rows always, so the grid does not change height as the user steps
 * through months.
 * @param date - any local date in the month.
 * @returns 42 local dates at midnight, in reading order.
 */
export declare function monthOf(date: Date): Date[];
/**
 * Whether a date falls in the same local month as another.
 * @param date - the date to test.
 * @param month - any date in the month.
 * @returns true when year and month match.
 */
export declare function inMonth(date: Date, month: Date): boolean;
/**
 * Whether two dates fall on the same local calendar day.
 * @param a - one date.
 * @param b - the other date.
 * @returns true when year, month, and day match.
 */
export declare function sameDay(a: Date, b: Date): boolean;
/**
 * "20 August 2026" in the pane's date navigator.
 * @param date - the shown day.
 * @param locale - BCP 47 tag (the dictionary's `sched.dateLocale`).
 * @returns the localised long date.
 */
export declare function longDate(date: Date, locale?: string): string;
/**
 * "September 2026" in the pane's date navigator, when the grid is a month.
 * @param date - any day in the shown month.
 * @param locale - BCP 47 tag (the dictionary's `sched.dateLocale`).
 * @returns the localised month and year.
 */
export declare function monthLabel(date: Date, locale?: string): string;
/**
 * The footer's "Next run: tomorrow at 09:00" line, from the host-computed
 * next fire for saved tasks; drafts get an approximation in the browser's
 * own clock (time-of-day rules in the browser zone).
 * @param draft - the edited task.
 * @param nextFireAt - the host-computed next fire, when the saved schedule is untouched.
 * @param now - the current time.
 * @param t - the schedule namespace's bound translate.
 * @returns the localised next-run line.
 */
export declare function nextRunLine(draft: TaskDraft, nextFireAt: string | undefined, now: Date, t: ScheduleTranslate): string;
/**
 * The last path segment, for "Save to" summaries.
 * @param path - a POSIX or Windows path, trailing separators allowed.
 * @returns the final segment, or the input when it has none.
 */
export declare function folderName(path: string): string;
/**
 * "Default" or the task's pinned model label.
 * @param draft - the provider/model half of a draft.
 * @param t - the schedule namespace's bound translate.
 * @returns the localised model label.
 */
export declare function modelLabel(draft: Pick<TaskDraft, 'provider' | 'model'>, t: ScheduleTranslate): string;
/**
 * One Create-with-chat message: the user's words first (so the session title
 * derives from them), then the seed that asks for prose plus one fenced JSON
 * task block the pane parses.
 * @param words - what the user typed.
 * @param timeZone - the zone times are read in.
 * @param cwd - the folder the task runs in.
 * @param slot - the tapped calendar slot, when the state opened from a tap; the model defaults the schedule to it.
 * @returns the message text to submit.
 */
export declare function seededMessage(words: string, timeZone: string, cwd: string, slot?: Schedule): string;
/**
 * Split one seeded user message back into the words the user typed.
 * @param text - a message `seededMessage` produced, or any other text.
 * @returns the text before the seed marker; the whole text when no marker is present.
 */
export declare function stripSeed(text: string): string;
/** A draft parsed from an assistant reply, or undefined when no valid block is present. */
export interface ParsedDraft {
    name: string;
    schedule: Schedule;
    prompt: string;
}
/**
 * Read the last fenced JSON block of an assistant reply as a task draft.
 * @param text - assistant reply text.
 * @param timeZone - zone stamped on time-of-day schedules.
 * @returns the draft, or undefined when the block is missing or invalid.
 */
export declare function parseDraft(text: string, timeZone: string): ParsedDraft | undefined;
/**
 * The reply with its fenced JSON blocks removed, for the transcript row.
 * @param text - the assistant reply text.
 * @returns the trimmed prose.
 */
export declare function replyProse(text: string): string;
//# sourceMappingURL=schedule-model.d.ts.map