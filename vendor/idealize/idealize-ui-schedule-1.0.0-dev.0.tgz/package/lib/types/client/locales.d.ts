/**
 * `idealize-schedule` namespace dictionaries: the calendar and its load
 * states (including the one-off ONCE / DONE badges), the task editor with its
 * notify row, and the Create-with-chat state.
 */
/** Simplified Chinese dictionary (the key-set source of truth). */
export declare const zh: {
    readonly 'sched.loading': "正在载入日程…";
    readonly 'sched.error.cause': "原因：{cause}";
    readonly 'sched.retry': "重试";
    readonly 'sched.title': "日程";
    readonly 'sched.subtitle': "规划并管理重复任务。";
    readonly 'sched.subtitle.drag': "拖动任务以更改其计划。";
    readonly 'sched.view.aria': "日历视图";
    readonly 'sched.view.day': "日";
    readonly 'sched.view.week': "周";
    readonly 'sched.view.month': "月";
    readonly 'sched.month.aria': "{month}，选择一天";
    readonly 'sched.month.tasks': "{count} 项";
    readonly 'sched.month.none': "无";
    readonly 'sched.allDay': "全天";
    readonly 'sched.lane.aria': "{day}的时间轴";
    readonly 'sched.lane.block': "{name}，{time}。拖动可更改时间。";
    readonly 'sched.moved': "{name} 已移至 {time}";
    readonly 'sched.new': "新任务";
    readonly 'sched.today': "今天";
    readonly 'sched.prev': "上一个";
    readonly 'sched.next': "下一个";
    readonly 'sched.error': "无法连接调度服务。";
    readonly 'sched.edit': "编辑任务";
    readonly 'sched.back': "返回日历";
    readonly 'sched.on': "开启";
    readonly 'sched.paused': "已暂停";
    readonly 'sched.enabled': "任务已启用";
    readonly 'sched.field.name': "任务名称";
    readonly 'sched.name.aria': "任务名称";
    readonly 'sched.name.placeholder': "每日产品简报";
    readonly 'sched.field.schedule': "计划";
    readonly 'sched.runat': "运行时间";
    readonly 'sched.runat.aria': "运行时间";
    readonly 'sched.timezone': "时区";
    readonly 'sched.repeat': "重复";
    readonly 'sched.repeat.aria': "重复";
    readonly 'sched.repeat.weekdays': "每个工作日";
    readonly 'sched.repeat.daily': "每天";
    readonly 'sched.repeat.custom': "指定日期";
    readonly 'sched.repeat.interval': "每 N 分钟";
    readonly 'sched.every': "每";
    readonly 'sched.minutes': "分钟";
    readonly 'sched.interval.aria': "间隔分钟数";
    readonly 'sched.field.instructions': "特别指令";
    readonly 'sched.instructions.aria': "特别指令";
    readonly 'sched.instructions.placeholder': "智能体每次运行要做什么。";
    readonly 'sched.field.deliver': "运行与交付";
    readonly 'sched.model': "模型";
    readonly 'sched.model.aria': "模型";
    readonly 'sched.model.default': "默认";
    readonly 'sched.model.defaultWith': "默认 · {model}";
    readonly 'sched.saveto': "保存到";
    readonly 'sched.saveto.empty': "选择项目文件夹";
    readonly 'sched.folder.aria': "项目文件夹";
    readonly 'sched.folder.pick': "选择项目…";
    readonly 'sched.folder.path': "文件夹路径";
    readonly 'sched.delete': "删除任务";
    readonly 'sched.delete.confirm': "确认删除";
    readonly 'sched.save': "保存更改";
    readonly 'sched.createTask': "创建任务";
    readonly 'sched.nextrun.paused': "已暂停——无下次运行";
    readonly 'sched.nextrun.today': "下次运行：今天 {time}";
    readonly 'sched.nextrun.tomorrow': "下次运行：明天 {time}";
    readonly 'sched.nextrun.day': "下次运行：{day} {time}";
    readonly 'sched.create.title': "新建定时任务";
    readonly 'sched.create.subtitle': "用自己的话描述它。";
    readonly 'sched.create.hint': "例如：“每个工作日 9 点，在 {folder} 中回顾昨天的工作并给我写一份简报。”";
    readonly 'sched.create.slot': "预定{day} {time}——可在对话中更改。";
    readonly 'sched.create.thisProject': "这个项目";
    readonly 'sched.create.times': "时间使用 {zone}。";
    readonly 'sched.create.draft': "任务草稿";
    readonly 'sched.create.edit': "编辑字段";
    readonly 'sched.create.deliver': "交付";
    readonly 'sched.create.instructions': "指令";
    readonly 'sched.create.describe': "描述任务…";
    readonly 'sched.create.change': "想改哪里…";
    readonly 'sched.create.aria': "描述任务";
    readonly 'sched.create.send': "发送";
    readonly 'sched.create.pickFolder': "请先选择项目文件夹（在其中打开一个对话）。";
    readonly 'sched.create.noChat': "无法为该文件夹启动对话。";
    readonly 'sched.day.0': "周日";
    readonly 'sched.day.1': "周一";
    readonly 'sched.day.2': "周二";
    readonly 'sched.day.3': "周三";
    readonly 'sched.day.4': "周四";
    readonly 'sched.day.5': "周五";
    readonly 'sched.day.6': "周六";
    readonly 'sched.dayname.0': "星期日";
    readonly 'sched.dayname.1': "星期一";
    readonly 'sched.dayname.2': "星期二";
    readonly 'sched.dayname.3': "星期三";
    readonly 'sched.dayname.4': "星期四";
    readonly 'sched.dayname.5': "星期五";
    readonly 'sched.dayname.6': "星期六";
    readonly 'sched.days.0': "每周日";
    readonly 'sched.days.1': "每周一";
    readonly 'sched.days.2': "每周二";
    readonly 'sched.days.3': "每周三";
    readonly 'sched.days.4': "每周四";
    readonly 'sched.days.5': "每周五";
    readonly 'sched.days.6': "每周六";
    readonly 'sched.dateLocale': "zh-CN";
    readonly 'sched.badge.daily': "每天";
    readonly 'sched.badge.weekdays': "工作日";
    readonly 'sched.badge.everyMin': "每 {n} 分钟";
    readonly 'sched.badge.everyHour': "每 1 小时";
    readonly 'sched.badge.everyHours': "每 {n} 小时";
    readonly 'sched.badge.allDay': "全天";
    readonly 'sched.badge.once': "一次";
    readonly 'sched.badge.done': "已完成";
    readonly 'sched.repeat.once': "仅一次";
    readonly 'sched.sent.once': "{date} {time}，仅一次";
    readonly 'sched.once.aria': "日期和时间";
    readonly 'sched.remind': "桌面通知";
    readonly 'sched.remind.aria': "触发时发送桌面通知";
    readonly 'sched.remind.on': "触发时通知我";
    readonly 'sched.remind.off': "不通知";
    readonly 'sched.nextrun.done': "已于 {date} {time} 触发";
    readonly 'sched.sent.hour': "每小时";
    readonly 'sched.sent.hours': "每 {n} 小时";
    readonly 'sched.sent.minutes': "每 {n} 分钟";
    readonly 'sched.sent.two': "{a}和{b}";
    readonly 'sched.sent.sep': "、";
};
/** English dictionary. */
export declare const en: Record<ScheduleKey, string>;
/** Keys of this plugin's dictionary. */
export type ScheduleKey = keyof typeof zh;
/** Dictionary namespace owned by this plugin. */
export declare const NS = "idealize-schedule";
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** The Schedule view's copy. */
        'idealize-schedule': ScheduleKey;
    }
}
//# sourceMappingURL=locales.d.ts.map