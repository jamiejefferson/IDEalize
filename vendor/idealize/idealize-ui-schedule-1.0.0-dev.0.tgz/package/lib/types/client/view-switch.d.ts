/**
 * Flipping one chat's conversation view ring onto the Schedule tab from
 * outside `ui-conversation`.
 *
 * The write resolves the per-session chat-store instance through the
 * SlotRegistry's renderer host face (`hostFace().storeOf`) — the instance the
 * rendered ring reads; `handle.create()` would mint a parallel one the ring
 * never sees. `@idealize/ui-terminal` performs the same write behind its
 * `terminalMode` service and `@idealize/ui-bar` restates it for the welcome
 * card, because the client bundle purity gate forbids importing another
 * package's value exports. If upstream exposes a public per-session store
 * resolver, this is the module to move onto it.
 * @module @idealize/ui-schedule/client/view-switch
 */
/** The view ring's chat entry id: the view a chat falls back to, and the holder of the ring's active-view store. */
export declare const CHAT_VIEW = "chat";
/** This package's ring entry id. */
export declare const SCHEDULE_VIEW = "schedule";
/** Chat-store write used by the view switch (restated from ui-conversation's action set). */
interface ChatViewActions {
    setView(view: string): void;
}
/** The renderer host face's store resolver (the framework's per-session instance cache). */
interface ErasedStoreHost {
    storeOf(entry: {
        options: {
            id?: string;
        };
        store?: unknown;
    }, scopeKey?: string): {
        actions: ChatViewActions;
    } | undefined;
}
/** Type-erased slot registry face used where the typed overloads cannot see a foreign store. */
export interface ErasedSlots {
    entries(key: string): readonly {
        options: {
            id?: string;
        };
        store?: unknown;
    }[];
    subscribe(key: string, fn: () => void): () => void;
    register(options: Record<string, unknown>, component: unknown): () => void;
    inject(key: string, fn: () => () => void): void;
    /** SlotRegistry's renderer host face (TS-private; no public seam resolves a per-session store instance). */
    hostFace(): ErasedStoreHost;
}
/**
 * Switch one chat's conversation ring onto the Schedule view.
 * @param slots - the erased slot registry.
 * @param sessionId - the chat whose ring flips.
 * @returns whether the switch was written (false until the chat entry exists).
 */
export declare function openScheduleView(slots: ErasedSlots, sessionId: string): boolean;
export {};
//# sourceMappingURL=view-switch.d.ts.map