/**
 * The bridge's event buffer: a capped in-memory ring of notification events
 * with live subscriber fanout. Pure state — the service owns wiring and HTTP.
 */
/** What a bridge event is about; the shell maps kinds to badges and toasts. */
export type BridgeEventKind = 'cron-run' | 'cron-changed' | 'agent-finished' | 'agent-error' | 'approval-pending' | 'approval-decided' | 'mail' | 'notify' | 'focus' | 'reveal' | 'open-studio' | 'new-chat' | 'open-folder' | 'attention';
/** One notification the host wants a shell (desktop or browser) to surface. */
export interface BridgeEvent {
    /** Monotonic per-process sequence; `since` cursors compare against it. */
    seq: number;
    /** ISO-8601 instant the event was recorded. */
    at: string;
    kind: BridgeEventKind;
    /** Short human line, e.g. `Nightly digest — ok in 2.1s`. */
    title: string;
    /** Longer human detail; empty when the title says it all. */
    body: string;
    /** The session the event belongs to, when it has one. */
    sessionId?: string;
    /** The project the Askbar showed when it asked for the Studio (context only: the Studio spans every project). */
    project?: string;
    /** The Studio event an `attention` alert was raised for; opening the alert opens this event. */
    studioEvent?: string;
    /** On `agent-finished`: the turn the agent stopped on ended in an error, so no reply is waiting. */
    failed?: boolean;
    /** The absolute folder an `open-folder` event asks the shell to register as a project and open. */
    folder?: string;
}
/** The notification feed's retained tail (200 events) with live fan-out to subscribers. */
export declare class BridgeBuffer {
    private events;
    private nextSeq;
    private subscribers;
    /**
     * Record one event and fan it out to live subscribers.
     * @param input - the event without its `seq` and `at`, which this call assigns.
     * @returns the stored event; a throwing subscriber does not affect it or the others.
     */
    push(input: Omit<BridgeEvent, 'seq' | 'at'>): BridgeEvent;
    /**
     * Events after a cursor, oldest first.
     * @param sinceSeq - the last sequence the caller has seen; 0 for everything retained.
     * @returns the retained events with a greater `seq`.
     */
    recent(sinceSeq: number): BridgeEvent[];
    /**
     * Attach a live listener.
     * @param listener - called synchronously with each pushed event.
     * @returns the detach function.
     */
    subscribe(listener: (event: BridgeEvent) => void): () => void;
}
//# sourceMappingURL=buffer.d.ts.map