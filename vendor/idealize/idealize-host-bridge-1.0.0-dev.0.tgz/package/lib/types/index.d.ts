/**
 * The IDEalize host bridge: `ctx.idealizeBridge`, one place where the host
 * turns "something a person cares about happened" into a feed a shell can
 * surface as toasts and badges — the Electron desktop app and the plain
 * browser tab read the same feed.
 *
 * Sources: `idealize/cron-run` and `idealize/cron-changed` (from
 * @idealize/cron; the latter tells the Schedule pane to refetch), `agent/status` idle
 * transitions after a running spell, `agent/error`, and the approval
 * waterfall observed pass-through (pending + decided, never deciding).
 * The command surface (@idealize/comm) pushes `mail`, `notify`, `focus`, and
 * `reveal` events into the same buffer; the Askbar (@idealize/askbar) pushes
 * `open-studio` when its Group chat button asks the main window for a
 * project's Studio chat.
 *
 * HTTP surface (loopback-fenced, read-only):
 * - GET /idealize/events/recent?since=<seq> — retained events after the cursor.
 * - GET /idealize/events/stream — SSE; one `data:` JSON line per event.
 */
import { Context, Service } from '@deepseek-ai/cordis';
import { BridgeBuffer } from './buffer.ts';
export { BridgeBuffer } from './buffer.ts';
export type { BridgeEvent, BridgeEventKind } from './buffer.ts';
declare module '@deepseek-ai/cordis' {
    interface Context {
        idealizeBridge: IdealizeBridge;
    }
}
/** The notification feed behind `ctx.idealizeBridge`: a capped buffer plus its HTTP surface. */
export declare class IdealizeBridge extends Service {
    /** The retained feed the HTTP routes read and the producers push into. */
    readonly buffer: BridgeBuffer;
    /** Agents currently in a running spell; an idle flip for one is a finish. */
    private readonly runningAgents;
    constructor(ctx: Context);
}
export declare function apply(ctx: Context): void;
//# sourceMappingURL=index.d.ts.map