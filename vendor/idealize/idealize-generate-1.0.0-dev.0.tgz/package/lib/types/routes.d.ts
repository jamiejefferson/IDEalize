/**
 * The `/idealize/brains/media` route: GET lists every media preset with its
 * stored model choice, compatibility-filtered candidates, and availability;
 * POST stores (or clears) one preset's choice in the `idealize-activity-pills`
 * settings section's `models` map, beside the activity agents' choices.
 * The `/idealize/brains/media-keys` route: GET lists the backends that take a
 * key from the person with whether one is stored; POST stores (or, with an
 * empty key, removes) one backend's key through `ctx.credentials` and
 * refreshes that backend's catalogue. The `/idealize/generate/inputs` route:
 * GET with `?space=` answers the space's chosen media model and the inputs a
 * person may choose for it, read from the model's own schema. Loopback-fenced;
 * the mutations demand the `x-idealize-auth` header.
 * @module @idealize/generate/routes
 */
import type { Context } from '@deepseek-ai/cordis';
import type { GenerationInputQueries, GenerationKeyQueries, GenerationQueries } from './media.ts';
/**
 * Mount the media preset route and the inputs route while a web server and
 * settings service are composed beside the generation service.
 * @param ctx - the generation service's plugin context.
 * @param runtime - the catalogue, key and input queries the routes read.
 */
export declare function installMediaRoutes(ctx: Context, runtime: GenerationQueries & GenerationKeyQueries & GenerationInputQueries): void;
//# sourceMappingURL=routes.d.ts.map