/**
 * Service Definition for the generation capability seam (`ctx.generation`):
 * a registry of generation backends plus compatibility-checked dispatch.
 * Backends register with `register()` (duplicate ids are rejected; the
 * returned disposer removes the backend); consumers query the merged
 * catalogue, ask availability for a requirement set, and run generations
 * routed to the chosen backend.
 * @module @idealize/generate/service
 */
import { Context, Service } from '@deepseek-ai/cordis';
import type { BackendCredentialState, CapabilityRequirement, GenCatalogEntry, GenerationAvailability, GenerationBackend, GenerationProgressSink, GenerationRequest, GenerationResult, GenInputField, GenModelRef } from './types.ts';
/** Version carried by descriptors, requests, and results this seam exchanges. */
export declare const GENERATION_SCHEMA_VERSION = 1;
declare module '@deepseek-ai/cordis' {
    interface Context {
        generation: GenerationRuntime;
    }
}
/**
 * The generation service. Registered as `ctx.generation` (one instance per
 * context). Also mounts the `/idealize/brains/media` preset routes and the
 * `/idealize/generate/inputs` route while a web server and settings service
 * are composed beside it.
 */
export declare class GenerationRuntime extends Service {
    private readonly backendsById;
    constructor(ctx: Context);
    /**
     * Register a generation backend. Throws if its id is already registered —
     * a duplicate is a composition bug, not a task failure. Returns a disposer;
     * disposed with the calling fiber.
     * @param backend - the backend; its `id` is the registry key.
     * @returns the disposer that unregisters the backend.
     */
    register(backend: GenerationBackend): () => void;
    /**
     * The registered backend ids.
     * @returns the ids in registration order.
     */
    backends(): readonly string[];
    /**
     * The backends that take a key from the person, with whether one is stored
     * and what each serves: a backend is connected while none of its descriptors
     * reads `no-credential`, and its artefacts are the ones its descriptors name,
     * which a backend states before it has fetched a single model.
     * @returns one row per backend declaring a {@link BackendCredential}, in registration order.
     */
    credentials(): BackendCredentialState[];
    /**
     * Re-fetch one backend's catalogue after its key changed.
     * @param id - the backend id.
     * @returns false when no backend has that id; true once its refresh (if any) settled.
     */
    refreshBackend(id: string): Promise<boolean>;
    /**
     * The inputs a person may choose for one model before generating, from its
     * backend's {@link GenerationBackend.inputs}.
     * @param model - the backend and model id.
     * @returns the fields; empty when no backend has that id or the backend publishes no schema. Rejects when the backend's fetch fails.
     */
    inputs(model: GenModelRef): Promise<readonly GenInputField[]>;
    /**
     * The merged catalogue: every model each registered backend publishes.
     * @returns one entry per (backend, model), in registration order.
     */
    catalog(): GenCatalogEntry[];
    /**
     * Catalogue rows whose model satisfies every requirement in the set
     * (artefact matches and required input modalities are a subset).
     * @param requirements - a preset's or task's `requiredCapabilities`.
     * @returns the compatible entries, in catalogue order.
     */
    compatible(requirements: readonly CapabilityRequirement[]): GenCatalogEntry[];
    /**
     * Queryable availability for a requirement set: available with the match
     * counts, or unavailable with the reason and a recovery action.
     * @param requirements - a preset's or task's `requiredCapabilities`.
     * @returns the availability verdict.
     */
    availability(requirements: readonly CapabilityRequirement[]): GenerationAvailability;
    /**
     * Run one generation on the request's chosen backend and model. The model
     * must exist in that backend's catalogue and satisfy the request's required
     * capabilities. Backend failures that are not already GenerationErrors are
     * wrapped as `PROVIDER_ERROR` with the cause chained.
     * @param request - the task request; `model` names the backend and model id.
     * @param onProgress - optional progress sink; omitted reports are dropped.
     * @param signal - optional cancellation signal forwarded to the backend.
     * @returns the completed result.
     */
    generate(request: GenerationRequest, onProgress?: GenerationProgressSink, signal?: AbortSignal): Promise<GenerationResult>;
}
export default GenerationRuntime;
//# sourceMappingURL=service.d.ts.map