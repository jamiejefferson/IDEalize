/**
 * The pane's message strip (A4, FR-P0-09/27, group-chat form): one input
 * whose leading `@name` token addresses a participant, resolved against the
 * live roster at send time; the message delivers to that one participant.
 * Without a leading `@` the send is a group post — recorded on the project
 * timeline for everyone, invoking nobody. An unresolvable `@token` sends
 * nothing and names who is present.
 *
 * The draft lives in the pane's store (the drawer unmounts a closed pane);
 * the sending flag and the notice are component state and reset with it.
 * @module @idealize/ui-studio/client/StudioComposer
 */
import type { StudioTranslate } from './studio-model.ts';
export interface StudioComposerProps {
    /** The project the message belongs to. */
    project: string;
    /** The store-held draft (survives the drawer's unmounts). */
    draft: string;
    /** Write the draft back to the store. */
    setDraft: (text: string) => void;
    /** Refresh the pane after a landed send, so the row appears at once. */
    onSent: () => void;
    t: StudioTranslate;
}
/**
 * Render the addressing composer.
 * @param props - the project, the store-held draft, and the send plumbing.
 * @returns the composer strip.
 */
export declare function StudioComposer({ project, draft, setDraft, onSent, t }: StudioComposerProps): import("react").JSX.Element;
//# sourceMappingURL=StudioComposer.d.ts.map