/**
 * The Studio view: every project's coordination at a glance (JJ, 3 Sep 2026:
 * "the studio is for all projects"). One section per project over its folded
 * state — the coordinator's synthesis, the tasks holding unresolved attention,
 * every task, each participant's work view — then one timeline merged across
 * projects, each row naming its project and each addressed row offering the
 * way back to its source chat.
 *
 * Reading the Studio is what marks it read: while the view is mounted it
 * moves each project's read position to the newest event it shows, and rows
 * past the stored position carry `data-studio-unread`. An alert the person
 * opened names its event, and the view lands on that row (`data-studio-focused`)
 * showing the request's recorded resolution — an answered request offers
 * nothing to answer again.
 *
 * The chat's ordinary composer overlays the view's foot (the
 * `data-conversation-composer-overlay` contract ui-conversation offers a view
 * that scrolls itself, as Trajectory does): a leading `@name` reaches that
 * participant, anything else is a group post on every project; the host takes
 * the message before any model runs.
 *
 * Pure over the injected face: state arrives through the `useStudio` hook,
 * refresh through `sync`, and navigation through `openThread`. The component
 * polls while mounted; the store keeps the view across unmounts.
 * @module @idealize/ui-studio/client/StudioView
 */
import type { StudioTranslate } from './studio-model.ts';
import type { StudioViewState } from './store.ts';
/** The wiring the view's plugin supplies (`studioSection.face()`). */
export interface StudioViewInjected {
    /** Selector hook over the Studio store. */
    useStudio: <T>(selector: (state: StudioViewState) => T) => T;
    /** Read the overview; see the store. */
    sync: () => Promise<void>;
    /** Open a participant's chat on the main surface, aimed at an instant when given (timeline source links). */
    openThread: (sessionId: string, at?: string) => void;
    /** Take the Studio event an opened alert asked the view to land on. */
    takeFocus: () => string | null;
    /**
     * Selector hook over the participant roster: session id to agent name. The
     * timeline stores authors as session ids, which is what an id is for, and
     * every row read as `session-11d20279-7215-…` until this resolved them
     * (JJ, 11 Sep 2026: "the studio chat view is broken").
     */
    useNames: <T>(selector: (names: Record<string, string>) => T) => T;
    /**
     * Put `@name ` in the composer below, so a reference in the timeline is the
     * start of a reply rather than a label (JJ, 11 Sep 2026: "references to
     * agents should use the @ feature").
     */
    address: (name: string) => void;
    /** Record that the person has seen a project's timeline up to `seq`. */
    markRead: (project: string, seq: number) => void;
}
/** Everything the component renders from. */
export type StudioViewProps = StudioViewInjected & {
    t: StudioTranslate;
};
/**
 * Render the Studio view.
 * @param props - the wired face plus the bound translate.
 * @returns the view's element tree.
 */
export declare function StudioView({ useStudio, sync, openThread, takeFocus, markRead, useNames, address, t }: StudioViewProps): import("react").JSX.Element;
//# sourceMappingURL=StudioView.d.ts.map