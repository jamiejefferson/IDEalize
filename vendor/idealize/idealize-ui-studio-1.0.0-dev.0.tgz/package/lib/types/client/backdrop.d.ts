/**
 * The Studio's backdrop (appearance `studio-backdrop.ts`): the resolved paint
 * the appearance panel's Studio tab sets, held here for the view, and the
 * layers that draw it. The plugin body pushes each new paint through
 * {@link applyStudioBackdrop}; without the appearance service the paint stays
 * undefined and the Studio sits on the app theme.
 * @module @idealize/ui-studio/client/backdrop
 */
import type { StudioBackdropPaint } from '@idealize/appearance/client';
/** Set on the page root while a backdrop is drawn, so a view outside this package can style itself for it. */
export declare const BACKDROP_ATTRIBUTE = "data-idealize-backdrop";
/**
 * Take the backdrop to draw. Its text and panel values go on the page root as
 * custom properties, with {@link BACKDROP_ATTRIBUTE} beside them, because the
 * composer card sits outside the view and the media Studio chat
 * (`@idealize/ui-gallery`) draws the same backdrop from its own package.
 * @param next - the resolved paint, or undefined to return to the app theme.
 */
export declare function applyStudioBackdrop(next: StudioBackdropPaint | undefined): void;
/**
 * The backdrop the Studio view draws on.
 * @returns the current paint, or undefined on the app theme.
 */
export declare function useStudioBackdrop(): StudioBackdropPaint | undefined;
/**
 * The backdrop's layers, behind the Studio's content: the lamp's pool, the
 * shade and the floor, the corner falloff, then the canvas clouding and the
 * grain over all of it. The stack carries the wall colour itself: it is its
 * own stacking context, and the clouding and grain blend with what is inside it.
 * @param props - the resolved paint.
 * @returns the layer stack.
 */
export declare function StudioBackdrop({ paint }: {
    paint: StudioBackdropPaint;
}): import("react").JSX.Element;
/**
 * The current backdrop's layers, or nothing on the app theme. This is the
 * `studioBackdrop` service's component: a view in another package seats it
 * behind its own content and needs no paint of its own.
 * @returns the layer stack, or null.
 */
export declare function StudioBackdropLayers(): import("react").JSX.Element | null;
//# sourceMappingURL=backdrop.d.ts.map