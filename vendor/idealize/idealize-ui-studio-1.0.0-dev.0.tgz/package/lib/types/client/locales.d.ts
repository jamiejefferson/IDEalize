/**
 * `idealize-studio` namespace dictionaries: the coordination pane's header,
 * its load states and the one line under the owl on an empty Studio, the
 * synthesis card, the attention and task lists, the agents row, and the
 * timeline with each request's recorded resolution.
 */
/** Simplified Chinese dictionary (the key-set source of truth). */
export declare const zh: {
    'studio.title': string;
    'studio.loading': string;
    'studio.error.cause': string;
    'studio.retry': string;
    'studio.empty': string;
    'studio.synthesis.title': string;
    'studio.synthesis.stale': string;
    'studio.synthesis.none': string;
    'studio.synthesis.at': string;
    'studio.attention.title': string;
    'studio.attention.none': string;
    'studio.attention.for': string;
    'studio.tasks.title': string;
    'studio.tasks.none': string;
    'studio.agents.title': string;
    'studio.agents.queued': string;
    'studio.agents.idle': string;
    'studio.agents.finished': string;
    'studio.timeline.title': string;
    'studio.openThread': string;
    'studio.address': string;
    'studio.author.unknown': string;
    'studio.request.open': string;
    'studio.request.answered': string;
    'studio.presence.reachable': string;
    'studio.presence.unreachable': string;
    'studio.state.queued': string;
    'studio.state.working': string;
    'studio.state.waiting': string;
    'studio.state.paused': string;
    'studio.state.done': string;
    'studio.state.failed': string;
    'studio.state.cancelled': string;
    'studio.attn.needs-input': string;
    'studio.attn.needs-action': string;
    'studio.attn.blocked': string;
    'studio.attn.completion': string;
    'studio.attn.failure': string;
    'studio.attn.handoff-ready': string;
    'studio.kind.message': string;
    'studio.kind.assignment': string;
    'studio.kind.task-update': string;
    'studio.kind.request': string;
    'studio.kind.decision': string;
    'studio.kind.handoff': string;
    'studio.kind.delivery': string;
    'studio.kind.synthesis': string;
    'studio.kind.system': string;
    'studio.agents.source': string;
};
/** One key of the `idealize-studio` dictionary. */
export type StudioKey = keyof typeof zh;
/** English dictionary; keys mirror {@link zh} exactly. */
export declare const en: Record<StudioKey, string>;
/** The locale registry namespace this package owns. */
export declare const NS = "idealize-studio";
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** The Studio view's copy. */
        'idealize-studio': StudioKey;
    }
}
//# sourceMappingURL=locales.d.ts.map