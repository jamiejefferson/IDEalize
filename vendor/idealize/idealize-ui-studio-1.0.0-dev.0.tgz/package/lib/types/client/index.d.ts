/**
 * The Studio view, browser half. Three registrations over one store:
 *
 * - the `studio` entry in the conversation view ring: the Studio chat (a chat
 *   in the `studio` space, opened from the pinned Studio card) renders every
 *   project's coordination full-height over the ordinary composer;
 * - an `@` source, "Agents", for the composer's trigger menu: every named chat
 *   across every project, inserting `@Name `, so an address in the Studio
 *   chat autocompletes (JJ, 3 Sep 2026);
 * - the `studioSection` service — the view component, its wired face and the
 *   store — so `@idealize/ui-bar`'s pinned card reads the same state without
 *   a value import, which the client bundle purity gate forbids. Same seam as
 *   `scheduleSection` and `trajectorySection` (FORK.md).
 *
 * Studio data belongs to `@idealize/studio` and travels over its own loopback
 * routes, so this half owns no records, no ids and no permissions.
 * @module @idealize/ui-studio/client
 */
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
import type { PropsLocale } from '@deepseek-ai/dsh-client-ui-slots';
import { StudioView } from './StudioView.tsx';
import type { StudioViewInjected } from './StudioView.tsx';
import type { StudioStore } from './store.ts';
/** The ring entry id; equals the `studio` space id, which is how the ring is seeded. */
export declare const STUDIO_VIEW = "studio";
export { StudioView } from './StudioView.tsx';
/** What the name projection reads off a session-list snapshot. */
interface NamedSessions {
    byId: Record<string, {
        projectionValues?: {
            agentName?: {
                name?: string | undefined;
            } | undefined;
        } | undefined;
    }>;
}
/**
 * Build the session-id-to-agent-name projection. It returns the previous map,
 * by reference, while the names are shallow-equal (same ids, same names), so a
 * selector over it holds still across session updates that rename nobody.
 * @returns the projection from a session-list snapshot to its name map.
 */
export declare function createNameProjection(): (snapshot: NamedSessions) => Record<string, string>;
export type { StudioViewInjected, StudioViewProps } from './StudioView.tsx';
export { createStudioStore } from './store.ts';
export type { StudioStore, StudioViewState } from './store.ts';
export type { StudioKey } from './locales.ts';
export type { AgentViewRow, DeliveryState, EventRow, HandoffRow, OverviewResponse, ProjectView, StateResponse, StudioPresence, StudioTranslate, SynthesisRow, TaskAttention, TaskExecutionState, TaskRow, TimelineResponse, } from './studio-model.ts';
/**
 * Required services: the slot registry (the ring entry), copy, the session
 * rows (the `@` roster + navigation), the chat surface the reveal targets,
 * and the composer's trigger pipeline.
 */
export declare const inject: string[];
/**
 * The Studio view as a service (IDEalize fork seam): the pinned Studio card in
 * `@idealize/ui-bar` reads the project state through it, and the client bundle
 * purity gate forbids cross-plugin value imports, so the consumer takes the
 * component, its wired face and the store through the Context.
 */
export interface StudioSectionHost {
    /** The view component, rendered by the consuming surface. */
    Component: typeof StudioView;
    /**
     * Wire the view: the store-bound selector hook, sync, source navigation,
     * the read-position and focus writes, and the bound translate. One store
     * serves the one Studio.
     * @returns the wired face.
     */
    face: () => StudioSectionFace;
    /** The shared store, so a consumer can poll without mounting the view. */
    store: StudioStore;
}
/** The wired face: every prop the pane needs beyond React's own. */
export type StudioSectionFace = StudioViewInjected & PropsLocale<'idealize-studio'>;
declare module '@deepseek-ai/cordis' {
    interface Context {
        studioSection: StudioSectionHost;
    }
}
/**
 * Client plugin body: register the dictionaries, the ring entry and the service.
 * @param ctx - client root context.
 */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map