/**
 * The Studio view's state, held outside React because leaving the Studio chat
 * unmounts the view: coming back must land on the same state without a blank
 * flash, and an in-flight sync must not write over a newer one.
 *
 * The store is created once per plugin fiber. Sync reads two loopback
 * routes: `GET /idealize/studio/overview` (every stored project's folded
 * state — the fold is the authority — and its recent timeline) and
 * `GET /idealize/notify/attention` (where the person has read to, and what
 * became of each alert). The Studio spans every project (JJ, 3 Sep 2026), so
 * there is no project to select.
 *
 * Read position is the only thing this store writes, and it writes it to
 * `@idealize/notify`: viewing the Studio is what marks its events read.
 * Nothing here resolves a request — that is the fold's record (FR-P0-19).
 * @module @idealize/ui-studio/client/store
 */
import { type SnapshotStore } from '@deepseek-ai/dsh-client-runtime/client';
import type { ProjectView } from './studio-model.ts';
/** The Studio's view: every project's folded state and recent timeline. */
export interface StudioViewState {
    /** Every project with a timeline, in path order; empty before the first read or while nothing is recorded. */
    projects: ProjectView[];
    /** True from mount until the first settle. */
    loading: boolean;
    /** True once a read has succeeded; the card's presence dot reads it. */
    loaded: boolean;
    /** The last sync failure, or null; stale data stays visible under it. */
    error: string | null;
    /** Newest seq the person has read, per project folder; a project absent here is wholly unread. */
    read: Record<string, number>;
    /** A Studio event the view should land on, until the view takes it. */
    focus: string | null;
}
/** The view state plus its complete write set. */
export interface StudioStore {
    /** The observable state (arrives at the component as the `useStudio` hook). */
    state: SnapshotStore<StudioViewState>;
    /**
     * Read the overview and the attention ledger. Concurrent calls settle
     * newest-wins; a superseded response is dropped.
     */
    sync: () => Promise<void>;
    /**
     * Land the view on one Studio event (an opened alert names it). The view
     * takes it on its next render.
     */
    focus: (studioEvent: string) => void;
    /** Take the pending focus target, leaving none behind. */
    takeFocus: () => string | null;
    /**
     * Record that the person has seen a project's timeline up to `seq`. A
     * position never moves backwards, in the store or on the host.
     */
    markRead: (project: string, seq: number) => Promise<void>;
}
/**
 * Create the Studio store.
 * @returns the store: nothing loaded.
 */
export declare function createStudioStore(): StudioStore;
//# sourceMappingURL=store.d.ts.map