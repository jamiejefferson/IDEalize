/**
 * @idealize/studio — the Studio event contract's host half: `ctx.idealizeStudio`
 * over the durable per-project timeline, the deterministic task fold, and the
 * loopback routes the coordination surfaces read and write.
 *
 * HTTP: `GET /idealize/studio/timeline?project=<folder>&since=<seq>` serves a
 * project's events after a cursor; `GET /idealize/studio/state?project=<folder>`
 * serves the folded tasks and per-agent views; `GET /idealize/studio/overview`
 * serves every stored project's state and recent timeline in one read (the
 * Studio spans every project, JJ 3 Sep 2026); `POST /idealize/studio/event`
 * records one event (loopback + `x-idealize-auth: 1`). Reads are loopback-only.
 *
 * The Studio chat (a chat in the `studio` space) posts through the ordinary
 * composer: `agent/pre-step` takes the user's message before any model runs,
 * delivers a leading `@name` to that participant or records the rest as a
 * group post on every project, and rejects the step.
 *
 * @module @idealize/studio
 */
import { Context, Service } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import type { StudioEvent, StudioEventInput } from './events.ts';
import type { DeliveryState, StudioState } from './fold.ts';
import { StudioStore } from './store.ts';
import type { StudioAppendResult } from './store.ts';
export { STUDIO_EVENT_KINDS, StudioEventId, StudioTaskId, studioEventInputSchema, studioEventSchema } from './events.ts';
export type { StudioEvent, StudioEventInput, StudioEventKind, StudioEventSource } from './events.ts';
export { foldStudioState } from './fold.ts';
export type { DeliveryState, StudioAgentView, StudioHandoff, StudioState, StudioSynthesis, StudioTask, TaskAttention, TaskExecutionState } from './fold.ts';
export { projectKey, StudioStore, studioRootPath } from './store.ts';
export type { StudioAppendResult } from './store.ts';
declare module '@deepseek-ai/cordis' {
    interface Context {
        idealizeStudio: IdealizeStudio;
    }
    interface Events {
        /**
         * A Studio event committed to its project's timeline; announced after the
         * append is on disk, never for a suppressed duplicate.
         * @mode emit
         * @param event - the recorded event, with its assigned id, seq and time.
         */
        'idealize/studio-event'(event: StudioEvent): void;
    }
}
/** Timeline paths. */
export declare const TIMELINE_PATH = "/idealize/studio/timeline";
/** Folded-state path. */
export declare const STATE_PATH = "/idealize/studio/state";
/** Event submission path. */
export declare const EVENT_PATH = "/idealize/studio/event";
/** Addressed-delivery path. */
export declare const DELIVER_PATH = "/idealize/studio/deliver";
/** Every project's state and recent timeline in one read. */
export declare const OVERVIEW_PATH = "/idealize/studio/overview";
/** One project's slice of the overview. */
export interface StudioOverviewProject {
    /** The resolved project folder. */
    project: string;
    /** The newest recorded seq. */
    lastSeq: number;
    /** The folded state with runtime presence. */
    state: StudioState & {
        presence: Record<string, StudioPresence>;
    };
    /** The most recent events, oldest first, at most {@link OVERVIEW_RECENT}. */
    recent: StudioEvent[];
}
/**
 * The task-update subtypes that end a task, and how the group chat says so.
 * A subtype absent here left the task open, and an open task is not news.
 * Exported so every surface that reports an ending (the group chat, the
 * Telegram remote) agrees on which subtypes end a task.
 */
export declare const ENDING_WORDS: Readonly<Record<string, string | undefined>>;
/**
 * The Studio's own timeline key. Every other timeline is keyed by a resolved
 * project folder, which is always absolute, so this bare word can never
 * collide with one. The Studio coordinator's conversation with the user lives
 * here rather than on any project's timeline.
 */
export declare const STUDIO_PROJECT = "studio";
/** Where a Studio-chat post landed. */
export type StudioChatPost = {
    kind: 'delivered';
    target: string;
    project: string;
    delivery: DeliveryState;
} | {
    kind: 'no-coordinator';
    reason: string;
} | {
    kind: 'unresolved';
    token: string;
    names: string[];
};
/**
 * FR-P0-09 in its group-chat form (JJ, 1 Sep): an addressed message invokes
 * exactly one participant, and only deliver invokes — the event route and
 * {@link IdealizeStudio.record} refuse an addressed `message` with this rule
 * so no producer can put an invocation in the timeline that never reached
 * anyone. An unaddressed `message` is a group post: recorded on the timeline
 * for everyone, invoking nobody, through the event route like any other
 * event. The deliver route refuses the unaddressed form with the same rule,
 * so the choice between posting and invoking stays the producer's.
 */
export declare const MESSAGE_ROUTE_RULE = "an addressed message goes through POST /idealize/studio/deliver and invokes exactly one participant; an unaddressed message is a group post and goes through POST /idealize/studio/event";
/** Runtime presence: whether a participant's session can take a delivery now. */
export type StudioPresence = 'reachable' | 'unreachable';
/** A participant the Studio chat can address: comm's roster row, as read here. */
interface Participant {
    id: string;
    name: string;
    title: string;
    project: string | undefined;
}
/**
 * Resolve a leading `@` address against the roster: the LONGEST name, title
 * or session id that prefixes the text after `@` wins (agent names are
 * two-word pairs, so a single-token parse would truncate most of them), and
 * the message is what follows. Two participants tying on the same longest
 * key is ambiguous and resolves to nothing.
 * @param rest - the text after the leading `@`.
 * @param participants - the roster.
 * @returns the addressed participant and the body, or null.
 */
export declare function resolveAddress(rest: string, participants: readonly Participant[]): {
    target: Participant;
    body: string;
} | null;
/** The Studio service: record, read and fold one project's coordination timeline. */
export declare class IdealizeStudio extends Service {
    private readonly store;
    /** The last fold per project, and the newest seq it folded up to. */
    private readonly folds;
    private readonly deliveryExpiryMs;
    constructor(ctx: Context, options: {
        store: StudioStore;
        deliveryExpiryHours?: number;
    });
    /**
     * Record one event and announce it. A duplicate `messageId` returns the
     * recorded event, writes nothing, and announces nothing.
     * @param input - the validated submission, its project already resolved.
     * @returns the recorded (or already-recorded) event.
     */
    record(input: StudioEventInput): Promise<StudioAppendResult>;
    /** Append and announce without the message-routing check: deliver's own path. */
    private commit;
    /**
     * Post the group-chat line for a task that has just ended.
     *
     * A `task-update` moves the fold, and the surfaces that read the fold show
     * it — but the group chat reads the timeline as conversation, so a task
     * ending left the chat silent and the person had to open the Studio to find
     * out (JJ, 10 Sep 2026). The line carries the outcome the agent gave and
     * names the task's goal, so the chat reads as the agents reporting in.
     * @param event - the event just appended.
     */
    private sayItEnded;
    /**
     * A project's events after a cursor, oldest first.
     * @param project - the resolved project folder.
     * @param since - return events with `seq` greater than this; 0 for all.
     * @returns the retained events after the cursor.
     */
    timeline(project: string, since?: number): Promise<StudioEvent[]>;
    /**
     * The folded project state.
     * @param project - the resolved project folder.
     * @returns tasks in creation order plus per-owner work views.
     */
    state(project: string): Promise<StudioState>;
    /**
     * Runtime presence for every participant the folded state names as a task
     * owner. In-process, a participant is reachable exactly while a live root
     * agent runs its session; there is no heartbeat to expire, so the answer is
     * current by construction. Non-session participants (`user`) read as
     * unreachable — the surface decides how to render them.
     * @param state - the folded state whose agents are keyed.
     * @returns presence per participant key.
     */
    presenceOf(state: StudioState): Record<string, StudioPresence>;
    /**
     * Record one addressed message and attempt its delivery into the target's
     * mailbox. One logical message: a repeated `messageId` never records a
     * second message event — a retry re-attempts a still-queued delivery and
     * returns the recorded state once it is delivered or acknowledged.
     * @param input - the validated submission; `target` names the recipient.
     * @returns the message event, whether it already existed, and its delivery state.
     */
    deliver(input: StudioEventInput & {
        target: string;
    }): Promise<{
        event: StudioEvent;
        duplicate: boolean;
        delivery: DeliveryState;
    }>;
    /** The composed messaging service, when one is mounted. */
    private comm;
    /** One mailbox attempt through the composed messaging service, when there is one. */
    private attempt;
    /** Append one delivery-state record naming its message event. */
    private deliveryRecord;
    /**
     * Every stored project's folded state, presence and recent timeline: the
     * Studio's one read across projects.
     * @returns the projects in path order.
     */
    overview(): Promise<StudioOverviewProject[]>;
    /** Every participant comm lists, with the project each works in. */
    private participants;
    /**
     * The one Studio coordinator's session id, starting or resuming it when none is running.
     *
     * It is found by its role rather than by a folder: every other coordinator
     * runs one project and is found by that project, and this one runs the
     * Studio, which spans them all.
     * @returns the session id, or undefined when no mailbox half is composed or the start failed.
     */
    private studioCoordinator;
    /**
     * Post one message from the Studio chat. A leading `@name` delivers to that
     * participant on its own project's timeline. Anything else goes to the one
     * Studio coordinator, on the Studio's own timeline.
     *
     * An untagged post used to be recorded on every project the Studio watches,
     * which put one typed line on every timeline and woke every project's
     * coordinator at once (JJ, 11 Sep 2026: "its literally posting to all the
     * agents! that's not right"). The Studio has an agent of its own now; it
     * reads the line and works through the project coordinators itself.
     * @param text - the user's message.
     * @param messageId - the logical message id (one per send; retries reuse it).
     * @returns where the post landed, the unresolved token with who is present, or why no coordinator took it.
     */
    postFromChat(text: string, messageId: string): Promise<StudioChatPost>;
    /**
     * Re-attempt every queued delivery addressed to one participant, across
     * every stored project — the reconnection hook. A message older than the
     * delivery expiry is recorded `delivery-expired` instead of attempted; an
     * explicit {@link deliver} retry with its messageId can still revive it.
     * @param target - the participant whose session came back.
     * @param now - the clock for the expiry decision (tests pin it).
     * @returns how many deliveries were delivered and how many expired.
     */
    retryQueued(target: string, now?: number): Promise<{
        delivered: number;
        expired: number;
    }>;
    /**
     * The newest recorded seq, for cursors and the announce invariant.
     * Synchronous over what is loaded: 0 for a project never read or written.
     * @param project - the resolved project folder.
     * @returns the last event's seq, 0 for an empty or unloaded timeline.
     */
    lastSeq(project: string): number;
}
export declare const name = "idealize-studio";
/** Deployment tunables. */
export interface StudioConfig {
    /** How long a queued delivery stays retryable on reconnection before it is recorded expired. */
    deliveryExpiryHours?: number;
}
/** Runtime schema for {@link StudioConfig}. */
export declare const Config: z<StudioConfig>;
export declare function apply(ctx: Context, config?: StudioConfig): void;
//# sourceMappingURL=index.d.ts.map