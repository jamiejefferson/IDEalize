/**
 * The deterministic project-state view: a pure fold of one timeline into
 * tasks and per-agent work. Unmentioned structured updates change this view
 * and invoke nobody — the fold is how routine status stays cheap.
 *
 * Kinds the fold reads: `assignment`, `task-update`, `request`, `handoff`,
 * `synthesis`, `system`. `message`, `decision` and `delivery` are timeline
 * items (decisions and deliveries still mark the synthesis stale); an
 * unknown subtype under a read kind touches `updated` and nothing else.
 */
import type { StudioEvent, StudioEventId } from './events.ts';
/** What one task is doing. */
export type TaskExecutionState = 'queued' | 'working' | 'waiting' | 'paused' | 'done' | 'failed' | 'cancelled';
/** What another participant must do about it. */
export type TaskAttention = 'none' | 'needs-input' | 'needs-action' | 'blocked' | 'completion' | 'failure' | 'handoff-ready';
/** One addressed message's delivery state, from the system delivery records. */
export type DeliveryState = 'queued' | 'delivered' | 'acknowledged' | 'expired';
/** The open ownership transfer, while one is offered. */
export interface StudioHandoff {
    /** The offering event; acceptance and rejection name it in `source.event`. */
    event: StudioEventId;
    /** The offering sender, who owns the work until acceptance. */
    from: string;
    /** The invited recipient; only its events move the transfer. */
    to: string;
    /** `needs-clarification` puts the ball back with the sender. */
    state: 'offered' | 'needs-clarification';
}
/** One project-owned task as the fold sees it. */
export interface StudioTask {
    id: string;
    /** The assignment's body; empty when the assignment carried none. */
    goal: string;
    owner: string;
    /** The assignment's author: who asked for the work. */
    requester: string;
    state: TaskExecutionState;
    attention: TaskAttention;
    /** Who must answer the open request; absent for an unassigned blocker. */
    attentionOwner?: string | undefined;
    /** The event whose resolution clears the open request. */
    requestEvent?: StudioEventId | undefined;
    /** The open ownership transfer, until accepted, rejected or cancelled. */
    handoff?: StudioHandoff | undefined;
    /** Who acknowledged the terminal attention, once someone has. */
    acknowledgedBy?: string | undefined;
    /** ISO-8601 instant of that acknowledgement. */
    acknowledgedAt?: string | undefined;
    /** ISO-8601 instant of the creating assignment. */
    created: string;
    /** The creating assignment's seq: the queue-promotion order. */
    createdSeq: number;
    /** ISO-8601 instant of the last event that touched the task. */
    updated: string;
}
/** One agent's work, derived from the tasks it owns. */
export interface StudioAgentView {
    /** The one task in `working`/`waiting`/`paused`; earliest-created when the log claims several. */
    active?: string | undefined;
    /** Queued task ids, earliest created first. */
    queued: string[];
    /** The chip's routing target: the active task, else the first queued. */
    displayed?: string | undefined;
    /** Tasks holding any unresolved attention, earliest created first. */
    unresolved: string[];
}
/** The coordinator's latest published project view, and whether events have moved past it. */
export interface StudioSynthesis {
    /** The publishing event. */
    event: StudioEventId;
    author: string;
    /** ISO-8601 publish instant. */
    at: string;
    body: string;
    /** True once any later state-changing event arrives (see STALING_KINDS). */
    stale: boolean;
}
/** The folded project state. */
export interface StudioState {
    /** Every task, in creation order. */
    tasks: StudioTask[];
    /** Per-owner work views, keyed by participant. */
    agents: Record<string, StudioAgentView>;
    /** Delivery state per addressed message event id; latest record wins. */
    deliveries: Record<string, DeliveryState>;
    /** The latest published synthesis, absent until the coordinator publishes one. */
    synthesis?: StudioSynthesis | undefined;
}
/**
 * Fold one timeline into the deterministic project state.
 * @param events - the project's events, oldest first.
 * @returns tasks in creation order plus per-owner work views.
 */
export declare function foldStudioState(events: readonly StudioEvent[]): StudioState;
//# sourceMappingURL=fold.d.ts.map