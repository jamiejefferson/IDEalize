/**
 * The Studio event vocabulary: what one durable coordination record carries,
 * the closed set of event kinds, and the wire schema that validates a
 * submitted event. Subtypes are open strings — a reader that meets an unknown
 * subtype treats the event as a plain timeline item.
 */
import { z } from 'zod';
import type { Branded } from '@deepseek-ai/dsh-brand';
/** One Studio event's stable identity, minted by the store on append. */
export type StudioEventId = Branded<'StudioEventId'>;
/**
 * Brand a string as a {@link StudioEventId}.
 * @param value - the raw id.
 * @returns the branded id.
 */
export declare const StudioEventId: (value: string) => StudioEventId;
/** One project-owned task's stable identity, chosen by the assigning author. */
export type StudioTaskId = Branded<'StudioTaskId'>;
/**
 * Brand a string as a {@link StudioTaskId}.
 * @param value - the raw id.
 * @returns the branded id.
 */
export declare const StudioTaskId: (value: string) => StudioTaskId;
/** Every event kind the timeline accepts; the wire refuses anything else. */
export declare const STUDIO_EVENT_KINDS: readonly ["message", "assignment", "task-update", "request", "decision", "handoff", "delivery", "synthesis", "system"];
/** One of {@link STUDIO_EVENT_KINDS}. */
export type StudioEventKind = typeof STUDIO_EVENT_KINDS[number];
/** Links from an event back to its evidence. */
export interface StudioEventSource {
    /** The session id of the thread the event summarises or answers. */
    thread?: string | undefined;
    /** An earlier Studio event this one resolves or revises. */
    event?: string | undefined;
}
/** What a producer submits; the store adds identity, order and time. */
export interface StudioEventInput {
    /** The project folder the timeline belongs to, resolved by the route. */
    project: string;
    /** The authoring participant: a session id, or `user`. */
    author: string;
    kind: StudioEventKind;
    /** Open refinement of the kind (`new-task`, `blocked`, `needs-input`, …). */
    subtype?: string | undefined;
    /** The addressed participant, or the owner an assignment/request names. */
    target?: string | undefined;
    /** The task the event belongs to. */
    taskId?: string | undefined;
    /** The event's text: a message body, a task goal, a request question. */
    body?: string | undefined;
    source?: StudioEventSource | undefined;
    /**
     * The producer's logical message id. Appending the same id to the same
     * project again returns the recorded event instead of a duplicate, so a
     * retried delivery cannot bind twice.
     */
    messageId?: string | undefined;
    /** Who may read the event. The MVP records every event Studio-wide. */
    visibility?: 'studio' | undefined;
}
/** One durable timeline record. */
export interface StudioEvent extends StudioEventInput {
    id: StudioEventId;
    /** Per-project monotonic order, 1-based, no gaps. */
    seq: number;
    /** ISO-8601 append instant. */
    at: string;
    visibility: 'studio';
}
/** Wire schema for one submitted event; the route parses, the service trusts. */
export declare const studioEventInputSchema: z.ZodObject<{
    project: z.ZodString;
    author: z.ZodString;
    kind: z.ZodEnum<{
        message: "message";
        assignment: "assignment";
        "task-update": "task-update";
        request: "request";
        decision: "decision";
        handoff: "handoff";
        delivery: "delivery";
        synthesis: "synthesis";
        system: "system";
    }>;
    subtype: z.ZodOptional<z.ZodString>;
    target: z.ZodOptional<z.ZodString>;
    taskId: z.ZodOptional<z.ZodString>;
    body: z.ZodOptional<z.ZodString>;
    source: z.ZodOptional<z.ZodObject<{
        thread: z.ZodOptional<z.ZodString>;
        event: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>;
    messageId: z.ZodOptional<z.ZodString>;
    visibility: z.ZodOptional<z.ZodLiteral<"studio">>;
}, z.core.$strict>;
/** Schema of one stored line: the input plus the store-assigned fields. */
export declare const studioEventSchema: z.ZodObject<{
    project: z.ZodString;
    author: z.ZodString;
    kind: z.ZodEnum<{
        message: "message";
        assignment: "assignment";
        "task-update": "task-update";
        request: "request";
        decision: "decision";
        handoff: "handoff";
        delivery: "delivery";
        synthesis: "synthesis";
        system: "system";
    }>;
    subtype: z.ZodOptional<z.ZodString>;
    target: z.ZodOptional<z.ZodString>;
    taskId: z.ZodOptional<z.ZodString>;
    body: z.ZodOptional<z.ZodString>;
    source: z.ZodOptional<z.ZodObject<{
        thread: z.ZodOptional<z.ZodString>;
        event: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>;
    messageId: z.ZodOptional<z.ZodString>;
    id: z.ZodString;
    seq: z.ZodNumber;
    at: z.ZodString;
    visibility: z.ZodLiteral<"studio">;
}, z.core.$strict>;
//# sourceMappingURL=events.d.ts.map