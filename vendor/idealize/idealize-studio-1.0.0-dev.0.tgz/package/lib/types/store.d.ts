/**
 * The durable per-project timeline: one append-only JSONL file per project
 * under the harness home. Appends are serialised per project, so `seq` is
 * per-project monotonic with no gaps; a torn final line from a crashed write
 * is dropped on load, while any other malformed line refuses the file.
 */
import type { StudioEvent, StudioEventInput } from './events.ts';
/**
 * Where a harness home keeps its Studio timelines.
 * @param dshHome - the harness home directory.
 * @returns the absolute path of `idealize/studio` under it.
 */
export declare function studioRootPath(dshHome: string): string;
/**
 * A project's timeline file name: a readable slug plus a hash of the full
 * path, so two folders sharing a basename cannot share a timeline.
 * @param project - the resolved project folder.
 * @returns the file name, without directory.
 */
export declare function projectKey(project: string): string;
/** One append's outcome: the recorded event, and whether it already existed. */
export interface StudioAppendResult {
    event: StudioEvent;
    /** True when the input's `messageId` was already recorded; nothing was written. */
    duplicate: boolean;
}
/** The timeline store: loads lazily per project, appends through a per-project chain. */
export declare class StudioStore {
    readonly root: string;
    private readonly timelines;
    private readonly byMessage;
    private readonly loads;
    private readonly chains;
    constructor(root: string);
    /**
     * A project's timeline file path.
     * @param project - the resolved project folder.
     * @returns the absolute JSONL path.
     */
    path(project: string): string;
    /**
     * Read a project's file once; a missing file is an empty timeline.
     * @param project - the resolved project folder.
     */
    load(project: string): Promise<void>;
    private read;
    /**
     * A project's events after a cursor, oldest first. Call after {@link load}.
     * @param project - the resolved project folder.
     * @param since - return events with `seq` greater than this; 0 for all.
     * @returns the retained events after the cursor.
     */
    events(project: string, since?: number): StudioEvent[];
    /**
     * The newest recorded seq. Call after {@link load}.
     * @param project - the resolved project folder.
     * @returns the last event's seq, 0 for an empty timeline.
     */
    lastSeq(project: string): number;
    /**
     * Every project with a stored timeline, read off the first line of each
     * file (a line names its project, so the hashed file name never needs
     * reversing).
     * @returns the stored project folders, in directory order.
     */
    storedProjects(): Promise<string[]>;
    /**
     * Record one event: identity, order and time are assigned here, and the
     * result resolves once the line is on disk. A `messageId` already recorded
     * for the project returns its event and writes nothing.
     * @param input - the validated submission.
     * @returns the recorded (or already-recorded) event.
     */
    append(input: StudioEventInput): Promise<StudioAppendResult>;
}
//# sourceMappingURL=store.d.ts.map