/**
 * The on-device speech provider: a whisper model run through
 * `@huggingface/transformers` on this machine. Captured samples reach the
 * model in process and no network, which is the claim the consent card makes
 * on this provider's behalf (JJ, 9 Sep 2026, choosing on-device over a
 * hosted API).
 *
 * The library and its ONNX runtime are imported on the first `prepare()`, so
 * a composition that never records speech never loads them. Model files are
 * fetched once into the configured cache directory and reused from there.
 * @module @idealize/transcribe/local-whisper
 */
import type { DataType } from '@huggingface/transformers';
import type { TranscriptionProvider } from './types.ts';
/** Registry id of the on-device provider. */
export declare const LOCAL_WHISPER_ID = "local-whisper";
/** Whisper takes 16 kHz mono; every capture is resampled to it before it arrives. */
export declare const WHISPER_SAMPLE_RATE = 16000;
/** What the provider needs to run. */
export interface LocalWhisperOptions {
    /** The model, named the way its publisher names it. */
    model: string;
    /** Weight quantisation the model is loaded at, as the library names its quantisations. */
    dtype: DataType;
    /** Directory the model files are fetched into and reused from. */
    cacheDir: string;
}
/**
 * Build the on-device provider.
 * @param options - the model, its quantisation and where its files live.
 * @returns the provider, ready to register.
 */
export declare function localWhisper(options: LocalWhisperOptions): TranscriptionProvider;
//# sourceMappingURL=local-whisper.d.ts.map