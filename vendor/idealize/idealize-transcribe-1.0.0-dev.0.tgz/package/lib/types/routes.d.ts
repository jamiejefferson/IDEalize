/**
 * The transcription routes, mounted while a web server is composed beside the
 * runtime. Kept apart from the plugin so a test can compose the runtime, a
 * stub provider and these routes without the on-device model.
 * @module @idealize/transcribe/routes
 */
import type { Context } from '@deepseek-ai/cordis';
import type { TranscriptionDescriptor, TranscriptionReadiness, TranscriptionRequest, TranscriptionResult } from './types.ts';
/** State path. */
export declare const STATE_PATH = "/idealize/transcribe/state";
/** Prepare path. */
export declare const PREPARE_PATH = "/idealize/transcribe/prepare";
/** Transcribe path. */
export declare const TRANSCRIBE_PATH = "/idealize/transcribe";
/**
 * The body's bytes as mono float samples. A body whose length is not a whole
 * number of 32-bit floats is a truncated upload, not a short capture.
 * @param body - the raw request body.
 * @returns the samples, or undefined when the body is not whole floats.
 */
export declare function samplesOf(body: Buffer): Float32Array | undefined;
/**
 * The sample rate a request declares. A request that names none was recorded
 * at whisper's rate, which is what the recorder resamples to.
 * @param url - the request's URL, absent on a request that carried none.
 * @returns the declared rate, or whisper's.
 */
export declare function rateOf(url: string | undefined): number;
/** The runtime slice the routes read, so the service can hand itself in before it is published. */
export interface TranscribeQueries {
    /** Every registered provider's descriptor. */
    list(): TranscriptionDescriptor[];
    /** Readiness of the provider a capture would reach. */
    readiness(id?: string): Promise<TranscriptionReadiness>;
    /** Bring that provider up to ready. */
    prepare(id?: string): Promise<TranscriptionReadiness>;
    /** Resolve a capture and run it. */
    transcribe(request: TranscriptionRequest, signal?: AbortSignal): Promise<TranscriptionResult>;
}
/**
 * Mount the three transcription routes while a web server is composed.
 * @param ctx - the context to mount on.
 * @param runtime - the runtime the routes read; handed in rather than read off
 *   the context, because the service mounts these from its own constructor.
 */
export declare function installTranscribeRoutes(ctx: Context, runtime: TranscribeQueries): void;
//# sourceMappingURL=routes.d.ts.map