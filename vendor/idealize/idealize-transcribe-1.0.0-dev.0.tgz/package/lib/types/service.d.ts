/**
 * Service Definition for the transcription capability seam (`ctx.transcription`):
 * a registry of speech providers, an explicit request-to-spec resolve step, and
 * dispatch to the resolved provider.
 * @module @idealize/transcribe/service
 */
import { Context, Service } from '@deepseek-ai/cordis';
import type { TranscriptionDescriptor, TranscriptionProvider, TranscriptionReadiness, TranscriptionRequest, TranscriptionResult, TranscriptionSpec } from './types.ts';
/** Version carried by the descriptors and results this seam exchanges. */
export declare const TRANSCRIPTION_SCHEMA_VERSION = 1;
declare module '@deepseek-ai/cordis' {
    interface Context {
        transcription: TranscriptionRuntime;
    }
}
/** The capture bounds every request is held to; the plugin's Config supplies them. */
export interface CaptureBounds {
    /** Captures shorter than this are refused as a slip rather than speech, in milliseconds. */
    minCaptureMs: number;
    /** Captures longer than this are refused, in milliseconds. */
    maxCaptureMs: number;
}
/**
 * The transcription service. Registered as `ctx.transcription` (one instance
 * per context). Providers register with `register()`; consumers resolve a
 * capture and run it.
 */
export declare class TranscriptionRuntime extends Service {
    private readonly providersById;
    private readonly bounds;
    /**
     * @param ctx - the Cordis context this service is registered on.
     * @param bounds - the capture bounds every request is held to.
     */
    constructor(ctx: Context, bounds: CaptureBounds);
    /**
     * Register a speech provider. Throws on a duplicate id, which is a
     * composition bug rather than a task failure.
     * @param provider - the provider; its `id` is the registry key.
     * @returns the disposer that unregisters it.
     */
    register(provider: TranscriptionProvider): () => void;
    /**
     * Every registered provider's descriptor, in registration order.
     * @returns the descriptors.
     */
    list(): TranscriptionDescriptor[];
    /**
     * Readiness of the provider a request would resolve to.
     * @param id - a pinned provider id; absent picks the only registered one.
     * @returns that provider's readiness.
     */
    readiness(id?: string): Promise<TranscriptionReadiness>;
    /**
     * Bring the provider a request would resolve to up to `ready`.
     * @param id - a pinned provider id; absent picks the only registered one.
     * @returns readiness once the attempt settles.
     */
    prepare(id?: string): Promise<TranscriptionReadiness>;
    /**
     * Choose the provider for a request and hold the capture to its terms. The
     * defaulting a caller does not state lives here, in the open, rather than
     * inside `transcribe()`.
     * @param request - the capture and any pinned provider.
     * @returns the resolved capture.
     */
    resolve(request: TranscriptionRequest): TranscriptionSpec;
    /**
     * Resolve a capture and run it.
     * @param request - the capture and any pinned provider.
     * @param signal - aborts the run; an aborted run rejects and produces nothing.
     * @returns the transcript.
     */
    transcribe(request: TranscriptionRequest, signal?: AbortSignal): Promise<TranscriptionResult>;
    /** The provider a pinned id names, or the only registered one. */
    private provider;
}
export default TranscriptionRuntime;
//# sourceMappingURL=service.d.ts.map