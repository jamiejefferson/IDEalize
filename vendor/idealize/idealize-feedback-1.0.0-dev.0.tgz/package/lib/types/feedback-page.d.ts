/**
 * The /idealize/feedback page: a small branded form posting through the
 * host's proxy endpoint. Self-contained like /idealize/signin and
 * /idealize/calendar; a client-slot sheet inside the web app is queued.
 *
 * Screenshots attach three ways (V0 parity): the Attach button, drag-drop
 * anywhere on the form, or paste. The image is downscaled in-page to at most
 * 1600px on its long edge and sent as plain base64 JPEG (`screenshot_b64`,
 * same column V0 writes; the table caps it at 2M characters).
 */
export declare function feedbackPage(): string;
//# sourceMappingURL=feedback-page.d.ts.map