/**
 * IDEalize feedback + announcements over a Supabase REST endpoint the
 * composition names. No project or key ships in the code: `endpoint` and
 * `publishableKey` come from the plugin config or the environment
 * (`IDEALIZE_FEEDBACK_ENDPOINT`, `IDEALIZE_FEEDBACK_KEY`); without both, a
 * submission is kept locally and the announcements feed is empty.
 *
 * HTTP surface (loopback-fenced; the submit route demands the header):
 * - POST /idealize/feedback/submit — {text, feedbackType?} proxied to the
 *   `idealize_feedback` table with app/os versions stamped, and appended to a
 *   local backup file in the Harness home regardless of network outcome.
 * - GET  /idealize/announcements — the newest active row of
 *   `idealize_announcements`, verbatim; the client owns version gating and
 *   dismissal, exactly as V0's banner did.
 *
 * The form itself is ui-bar's FeedbackPanel (a drawer pane); this package
 * serves no page of its own.
 */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
/** Plugin config. */
export interface Config {
    /** Stamped into feedback rows as `app_version`. */
    appVersion?: string;
    /** The Supabase REST base URL (`https://<project>.supabase.co/rest/v1`); `IDEALIZE_FEEDBACK_ENDPOINT` when empty. */
    endpoint?: string;
    /**
     * The project's publishable key, whose row-level security allows only
     * feedback inserts and announcement reads; `IDEALIZE_FEEDBACK_KEY` when empty.
     */
    publishableKey?: string;
}
export declare const Config: z<Config>;
export declare function apply(ctx: Context, config: Config): void;
//# sourceMappingURL=index.d.ts.map