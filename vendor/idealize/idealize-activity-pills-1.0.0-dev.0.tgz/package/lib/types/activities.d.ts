/**
 * The five activity agents: identity, roster text, and persona. Browser-safe
 * (no imports), so the client half shares the ids with the host seeding.
 * @module @idealize/activity-pills/activities
 */
/** One activity's identity and the preset it seeds. */
export interface ActivityDefinition {
    /** Preset id (and directory name) under the user root. */
    id: string;
    /** Roster display name. */
    name: string;
    /** Roster description. */
    description: string;
    /** Roster sort position, before the shipped set's own order. */
    order: number;
    /** Persona text the seeded composition carries. */
    persona: string;
}
/** The five defaults, in pill order. */
export declare const ACTIVITIES: readonly ActivityDefinition[];
/** The pill ids in pill order. */
export declare const ACTIVITY_IDS: readonly string[];
/** The activity whose selection also switches the model policy to the free-tokens auto route. */
export declare const FREE_ACTIVITY_ID = "free";
//# sourceMappingURL=activities.d.ts.map