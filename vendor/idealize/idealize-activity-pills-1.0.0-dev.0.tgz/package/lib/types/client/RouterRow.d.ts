/**
 * The model router's place in the composer: a chip beside the three-dot
 * control while the router has moved this chat or has a model to offer, and
 * the row inside the panel that says why, takes the switch back, accepts an
 * offer, and locks the chat. Reads the `router` projection off the session
 * summary, so it follows the chat with no request of its own.
 * @module @idealize/activity-pills/client/RouterRow
 */
import type { RoutedModel, RouterProjection } from '@idealize/router/client';
import type { ActivityKey } from './locales.ts';
/** What the row asks of the plugin: the router's routes and the chat's model write. */
export interface RouterActions {
    /** Lock or unlock the chat against routing. */
    lock(sessionId: string, locked: boolean): Promise<void>;
    /** Put the chat back on the model it had, and lock it there. */
    back(sessionId: string, to: RoutedModel): Promise<void>;
    /** Move the chat to a model the router offered. */
    accept(sessionId: string, to: RoutedModel): Promise<void>;
}
type Translate = (key: ActivityKey, params?: Record<string, string | number>) => string;
/**
 * The chip on the tool row.
 * @param props.router - the chat's router projection.
 * @param props.onOpen - open the panel the row lives in.
 * @returns the chip, or null while the router has nothing to show.
 */
export declare function RouterBadge({ router, onOpen, t }: {
    router: RouterProjection | undefined;
    onOpen: () => void;
    t: Translate;
}): import("react").JSX.Element | null;
/**
 * The panel's router row.
 * @param props.router - the chat's router projection.
 * @param props.actions - the plugin's router face.
 * @returns the row; with nothing routed yet it is the lock alone.
 */
export declare function RouterRow({ sessionId, router, actions, t }: {
    sessionId: string;
    router: RouterProjection | undefined;
    actions: RouterActions;
    t: Translate;
}): import("react").JSX.Element;
export {};
//# sourceMappingURL=RouterRow.d.ts.map