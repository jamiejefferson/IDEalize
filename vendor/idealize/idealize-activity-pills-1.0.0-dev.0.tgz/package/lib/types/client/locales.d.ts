/** `idealize-activity` namespace dictionaries: the composer's model chip and the router's lines. */
/** Simplified Chinese dictionary (the key-set source of truth). */
export declare const zh: {
    readonly 'space.chat': "对话";
    readonly 'space.terminal': "终端";
    readonly 'space.gallery': "图片";
    readonly 'space.soundstage': "声音";
    readonly 'space.motion': "视频";
    readonly 'space.studio': "智能体协调";
    readonly 'chip.trigger': "{model}，{mode}。模型设置";
    readonly 'chip.triggerPlain': "{model}。模型设置";
    readonly 'chip.panel': "Model";
    readonly 'chip.mode': "How the model switches";
    readonly 'chip.mode.auto': "Auto";
    readonly 'chip.mode.ask': "Ask me";
    readonly 'chip.mode.fixed': "Fixed";
    readonly 'chip.lean': "Cheaper to smarter";
    readonly 'chip.lean.cheaper': "Cheaper";
    readonly 'chip.lean.smarter': "Smarter";
    readonly 'chip.models': "Models";
    readonly 'chip.answering': "Answering now";
    readonly 'chip.price': "{price} / M";
    readonly 'chip.price.free': "Free";
    readonly 'chip.otherModels': "Other models";
    readonly 'chip.thinking': "思考";
    readonly 'chip.thinkingDefault': "默认";
    readonly 'chip.needsAccount': "需要账户";
    readonly 'chip.needsSetup': "需要设置";
    readonly 'chip.blocked.account': "{model} needs an account before it can answer.";
    readonly 'chip.blocked.plain': "This chat needs an account before it can answer.";
    readonly 'chip.blocked.setup': "免费模型尚未设置。";
    readonly 'chip.blocked.connect': "连接账户";
    readonly 'chip.blocked.setUp': "设置";
    readonly 'chip.blocked.useFree': "使用免费";
    readonly 'chip.switchBack': "切换回去";
    readonly 'chip.try': "试试 {model}";
    readonly 'chip.switch': "Switch";
    readonly 'chip.stay': "Stay";
    readonly 'chip.dismiss': "关闭";
    readonly 'overflow.trigger': "更多设置";
    readonly 'overflow.access': "项目权限";
    readonly 'router.ask.dearer': "Use {model} for this? It costs more.";
    readonly 'router.ask.plain': "Use {model} for this?";
    readonly 'router.offer.needs-payment': "{to} 更适合这项工作。它是付费模型,由你决定是否使用。";
    readonly 'router.offer.other-company': "{to} 可以接手。这会把此聊天发送给另一家公司,由你决定。";
    readonly 'router.offer.loses-context': "{to} 更适合这项工作。它能容纳的内容少于此聊天已有的内容,最早的部分会被丢弃。";
    readonly 'router.offer.said-cannot': "{from} 表示它做不到这件事。{to} 也许可以。";
    readonly 'router.note.switched': "本次回复改用 {to}（原为 {from}）。";
    readonly 'router.note.back': "此聊天回到 {to}。";
    readonly 'router.note.accepted': "已改用 {to}。请再次发送消息以继续。";
    readonly 'router.note.stayed': "Stayed on {from}.";
};
/** Dictionary key set. */
export type ActivityKey = keyof typeof zh;
/** English dictionary, checked complete against the zh key set. */
export declare const en: Record<ActivityKey, string>;
//# sourceMappingURL=locales.d.ts.map