/** `idealize-activity` namespace dictionaries: the composer's brain switcher. */
/** Simplified Chinese dictionary (the key-set source of truth). */
export declare const zh: {
    readonly 'confirm.continue': "继续";
    readonly 'confirm.cancel': "取消";
    readonly 'space.chat': "对话";
    readonly 'space.terminal': "终端";
    readonly 'space.gallery': "图片";
    readonly 'space.soundstage': "声音";
    readonly 'space.motion': "视频";
    readonly 'space.studio': "工作室";
    readonly 'brain.trigger': "当前大脑";
    readonly 'brain.restarts': "用这个大脑重启终端";
    readonly 'brain.confirmTitle': "切换到{brain}？";
    readonly 'brain.restartLine': "终端将重启，部分上下文可能会丢失。";
    readonly 'brain.purpose.coding': "构建和修改软件";
    readonly 'brain.purpose.design': "处理界面和视觉系统";
    readonly 'brain.purpose.writing': "起草和编辑文字";
    readonly 'brain.purpose.admin': "整理文件、清单和日程";
    readonly 'brain.purpose.free': "免费处理简单问题";
    readonly 'chip.trigger': "{brain}，{model}。更改大脑或模型";
    readonly 'chip.brain': "大脑";
    readonly 'chip.runsOn': "{brain}运行于";
    readonly 'chip.change': "更改";
    readonly 'chip.changeHint': "仅更改此聊天。要更改所有{brain}聊天，请使用“管理大脑”。";
    readonly 'chip.mediaCost': "{service} · 按量付费";
    readonly 'chip.thinking': "思考";
    readonly 'chip.thinkingDefault': "默认";
    readonly 'chip.autoSwitch': "自动切换";
    readonly 'chip.autoSwitchHint': "有更合适的模型时自动切换";
    readonly 'chip.autoSwitchNeeds': "需要 OpenRouter 账户";
    readonly 'chip.autoSwitchNeedsModel': "需要再连接一个模型";
    readonly 'chip.autoSwitchOff': "已在大脑面板中关闭";
    readonly 'chip.noMediaModel': "已连接的账户都无法生成这类内容";
    readonly 'chip.autoSwitchOffBrain': "此大脑已关闭自动切换";
    readonly 'chip.manage': "管理大脑";
    readonly 'chip.add': "添加大脑";
    readonly 'chip.needsAccount': "需要账户";
    readonly 'chip.needsSetup': "需要设置";
    readonly 'chip.started.line': "从现在起使用{brain}的模型。此聊天保留{current}的指令。";
    readonly 'chip.started.use': "使用它的模型";
    readonly 'chip.started.newChat': "新建{brain}聊天";
    readonly 'chip.blocked.account': "{brain}需要账户才能回答。";
    readonly 'chip.blocked.setup': "免费模型尚未设置。";
    readonly 'chip.blocked.connect': "连接账户";
    readonly 'chip.blocked.setUp': "设置";
    readonly 'chip.blocked.useFree': "使用免费";
    readonly 'chip.switchBack': "切换回去";
    readonly 'chip.try': "试试 {model}";
    readonly 'chip.dismiss': "关闭";
    readonly 'cost.free': "免费";
    readonly 'cost.plan': "包含在你的套餐中";
    readonly 'cost.payg': "按量付费";
    readonly 'overflow.trigger': "更多设置";
    readonly 'overflow.access': "项目权限";
    readonly 'router.offer.needs-payment': "{to} 更适合这项工作。它是付费模型,由你决定是否使用。";
    readonly 'router.offer.other-company': "{to} 可以接手。这会把此聊天发送给另一家公司,由你决定。";
    readonly 'router.offer.loses-context': "{to} 更适合这项工作。它能容纳的内容少于此聊天已有的内容,最早的部分会被丢弃。";
    readonly 'router.offer.said-cannot': "{from} 表示它做不到这件事。{to} 也许可以。";
    readonly 'router.note.switched': "本次回复改用 {to}（原为 {from}）。";
    readonly 'router.note.back': "此聊天回到 {to}。";
    readonly 'router.note.accepted': "已改用 {to}。请再次发送消息以继续。";
};
/** Dictionary key set. */
export type ActivityKey = keyof typeof zh;
/** English dictionary, checked complete against the zh key set. */
export declare const en: Record<ActivityKey, string>;
//# sourceMappingURL=locales.d.ts.map