/** `idealize-activity` namespace dictionaries: the composer's brain switcher. */
/** Simplified Chinese dictionary (the key-set source of truth). */
export declare const zh: {
    readonly 'confirm.continue': "继续";
    readonly 'confirm.cancel': "取消";
    readonly 'space.chat': "对话";
    readonly 'space.terminal': "终端";
    readonly 'space.gallery': "图片";
    readonly 'space.soundstage': "声音";
    readonly 'space.motion': "视频";
    readonly 'space.studio': "工作室";
    readonly 'brain.trigger': "当前大脑";
    readonly 'brain.heading': "可用于{space}的大脑";
    readonly 'brain.restarts': "将重启终端";
    readonly 'brain.noInstructions': "没有专属指令";
    readonly 'brain.addBrain': "为{space}添加大脑";
    readonly 'brain.confirmTitle': "切换到{brain}？";
    readonly 'brain.restartLine': "终端将重启，部分上下文可能会丢失。";
    readonly 'overflow.trigger': "更多设置";
    readonly 'overflow.access': "项目权限";
    readonly 'overflow.brain': "大脑";
    readonly 'overflow.blocked': "选择大脑";
    readonly 'overflow.openBrains': "打开大脑面板";
    readonly 'router.row': "模型路由";
    readonly 'router.badge.switched': "当前为 {model}";
    readonly 'router.badge.offer': "试试 {model}";
    readonly 'router.switched': "路由已将此聊天从 {from} 切换到 {to}。";
    readonly 'router.offer.needs-payment': "{to} 更适合这项工作。它是付费模型,由你决定是否使用。";
    readonly 'router.offer.loses-context': "{to} 更适合这项工作。它能容纳的内容少于此聊天已有的内容,最早的部分会被丢弃。";
    readonly 'router.back': "切换回 {from}";
    readonly 'router.accept': "使用 {to}";
    readonly 'router.lock': "让此聊天保持当前模型";
};
/** Dictionary key set. */
export type ActivityKey = keyof typeof zh;
/** English dictionary, checked complete against the zh key set. */
export declare const en: Record<ActivityKey, string>;
//# sourceMappingURL=locales.d.ts.map