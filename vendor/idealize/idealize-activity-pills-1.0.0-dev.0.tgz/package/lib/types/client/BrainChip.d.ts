/**
 * The composer's brain chip: one control on the model seat
 * (`conversation.input.model`) that answers "who is answering?" in every state
 * (Paper "Brains rethink", boards 08 and 09, approved by JJ on 4 Nov 2026). It
 * names the brain and the model it runs on, and its panel holds the brain
 * list, the model with Change into the model browser, thinking effort and
 * auto-switch.
 *
 * THE BRAIN IS BACK ON THE ROW. JJ moved it behind the three dots on 9 Sep 2026
 * ("the main ask bar settings is a mess"), then chose this chip on 4 Nov. The
 * row ends one control shorter on a chat, because this replaces the model chip
 * and takes effort in. Project access stays behind the dots.
 *
 * A media chat's chip names the brain alone. The model is the brain's to define
 * and stays off the row (JJ, 13 Sep 2026); the panel states it.
 *
 * WHAT A SWITCH COSTS IS STATED BEFORE THE CLICK. A started chat's preset is
 * fixed, so choosing a brain there takes its model and leaves the instructions:
 * the row opens to say so and offers a new chat instead. In Terminal a brain
 * whose command differs restarts the shell, the row says so, and the dialog
 * asks once more.
 *
 * UNDER A COMPOSER BLOCK THIS CONTROL STAYS LIVE. The composer keeps its model
 * seat unlocked for that, because choosing a model is how a person clears the
 * block (PC test drive, 18 Sep 2026). The chip turns amber and names what is
 * missing; {@link BrainNotice} carries the fix.
 *
 * The panel is portalled to the body and positioned against the trigger,
 * because the composer's tool row scrolls sideways and clips both axes
 * (JJ, 11 Sep 2026).
 * @module @idealize/activity-pills/client/BrainChip
 */
import type { ReactNode } from 'react';
import type { SnapshotStore } from '@deepseek-ai/dsh-client-runtime/client';
import type { InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { SpaceId } from '@idealize/spaces/client';
import type { RoutedModel } from '@idealize/router/client';
import type { ActivityKey } from './locales.ts';
import type { BrainOption, BrainSessionSummary, BrainSwitcherState } from './brain-switcher.ts';
/** One chat's composer block, as far as the chip reads it: raised or not. */
export interface ComposerBlockSource {
    subscribe(listener: () => void): () => void;
    getSnapshot(): unknown;
}
/** One effort level of a model, as the host reports it. */
interface EffortLevel {
    id: string;
    name: string;
}
/** The directory's share of a model that the chip reads (restated; ui-model-selection owns it). */
interface DirectoryModel {
    id: string;
    name: string;
    reasoning?: {
        efforts: readonly EffortLevel[];
        defaultEffort?: string;
    };
}
/** The model the chat runs on, with the effort it runs at. */
export interface ModelChoice {
    provider: string;
    model: string;
    reasoningEffort?: string;
}
/** The directory's state as the chip reads it (restated; ui-model-selection owns it). */
export interface ChipDirectoryState {
    current: ModelChoice | null;
    groups: readonly {
        id: string;
        name: string;
        models: readonly DirectoryModel[];
    }[];
    status: string;
}
/** A session's model directory (restated; ui-model-selection owns it). */
export interface ChipDirectorySource {
    subscribe(listener: () => void): () => void;
    getSnapshot(): ChipDirectoryState;
}
/** Whether auto-switch can run at all, from `GET /idealize/router/state`. */
export interface RouterAvailability {
    /** On, with OpenRouter connected for the reading and a second model to move to. */
    canRun: boolean;
    /** What stands in its way when it cannot run, so the line under the switch can say so. */
    blockedBy?: 'off' | 'account' | 'model';
    /** The brains a person has told auto-switch to leave alone. */
    offBrains: readonly string[];
}
/** What the chip asks of the router plugin; a shell without it answers 404 and changes nothing. */
export interface RouterActions {
    /** Lock or unlock the chat against routing. */
    lock(sessionId: string, locked: boolean): Promise<void>;
    /** Put the chat back on the model it had, and lock it there. */
    back(sessionId: string, to: RoutedModel): Promise<void>;
    /** Move the chat to a model the router offered. */
    accept(sessionId: string, to: RoutedModel): Promise<void>;
}
/** A media brain's generation model, as the panel states it. */
export interface MediaBrainModel {
    name: string;
    service: string;
}
/** Everything the bar's model browser needs from the chip. */
export interface ChipBrowserRequest {
    /** The brain's name, for the browser's heading. */
    brainName: string;
    /** The chat's model. */
    current: {
        provider: string;
        model: string;
    } | null;
    onApply: (model: {
        provider: string;
        model: string;
    }) => void;
    onClose: () => void;
}
/** Registration-side face for the chip and its notice. */
export interface BrainChipInjected {
    hooks: {
        /** Menu snapshot bound by the renderer as useBrainSwitcher. */
        brainSwitcher: SnapshotStore<BrainSwitcherState>;
    };
    /** Read the brains of this chat's space. */
    load: (session: BrainSessionSummary) => Promise<void>;
    /** Make one brain current for this chat. */
    select: (brainId: string, session: BrainSessionSummary) => Promise<void>;
    /** Whether this session supports model reads and writes. An addressed subagent does not. */
    available: boolean;
    /** The chat's shared model directory. */
    directory: ChipDirectorySource;
    /** Refresh the directory. */
    loadModels: () => void;
    /**
     * Put the chat on a model at an effort.
     * @returns whether the host accepted it.
     */
    selectModel: (choice: ModelChoice) => Promise<boolean>;
    /** The store holding one chat's composer block. Undefined where no conversation service is composed. */
    composerBlock?: (sessionId: string) => ComposerBlockSource | undefined;
    /** Open the Brains pane's add flow with the space already set. */
    addBrain?: (space: SpaceId) => void;
    /** Open the Brains pane. */
    openBrains?: () => void;
    /** Open the key field for a route, or the account list with no route named. */
    addKey?: (provider?: string) => void;
    /** Open the sign-in surface. */
    signIn?: () => void;
    /** Open a brain's sheet in the Brains pane. */
    editBrain?: (brainId: string) => void;
    /** Render the model browser over the window. Absent wherever the tool rail is not composed. */
    renderModelBrowser?: (request: ChipBrowserRequest) => ReactNode;
    /** Start a new chat on a brain, in the same project. */
    startChat?: (brainId: string, space: SpaceId, sessionId: string) => Promise<void>;
    /** The model router's routes and the chat's model write. */
    router?: RouterActions;
    /** Read whether auto-switch can run; null when the router is absent. */
    routerState?: () => Promise<RouterAvailability | null>;
    /** How each route is paid for, by provider id. */
    planRoutes?: () => Promise<ReadonlySet<string>>;
    /** A media brain's generation model; null when it has none. */
    mediaModel?: (space: SpaceId) => Promise<MediaBrainModel | null>;
}
/** Full slot component props. */
export type BrainChipProps = PropsRuntime<'conversation.input.model'> & PropsLocale<'idealize-activity'> & InjectFace<BrainChipInjected>;
/** The translator the chip's parts share. */
export type Translate = BrainChipProps['t'];
/**
 * The name a brain goes by on the chip. A media space's seeded brain carries
 * an old stored name ("Gallery"), so the space's own label stands in for it.
 * @param brain - the brain.
 * @param space - the chat's space.
 * @param soleBrain - whether it is the only brain of its space.
 * @param t - the translator.
 * @returns the name to show.
 */
export declare function brainLabel(brain: Pick<BrainOption, 'name'>, space: SpaceId, soleBrain: boolean, t: Translate): string;
/**
 * The line under a brain's name.
 * @param brain - the brain.
 * @param t - the translator.
 * @returns what the brain is for, or what choosing it costs; empty when nothing is known.
 */
export declare function brainPurpose(brain: BrainOption, t: Translate): string;
/**
 * A model's name without the maker's prefix, which the route's catalogue
 * repeats on every row ("DeepSeek: DeepSeek V4 Flash").
 * @param name - the catalogue name.
 * @returns the readable name.
 */
export declare function readableModel(name: string): string;
/**
 * How a model is paid for, in the three words the rethink settled on.
 * @param model - the model.
 * @param plans - the routes a person's plan covers.
 * @returns the label's key.
 */
export declare function costKey(model: {
    provider: string;
    model: string;
}, plans: ReadonlySet<string>): ActivityKey;
/** What the chip and its notice both read about one chat. */
export interface BrainChipView {
    session: BrainSessionSummary | undefined;
    space: SpaceId;
    brains: readonly BrainOption[];
    current: BrainOption | undefined;
    busy: string | null;
    /** The chat's model, by the directory. */
    model: ModelChoice | null;
    /** The chat's model by its readable name; undefined until the directory knows it. */
    modelName: string | undefined;
    /** The chat's model has no route, or the chat sits on a brain whose route has no account. */
    blocked: boolean;
    /** The router's record for this chat. */
    routed: ReturnType<typeof readRouter>;
}
/** The projection read, split out so its type names itself. */
declare function readRouter(useSessions: BrainChipProps['useSessions'], sessionId: BrainChipProps['sessionId']): import("@idealize/router/client").RouterProjection | undefined;
/**
 * Read one chat's brain, model and block.
 * @param props - the seat's composed props.
 * @returns the view.
 */
export declare function useBrainChipView(props: Pick<BrainChipProps, 'sessionId' | 'useSessions' | 'useBrainSwitcher' | 'load' | 'directory' | 'composerBlock'>): BrainChipView;
/**
 * The composer's brain chip and its panel.
 * @param props - composed slot props.
 * @returns the chip, or null until the roster has placed this chat on a brain.
 */
export declare function BrainChip(props: BrainChipProps): import("react").JSX.Element | null;
export {};
//# sourceMappingURL=BrainChip.d.ts.map