/**
 * The composer's model chip: one control on the model seat
 * (`conversation.input.model`) that answers "which model is answering, and may
 * it change?" (JJ, 24 Nov 2026: a chat runs on one company's models). It names
 * the model answering now and how the router behaves, and its panel holds the
 * three-way choice (Auto, Ask me, Fixed), the Cheaper to Smarter slider, the
 * company's models with a tick each, thinking effort, and the way into the
 * model browser.
 *
 * THE CHIP RENDERS FOR EVERY CHAT. Presets still compose a chat underneath,
 * and nobody sees or chooses one, so the chip reads the chat's model and never
 * waits on a recorded preset.
 *
 * THE THREE SETTINGS ARE APP-WIDE. Mode, the slider and the ticks are written
 * to the router's settings, so every chat follows them. A chat locked by
 * "Switch back" reads as Fixed here, and choosing Auto or Ask me unlocks it.
 *
 * A Terminal chat's chip names the command-line app and opens nothing: the app
 * picks its own model. An image, sound or video chat is never routed, so its
 * panel lists the models as one choice and leaves the router's settings out.
 *
 * UNDER A COMPOSER BLOCK THIS CONTROL STAYS LIVE. The composer keeps its model
 * seat unlocked for that, because choosing a model is how a person clears the
 * block (PC test drive, 18 Sep 2026). The chip turns amber and names what is
 * missing; {@link BrainNotice} carries the fix.
 *
 * The panel is portalled to the body and positioned against the trigger,
 * because the composer's tool row scrolls sideways and clips both axes
 * (JJ, 11 Sep 2026).
 * @module @idealize/activity-pills/client/BrainChip
 */
import type { ReactNode } from 'react';
import type { SnapshotStore } from '@deepseek-ai/dsh-client-runtime/client';
import type { InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { SpaceId } from '@idealize/spaces/client';
import type { RoutedModel, RouterChoice, RouterChoices, RouterMode } from '@idealize/router/client';
import type { BrainOption, BrainSessionSummary, BrainSwitcherState } from './brain-switcher.ts';
/** One chat's composer block, as far as the chip reads it: raised or not. */
export interface ComposerBlockSource {
    subscribe(listener: () => void): () => void;
    getSnapshot(): unknown;
}
/** One effort level of a model, as the host reports it. */
interface EffortLevel {
    id: string;
    name: string;
}
/** The directory's share of a model that the chip reads (restated; ui-model-selection owns it). */
interface DirectoryModel {
    id: string;
    name: string;
    reasoning?: {
        efforts: readonly EffortLevel[];
        defaultEffort?: string;
    };
}
/** The model the chat runs on, with the effort it runs at. */
export interface ModelChoice {
    provider: string;
    model: string;
    reasoningEffort?: string;
}
/** The directory's state as the chip reads it (restated; ui-model-selection owns it). */
export interface ChipDirectoryState {
    current: ModelChoice | null;
    groups: readonly {
        id: string;
        name: string;
        models: readonly DirectoryModel[];
    }[];
    status: string;
}
/** A session's model directory (restated; ui-model-selection owns it). */
export interface ChipDirectorySource {
    subscribe(listener: () => void): () => void;
    getSnapshot(): ChipDirectoryState;
}
/** What the chip reads from `GET /idealize/router/choices`. */
export type ChipChoices = RouterChoices;
/** What the chip writes to `POST /idealize/router/settings`. */
export interface RouterSettingsPatch {
    mode?: RouterMode;
    lean?: number;
    excluded?: string[];
}
/** What the chip asks of the router plugin; a shell without it answers 404 and changes nothing. */
export interface RouterActions {
    /** Lock or unlock the chat against routing. */
    lock(sessionId: string, locked: boolean): Promise<void>;
    /** Put the chat back on the model it had, and lock it there. */
    back(sessionId: string, to: RoutedModel): Promise<void>;
    /** Move the chat to a model the router offered. */
    accept(sessionId: string, to: RoutedModel): Promise<void>;
    /** Turn the open offer down. */
    stay(sessionId: string): Promise<void>;
    /** Let go of a switch the router made, so the chat runs on the model the person just chose. */
    drop(sessionId: string): Promise<void>;
}
/** Everything the bar's model browser needs from the chip. */
export interface ChipBrowserRequest {
    /** The heading the browser names the chat by: its space. */
    brainName: string;
    /** The chat's model. */
    current: {
        provider: string;
        model: string;
    } | null;
    onApply: (model: {
        provider: string;
        model: string;
    }) => void;
    onClose: () => void;
}
/** Registration-side face for the chip and its notice. */
export interface BrainChipInjected {
    hooks: {
        /** The presets of this chat's space, bound by the renderer as useBrainSwitcher. The chip reads whether the chat's own can answer. */
        brainSwitcher: SnapshotStore<BrainSwitcherState>;
    };
    /** Read the presets of this chat's space. */
    load: (session: BrainSessionSummary) => Promise<void>;
    /** Move this chat to another preset of its space; the notice's way out of a block. */
    select: (brainId: string, session: BrainSessionSummary) => Promise<void>;
    /** Whether this session supports model reads and writes. An addressed subagent does not. */
    available: boolean;
    /** The chat's shared model directory. */
    directory: ChipDirectorySource;
    /** Refresh the directory. */
    loadModels: () => void;
    /**
     * Put the chat on a model at an effort.
     * @returns whether the host accepted it.
     */
    selectModel: (choice: ModelChoice) => Promise<boolean>;
    /** The store holding one chat's composer block. Undefined where no conversation service is composed. */
    composerBlock?: (sessionId: string) => ComposerBlockSource | undefined;
    /** Open the Models pane. */
    openBrains?: () => void;
    /** Open the key field for a route, or the account list with no route named. */
    addKey?: (provider?: string) => void;
    /** Open the sign-in surface. */
    signIn?: () => void;
    /** Render the model browser over the window. Absent wherever the tool rail is not composed. */
    renderModelBrowser?: (request: ChipBrowserRequest) => ReactNode;
    /** The model router's routes and the chat's model write. */
    router?: RouterActions;
    /** Read the router's settings and the models of the chat's company; null when the router is absent. */
    routerChoices?: (sessionId: string, own: {
        provider: string;
        model: string;
    } | null) => Promise<ChipChoices | null>;
    /** Write the router's mode, slider or unticked models. */
    routerSettings?: (patch: RouterSettingsPatch) => Promise<void>;
    /** The name of the command-line app a Terminal chat launches; `''` when none is known. */
    terminalApp?: (presetId: string | undefined) => Promise<string>;
}
/** Full slot component props. */
export type BrainChipProps = PropsRuntime<'conversation.input.model'> & PropsLocale<'idealize-activity'> & InjectFace<BrainChipInjected>;
/** The translator the chip's parts share. */
export type Translate = BrainChipProps['t'];
/**
 * A model's name without the maker's prefix, which the route's catalogue
 * repeats on every row ("DeepSeek: DeepSeek V4 Flash").
 * @param name - the catalogue name.
 * @returns the readable name.
 */
export declare function readableModel(name: string): string;
/**
 * The word the chip shows after the model's name.
 * @param mode - how the router behaves for this chat; undefined where it does not route.
 * @param t - the translator.
 * @returns "Auto", "Ask me", or nothing when the model is fixed.
 */
export declare function modeWord(mode: RouterMode | undefined, t: Translate): string;
/**
 * A model's price on its row: what a million written tokens cost.
 * @param price - the price the router holds.
 * @param t - the translator.
 * @returns "$15 / M", "Free", or nothing when no price is known.
 */
export declare function priceLabel(price: RouterChoice['price'], t: Translate): string;
/**
 * The unticked models after one row's tick changes. A model behind a key gateway follows the
 * tick of the route the gateway fronts, so ticking it clears both keys.
 * @param excluded - the unticked models now.
 * @param row - the row whose tick changed.
 * @param allowed - whether the row is now ticked.
 * @returns the list to write.
 */
export declare function excludedAfter(excluded: readonly string[], row: {
    provider: string;
    model: string;
}, allowed: boolean): string[];
/** What the chip and its notice both read about one chat. */
export interface BrainChipView {
    session: BrainSessionSummary | undefined;
    space: SpaceId;
    /** The presets of the chat's space. */
    brains: readonly BrainOption[];
    /** The chat's own preset, when its space lists it. */
    current: BrainOption | undefined;
    /** The chat's model, by the directory. */
    model: ModelChoice | null;
    /** The chat's model by its readable name; undefined until the directory knows it. */
    modelName: string | undefined;
    /** The chat's model has no route, or its preset's route has no account. */
    blocked: boolean;
    /** The router's record for this chat. */
    routed: ReturnType<typeof readRouter>;
}
/** The projection read, split out so its type names itself. */
declare function readRouter(useSessions: BrainChipProps['useSessions'], sessionId: BrainChipProps['sessionId']): import("@idealize/router/client").RouterProjection | undefined;
/**
 * Read one chat's model, block and routing record.
 * @param props - the seat's composed props.
 * @returns the view.
 */
export declare function useBrainChipView(props: Pick<BrainChipProps, 'sessionId' | 'useSessions' | 'useBrainSwitcher' | 'load' | 'directory' | 'composerBlock'>): BrainChipView;
/**
 * The composer's model chip and its panel.
 * @param props - composed slot props.
 * @returns the chip, or null for a session with no model reads.
 */
export declare function BrainChip(props: BrainChipProps): import("react").JSX.Element | null;
export {};
//# sourceMappingURL=BrainChip.d.ts.map