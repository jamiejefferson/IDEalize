/**
 * @idealize/activity-pills — browser half: the composer's three-dot overflow
 * control on the `conversation.input.access` seat, holding the project's
 * access mode (handed in by the composer) and the brain switcher, which offers
 * the brains of THIS chat's space in place of the composer's model dropdown;
 * and the `activityPills` service, the controller the welcome card
 * (`@idealize/ui-bar`) launches an activity brain through so the free-tokens
 * route and the roster default keep one owner. The composer's
 * `conversation.input.dock` seat gets nothing from this package: the overflow
 * panel is the only brain control on a started chat.
 * @module @idealize/activity-pills/client
 */
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
import { type ActivityPillsFace } from './pills-store.ts';
import { type ActivityKey } from './locales.ts';
export { BrainSwitcher, brainMeta } from './BrainSwitcher.tsx';
export { ComposerOverflow } from './ComposerOverflow.tsx';
export type { ComposerBlockSource, ComposerOverflowInjected, ComposerOverflowProps } from './ComposerOverflow.tsx';
export type { BrainSwitcherInjected, BrainSwitcherProps } from './BrainSwitcher.tsx';
export { BrainSwitcherController, composeBrains, launchOf } from './brain-switcher.ts';
export type { BrainAgent, BrainOption, BrainSessionSummary, BrainSwitcherReads, BrainSwitcherState, BrainSwitcherWrites, TerminalLaunchTable, } from './brain-switcher.ts';
export { ActivityPillsController } from './pills-store.ts';
export type { ActivityAvailabilityMap, ActivityModelSelection, ActivityPill, ActivityPillsFace, ActivityPillsState, PillSessionSummary, PillsApi } from './pills-store.ts';
export type { ActivityModel, PillAvailability, PillReason, Surface, TerminalRun } from '../availability.ts';
export type { ActivityKey } from './locales.ts';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** The brain switcher's copy. */
        'idealize-activity': ActivityKey;
    }
}
/**
 * The activity-brain controller as a cordis service, for the welcome card in
 * `@idealize/ui-bar`: one controller owns the free-tokens route and the roster
 * default, whichever surface selects an activity brain.
 */
export interface ActivityPillsHost {
    /** The wired face over the controller the brain switcher also uses. */
    face: () => ActivityPillsFace;
}
declare module '@deepseek-ai/cordis' {
    interface Context {
        activityPills: ActivityPillsHost;
    }
}
/** Required services. */
export declare const inject: string[];
/**
 * Client plugin body: the composer's brain switcher and the `activityPills` service.
 * @param ctx - client root context.
 */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map