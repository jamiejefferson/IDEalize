/**
 * Activity-brain controller: which activity brain the current chat runs and
 * which one new chats get. The welcome card (through the `activityPills`
 * service) and the composer's brain switcher both select activity brains
 * through one instance of it.
 *
 * An activity brain is one of five named presets. Selecting it does two
 * things: when the current session is still blank the host recomposes that
 * session on the preset (a started conversation keeps the preset it began
 * with, as the host refuses the swap); on a started session the selection
 * changes the session's MODEL instead, to the one the host maps to that
 * activity (`activityModel`); and the preset becomes the roster default, so
 * every new chat opens on it. Free additionally moves the model policy to the
 * free-tokens auto route through the injected `freeRoute` hook.
 */
import type { IApiClient } from '@deepseek-ai/dsh-api-remotes/client';
import { type SnapshotStore } from '@deepseek-ai/dsh-client-runtime/client';
import type { PillAvailability } from '../availability.ts';
/** The wired face over one controller, as the `activityPills` service publishes it. */
export interface ActivityPillsFace {
    hooks: {
        /** Roster snapshot: the activity brains the host serves and the roster default. */
        activityPills: SnapshotStore<ActivityPillsState>;
    };
    /** Read the roster. */
    load: () => Promise<void>;
    /** Make one activity brain current for the given session (and for new chats). */
    select: (id: string, session?: PillSessionSummary) => Promise<void>;
}
/** One activity brain the roster can serve. */
export interface ActivityPill {
    /** Preset id; also the locale key suffix and glyph key. */
    id: string;
    /** Roster display name, shown when the locale carries no pill label. */
    name?: string;
    /** Whether the pill may be selected now (ready until the host answers). */
    availability: PillAvailability;
}
/** Roster snapshot. */
export interface ActivityPillsState {
    status: 'idle' | 'loading' | 'ready' | 'error';
    /** The activity presets the roster serves, in roster order. */
    pills: readonly ActivityPill[];
    /** The roster default: what a session that names no preset gets. */
    defaultId: string;
    /** The brain whose selection is in flight, null when idle. */
    busy: string | null;
    /** A rejected select's message, cleared by the next attempt. */
    error: string | null;
}
/** What the controller needs to know about the current session. */
export interface PillSessionSummary {
    id: string;
    /** False once a turn has run; the host refuses the swap from then on. */
    blank: boolean;
    /** The preset the session already runs, when the summary reports one. */
    agentPreset?: string;
}
/** The wire faces the controller calls. */
export type PillsApi = Pick<IApiClient, 'agentPresets' | 'settings' | 'sessions'>;
/** One provider route + model id, as the host's activity-model route reports it. */
export interface ActivityModelSelection {
    provider: string;
    model: string;
}
/** The host's activity-model answer: the model and state per activity brain. */
export type ActivityAvailabilityMap = Readonly<Record<string, PillAvailability>>;
/** Reads the roster, recomposes the blank session, and writes the default. */
export declare class ActivityPillsController {
    private readonly api;
    /** The session a selection acts on, when there is one. */
    private readonly currentSession;
    /** Publish an applied switch into the session list (optional). */
    private readonly onApplied?;
    /** Move the model policy to the free-tokens auto route (optional). */
    private readonly freeRoute?;
    /** The model and state per activity brain, from the host (optional). */
    private readonly availability?;
    /** Roster snapshot its consumers subscribe to. */
    readonly store: SnapshotStore<ActivityPillsState>;
    constructor(api: PillsApi, 
    /** The session a selection acts on, when there is one. */
    currentSession: () => PillSessionSummary | undefined, 
    /** Publish an applied switch into the session list (optional). */
    onApplied?: ((sessionId: string, agentPreset: string) => void) | undefined, 
    /** Move the model policy to the free-tokens auto route (optional). */
    freeRoute?: (() => Promise<void>) | undefined, 
    /** The model and state per activity brain, from the host (optional). */
    availability?: (() => Promise<ActivityAvailabilityMap>) | undefined);
    private set;
    /**
     * Read the roster and keep the five activity presets it serves.
     * @returns once the snapshot reflects the host.
     */
    load(): Promise<void>;
    /**
     * Make one activity agent current: recompose the blank current session on
     * it, give the session the brain's model, persist it as the default for
     * new chats, and route Free to the free-tokens policy.
     * @param id - the activity preset id.
     * @param session - the session the selection is for; falls back to the
     * list's current session when the caller has none.
     * @returns once every write settled.
     */
    select(id: string, session?: PillSessionSummary | undefined): Promise<void>;
}
//# sourceMappingURL=pills-store.d.ts.map