/**
 * The line above the composer that belongs to the model chip: what the router
 * just did or offers, and what the chat's model is missing, each with the
 * action that answers it. It rides the input dock because the chip's seat on
 * the tool row has no room for a sentence.
 *
 * A router set to ask first puts its question here: Switch takes the model,
 * and Stay turns it down, which the router records so it waits before asking
 * again. Any other switch or offer can be dismissed, because the router's
 * record outlives the moment and the line would otherwise sit there until the
 * next decision. A block cannot: the chat cannot answer until it clears.
 * @module @idealize/activity-pills/client/BrainNotice
 */
import type { InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import { type BrainChipInjected } from './BrainChip.tsx';
/** Full slot component props. */
export type BrainNoticeProps = PropsRuntime<'conversation.input.dock'> & PropsLocale<'idealize-activity'> & InjectFace<BrainChipInjected>;
/**
 * The composer's model notice.
 * @param props - composed slot props.
 * @returns the line, or null while there is nothing to say.
 */
export declare function BrainNotice(props: BrainNoticeProps): import("react").JSX.Element | null;
//# sourceMappingURL=BrainNotice.d.ts.map