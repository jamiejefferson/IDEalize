/**
 * Renders the router's transcript line: which model this reply moved to and
 * why, a model offered for the user to take, or the chat back on its own model.
 * @module @idealize/activity-pills/client/RouterNote
 */
import type { ChatNodeViewProps } from '@deepseek-ai/dsh-client-ui-conversation/client';
import type { RouterEventData } from '@idealize/router/client';
import type { ActivityKey } from './locales.ts';
type Translate = (key: ActivityKey, params?: Record<string, string | number>) => string;
/**
 * The line's words for one router event.
 * @param data - the event.
 * @param t - activity copy.
 * @returns the headline and, when the router gave one, its reason.
 */
export declare function routerNoteText(data: RouterEventData, t: Translate): {
    headline: string;
    reason?: string;
};
/**
 * The keyed `conversation.chat.node` renderer for `kind: 'router-note'`, bound to the plugin's copy.
 * @param t - activity copy.
 * @returns the renderer.
 */
export declare function routerNoteView(t: Translate): ({ node }: ChatNodeViewProps<"router-note">) => import("react").JSX.Element;
export {};
//# sourceMappingURL=RouterNote.d.ts.map