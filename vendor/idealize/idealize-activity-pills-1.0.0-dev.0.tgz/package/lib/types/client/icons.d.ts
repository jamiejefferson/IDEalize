/** The five pill glyphs, 15×15, stroke from `currentColor` (geometry from the Paper frame 27K-0). */
import type { JSX } from 'react';
interface GlyphProps {
    /** Stroke width; the selected Coding glyph in the frame draws at 1.35. */
    strokeWidth: number;
}
/** Code glyph: two chevrons and a slash. */
export declare function IconCode({ strokeWidth }: GlyphProps): JSX.Element;
/** Diamond (four-point star) glyph. */
export declare function IconDiamond({ strokeWidth }: GlyphProps): JSX.Element;
/** Pencil glyph. */
export declare function IconPencil({ strokeWidth }: GlyphProps): JSX.Element;
/** Document glyph. */
export declare function IconDocument({ strokeWidth }: GlyphProps): JSX.Element;
/** Sparkles glyph. */
export declare function IconSparkles({ strokeWidth }: GlyphProps): JSX.Element;
/** Glyph per activity id. */
export declare const ACTIVITY_GLYPHS: Readonly<Record<string, (props: GlyphProps) => JSX.Element>>;
export {};
//# sourceMappingURL=icons.d.ts.map