/**
 * The composer's brain switcher: the control the overflow panel's Brain row
 * holds (`conversation.input.access`, through {@link ComposerOverflow}; it sat
 * on `conversation.input.model` as a chip on the tool row until 9 Sep 2026)
 * (Paper `01M0WPEDKBV54502M7YV97PZDZ` page v2, board "3 — Terminal: switching
 * brain"). It names the brain this chat is running and opens the brains that
 * work in this chat's SPACE, the current one marked.
 *
 * WHAT A SWITCH COSTS IS STATED IN THE MENU ROW, BEFORE THE CLICK. In the
 * Terminal space a brain whose shell command or provider differs restarts the
 * running shell, and its row says so; the confirm dialog then repeats it once
 * and offers Cancel and Continue. Cancel writes nothing at all.
 *
 * The switch itself never changes the chat's TOOLS. A started conversation's
 * history was produced under its preset's tools, so the host fixes that preset;
 * the space owns the tools, and the brain owns the model and the standing
 * instructions ({@link BrainSwitcherController}).
 */
import type { SnapshotStore } from '@deepseek-ai/dsh-client-runtime/client';
import type { InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { SpaceId } from '@idealize/spaces/client';
import type { ActivityKey } from './locales.ts';
import type { BrainOption, BrainSessionSummary, BrainSwitcherState } from './brain-switcher.ts';
/** Registration-side business face for the switcher. */
export interface BrainSwitcherInjected {
    hooks: {
        /** Menu snapshot bound by the renderer as useBrainSwitcher. */
        brainSwitcher: SnapshotStore<BrainSwitcherState>;
    };
    /** Read the brains of this chat's space. */
    load: (session: BrainSessionSummary) => Promise<void>;
    /** Make one brain current for this chat. */
    select: (brainId: string, session: BrainSessionSummary) => Promise<void>;
    /**
     * Open the Brains pane's add flow with the space already set. Absent
     * wherever the tool rail is not composed, and the row goes with it.
     */
    addBrain?: (space: SpaceId) => void;
}
/** Full slot component props. */
export type BrainSwitcherProps = PropsRuntime<'conversation.input.access'> & PropsLocale<'idealize-activity'> & InjectFace<BrainSwitcherInjected>;
/**
 * The line to the right of a brain's name: what choosing it costs, what it
 * runs on, or that it carries no standing instructions.
 * @param brain - the menu row's brain.
 * @param t - the row's translator.
 * @returns the meta line, empty when there is nothing to say.
 */
export declare function brainMeta(brain: BrainOption, t: (key: ActivityKey) => string): string;
/**
 * The composer's brain control.
 * @param props - composed slot props.
 * @returns the control, or null while this chat has no brains to offer.
 */
export declare function BrainSwitcher({ locked, sessionId, useSessions, useBrainSwitcher, load, select, addBrain, t }: BrainSwitcherProps): import("react").JSX.Element | null;
//# sourceMappingURL=BrainSwitcher.d.ts.map