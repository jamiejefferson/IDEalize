/**
 * The activity pill row: five preset pills directly above the composer
 * (Paper 27K-0). `ActivityPillRow` is the presentational row any surface can
 * render (the welcome card reuses it through the `activityPills` service);
 * `ActivityPills` is the composer-dock registrant that wires it to the
 * current session.
 */
import type { SnapshotStore } from '@deepseek-ai/dsh-client-runtime/client';
import type { InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { ActivityKey } from './locales.ts';
import { type ActivityPill, type ActivityPillsState, type PillSessionSummary } from './pills-store.ts';
/** Registration-side business face for the pill row. */
export interface ActivityPillsInjected {
    hooks: {
        /** Row snapshot bound by the renderer as useActivityPills. */
        activityPills: SnapshotStore<ActivityPillsState>;
    };
    /** Read the roster when the row first renders. */
    load: () => Promise<void>;
    /** Make one activity agent current for the given session (and for new chats). */
    select: (id: string, session?: PillSessionSummary) => Promise<void>;
}
/** Translate face the row needs: the pill labels and the row's accessible name. */
export type ActivityTranslate = (key: ActivityKey) => string;
/** Presentational row props. */
export interface ActivityPillRowProps {
    pills: readonly ActivityPill[];
    /** The selected preset id. */
    selected: string;
    /** The pill whose selection is in flight, null when idle. */
    busy: string | null;
    onSelect: (id: string) => void;
    /**
     * Whether clicking the selected pill also calls `onSelect` (the welcome
     * card launches on any pill, including the one already chosen). Default
     * false: a re-click of the current pill is a no-op.
     */
    selectedClickable?: boolean;
    t: ActivityTranslate;
}
/**
 * Render the pill row from plain props.
 * @param props - pills, selection, and the select handler.
 * @returns the row, or null when there are no pills.
 */
export declare function ActivityPillRow({ pills, selected, busy, onSelect, selectedClickable, t }: ActivityPillRowProps): import("react").JSX.Element | null;
/** Full slot component props. */
export type ActivityPillsProps = PropsRuntime<'conversation.input.dock'> & PropsLocale<'idealize-activity'> & InjectFace<ActivityPillsInjected>;
/**
 * The composer-dock registrant: the row bound to the current session.
 * @param props - composed slot props.
 * @returns the row, or null while the chat is blank (the welcome card shows
 * the pills then) or the roster serves no activity preset.
 */
export declare function ActivityPills({ load, select, useActivityPills, useSessions, sessionId, t }: ActivityPillsProps): import("react").JSX.Element | null;
//# sourceMappingURL=ActivityPills.d.ts.map