/**
 * The model router's line in the transcript: one keyed chat node per
 * `idealize/router` event, so a switch, an offer, or the chat going back to
 * its own model shows where it happened in the conversation (JJ, 30 Sep
 * 2026). The composer chip still carries the actions; this line only says
 * what the router did.
 * @module @idealize/activity-pills/client/router-node
 */
import type { ConversationNodeDefinition } from '@deepseek-ai/dsh-client-runtime/client';
import type { RouterEventData } from '@idealize/router/client';
declare module '@deepseek-ai/dsh-client-ui-conversation/client' {
    interface ChatNodeDataMap {
        /** One router decision the chat should see: a switch, an offer, or a return to the chat's own model. */
        'router-note': RouterEventData;
    }
}
/** Each router event is its own whole-value Context, keyed by its place in the log. */
export declare const routerNoteDefinition: ConversationNodeDefinition<RouterEventData>;
//# sourceMappingURL=router-node.d.ts.map