/**
 * The composer's overflow control: a three-dot button on the tool row that
 * holds the project's access mode, the one setting that belongs to the project
 * rather than to the work in front of the user (JJ, 9 Sep 2026: "the main ask
 * bar settings is a mess"). The brain, the model and auto-switch live on the
 * brain chip since 4 Nov 2026 ({@link BrainChip}).
 *
 * The access control is not this package's to render: the composer passes it
 * in as `control` on the {@link 'conversation.input.access'} seat, already
 * built, and this component only decides where it goes.
 *
 * The panel is portalled to the body and positioned against the trigger. The
 * composer's tool row scrolls sideways when its content asks for more
 * (`.tools` carries `overflow-x: auto`, FORK.md), and CSS forces the other
 * axis to `auto` with it, so a panel opening upward out of the row was
 * clipped away: it mounted, measured and reported itself visible while
 * painting nothing (JJ, 11 Sep 2026: "3-dot menu in the askbar not working").
 * @module @idealize/activity-pills/client/ComposerOverflow
 */
import type { PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
/** Full slot component props: the access seat's share and the locale seat. */
export type ComposerOverflowProps = PropsRuntime<'conversation.input.access'> & PropsLocale<'idealize-activity'>;
/**
 * The overflow control and its panel.
 * @param props - composed slot props; `control` is the composer's own access chip.
 * @returns the trigger, and the panel while it is open.
 */
export declare function ComposerOverflow(props: ComposerOverflowProps): import("react").JSX.Element;
//# sourceMappingURL=ComposerOverflow.d.ts.map