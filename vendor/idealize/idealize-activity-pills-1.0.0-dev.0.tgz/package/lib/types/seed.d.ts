/**
 * The five activity agents and the composition each one is seeded with.
 *
 * An activity agent is an ordinary agent preset (a directory under the
 * user preset root) whose persona carries the activity's working
 * instructions. Seeding derives each composition from the shipped `standard`
 * preset so the activity agents carry the full tool set and track upstream
 * changes to it; only the persona row's text is replaced.
 * @module @idealize/activity-pills/seed
 */
import { type ActivityDefinition } from './activities.ts';
export { ACTIVITIES, ACTIVITY_IDS, FREE_ACTIVITY_ID } from './activities.ts';
export type { ActivityDefinition } from './activities.ts';
/**
 * Derive an activity's composition text from a source composition.
 *
 * The source is parsed with the loader's own YAML dialect so `!!js`
 * expressions survive the round trip. The first `@deepseek-ai/dsh-persona`
 * row's `text` is replaced by the activity's persona; when the source carries
 * no persona row, one is prepended.
 * @param source - the source composition text (the shipped `standard` preset).
 * @param activity - the activity whose persona the result carries.
 * @returns the derived composition text.
 * @throws when the source is not a top-level list of plugin rows.
 */
export declare function deriveComposition(source: string, activity: ActivityDefinition): string;
/**
 * Read the persona text a composition carries (its special instructions).
 * @param source - the composition text.
 * @returns the first `@deepseek-ai/dsh-persona` row's text, or undefined when
 * the composition carries none or is not a list of plugin rows.
 */
export declare function personaOf(source: string): string | undefined;
/**
 * Whether a roster already carries any activity agent.
 * @param ids - the preset ids the roster reports.
 * @returns true when at least one activity id is present.
 */
export declare function hasActivityPresets(ids: Iterable<string>): boolean;
//# sourceMappingURL=seed.d.ts.map