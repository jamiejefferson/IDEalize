/**
 * @idealize/activity-pills — host half: seeds the five activity agents
 * (Coding, Design, Writing, Admin, Free) into the user preset root the first
 * time a deployment runs without any of them, so the welcome card's brain
 * step and the composer's brain switcher have brains to offer in Chat and
 * Terminal.
 *
 * Each seeded composition is the shipped `standard` preset with its persona
 * replaced ({@link deriveComposition}); metadata carries the brain's name,
 * description, and roster order. Seeding never overwrites: a root that holds
 * any of the five ids is left as it is, so a user who deletes one brain's
 * preset keeps that deletion.
 *
 * It also serves four loopback routes:
 * - `GET /idealize/activity/models` — per activity brain, the model it selects
 *   on a started chat (a started chat keeps its preset, so there the selection
 *   changes the model only) and its availability ({@link assessPills}). Free
 *   resolves to the first model of the free-tokens route; every other brain
 *   resolves to the deployment default model; `config.models` overrides either
 *   per brain.
 * - `POST /idealize/activity/surface` `{kind, provider?}` — the shell reports
 *   which surface the user is on (chat, or the desktop terminal running a
 *   subscription agent), which turns cross-provider brains into confirmations.
 * - `GET /idealize/activity/agents` — every editable agent (the presets under
 *   the user root): name, description, the model it selects, its special
 *   instructions (the composition's persona text), whether it is one of the
 *   activity brains, whether the free-tokens route pins its model (so a surface
 *   states the model rather than offering a picker), which spaces it works
 *   in ({@link presetSpaces} over the `spaces` map, so an entry the user never
 *   set reads as the computed default rather than as no spaces at all), its
 *   `access` and, for a subscription route, the route's display name.
 * - `POST /idealize/activity/agent` `{id?, name, model, instructions, spaces?}`
 *   — edit one agent, or create one when `id` is absent: the name lands in
 *   `preset.yml`, the instructions replace the persona row, the model (or null
 *   for the default) lands in this plugin's `models` setting, and `spaces`
 *   lands in its `spaces` sibling. An absent `spaces` leaves the stored list
 *   untouched, so saving a name or a model never moves a brain between spaces.
 *
 * The space owns the tools; the brain owns the model and the instructions
 * (JJ, 7 Sep 2026). A brain whose every space generates (Images, Sounds,
 * Video) composes the generation toolset only — `mediaCompositionFor` from
 * `@idealize/gen-tools` — and a brain that works in Chat or Terminal derives
 * from the shipped `standard` preset. The create and save routes apply the
 * rule to the brain's resulting spaces, and {@link repairGeneratingBrains}
 * applies it at startup to every preset under the user root that predates it,
 * keeping each preset's persona.
 *
 * `models` is a settings section (`idealize-activity-pills`) over the
 * composition config, so the Brains pane's edits persist without a restart.
 * `spaces` is its sibling in the same section: which spaces each brain works
 * in, read through `presetSpaces` (`@idealize/spaces`).
 * @module @idealize/activity-pills
 */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import { type AgentDefaultModelSettings } from '@deepseek-ai/dsh-agent-default-model';
import { type SpaceId } from '@idealize/spaces';
import { type ActivityModel } from './availability.ts';
export { assessPills, terminalRestarts } from './availability.ts';
export type { ActivityModel, AvailabilityFacts, PillAvailability, PillReason, Surface, TerminalRun, } from './availability.ts';
export { ACTIVITIES, ACTIVITY_IDS, FREE_ACTIVITY_ID, deriveComposition, hasActivityPresets, personaOf } from './seed.ts';
export type { ActivityDefinition } from './seed.ts';
/** Plugin config. */
export interface Config {
    /**
     * The preset root the activity agents are written to. Defaults to the
     * roster's own user root (`$DSH_HOME/.agent-presets`), which is where
     * `dsh-agent-presets` reads locally authored presets from.
     */
    root?: string;
    /** The shipped preset each activity composition derives from. */
    source?: string;
    /**
     * Per-brain model for started chats, keyed by activity id. Absent brains
     * resolve to the free-tokens route (Free) or the deployment default model.
     */
    models?: Record<string, ActivityModel>;
    /**
     * Which spaces each brain works in, keyed by agent preset id — the sibling
     * of {@link Config.models} in the same settings section, so one document
     * holds every per-preset decision the Brains pane makes. `settings.update`
     * merges, so writing `models` alone leaves this key intact and vice versa.
     *
     * Values are plain strings because a settings document is a file boundary:
     * `presetSpaces` (`@idealize/spaces`) narrows a stored list to the declared
     * space ids and computes the default for a preset with no entry.
     */
    spaces?: Record<string, string[]>;
    /**
     * Routes that only a terminal agent serves on subscription here (no chat
     * credential path), so a pill targeting one is refused in the chat with a
     * pointer to the terminal. Anthropic by default: Claude on subscription runs
     * as Claude Code in the desktop terminal.
     */
    terminalOnlyProviders?: string[];
    /**
     * The command-line agent that serves each terminal-only route, keyed by
     * provider (Anthropic → `claude`, Claude Code). The agents route reports
     * whether the user's login shell can find it, so the Brains pane can say
     * which brains run as a CLI in the terminal and whether that CLI is there.
     */
    terminalCliByProvider?: Record<string, string>;
    /** Environment variables holding a route's API key when the settings profile names none. */
    apiKeyEnvByProvider?: Record<string, string>;
}
/** Runtime schema for {@link Config}. */
export declare const Config: z<Config>;
/** One terminal-only route and the command-line agent that serves it, as `GET /idealize/activity/agents` reports it. */
export interface TerminalCli {
    provider: string;
    /** The executable a fresh shell types (`claude`). */
    cli: string;
    /** Whether the login shell finds it; null where the probe cannot run. */
    installed: boolean | null;
}
/**
 * The shell a CLI probe runs in: the login shell SHELL names when it exists,
 * else the first of zsh, bash and sh present; null where nothing can probe
 * (Windows, a bare image).
 * @param shell - the SHELL variable's value.
 * @param exists - whether a path exists; the file system by default.
 * @returns an absolute shell path, or null.
 */
export declare function probeShell(shell?: string | undefined, exists?: (path: string) => boolean): string | null;
/**
 * The flags that run one command in `shell` as a login shell: interactive too
 * for zsh and bash, whose rc files add to PATH; plain login for sh.
 * @param shell - an absolute shell path.
 * @returns the flag argument.
 */
export declare function probeFlags(shell: string): string;
/**
 * Whether the user's login shell resolves `cli`, or null when no shell can
 * probe (Windows, no shell present, or a shell that exits abnormally).
 * @param cli - the executable name, a single path component.
 * @returns true/false from `command -v`, null when the probe itself failed.
 */
export declare function cliInstalled(cli: string, platform?: NodeJS.Platform): Promise<boolean | null>;
/** Required services. */
export declare const inject: string[];
/**
 * A wire `spaces` field: the spaces a brain works in.
 *
 * Absent is not the same as empty. Absent means the caller is saying nothing
 * about spaces, so the stored list stands; `[]` means the brain works in none,
 * which is what an agent role is. Accepted lists are normalized to the declared
 * table order, the order {@link presetSpaces} reads a stored list back in. Only
 * launchable spaces are accepted: a brain is never assigned to Studio.
 * @param value - the raw field (wire boundary: untrusted).
 * @returns `spaces` absent for "leave it alone", present for a list to store, or the refusal.
 */
export declare function parseSpaces(value: unknown): {
    ok: true;
    spaces?: SpaceId[];
} | {
    ok: false;
};
/**
 * Derive a preset id from a display name.
 * @param name - the agent's name.
 * @returns the hyphenated lowercase id, empty when nothing survives.
 */
export declare function slugOf(name: string): string;
/** The llm-pi-ai providers section, as far as reachability reads it. */
interface LlmProvidersSection {
    providers?: Record<string, {
        apiKeyEnv?: unknown;
        models?: {
            id?: unknown;
        }[];
    }>;
}
/**
 * Resolve the model each pill selects on a started chat.
 * @param overrides - `config.models`.
 * @param llm - the llm-pi-ai settings section, for the free-tokens route.
 * @param fallback - the agent-default-model settings section.
 * @returns one selection per activity id, null when nothing resolves.
 */
export declare function resolveActivityModels(overrides: Readonly<Record<string, ActivityModel>>, llm: LlmProvidersSection | undefined, fallback: AgentDefaultModelSettings | undefined): Record<string, ActivityModel | null>;
/** What {@link repairGeneratingBrains} reads and writes. */
export interface RepairFacts {
    /** The usable presets under the user root, each with its composition text. */
    presets: readonly {
        id: string;
        name: string;
        path: string;
        composition: string;
    }[];
    /** Preset ids carrying agent roles ({@link presetSpaces}' second argument). */
    rolePresets: readonly string[];
    /** The `spaces` map of the settings section, keyed by preset id. */
    storedSpaces: Readonly<Record<string, readonly string[] | undefined>>;
}
/**
 * The presets whose composition contradicts their spaces: every space
 * generates, yet the composition is not generation-only. Each is returned with
 * the composition to write — `mediaCompositionFor` over the brain's spaces,
 * keeping the persona the composition carries (the default media persona when
 * it carries none). A preset already generation-only, or working in Chat or
 * Terminal, is not returned, so applying the result twice writes nothing the
 * second time.
 * @param facts - the presets, the roles, and the stored space map.
 * @returns one entry per preset to rewrite, in roster order.
 */
export declare function repairGeneratingBrains(facts: RepairFacts): {
    id: string;
    path: string;
    spaces: SpaceId[];
    composition: string;
}[];
/** What {@link retiredRolePresetsToRemove} reads. */
export interface RetirementFacts {
    /** Ids of the usable presets under the user root. */
    presetIds: readonly string[];
    /** The `spaces` map of the settings section, keyed by preset id. */
    storedSpaces: Readonly<Record<string, readonly string[] | undefined>>;
}
/**
 * The retired role presets to delete: each id on `RETIRED_ROLE_PRESETS` that
 * sits in the roster with no stored space list. A stored list means the person
 * placed the preset in a space after its role was retired, so it stays as an
 * ordinary brain of theirs.
 * @param facts - the roster ids and the stored space map.
 * @returns the ids to remove, in roster order.
 */
export declare function retiredRolePresetsToRemove(facts: RetirementFacts): string[];
/**
 * Seed the activity agents once the roster service is up, remove a retired
 * role's preset nobody placed in a space, then repair the presets whose
 * composition contradicts their spaces.
 * @param ctx - the host plugin context.
 * @param config - the seeding root and source preset.
 */
export declare function apply(ctx: Context, config: Config): void;
//# sourceMappingURL=index.d.ts.map