/**
 * The auto-selection policy: a pure decision over the preference weights and
 * the live facts. The dominant weight orders the tiers — cost or speed puts
 * free tokens first (the engine's own `auto` router already picks the
 * cheapest-then-fastest healthy free route per call), intelligence puts the
 * ChatGPT subscription first. The first tier whose facts say "usable" wins.
 * Paid keyed routes join in a later drop; today the policy never routes to a
 * provider it cannot verify credentials for.
 */
export interface PolicyWeights {
    cost: number;
    speed: number;
    intelligence: number;
}
/** What the policy knows about the free-tokens route and its engine. */
export interface FreetokensFacts {
    /** Models on the registered freetokens route; 0 = no route. */
    routeModels: number;
    /** Whether anything answers at the engine origin right now. */
    engineUp: boolean;
    /**
     * Enabled + healthy upstream provider keys in the engine; undefined when
     * unknowable (an adopted engine this host did not provision).
     */
    usableKeys: number | undefined;
}
/** Everything the auto policy decides from. */
export interface PolicyFacts {
    freetokens: FreetokensFacts;
    /** OAuth provider ids with stored credentials (e.g. openai-codex). */
    signedIn: string[];
    /** Live model ids per provider, from the directory. */
    models: Record<string, string[]>;
}
/** The policy's answer: a model to select, or none, with the reason the models page shows. */
export interface PolicyDecision {
    /** Absent when nothing usable is available. */
    choice?: {
        provider: string;
        model: string;
    };
    reason: string;
}
type Dominant = 'cost' | 'speed' | 'intelligence';
/**
 * The heaviest weight; ties resolve towards cost — free-first is the product promise.
 * @param weights - the three relative preference weights.
 * @returns the dominant axis.
 */
export declare function dominantWeight(weights: PolicyWeights): Dominant;
/**
 * Pick the subscription model. The flagship carries intelligence; when speed
 * leads the weights a `-mini` variant of it is preferred if one exists.
 * @param models - the live model ids on the subscription provider.
 * @param dominant - the dominant preference axis.
 * @returns the chosen model id, or undefined when the list is empty.
 */
export declare function subscriptionModel(models: string[], dominant: Dominant): string | undefined;
/**
 * Decide the auto model: free when the engine is usable and cost leads, the
 * subscription when signed in and intelligence or speed leads, otherwise
 * whichever is available.
 * @param weights - the preference weights.
 * @param facts - the current route, sign-in, and directory facts.
 * @returns the decision with its reason; `choice` is absent when neither route is usable.
 */
export declare function choose(weights: PolicyWeights, facts: PolicyFacts): PolicyDecision;
export {};
//# sourceMappingURL=policy.d.ts.map