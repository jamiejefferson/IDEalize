/** The /idealize/models page: default model, auto preferences, spend link. */
/**
 * Render the models page.
 * @returns the complete HTML document.
 */
export declare function modelsPage(): string;
//# sourceMappingURL=models-page.d.ts.map