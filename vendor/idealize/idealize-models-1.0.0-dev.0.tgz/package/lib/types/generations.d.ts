/**
 * Generation spend for the Brains pane's Budget tab. Images, video and sound
 * run through fal, which bills per generated unit and reports what it billed
 * through its Platform API (`GET https://api.fal.ai/v1/models/usage`,
 * `Authorization: Key <key>`). Two folds meet here:
 *
 * - a local count of generations from `artefact/created` session events
 *   (`record.provenance.provider` and `.model` name the backend and the
 *   endpoint), per month and year to date, so the table lists what was made
 *   even before fal answers;
 * - fal's own usage rows — billed quantity, unit, currency and `cost_total`
 *   with discounts applied — read per endpoint per calendar month for the
 *   current year and cached at `<home>/service-catalogues/fal-usage.json`
 *   with the instant they were read, refreshed after the configured age.
 *
 * Nothing here prices a generation itself: a row fal has not reported stays
 * unpriced, and a failed read is reported as its error text.
 */
import type { SessionEvent } from '@deepseek-ai/dsh-session';
/** The fal backend id, as `@idealize/services` registers it. */
export declare const FAL_PROVIDER = "fal";
/** fal's usage report; `start`, `end`, `timeframe`, `expand` and `cursor` are query parameters. */
export declare const FAL_USAGE_URL = "https://api.fal.ai/v1/models/usage";
/** One backend endpoint's local count for a period. */
export interface GenerationCount {
    /** How many artefacts the endpoint produced. */
    count: number;
    /** The media type of the artefacts, from the first one seen. */
    mediaType: string;
}
/** Local counts per backend, then per endpoint (the artefact's `provenance.model`). */
export type PeriodGenerations = Record<string, Record<string, GenerationCount>>;
/** The local fold: month-to-date and year-to-date counts with their per-endpoint detail. */
export interface GenerationPeriods {
    month: PeriodGenerations;
    year: PeriodGenerations;
}
/**
 * A fresh, empty fold target.
 * @returns empty month and year detail.
 */
export declare function emptyGenerationPeriods(): GenerationPeriods;
/**
 * Fold one session log's committed artefacts into per-endpoint counts.
 * @param events - the session's events.
 * @param now - the instant that fixes the current month and year (ms).
 * @param into - the counts to add to; a fresh pair when omitted.
 * @returns the accumulated counts.
 */
export declare function foldGenerations(events: readonly SessionEvent[], now: number, into?: GenerationPeriods): GenerationPeriods;
/** One billed line as fal reports it, folded per endpoint within one month. */
export interface FalBilledLine {
    endpoint: string;
    /** fal's billing unit for the endpoint (`image`, `video`, a compute unit). */
    unit: string;
    /** Billed quantity in `unit`. */
    quantity: number;
    /** Amount charged after discounts, in `currency`. */
    cost: number;
    /** ISO 4217 code. */
    currency: string;
}
/** What the fal usage cache file holds: the current year's billed lines per calendar month. */
export interface FalUsageCache {
    /** ISO instant the report was read. */
    fetchedAt: string;
    /** The calendar year the months belong to. */
    year: number;
    /** Billed lines by `YYYY-MM`. */
    months: Record<string, FalBilledLine[]>;
}
/**
 * Read the billed lines out of one page of fal's `/models/usage` payload,
 * requested with `timeframe=month` and `expand=time_series`, into the cache's
 * per-month table. A bucket is filed under its UTC calendar month; a line
 * missing a required field is skipped rather than billed at zero.
 * @param payload - the parsed JSON body of one page.
 * @param into - the per-month table to add to.
 * @returns the `next_cursor` to follow, or undefined when the page was the last.
 */
export declare function falUsageLines(payload: unknown, into: Record<string, FalBilledLine[]>): string | undefined;
/**
 * Read the last fal usage report this home fetched, for the given year only.
 * @param home - the harness home directory.
 * @param year - the calendar year the report must cover.
 * @returns the cache, or undefined when there is no readable one for that year.
 */
export declare function readFalUsageCache(home: string, year: number): FalUsageCache | undefined;
/**
 * Record the usage fal just reported.
 * @param home - the harness home directory.
 * @param cache - the report to write.
 * @returns the cache as written.
 */
export declare function writeFalUsageCache(home: string, cache: FalUsageCache): FalUsageCache;
/**
 * This year's fal usage, read from fal when the cache is missing or older
 * than `maxAgeMs`, else from disk. A failed read keeps the cache it has and
 * reports the failure; a failed read with no cache reports the failure alone.
 * @param options.home - the harness home directory.
 * @param options.key - the stored fal API key.
 * @param options.fetchImpl - the fetch to use (tests inject one).
 * @param options.maxAgeMs - how old a cache may be before it is refreshed; 0 disables fetching.
 * @param options.now - the current instant (ms).
 * @returns the usage with its read time when one is known, and the error text when the read failed.
 */
export declare function refreshFalUsage(options: {
    home: string;
    key: string;
    fetchImpl: typeof fetch;
    maxAgeMs: number;
    now: number;
}): Promise<{
    usage?: FalUsageCache;
    error?: string;
}>;
/**
 * One endpoint with generations this month, as the Budget tab's table lists
 * it: the local count, and what fal billed for it where fal reported it.
 */
export interface GenerationRow {
    provider: string;
    /** The endpoint id (`fal-ai/flux/dev`). */
    model: string;
    /** The artefacts' media type, from the local fold; absent for an endpoint only fal reported. */
    mediaType?: string;
    /** Artefacts this app made this month; 0 for an endpoint only fal reported. */
    count: number;
    /** What fal billed this month, with discounts applied. */
    billed?: {
        quantity: number;
        unit: string;
        cost: number;
        currency: string;
    };
}
/** Billed totals per currency: fal may bill one account in one currency, so this is usually one entry. */
export type BilledTotals = Record<string, number>;
/**
 * The Budget tab's generation rows for this month and the billed totals fal
 * reported, this month and year to date.
 * @param local - the local fold of committed artefacts.
 * @param usage - fal's cached report, when one is known.
 * @param now - the instant that fixes the current month (ms).
 * @returns rows by billed cost then count descending, and the per-currency totals fal reported.
 */
export declare function generationRows(local: GenerationPeriods, usage: FalUsageCache | undefined, now: number): {
    rows: GenerationRow[];
    billed?: {
        month: BilledTotals;
        year: BilledTotals;
    };
};
//# sourceMappingURL=generations.d.ts.map