/**
 * Where token prices come from, besides the person typing them. OpenRouter
 * publishes every model's price inside its `/api/v1/models` payload, so a
 * connected OpenRouter route prices its own usage; the prices are cached on
 * disk beside the media catalogues (`<home>/service-catalogues/openrouter-prices.json`)
 * with the instant they were read, and refreshed when the cache is older
 * than the configured age. The model catalogue the app ships (pi-ai's
 * provider data, read through `@idealize/services`) carries a published price
 * per catalogue model, which prices a metered route the person has not typed
 * a price for. Nothing here estimates: a model no source prices stays
 * unpriced, and the sources rank typed price, then OpenRouter's directory,
 * then the shipped catalogue.
 *
 * This module also validates the `POST /idealize/models/prices` body — the
 * one place a price enters the settings document from the pane.
 */
import type { TokenPrice, TokenPriceTable } from './pricing.ts';
/** The OpenRouter route id, as `llm-pi-ai` declares it. */
export declare const OPENROUTER_PROVIDER = "openrouter";
/** OpenRouter's public model directory; each row carries its `pricing`. */
export declare const OPENROUTER_MODELS_URL = "https://openrouter.ai/api/v1/models";
/**
 * Who supplied a price: the person, the public market directory the app
 * fetches, or the model catalogue it ships. The market's own name stays in
 * the payload beside the prices, so a surface can say which market without
 * naming a provider in its source (the mode/provider boundary, AC-03).
 */
export type PriceSource = 'user' | 'market' | 'catalogue';
/** A price with its origin, so the pane can say where a figure came from. */
export type PricedModel = TokenPrice & {
    source: PriceSource;
};
/** Prices with their origin, per provider then model. */
export type PricedTable = Record<string, Record<string, PricedModel>>;
/**
 * What OpenRouter's directory says about one model beyond its price, for the
 * model browser: every field is optional, because a row states what it states.
 */
export interface OpenRouterModelDetail {
    name?: string;
    description?: string;
    /** When the model was listed, as an ISO date (`YYYY-MM-DD`). */
    released?: string;
    /** The context window in tokens. */
    contextLength?: number;
    /** What the model reads: `text`, `image`, `file`, `audio`, `video`. */
    inputModalities?: string[];
    /** Whether the model takes tool definitions. */
    tools?: boolean;
    /** Whether the model reasons before it answers. */
    reasoning?: boolean;
}
/** What the price cache file holds. */
export interface OpenRouterPriceCache {
    /** ISO instant the directory was read. */
    fetchedAt: string;
    /** USD per million tokens, by OpenRouter model id. */
    prices: Record<string, TokenPrice>;
    /** Each model's description and capabilities, by OpenRouter model id; absent in a cache written before the browser. */
    details?: Record<string, OpenRouterModelDetail>;
}
/**
 * Read the prices out of an OpenRouter `/api/v1/models` payload.
 *
 * `pricing.prompt` and `pricing.completion` are required for a row to count;
 * a row missing either, or printing a non-numeric string, is skipped rather
 * than priced at zero. `input_cache_read` and `input_cache_write` are absent
 * for models whose upstream provider offers no cache discount; such a model
 * bills a cached token at its prompt price, so that is what the absent field
 * resolves to — no discount is assumed.
 * @param payload - the parsed JSON body.
 * @returns USD per million tokens by model id; empty when the payload has no usable rows.
 */
export declare function openRouterPrices(payload: unknown): Record<string, TokenPrice>;
/**
 * Read each model's description and capabilities out of an OpenRouter
 * `/api/v1/models` payload, for the model browser.
 * @param payload - the parsed JSON body.
 * @returns details by model id; empty when the payload has no usable rows.
 */
export declare function openRouterDetails(payload: unknown): Record<string, OpenRouterModelDetail>;
/**
 * Read the last OpenRouter price list this home fetched.
 * @param home - the harness home directory.
 * @returns the cache, or undefined when there is no readable one.
 */
export declare function readOpenRouterPriceCache(home: string): OpenRouterPriceCache | undefined;
/**
 * Record the prices OpenRouter just published.
 * @param home - the harness home directory.
 * @param prices - the converted per-million prices.
 * @param fetchedAt - the instant they were read (ms).
 * @param details - each model's description and capabilities, when read.
 * @returns the cache as written.
 */
export declare function writeOpenRouterPriceCache(home: string, prices: Record<string, TokenPrice>, fetchedAt: number, details?: Record<string, OpenRouterModelDetail>): OpenRouterPriceCache;
/**
 * The OpenRouter price list, refreshed from the directory when the cache is
 * missing or older than `maxAgeMs`, else read from disk. A failed fetch keeps
 * the cache it has; a failed fetch with no cache yields nothing, which prices
 * nothing.
 * @param options.home - the harness home directory.
 * @param options.fetchImpl - the fetch to use (tests inject one).
 * @param options.maxAgeMs - how old a cache may be before it is refreshed; 0 disables fetching.
 * @param options.now - the current instant (ms).
 * @returns the prices with their read time, or undefined.
 */
export declare function refreshOpenRouterPrices(options: {
    home: string;
    fetchImpl: typeof fetch;
    maxAgeMs: number;
    now: number;
}): Promise<OpenRouterPriceCache | undefined>;
/**
 * The price table cost is computed from, lowest source first: the shipped
 * catalogue's prices per route, OpenRouter's published prices under its
 * route, then the person's own entries over both, each marked with its source.
 * @param user - the configured `tokenPrices`.
 * @param openRouter - the cached OpenRouter prices, when the route is connected and the currency is USD.
 * @param shipped - the catalogue prices per route, when the currency is USD; a route absent here has none.
 * @returns the merged, source-marked table.
 */
export declare function effectivePrices(user: TokenPriceTable, openRouter: Record<string, TokenPrice> | undefined, shipped?: TokenPriceTable): PricedTable;
/** A valid `POST /idealize/models/prices` body: a price to store, or `null` to clear one. */
export interface PriceWrite {
    provider: string;
    model: string;
    price: TokenPrice | null;
}
/**
 * Validate a `POST /idealize/models/prices` body. Every price kind must be
 * present and a finite non-negative number: a missing kind is never read as
 * free.
 * @param body - the parsed JSON body.
 * @returns the write to apply, or the reason it is refused.
 */
export declare function parsePriceBody(body: unknown): {
    ok: true;
    write: PriceWrite;
} | {
    ok: false;
    error: string;
};
//# sourceMappingURL=prices.d.ts.map