/**
 * Key headroom on the free-tokens engine, for the auto policy: how many
 * upstream provider keys the engine's own router would still use. Reading it
 * needs an admin session. The engine's sessions last for days and every login
 * stores another one, so the reader signs in once and carries that session
 * from pass to pass, signing in again only when the engine refuses it (401:
 * expired, or a restarted engine with a fresh database).
 */
/** Reads the engine's usable-key count, holding one admin session between reads. */
export interface EngineKeyReader {
    /**
     * Count the keys the engine's router would use.
     * @param origin - The engine's origin, without the `/v1` suffix.
     * @param password - The admin password this host provisioned the engine with.
     * @returns the usable-key count, or undefined when it cannot be read.
     */
    usableKeys(origin: string, password: string): Promise<number | undefined>;
}
/**
 * Build a usable-key reader. It never throws: a failed sign-in, an unreachable
 * engine or an unexpected answer all read as "unknown".
 * @returns the reader, with no session held yet.
 */
export declare function createEngineKeyReader(): EngineKeyReader;
//# sourceMappingURL=engine-keys.d.ts.map