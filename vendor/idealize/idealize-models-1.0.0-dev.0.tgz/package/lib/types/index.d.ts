/**
 * IDEalize model management: the host-served models panel. Reads the live
 * provider directory + model lists from the llm service, sets the default
 * model through the agent-default-model settings section, and stores the
 * auto-selection preference weights (cost / speed / intelligence). With mode
 * `auto` the policy (policy.ts) re-evaluates on a timer and keeps the default
 * pointed at the best usable route — free tokens first while the engine has
 * key headroom, the ChatGPT subscription otherwise. A chat pinned to a model
 * keeps it; the default only steers new chats and unpinned scheduled runs.
 * The in-app client-slot panel follows once JJ settles the design; this page
 * is the working draft of it.
 *
 * HTTP surface (loopback-fenced; mutations demand the header):
 * - GET  /idealize/models — the panel page.
 * - GET  /idealize/models/state — providers+models (display names resolved
 *   through `@idealize/services`' directory, each with where its catalogue
 *   comes from), default, mode, auto verdict, preferences, and `readAt`.
 * - POST /idealize/models/default — {provider, model} becomes the default (switches mode to manual).
 * - POST /idealize/models/mode — {mode: 'manual'|'auto'}; auto evaluates at once.
 * - POST /idealize/models/preferences — {cost, speed, intelligence} weights.
 * - GET  /idealize/models/usage?scope=<project path> — month-to-date and
 *   year-to-date tokens per billing category (usage.ts), the project list,
 *   the monthly budget, and the cost breakdown computed from the configured
 *   token prices and subscription plan costs (pricing.ts), plus one row per
 *   model with usage this month; no scope folds every session. Three sources
 *   price a token, the person's entry over OpenRouter's published directory
 *   over the catalogue the app ships (prices.ts). The same pass counts the
 *   media the app generated this month per endpoint, and reports what fal
 *   billed for it (generations.ts).
 * - GET  /idealize/models/work — working time and cost per project for the
 *   Time & cost pane: each project's chats' turns unioned into working
 *   spans, pauses under five minutes bridged (worktime.ts), as seconds for
 *   today, this month and all time, beside what the project's metered
 *   tokens cost this month at the known prices; the totals union every log
 *   and add the subscription plans, which belong to no one project.
 * - POST /idealize/models/budget — {monthlyTokenBudget} (0 clears it).
 * - POST /idealize/models/prices — {provider, model, price} stores one
 *   model's token prices; `price: null` clears it.
 */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import type { SubscriptionPlan, TokenPrice } from './pricing.ts';
export { costBreakdown, meteredCost, modelRows, subscriptionCost } from './pricing.ts';
export type { CostBreakdown, CostTotals, ModelCostRow, SubscriptionPlan, SubscriptionPlanTable, TokenPrice, TokenPriceTable, } from './pricing.ts';
export { effectivePrices, OPENROUTER_MODELS_URL, OPENROUTER_PROVIDER, openRouterPrices, parsePriceBody, readOpenRouterPriceCache, refreshOpenRouterPrices, writeOpenRouterPriceCache, } from './prices.ts';
export type { OpenRouterPriceCache, PricedModel, PricedTable, PriceSource, PriceWrite } from './prices.ts';
export { emptyGenerationPeriods, FAL_PROVIDER, FAL_USAGE_URL, falUsageLines, foldGenerations, generationRows, readFalUsageCache, refreshFalUsage, writeFalUsageCache, } from './generations.ts';
export type { BilledTotals, FalBilledLine, FalUsageCache, GenerationCount, GenerationPeriods, GenerationRow, PeriodGenerations, } from './generations.ts';
export { categoryOf, emptyUsagePeriods, foldUsage, totalTokens, USAGE_CATEGORIES } from './usage.ts';
export type { CategoryFacts, ModelTokens, PeriodModels, UsageCategory, UsagePeriods, UsageTotals } from './usage.ts';
export { foldWorkSpans, foldWorkTime, mergeSpans, turnSpans, WORK_GAP_MS, workBounds, workTotals } from './worktime.ts';
export type { WorkBounds, WorkSpan, WorkTotals } from './worktime.ts';
/** Auto-selection preference weights (relative, not percentages), mode, and the monthly token budget. */
export interface ModelsConfig {
    /** Weight for the free-first axis; the heaviest of the three decides the auto choice, ties favouring cost. */
    cost?: number;
    /** Weight for response speed; when it leads, a `-mini` subscription variant is preferred. */
    speed?: number;
    /** Weight for model capability; when it leads, the subscription flagship is preferred over the free route. */
    intelligence?: number;
    /** `auto` lets the policy re-evaluate the default model every three minutes; `manual` leaves the user's pick alone. */
    mode?: 'manual' | 'auto';
    /** Tokens per calendar month the Budget tab measures against; 0 = no budget set. */
    monthlyTokenBudget?: number;
    /** ISO 4217 code the Budget tab's costs are shown in; token prices and plan costs are entered in this currency. */
    currency?: string;
    /** Token prices per provider then model, in currency units per million tokens; a priceless route shows as unpriced, never estimated. */
    tokenPrices?: Record<string, Record<string, TokenPrice>>;
    /** Monthly plan cost per subscription provider; `since` (YYYY-MM) starts the year-to-date count part-way through the year. */
    subscriptionCosts?: Record<string, SubscriptionPlan>;
    /** Minutes a cached OpenRouter price list is trusted before the usage route re-reads the directory; 0 never fetches. */
    openRouterPriceRefreshMinutes?: number;
    /** Minutes a cached fal usage report is trusted before the usage route re-reads it; 0 never fetches. */
    falUsageRefreshMinutes?: number;
}
export declare const Config: z<ModelsConfig>;
export declare function apply(ctx: Context, config: ModelsConfig): void;
//# sourceMappingURL=index.d.ts.map