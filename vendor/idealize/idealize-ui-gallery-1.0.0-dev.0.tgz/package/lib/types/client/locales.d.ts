/** `idealize-gallery` namespace dictionaries: the Gallery view and the generation settings strip. */
/** Simplified Chinese dictionary (the key-set source of truth). */
export declare const zh: {
    readonly 'view.gallery': "图片";
    readonly 'view.motion': "视频";
    readonly 'gallery.empty.image.title': "还没有生成图片";
    readonly 'gallery.empty.image.body': "描述你想要的画面，生成结果会收在这里。";
    readonly 'gallery.empty.video.title': "还没有生成视频";
    readonly 'gallery.empty.video.body': "描述你想要的镜头，生成结果会收在这里。";
    readonly 'gallery.empty.audio.title': "还没有生成声音";
    readonly 'gallery.empty.audio.body': "描述你想要的声音，生成结果会收在这里。";
    readonly 'gallery.status.running': "正在生成…";
    readonly 'gallery.status.thinking': "正在思考…";
    readonly 'gallery.status.failed': "生成失败";
    readonly 'gallery.turn.nothing': "这一轮没有生成任何内容。";
    readonly 'gallery.turn.stopped': "已停止。";
    readonly 'gallery.turn.failed': "这一轮失败了：{reason}";
    readonly 'gallery.retry': "重试";
    readonly 'gallery.retrying': "正在重新提交…";
    readonly 'gallery.retry.failed': "重新提交失败";
    readonly 'gallery.open': "打开原文件";
    readonly 'gallery.enlarge': "放大查看：{prompt}";
    readonly 'gallery.close': "关闭";
    readonly 'gallery.archive': "归档";
    readonly 'gallery.reveal': "显示文件";
    readonly 'gallery.keep': "保留";
    readonly 'gallery.archived.fold': "已归档（{count}）";
    readonly 'gallery.detail.type': "类型";
    readonly 'gallery.detail.size': "大小";
    readonly 'gallery.detail.aspect': "画幅";
    readonly 'gallery.detail.path': "文件";
    readonly 'gallery.settings.aspect': "画幅";
    readonly 'gallery.settings.count': "数量";
    readonly 'gallery.settings.duration': "时长";
    readonly 'gallery.settings.length': "长度";
    readonly 'gallery.settings.resolution': "分辨率";
    readonly 'gallery.settings.auto': "自动";
    readonly 'gallery.settings.unset': "–";
    readonly 'gallery.settings.seconds': "{seconds} 秒";
    readonly 'gallery.settings.secondsUnit': "秒";
    readonly 'gallery.settings.hint': "所选设置会附在消息末尾发送。";
};
/** English dictionary. */
export declare const en: Record<GalleryKey, string>;
/** Keys of this plugin's dictionary. */
export type GalleryKey = keyof typeof zh;
/** Dictionary namespace owned by this plugin. */
export declare const NS = "idealize-gallery";
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** The Gallery's copy. */
        'idealize-gallery': GalleryKey;
    }
}
//# sourceMappingURL=locales.d.ts.map