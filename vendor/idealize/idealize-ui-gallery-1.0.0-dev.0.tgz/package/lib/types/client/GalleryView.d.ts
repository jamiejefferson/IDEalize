/**
 * The Gallery view: one image-only tile per artefact, newest first, at 320px
 * or wider (JJ, 2 Sep 2026: the image is the point; the copy waits for the
 * enlarged view; 8 Sep 2026: "use bigger images and hide ui elements on assets
 * until hover"). A resting tile shows nothing but its media; Reveal, Keep and
 * Archive appear in its corner on hover or focus. Clicking a tile opens it
 * full size with its prompt, type, size and project path beside the same
 * three verbs. A video tile is a muted, silent preview behind a play glyph;
 * the enlarged view carries the native player. Archived tiles leave the grid
 * for an "Archived (n)" fold under it.
 *
 * Between the person's message and the tile, the grid reads like a chat: a
 * turn still thinking shows the prompt and "Thinking…", a dispatched
 * generation shows it and "Generating…", and a turn that ended without a
 * generation shows the model's reply in place of a tile (JJ, 8 Sep 2026:
 * posting a message "looks like it's not working"). A failed task shows the
 * provider's own cause and a Retry that resubmits the same prompt and settings
 * as a new message (MOD-05). An empty grid explains what fills it.
 * @module @idealize/ui-gallery/client/GalleryView
 */
import type { ConvViewProps } from '@deepseek-ai/dsh-client-ui-conversation/client';
import type { InjectFace, PropsLocale } from '@deepseek-ai/dsh-client-ui-slots';
import type { GalleryArtefactKind, GalleryRow } from './contract.ts';
/** Registration-side face: the verbs that leave the view. */
export interface GalleryViewInjected {
    /**
     * Resubmit one generation task as a new user message on this chat.
     * @param row - the task to run again, with its original prompt and settings.
     * @returns null once the host accepted the message; a failure line otherwise.
     */
    retry: (row: GalleryRow) => Promise<string | null>;
    /**
     * Keep or archive one artefact through the artefact store's route; the
     * store moves the file and logs the verdict, which is what moves the tile.
     * @param artefactId - the artefact.
     * @param disposition - the verdict.
     * @returns null once the store recorded it; a failure line otherwise.
     */
    setDisposition: (artefactId: string, disposition: 'kept' | 'archived') => Promise<string | null>;
}
/**
 * Which artefact kind this grid shows. The Images space and the Video space
 * are the same grid over the same per-chat source, differing only in what they
 * show and what their empty state says.
 */
export interface GalleryViewKind {
    kind?: GalleryArtefactKind;
}
/** Full Gallery view props: the view-slot runtime share, the verbs, and the locale seat. */
export type GalleryViewProps = ConvViewProps & InjectFace<GalleryViewInjected & GalleryViewKind> & PropsLocale<'idealize-gallery'>;
/** The raw-route URL for one artefact id (same origin as the serving host). */
export declare function rawUrl(id: string): string;
/** `123456` bytes as a short human figure. */
export declare function formatBytes(bytes: number): string;
/**
 * The plain-language message the retry sends: the same request, stated the way
 * a person would. No provider or model id appears — the media preset's routing
 * chooses the model, and naming one here would pin the UI to a catalogue it
 * does not own.
 * @param row - the task being run again.
 * @returns the message text.
 */
export declare function retryMessage(row: GalleryRow): string;
/**
 * Render the Gallery grid for one chat.
 * @param props - composed slot props.
 * @returns the grid, or the empty state while the chat has generated nothing.
 */
export declare function GalleryView({ useSession, retry, setDisposition, kind, t }: GalleryViewProps): import("react").JSX.Element;
//# sourceMappingURL=GalleryView.d.ts.map