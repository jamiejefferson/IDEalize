/**
 * The Gallery's generation controls: aspect and image count, two compact
 * selects on the composer card's tool row (beside the plus and the mode
 * chips), shown only while this chat's view ring sits on the Gallery tab. The
 * entry shares the chat view's store (the ui-terminal ModeShortcut pattern),
 * so the controls appear and disappear with the tab instead of following
 * every chat in the app.
 *
 * Each choice is written into the draft as one trailing tag (see
 * `settings-tag.ts`): the composer exposes no pre-submit seam, so a control
 * that must reach the model states itself in the message.
 * @module @idealize/ui-gallery/client/GallerySettings
 */
import type { GalleryKey } from './locales.ts';
/** The view id this row belongs to. */
export declare const GALLERY_VIEW = "gallery";
/**
 * Props the row reads. Restated structurally: the entry carries a foreign
 * plugin's store, which the typed slot overloads cannot describe.
 */
export interface GallerySettingsProps {
    /** Selector hook over the chat store (the ring's active view lives here). */
    useStore: <T>(selector: (state: {
        view: string | null;
    }) => T) => T;
    /** Selector hook over this session's live input machine state. */
    useInput: <T>(selector: (state: {
        draft: string;
        locked?: boolean;
    }) => T) => T;
    /** The public input action face; the row's single write path. */
    inputActions: {
        setDraft: (text: string) => void;
    };
    /** Bound translate for the `idealize-gallery` namespace. */
    t: (key: GalleryKey, params?: Record<string, unknown>) => string;
}
/**
 * Render the aspect and count controls.
 * @param props - composed slot props.
 * @returns the control row, or null while another view is active.
 */
export declare function GallerySettings({ useStore, useInput, inputActions, t }: GallerySettingsProps): import("react").JSX.Element | null;
//# sourceMappingURL=GallerySettings.d.ts.map