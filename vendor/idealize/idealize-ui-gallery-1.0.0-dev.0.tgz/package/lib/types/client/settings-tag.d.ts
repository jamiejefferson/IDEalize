/**
 * The generation-settings tag the composer strip keeps at the end of the
 * draft.
 *
 * The composer has no pre-submit seam a plugin can occupy, so a control that
 * must reach the model states itself in the message the user sends. The strip
 * therefore maintains one trailing tag, `[aspect 16:9, duration 8, 3 images]`,
 * which the model reads alongside the prompt and turns into generation tool
 * arguments. A field at its default writes no part and a strip with every
 * field at its default writes no tag, so a user who never touches the strip
 * never sees one, and the tag stays ordinary editable text the user can delete.
 *
 * Grammar: `[part, part, …]`, where a part is `<name> <value>` for a field
 * (the name is the model's input name, except `aspect_ratio` writes `aspect`;
 * the value is one token without commas or spaces: an enum literal, a number
 * such as `45`, or `true`/`false` for a switch) or `<N> images` for the image
 * count. Parts appear in strip order, count last. A trailing bracket carrying
 * any part the current strip does not know is the user's own text and is left
 * alone.
 * @module @idealize/ui-gallery/client/settings-tag
 */
import type { GenerationField, GenerationSelection, GenerationStrip } from './contract.ts';
/** How many images one prompt may ask for, in menu order. */
export declare const GALLERY_COUNTS: readonly number[];
/** Every field at its default and one image: the draft carries no tag. */
export declare const DEFAULT_SELECTION: GenerationSelection;
/**
 * The tag part name a field writes.
 * @param name - the model's input name.
 * @returns `aspect` for `aspect_ratio`, otherwise the name itself.
 */
export declare function partName(name: string): string;
/**
 * A field's default as the tag would write it: the enum literal, the number's
 * text, `true`/`false` for a switch.
 * @param field - the field.
 * @returns the token, or undefined when the model states no default.
 */
export declare function defaultOf(field: GenerationField): string | undefined;
/**
 * The value the strip shows for one field.
 * @param field - the field.
 * @param selection - the current selection.
 * @returns the chosen value, else the field's default token, else the empty string (unset).
 */
export declare function valueOf(field: GenerationField, selection: GenerationSelection): string;
/**
 * Read the selection the draft's trailing tag states.
 * @param draft - the current composer draft.
 * @param strip - the fields and count menu the strip currently renders.
 * @returns the selection, and the draft with the tag removed. A trailing
 * bracket the strip did not write is left in the body untouched.
 */
export declare function readSettingsTag(draft: string, strip: GenerationStrip): {
    selection: GenerationSelection;
    body: string;
};
/**
 * Render one selection as its tag text.
 * @param selection - the chosen values and count.
 * @param strip - the fields and count menu the strip currently renders; a value for a field outside the strip is dropped.
 * @returns the tag, or an empty string when every part sits at its default.
 */
export declare function formatSettingsTag(selection: GenerationSelection, strip: GenerationStrip): string;
/**
 * Replace the draft's settings tag with the one the strip now states.
 * @param draft - the current composer draft.
 * @param selection - the chosen values and count.
 * @param strip - the fields and count menu the strip currently renders.
 * @returns the next draft. An empty tag over an empty body yields an empty
 * draft, so clearing every control on an untyped message leaves nothing behind.
 */
export declare function applySettingsTag(draft: string, selection: GenerationSelection, strip: GenerationStrip): string;
//# sourceMappingURL=settings-tag.d.ts.map