/**
 * The media grid, browser half. Registers four things and owns no state:
 *
 * - three Definitions and one `gallery` view target: one row per generation
 *   task folded from the generation tools' `tool/call`, the artefact store's
 *   `artefact/created` / `artefact/failed`, and a failing `tool/result`; one
 *   row per turn of the chat (thinking, generating, or ended with nothing
 *   made) folded from `turn/start`, `assistant/message` and `turn/end`; and
 *   one prompt per user message, joined to its turn in the target's builder;
 * - the `gallery` (Images) entry in the conversation view ring at order 6,
 *   rendering that chat's `image` rows as a grid of artefact tiles, with
 *   Keep / Archive posting to `@idealize/artefacts`' disposition route;
 * - the `motion` (Video) entry at order 8, the same grid over the same rows
 *   filtered to `video`;
 * - the generation settings strip on the composer card's tool row
 *   (`conversation.input.left`, beside the plus and the mode chips — JJ, 2 Sep
 *   2026: "aspect and no. of images should be in the ask bar"; 7 Sep 2026: a
 *   video model's duration "should be a setting that's visible in the ask
 *   bar along with anything else needed for the model to run"), shown while
 *   this chat's ring sits on Images, Video or the Sound Stage, with one select
 *   per field the space's model publishes on `GET /idealize/generate/inputs`.
 *
 * Everything it displays already exists in the session log (the store logs
 * every verdict), so the mode adds no session event and needs no host half.
 * @module @idealize/ui-gallery/client
 */
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
export type * from './contract.ts';
export { pendingTurns, rowsOfKind } from './contract.ts';
export { EMPTY_GALLERY_SNAPSHOT, galleryDefinition, galleryPromptDefinition, galleryTurnDefinition, galleryViewDefinition, GENERATION_TOOLS, joinPrompts, readToolArguments, registerGalleryConversation, } from './definition.ts';
export { GalleryView, formatBytes, rawUrl, retryMessage } from './GalleryView.tsx';
export type { GalleryViewInjected, GalleryViewProps } from './GalleryView.tsx';
export { FALLBACK_FIELDS, fieldLabel, GALLERY_VIEW, GENERATION_VIEWS, GenerationSettings, INPUTS_ROUTE, isGenerationView, loadInputs, } from './GenerationSettings.tsx';
export type { GenerationSettingsProps, GenerationView } from './GenerationSettings.tsx';
export { applySettingsTag, DEFAULT_SELECTION, formatSettingsTag, GALLERY_COUNTS, partName, readSettingsTag, valueOf, } from './settings-tag.ts';
export type { GalleryKey } from './locales.ts';
/** Required services: the slot registry, the conversation registries, copy, and session rows. */
export declare const inject: string[];
/** Type-erased slot registry face used where the typed overloads cannot see a foreign store. */
export interface ErasedSlots {
    entries(key: string): readonly {
        options: {
            id?: string;
        };
        store?: unknown;
    }[];
    subscribe(key: string, fn: () => void): () => void;
    register(options: Record<string, unknown>, component: unknown): () => void;
    inject(key: string, fn: () => () => void): void;
}
/**
 * Client plugin body.
 * @param ctx - client root context.
 */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map