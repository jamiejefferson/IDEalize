/**
 * The Studio controls on the composer card's tool row, shown while this chat's
 * view ring sits on Image, Video or Sound. The entry shares the chat view's
 * store (the ui-terminal ModeShortcut pattern), so the controls appear and
 * disappear with the view instead of following every chat in the app.
 *
 * The row carries the Image, Video, Sound toggle (JJ, 25 Nov 2026) and one
 * button that names the model and the settings in force. The button opens a
 * panel with the model that kind runs on and one control per setting that
 * model takes: a select for an enum, a number input for a number, a checkbox
 * for a switch. The controls sat on the row itself until 26 Nov 2026, where
 * they ran past the card's edge and were cut off. The model picker is here
 * because the person may change the model at any time inside a chat (JJ, 24
 * Nov 2026); "Auto" leaves the choice to the app. The composer's chat-model
 * seat stays retired on a media view, so the model is still named once.
 *
 * The fields come from `GET /idealize/generate/inputs?space=`, refetched when
 * the view changes and when the Brains pane raises `idealize:brains-changed`
 * after a model change. A space whose model publishes no schema gets the
 * fallback vocabulary in {@link FALLBACK_FIELDS}. Images always adds the
 * image-count control beside the fields.
 *
 * Each choice is written into the draft as one trailing tag (see
 * `settings-tag.ts`): the composer exposes no pre-submit seam, so a control
 * that must reach the model states itself in the message.
 * @module @idealize/ui-gallery/client/GenerationSettings
 */
import type React from 'react';
import type { GenerationField } from './contract.ts';
import type { GalleryKey } from './locales.ts';
/** The view id of the Images grid, the one space with a count control. */
export declare const GALLERY_VIEW = "gallery";
/** The view ids the strip renders on: the three media spaces. */
export declare const GENERATION_VIEWS: readonly ["gallery", "motion", "soundstage"];
/** One of {@link GENERATION_VIEWS}. */
export type GenerationView = typeof GENERATION_VIEWS[number];
/**
 * The host route publishing the active model's inputs per space (restated:
 * the client bundle purity gate forbids the value import).
 */
export declare const INPUTS_ROUTE = "/idealize/generate/inputs";
/**
 * The vocabulary each space offers when its model publishes no schema. A
 * default-less field (Video's duration) starts unset, so the strip shows that
 * the model has been told nothing until the user picks a value.
 */
export declare const FALLBACK_FIELDS: Readonly<Record<GenerationView, readonly GenerationField[]>>;
/**
 * The document event the strip raises when a person picks another kind of
 * thing to make. `@idealize/ui-bar` owns the chat's durable view record, so it
 * listens and writes it (restated there: neither package imports the other).
 */
export declare const STUDIO_KIND_EVENT = "idealize:studio-kind";
/** What {@link STUDIO_KIND_EVENT} carries: the chat and the view it moves to. */
export interface StudioKindDetail {
    sessionId: string;
    space: GenerationView;
}
/** The kinds in toggle order, each with its label key. */
export declare const STUDIO_KINDS: readonly {
    space: GenerationView;
    label: GalleryKey;
}[];
/**
 * Whether a ring view id is one the strip renders on.
 * @param view - the ring's active view id, or null before one is chosen.
 * @returns true for the three media spaces.
 */
export declare function isGenerationView(view: string | null): view is GenerationView;
/**
 * Fetch the active model's inputs for one space.
 * @param space - the view id.
 * @returns the fields, or an empty list when the route is absent, refuses, or publishes no schema.
 */
export declare function loadInputs(space: GenerationView): Promise<readonly GenerationField[]>;
/** The host route listing each kind's models and storing the chosen one (restated: the purity gate forbids the value import). */
export declare const MEDIA_ROUTE = "/idealize/brains/media";
/** The media preset behind each view (restated from `@idealize/generate`'s `PRESET_BY_SPACE`). */
export declare const MEDIA_PRESET_BY_VIEW: Readonly<Record<GenerationView, string>>;
/** One model a kind can run on, as the strip's picker lists it. */
export interface StudioModel {
    backend: string;
    model: string;
    name: string;
    /** What one typical output costs, as the provider publishes it; undefined when it publishes none. */
    price?: string;
}
/** One kind's models and the stored choice (null while the app picks). */
export interface StudioModels {
    chosen: {
        backend: string;
        model: string;
    } | null;
    models: readonly StudioModel[];
}
/**
 * Fetch one kind's models and the stored choice.
 * @param space - the view id.
 * @returns the models in name order, or an empty list when the route is absent or refuses.
 */
export declare function loadStudioModels(space: GenerationView): Promise<StudioModels>;
/**
 * Store one kind's model, or clear it so the app picks.
 * @param space - the view id.
 * @param model - the choice, or null for the app's pick.
 * @returns whether the route accepted it.
 */
export declare function storeStudioModel(space: GenerationView, model: {
    backend: string;
    model: string;
} | null): Promise<boolean>;
/**
 * Split a kind's models by the service that runs them, in first-seen order.
 * A service that lists one name several times keeps the first, because the
 * picker shows names and two identical rows cannot be told apart.
 * @param models - the models in name order.
 * @returns one group per service.
 */
export declare function groupByService(models: readonly StudioModel[]): {
    backend: string;
    models: StudioModel[];
}[];
/** Bound translate for the `idealize-gallery` namespace. */
type Translate = (key: GalleryKey, params?: Record<string, unknown>) => string;
/**
 * The label word for one field: known names read their locale text, so the
 * fallback vocabularies and the common schema fields translate; any other
 * field shows the label the route sent.
 * @param field - the field.
 * @param space - the view id, which decides whether a duration reads Duration or Length.
 * @param t - bound translate.
 * @returns the label.
 */
export declare function fieldLabel(field: GenerationField, space: GenerationView, t: Translate): string;
/**
 * Props the strip reads. Restated structurally: the entry carries a foreign
 * plugin's store, which the typed slot overloads cannot describe.
 */
export interface GenerationSettingsProps {
    /** Selector hook over the chat store (the ring's active view lives here). */
    useStore: <T>(selector: (state: {
        view: string | null;
    }) => T) => T;
    /** The chat store's actions; the kind toggle moves the ring through `setView`. */
    actions: {
        setView: (view: string) => void;
    };
    /** The chat the strip belongs to. */
    sessionId: string;
    /** Selector hook over this session's live input machine state. */
    useInput: <T>(selector: (state: {
        draft: string;
        locked?: boolean;
    }) => T) => T;
    /** The public input action face; the strip's single write path. */
    inputActions: {
        setDraft: (text: string) => void;
    };
    /** Bound translate for the `idealize-gallery` namespace. */
    t: Translate;
}
/**
 * Render the strip for the active media space.
 * @param props - composed slot props.
 * @returns the control row, or null while a non-media view is active.
 */
export declare function GenerationSettings({ useStore, useInput, inputActions, actions, sessionId, t }: GenerationSettingsProps): React.JSX.Element | null;
export {};
//# sourceMappingURL=GenerationSettings.d.ts.map