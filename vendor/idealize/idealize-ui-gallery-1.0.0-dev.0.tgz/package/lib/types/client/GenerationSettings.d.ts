/**
 * The generation settings strip: one compact control per setting the active
 * space's model takes (a select for an enum, a number input for a number, a
 * checkbox for a switch), on the composer card's tool row (beside the plus and
 * the mode chips), shown while this chat's view ring sits on Images, Video or
 * the Sound Stage. The entry shares the chat view's store (the ui-terminal
 * ModeShortcut pattern), so the strip appears and disappears with the view
 * instead of following every chat in the app.
 *
 * The strip carries the creation variables and nothing else. It names no
 * model: the space's generation model belongs to its brain and is chosen in
 * the Brains pane, and a picker here stated it a second time beside the
 * composer's own chat-model seat, which in a media space drives only the tool
 * (JJ, 13 Sep 2026: "the model is defined by the brain and therefore doesn't
 * need to be shown. its also shown twice - one of them being wrong"). The
 * sheet retires the chat-model seat on a media view for the same reason.
 *
 * The fields come from `GET /idealize/generate/inputs?space=`, refetched when
 * the view changes and when the Brains pane raises `idealize:brains-changed`
 * after a model change. A space whose model publishes no schema gets the
 * fallback vocabulary in {@link FALLBACK_FIELDS}. Images always adds the
 * image-count control beside the fields.
 *
 * Each choice is written into the draft as one trailing tag (see
 * `settings-tag.ts`): the composer exposes no pre-submit seam, so a control
 * that must reach the model states itself in the message.
 * @module @idealize/ui-gallery/client/GenerationSettings
 */
import type React from 'react';
import type { GenerationField } from './contract.ts';
import type { GalleryKey } from './locales.ts';
/** The view id of the Images grid, the one space with a count control. */
export declare const GALLERY_VIEW = "gallery";
/** The view ids the strip renders on: the three media spaces. */
export declare const GENERATION_VIEWS: readonly ["gallery", "motion", "soundstage"];
/** One of {@link GENERATION_VIEWS}. */
export type GenerationView = typeof GENERATION_VIEWS[number];
/**
 * The host route publishing the active model's inputs per space (restated:
 * the client bundle purity gate forbids the value import).
 */
export declare const INPUTS_ROUTE = "/idealize/generate/inputs";
/**
 * The vocabulary each space offers when its model publishes no schema. A
 * default-less field (Video's duration) starts unset, so the strip shows that
 * the model has been told nothing until the user picks a value.
 */
export declare const FALLBACK_FIELDS: Readonly<Record<GenerationView, readonly GenerationField[]>>;
/**
 * Whether a ring view id is one the strip renders on.
 * @param view - the ring's active view id, or null before one is chosen.
 * @returns true for the three media spaces.
 */
export declare function isGenerationView(view: string | null): view is GenerationView;
/**
 * Fetch the active model's inputs for one space.
 * @param space - the view id.
 * @returns the fields, or an empty list when the route is absent, refuses, or publishes no schema.
 */
export declare function loadInputs(space: GenerationView): Promise<readonly GenerationField[]>;
/** Bound translate for the `idealize-gallery` namespace. */
type Translate = (key: GalleryKey, params?: Record<string, unknown>) => string;
/**
 * The label word for one field: known names read their locale text, so the
 * fallback vocabularies and the common schema fields translate; any other
 * field shows the label the route sent.
 * @param field - the field.
 * @param space - the view id, which decides whether a duration reads Duration or Length.
 * @param t - bound translate.
 * @returns the label.
 */
export declare function fieldLabel(field: GenerationField, space: GenerationView, t: Translate): string;
/**
 * Props the strip reads. Restated structurally: the entry carries a foreign
 * plugin's store, which the typed slot overloads cannot describe.
 */
export interface GenerationSettingsProps {
    /** Selector hook over the chat store (the ring's active view lives here). */
    useStore: <T>(selector: (state: {
        view: string | null;
    }) => T) => T;
    /** Selector hook over this session's live input machine state. */
    useInput: <T>(selector: (state: {
        draft: string;
        locked?: boolean;
    }) => T) => T;
    /** The public input action face; the strip's single write path. */
    inputActions: {
        setDraft: (text: string) => void;
    };
    /** Bound translate for the `idealize-gallery` namespace. */
    t: Translate;
}
/**
 * Render the strip for the active media space.
 * @param props - composed slot props.
 * @returns the control row, or null while a non-media view is active.
 */
export declare function GenerationSettings({ useStore, useInput, inputActions, t }: GenerationSettingsProps): React.JSX.Element | null;
export {};
//# sourceMappingURL=GenerationSettings.d.ts.map