/**
 * The Studio backdrop behind the media Studio chat. `@idealize/ui-studio`
 * owns the backdrop and offers its layers as the `studioBackdrop` service;
 * the plugin body hands that component here, and the view seats it behind the
 * whole chat column (title strip, grid and message box). Without the service
 * nothing is drawn and the chat sits on the app theme.
 * @module @idealize/ui-gallery/client/backdrop
 */
import type { ComponentType } from 'react';
/**
 * Take the component that draws the current backdrop's layers.
 * @param Layers - the `studioBackdrop` service's component, or undefined when the service leaves.
 */
export declare function setBackdropLayers(Layers: ComponentType | undefined): void;
/**
 * The backdrop for one media Studio chat. It renders a marker inside the view
 * to find the chat column, then draws the layers into that column, under
 * everything else in it.
 *
 * The grid scrolls under the message box, and the box is see-through on a
 * backdrop, so tiles showed through it (JJ, 26 Nov 2026). A second copy of
 * the layers is drawn in the box's seat, placed over the column's copy, so
 * the seat shows the same wall and floor and covers what scrolls beneath. The
 * copy starts 36px above the seat and fades in across that band, so a tile
 * fades out before it reaches the box.
 *
 * The grid also scrolls under the title strip, which is see-through on a
 * backdrop: a light tile behind a light title left it unreadable (measured at
 * 2.4:1, 26 Nov 2026). A third copy is drawn in the strip, behind the title;
 * the strip's own mask fades it out along its lower edge.
 * @returns the marker and, once the column is found, the layers.
 */
export declare function GalleryBackdrop(): import("react").JSX.Element;
//# sourceMappingURL=backdrop.d.ts.map