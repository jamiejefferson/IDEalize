/**
 * The Gallery's conversation Definitions and view-target builder, folded from
 * the events the host already writes.
 *
 * `gallery-generation`, one Context per generation task:
 * - `tool/call` for one of the three generation tools STARTS a row and carries
 *   the prompt and settings the model asked for (the raw arguments JSON).
 * - `artefact/created` whose `sourceTask.callId` names that call adds the
 *   committed artefact and settles the row.
 * - `artefact/failed` settles the row with the adapter's provider cause
 *   (MOD-05); the first cause recorded wins, so a following error result never
 *   overwrites the provider's own words with the generic tool text.
 * - `artefact/disposition` marks one of the row's artefacts archived or kept
 *   and moves its path with the file.
 * - A failing `tool/result` settles a row whose call never reached the
 *   provider (an unavailable media preset fails before any adapter runs, so no
 *   `artefact/failed` exists to carry a cause).
 *
 * `gallery-turn`, one Context per turn of the chat (JJ, 8 Sep 2026: posting a
 * message on Images, Video or Sounds "looks like it's not working"):
 * - `turn/start` STARTS the turn in the `thinking` phase.
 * - a generation `tool/call` in that turn moves it to `generating`.
 * - `assistant/message` records the model's last text.
 * - `turn/end` settles it: `generated` when a generation call happened,
 *   `no-generation` otherwise, so the view shows what the model said instead.
 *
 * `gallery-prompt`, one Context per user message: the person's text and its
 * log position. A `user/message` carries no turn number, so the builder joins
 * each prompt to the turn whose `turn/start` precedes it.
 *
 * The Definitions add no session events: everything they read is already in
 * the log and in the read vocabulary.
 * @module @idealize/ui-gallery/client/definition
 */
import type { Context } from '@deepseek-ai/cordis';
import type { ConversationNodeDefinition, ConversationViewDefinition } from '@deepseek-ai/dsh-client-runtime/client';
import type { GalleryArtefactKind, GalleryConversationViewNode, GalleryPrompt, GalleryRow, GallerySnapshot, GallerySettings, GalleryTurn } from './contract.ts';
/** The generation Definition kind; also its Context key prefix. */
export declare const GALLERY_KIND = "gallery-generation";
/** The turn Definition kind; also its Context key prefix. */
export declare const GALLERY_TURN_KIND = "gallery-turn";
/** The prompt Definition kind; also its Context key prefix. */
export declare const GALLERY_PROMPT_KIND = "gallery-prompt";
/** The Gallery's view target id. */
export declare const GALLERY_TARGET = "gallery";
/** The generation tools whose calls become Gallery rows, and the artefact each produces. */
export declare const GENERATION_TOOLS: Readonly<Record<string, GalleryArtefactKind>>;
/** Stable empty target used until a session has assembled generation rows. */
export declare const EMPTY_GALLERY_SNAPSHOT: GallerySnapshot;
/**
 * Read the prompt and settings out of one `tool/call`'s raw arguments JSON.
 * The model produced this string, so every field is checked before use.
 * @param raw - the arguments string exactly as the model produced it.
 * @returns the prompt (empty when the model sent none or sent invalid JSON) and
 * the settings it named.
 */
export declare function readToolArguments(raw: string): {
    prompt: string;
    settings: GallerySettings;
};
/**
 * The Gallery Definition: one Context per generation call, publishing one
 * {@link GalleryRow} into the `gallery` target.
 */
export declare const galleryDefinition: ConversationNodeDefinition<GalleryRow>;
/**
 * The turn Definition: one Context per turn, publishing one {@link GalleryTurn}
 * into the `gallery` target.
 */
export declare const galleryTurnDefinition: ConversationNodeDefinition<GalleryTurn>;
/**
 * The prompt Definition: one Context per message the person sent (a `plugin`
 * or `model` source is context the model reads, not something the person
 * asked for), publishing one {@link GalleryPrompt} into the `gallery` target.
 */
export declare const galleryPromptDefinition: ConversationNodeDefinition<GalleryPrompt>;
/**
 * Give each turn the prompt that opened it: the first user message logged
 * after the turn's start and before the next turn's start.
 * @param turns - the turns, in any order.
 * @param prompts - the user messages, in any order.
 * @returns the turns with their prompt text, newest first.
 */
export declare function joinPrompts(turns: readonly GalleryTurn[], prompts: readonly GalleryPrompt[]): GalleryTurn[];
/** The Gallery target factory. */
export declare const galleryViewDefinition: ConversationViewDefinition<GalleryConversationViewNode, GallerySnapshot>;
/**
 * Register the three Gallery Definitions and their view target.
 * @param ctx - the client plugin context carrying `conversationEvents` and `conversationViews`.
 */
export declare function registerGalleryConversation(ctx: Context): void;
//# sourceMappingURL=definition.d.ts.map