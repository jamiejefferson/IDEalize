import { type SnapshotStore } from '@deepseek-ai/dsh-client-runtime/client';
import type { TourStep } from './tour-script.ts';
/** What the overlay seat shows: the tour run, the shortcuts sheet, or nothing. */
export interface TourViewState {
    /** The snapshotted steps of the run in progress, or null when no tour is up. */
    steps: TourStep[] | null;
    /** Index into `steps`. */
    index: number;
    /** Whether the ⌘/ sheet is open. */
    sheet: boolean;
}
/** The overlay's view state plus its write set; apply-constructed, one per plugin. */
export declare class TourView {
    /** The snapshot the overlay renders from. */
    readonly store: SnapshotStore<TourViewState>;
    /**
     * Read the current state without subscribing.
     * @returns the current state.
     */
    getSnapshot(): TourViewState;
    /**
     * Begin a run over a snapshot of steps; the sheet closes.
     * @param steps - the steps to run (at least the opening card).
     */
    start(steps: TourStep[]): void;
    /** Advance; past the last step the run ends. */
    next(): void;
    /** Step back (no-op on the first step). */
    back(): void;
    /** End the run. */
    finish(): void;
    /** Open the ⌘/ sheet. */
    openSheet(): void;
    /** Close the ⌘/ sheet. */
    closeSheet(): void;
    /** Flip the ⌘/ sheet. */
    toggleSheet(): void;
}
//# sourceMappingURL=tour-store.d.ts.map