import type { TranslateNS } from '@deepseek-ai/dsh-client-ui-slots';
import { type Keybind } from './keybinds.ts';
export interface KeybindsSheetProps {
    groups: {
        group: string;
        items: Keybind[];
    }[];
    onClose: () => void;
    t: TranslateNS<'idealize-tour'>;
}
export declare function KeybindsSheet({ groups, onClose, t }: KeybindsSheetProps): import("react").JSX.Element;
//# sourceMappingURL=KeybindsSheet.d.ts.map