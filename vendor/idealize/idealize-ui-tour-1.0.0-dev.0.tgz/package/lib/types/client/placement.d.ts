/**
 * Tour card placement, ported from V0's `TourLayout`: the card parks beside
 * the spotlight (right, else left, else above, else below) and clamps to the
 * container so it never hangs off an edge; with no spotlight it sits centred.
 */
/** A rectangle in container coordinates. */
export interface Rect {
    x: number;
    y: number;
    width: number;
    height: number;
}
/** Width and height only. */
export interface Size {
    width: number;
    height: number;
}
/** A point in container coordinates. */
export interface Point {
    x: number;
    y: number;
}
/** V0's fixed card width in px. */
export declare const CARD_WIDTH = 330;
/** Padding between the target and the spotlight edge. */
export declare const HOLE_PAD = 6;
/** Spotlight corner radius. */
export declare const HOLE_RADIUS = 10;
/**
 * Choose the card origin for one step.
 * @param card - measured card size.
 * @param spotlight - the spotlight rectangle, or null for the opening card.
 * @param container - the overlay's size.
 * @returns the card's top-left corner.
 */
export declare function placeCard(card: Size, spotlight: Rect | null, container: Size): Point;
/**
 * Pin a coordinate inside the container margins. A container smaller than
 * the card plus margins inverts the range; the near margin wins then.
 * @param value - proposed coordinate.
 * @param size - the card's extent on this axis.
 * @param bound - the container's extent on this axis.
 * @returns the pinned coordinate.
 */
export declare function clamp(value: number, size: number, bound: number): number;
/**
 * Grow a target rectangle into its spotlight.
 * @param target - the measured target.
 * @returns the padded spotlight rectangle.
 */
export declare function spotlightOf(target: Rect): Rect;
//# sourceMappingURL=placement.d.ts.map