/**
 * IDEalize first-run tour + keyboard shortcuts, browser half. One occupant on
 * the frame's shell.overlay seat renders V0's showcase tour (once, seeded in
 * the `idealize-tour` settings section) and the ⌘/ shortcuts sheet. Two
 * services let other plugins wire in without touching this package:
 * `ctx.keybinds` (register a shortcut; it is dispatched and listed) and
 * `ctx.tour` (anchor a tour target to a real element, start a run, open the
 * sheet). Targets no plugin has anchored resolve through default selectors.
 */
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
import { type IKeybinds } from './keybinds.ts';
import { type TourTarget } from './tour-script.ts';
import { type TourKey } from './locales.ts';
export { Overlay } from './Overlay.tsx';
export { KeybindRegistry, chord, formatChord, formatChords, matchesChord } from './keybinds.ts';
export type { IKeybinds, Keybind, KeyChord } from './keybinds.ts';
export { TOUR_STEPS, runnableSteps } from './tour-script.ts';
export type { TourStep, TourTarget } from './tour-script.ts';
export type { TourKey } from './locales.ts';
/** The tour face (`ctx.tour`). */
export interface ITour {
    /**
     * Point a tour target at a live element; the default selector for that
     * target is bypassed while the anchor stands.
     * @param target - which step's target.
     * @param element - the element to spotlight.
     * @returns disposer clearing the anchor.
     */
    anchor(target: TourTarget, element: Element): () => void;
    /** Start (or restart) the showcase over the targets on screen now. */
    start(): void;
    /** Open the ⌘/ shortcuts sheet. */
    openKeybinds(): void;
    /**
     * Suspend the automatic first-run start while at least one hold stands
     * (first-run setup runs its steps ahead of the showcase). Releasing the
     * last hold re-evaluates the trigger, so the tour still starts exactly
     * once — or not at all when the seed is already set.
     * @returns idempotent disposer releasing this hold.
     */
    holdFirstRun(): () => void;
}
declare module '@deepseek-ai/cordis' {
    interface Context {
        /** The keybinds catalogue + dispatcher. */
        keybinds: IKeybinds;
        /** The showcase tour face. */
        tour: ITour;
    }
}
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** The tour's and sheet's copy. */
        'idealize-tour': TourKey;
    }
}
/** Required services. */
export declare const inject: string[];
/**
 * Client plugin body: services, the overlay occupant, the default shortcut
 * catalogue, the global dispatcher, and the first-run trigger.
 * @param ctx - client root context.
 */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map