/** `idealize-tour` namespace dictionaries: the showcase tour and the shortcuts sheet. */
/** Simplified Chinese dictionary (the key-set source of truth). */
export declare const zh: {
    'tour.welcome.title': string;
    'tour.welcome.body': string;
    'tour.sidebar.title': string;
    'tour.sidebar.body': string;
    'tour.studio.title': string;
    'tour.studio.body': string;
    'tour.composer.title': string;
    'tour.composer.body': string;
    'tour.files.title': string;
    'tour.files.body': string;
    'tour.brains.title': string;
    'tour.brains.body': string;
    'tour.askbar.title': string;
    'tour.askbar.body': string;
    'tour.rail.title': string;
    'tour.rail.body': string;
    'tour.back': string;
    'tour.next': string;
    'tour.done': string;
    'tour.skip': string;
    'keys.title': string;
    'keys.done': string;
    'keys.close': string;
    'keys.empty': string;
    'group.chats': string;
    'group.composer': string;
    'group.panels': string;
    'group.app': string;
    'bind.newChat': string;
    'bind.send': string;
    'bind.sendWhenNewline': string;
    'bind.newline': string;
    'bind.history': string;
    'bind.undo': string;
    'bind.focusInput': string;
    'bind.sidebar': string;
    'bind.askbar': string;
    'bind.settings': string;
    'bind.keys': string;
};
/** English dictionary. */
export declare const en: Record<TourKey, string>;
/** Dictionary key set. */
export type TourKey = keyof typeof zh;
//# sourceMappingURL=locales.d.ts.map