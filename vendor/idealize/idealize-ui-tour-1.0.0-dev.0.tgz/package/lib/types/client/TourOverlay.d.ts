import type { TranslateNS } from '@deepseek-ai/dsh-client-ui-slots';
import type { TourStep, TourTarget } from './tour-script.ts';
export interface TourOverlayProps {
    steps: TourStep[];
    index: number;
    /** Resolve a target to its on-screen element (null when absent). */
    resolve: (target: TourTarget) => Element | null;
    onNext: () => void;
    onBack: () => void;
    onFinish: () => void;
    t: TranslateNS<'idealize-tour'>;
}
export declare function TourOverlay({ steps, index, resolve, onNext, onBack, onFinish, t }: TourOverlayProps): import("react").JSX.Element | null;
//# sourceMappingURL=TourOverlay.d.ts.map