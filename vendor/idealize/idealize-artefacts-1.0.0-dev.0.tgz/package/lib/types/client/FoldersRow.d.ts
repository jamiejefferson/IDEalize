import type { SnapshotStore } from '@deepseek-ai/dsh-client-runtime/client';
import type { InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import { type ArtefactFolderSettings } from '../settings.ts';
/** The editable fields, in display order. */
export declare const FOLDER_FIELDS: readonly ["images", "sounds", "video", "archive"];
/** One editable field name. */
export type FolderField = typeof FOLDER_FIELDS[number];
/** Registration-side face. */
export interface FoldersRowInjected {
    hooks: {
        /** The live folder settings (settings-backed, defaults until the scope loads). */
        folders: SnapshotStore<ArtefactFolderSettings>;
    };
    /** Write one field; the caller has validated the value. */
    setFolder: (field: FolderField, value: string) => void;
}
/** Full Settings-row props. */
export type FoldersRowProps = PropsRuntime<'settings.general.item'> & PropsLocale<'idealize-artefacts'> & InjectFace<FoldersRowInjected>;
/**
 * Render the media-folders row.
 * @param props - composed Settings slot props.
 * @returns the row.
 */
export declare function FoldersRow({ useFolders, setFolder, t }: FoldersRowProps): import("react").JSX.Element;
//# sourceMappingURL=FoldersRow.d.ts.map