/**
 * The artefact conversation-node Definition and its Chat payload: one keyed
 * transcript node per `artefact/created` / `artefact/failed` event
 * (cookbook: docs/cookbook/adding-a-conversation-node.md). Each event is a
 * whole-value single-event Context — the artefact id is the stable business
 * id, and a failed generation keys separately so a later success never
 * collides with it.
 */
import type { ConversationNodeDefinition } from '@deepseek-ai/dsh-client-runtime/client';
/** Chat payload of one artefact node. */
export interface ArtefactChatData {
    readonly status: 'created' | 'failed';
    readonly id: string;
    readonly mediaType: string;
    /** Byte size of the stored artefact; absent on failure. */
    readonly bytes?: number;
    /** Project-relative storage path; absent on failure. */
    readonly relPath?: string;
    /** The provider-reported cause; present only on failure. */
    readonly error?: string;
}
declare module '@deepseek-ai/dsh-client-ui-conversation/client' {
    interface ChatNodeDataMap {
        /** One generated artefact (or its failure) rendered inline in the transcript. */
        artefact: ArtefactChatData;
    }
}
/** The artefact Definition: single-event Contexts, no updates, one Chat node each. */
export declare const artefactDefinition: ConversationNodeDefinition<ArtefactChatData>;
//# sourceMappingURL=node.d.ts.map