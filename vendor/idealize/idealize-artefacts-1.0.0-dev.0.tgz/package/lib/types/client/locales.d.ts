/** `idealize-artefacts` namespace dictionaries: the media-folders settings row. */
/** Simplified Chinese dictionary (the key-set source of truth). */
export declare const zh: {
    readonly 'folders.title': "生成的媒体保存位置";
    readonly 'folders.description': "每个项目内的文件夹。归档的文件移入各文件夹下的归档子文件夹。";
    readonly 'folders.images': "图片";
    readonly 'folders.sounds': "声音";
    readonly 'folders.video': "视频";
    readonly 'folders.archive': "归档子文件夹";
    readonly 'folders.invalid': "请使用项目内的相对路径，不含“..”";
};
/** Translation key set. */
export type ArtefactsKey = keyof typeof zh;
/** English dictionary. */
export declare const en: Record<ArtefactsKey, string>;
//# sourceMappingURL=locales.d.ts.map