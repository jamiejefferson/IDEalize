/**
 * The artefact chat node renderer: an inline image for `image/*`, an audio
 * element for `audio/*`, and a generic card otherwise; failures render the
 * provider cause. Media loads through the loopback raw route by artefact id,
 * so the renderer stays a pure function of the node payload.
 */
import type { ChatNodeViewProps } from '@deepseek-ai/dsh-client-ui-conversation/client';
/** Keyed `conversation.chat.node` renderer for `kind: 'artefact'`. */
export declare function ArtefactNodeView({ node }: ChatNodeViewProps<'artefact'>): import("react").JSX.Element;
//# sourceMappingURL=ArtefactNode.d.ts.map