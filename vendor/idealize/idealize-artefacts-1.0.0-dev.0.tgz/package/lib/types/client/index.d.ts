/**
 * @idealize/artefacts, browser half: registers the artefact conversation-node
 * Definition and the keyed Chat renderer, so `artefact/created` and
 * `artefact/failed` events render inline in the transcript (image thumbnail,
 * audio element, or a generic card by media type), and the General Settings
 * row for where generated media saves (the `idealize-artefacts` section).
 * `reveal.ts` is the document event a gallery raises to have the Files pane
 * show an artefact's file; galleries and the rail inline that one module.
 */
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
import { type ArtefactsKey } from './locales.ts';
export { artefactDefinition } from './node.ts';
export type { ArtefactChatData } from './node.ts';
export { ArtefactNodeView } from './ArtefactNode.tsx';
export { FOLDER_FIELDS, FoldersRow } from './FoldersRow.tsx';
export type { FolderField, FoldersRowInjected, FoldersRowProps } from './FoldersRow.tsx';
export type { ArtefactsKey } from './locales.ts';
export { ARTEFACT_LANDED_EVENT, announceArtefact, onArtefactLanded, onRevealRequest, requestReveal, REVEAL_ARTEFACT_EVENT } from './reveal.ts';
export type { RevealArtefactDetail } from './reveal.ts';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** The media-folders row's copy. */
        'idealize-artefacts': ArtefactsKey;
    }
}
/** Required client services: the node assembler, the slot registry, copy, and the settings transport. */
export declare const inject: string[];
/**
 * Client plugin body: one Definition, one keyed renderer, one settings row.
 * @param ctx - client root context.
 */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map