/**
 * The artefact domain declaration: the zod record schema validating the
 * durable boundary and the `defineDomain` spec the store opens through
 * `ctx.storageDomain` (pattern: `dsh-workspace`'s `src/spec.ts`).
 * @module @idealize/artefacts/src/spec
 */
import { z } from 'zod';
import { SessionId } from '@deepseek-ai/dsh-session';
import type { ArtefactId, ArtefactRecord } from './types.ts';
/**
 * Durable shape of one artefact record. Field semantics live on
 * {@link ArtefactRecord}; this schema is the read-side validator, so a record
 * another build wrote with a different `schemaVersion` fails loud at open.
 */
export declare const artefactRecord: z.ZodObject<{
    schemaVersion: z.ZodLiteral<1>;
    id: z.ZodPipe<z.ZodString, z.ZodTransform<ArtefactId, string>>;
    mediaType: z.ZodString;
    storage: z.ZodObject<{
        kind: z.ZodLiteral<"file">;
        relPath: z.ZodString;
        bytes: z.ZodNumber;
        sha256: z.ZodString;
    }, z.core.$strip>;
    sourceTask: z.ZodObject<{
        sessionId: z.ZodPipe<z.ZodString, z.ZodTransform<SessionId, string>>;
        turnSeq: z.ZodNumber;
        callId: z.ZodPipe<z.ZodString, z.ZodTransform<import("@deepseek-ai/dsh-llm").CallId, string>>;
        toolName: z.ZodString;
    }, z.core.$strip>;
    settings: z.ZodJSONSchema;
    provenance: z.ZodObject<{
        provider: z.ZodString;
        model: z.ZodString;
        createdAt: z.ZodString;
        workspaceId: z.ZodPipe<z.ZodString, z.ZodTransform<import("../../../workspace/workspace/src/types.ts").WorkspaceId, string>>;
    }, z.core.$strip>;
    disposition: z.ZodOptional<z.ZodLiteral<"archived">>;
}, z.core.$strip>;
/**
 * The artefact domain spec: one `artefacts` table keyed by {@link ArtefactId}.
 * No global singleton — the table is the complete durable state.
 */
export declare const artefactDomainSpec: {
    name: string;
    version: number;
    tables: {
        artefacts: import("@deepseek-ai/dsh-storage-domain").DomainTableSpec<ArtefactId, ArtefactRecord>;
    };
};
//# sourceMappingURL=spec.d.ts.map