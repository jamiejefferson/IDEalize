/**
 * Durable cron state: one JSON document under the Harness home holding the
 * task list and a capped run history. Whole-document atomic writes (temp +
 * rename); a torn write can never half-record a task.
 */
import type { Schedule } from './schedule.ts';
/** The document's filename directly under the harness home. */
export declare const CRON_STORE_FILENAME = "idealize-cron.json";
/**
 * Where the document lives under one harness home.
 * @param dshHome - the harness home directory.
 * @returns the absolute document path.
 */
export declare function cronStorePath(dshHome: string): string;
/** One scheduled task as stored. */
export interface CronTask {
    id: string;
    name: string;
    schedule: Schedule;
    /**
     * The user message each run submits. Empty for a reminder that runs no
     * agent: the fire only raises the desktop notification.
     */
    prompt: string;
    /** Absolute workspace directory the run executes in. */
    cwd: string;
    /** Raise a desktop notification (title = name, body = the time) at each fire, beside any agent run. */
    remind?: boolean;
    /**
     * The instant a one-off (`at`) task fired. A done task stays listed so the
     * person sees it happened, arms no timer, and never fires again.
     */
    done?: string;
    /** Pinned provider route; absent = the deployment default. */
    provider?: string;
    /** Pinned model id; absent = the deployment default. */
    model?: string;
    /** A disabled task keeps its record but arms no timer. */
    enabled: boolean;
    createdAt: string;
}
/** How one fire ended: ran, failed, was missed while the host was down, or was skipped because the task was still running. */
export type RunStatus = 'ok' | 'error' | 'missed' | 'skipped-busy';
/** One fire of a task as recorded in the run history. */
export interface CronRun {
    taskId: string;
    firedAt: string;
    status: RunStatus;
    /** The session the run executed in, absent when no session was started. */
    sessionId?: string;
    durationMs?: number;
    /** The error line for `error`, or a note for `missed`/`skipped-busy`. */
    detail?: string;
}
/**
 * The cron document: every read and write goes through one serialised chain, so callers never observe a half-written list.
 * `onTasksChanged` runs after every committed task-list write (upsert, delete), never after a run record.
 */
export declare class CronStore {
    private readonly path;
    private readonly onTasksChanged;
    private chain;
    constructor(path: string, onTasksChanged?: () => void);
    private readAll;
    private writeAll;
    /** Serialize every mutation through one chain (single document). */
    private enqueue;
    /**
     * Every stored task.
     * @returns the task list in stored order; empty when no document exists.
     */
    tasks(): Promise<CronTask[]>;
    /**
     * The retained run history, oldest first.
     * @param taskId - restrict to one task; absent returns every run.
     * @returns at most the last 500 runs recorded.
     */
    runs(taskId?: string): Promise<CronRun[]>;
    /**
     * Insert a task, or replace the stored task with the same id.
     * @param task - the complete task record.
     */
    upsertTask(task: CronTask): Promise<void>;
    /**
     * Remove a task; its run history stays.
     * @param id - the task id.
     * @returns true when a task was removed, false when none had that id (nothing is written).
     */
    deleteTask(id: string): Promise<boolean>;
    /**
     * Append one run, dropping the oldest beyond the 500-run cap.
     * @param run - the run record.
     */
    recordRun(run: CronRun): Promise<void>;
}
//# sourceMappingURL=store.d.ts.map