/**
 * The /idealize/calendar page: month grid of upcoming fires and past runs
 * over the cron endpoints, plus an inline task editor. Self-contained and
 * dependency-free like /idealize/signin; a client-slot page inside the web
 * app proper is queued work.
 */
export declare function calendarPage(): string;
//# sourceMappingURL=calendar-page.d.ts.map