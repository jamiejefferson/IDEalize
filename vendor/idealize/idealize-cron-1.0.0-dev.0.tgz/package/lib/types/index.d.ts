/**
 * @idealize/cron — durable scheduled agent runs (`ctx.idealizeCron`), the
 * person's one calendar.
 *
 * Tasks (name, schedule, prompt, workspace, optional model) persist in one
 * JSON document under the Harness home. At fire time the service creates an
 * agent in-process — the same recipe as the dsh-headless runner — in the
 * task's workspace, waits for the turn, and records the outcome plus the
 * session id in run history. A task with an empty prompt is a reminder: its
 * fire runs no agent. A task marked `remind` (every prompt-less task is)
 * raises a desktop notification at each fire through the desktop shell's
 * notify face, the same face `@idealize/notify`'s route uses. A one-off (`at`)
 * task fires once, then records `done` and stays listed. One run per task at
 * a time: an overdue fire while one runs is recorded `skipped-busy`. Fires
 * missed while the server was down are recorded `missed` and never replayed
 * (the spec's default); the next live fire re-arms from the wall clock.
 *
 * Two writers share the document: the Schedule pane over the routes below,
 * and every agent through the `calendar_add` / `calendar_list` /
 * `calendar_remove` tools (`./tools.ts`), whose entries run in the calling
 * chat's project. An entry an agent adds starts paused and fires only once the
 * person approves it in the pane (JJ, 9 Oct 2026). Every committed task-list write
 * emits `idealize/cron-changed`, which the host bridge forwards so the pane refetches.
 *
 * HTTP surface (loopback-fenced; mutations demand `x-idealize-auth: 1`),
 * consumed by the Schedule drawer pane in @idealize/ui-bar:
 * - `GET  /idealize/cron/tasks`      — tasks with their next fire times
 * - `POST /idealize/cron/tasks`      — JSON body: create or update a task
 * - `POST /idealize/cron/delete`     — `?id=`
 * - `POST /idealize/cron/toggle`     — `?id=` flips `enabled`
 * - `POST /idealize/cron/approve`    — `?id=` the person approves an agent's entry
 * - `GET  /idealize/cron/runs`       — `?task=` filters
 *
 * Each completed fire also emits `idealize/cron-run` for the host bridge.
 *
 * @module @idealize/cron
 */
import { Context, Service } from '@deepseek-ai/cordis';
import { CronStore } from './store.ts';
import type { CronRun, CronTask } from './store.ts';
export { invalidReason, nextFire, WEEKDAYS, zoneWeekday } from './schedule.ts';
export type { Schedule } from './schedule.ts';
export { CronStore, cronStorePath } from './store.ts';
export type { CronRun, CronTask, RunStatus } from './store.ts';
export { CALENDAR_SECTION, createCalendarTools, describeSchedule, ONE_OFF_REMINDERS_WAIT_FOR_APPROVAL, scheduleOf } from './tools.ts';
export type { CalendarWriter } from './tools.ts';
declare module '@deepseek-ai/cordis' {
    interface Context {
        idealizeCron: IdealizeCron;
    }
    interface Events {
        /**
         * One scheduled run finished (any status); the host bridge forwards it
         * to the shell's notification feed.
         * @mode emit
         * @param run - The recorded run: status, timing, and the session it ran in.
         * @param task - The task definition that fired.
         */
        'idealize/cron-run'(run: CronRun, task: CronTask): void;
        /**
         * The task list changed (a task was added, edited, toggled, deleted, or a
         * one-off recorded done); the host bridge forwards it so the Schedule pane
         * refetches. Carries no payload: the pane reads the routes.
         * @mode emit
         */
        'idealize/cron-changed'(): void;
    }
}
/** The desktop shell's notify face, present only when the Electron host offers it. */
export interface CronNotifier {
    notify(notification: {
        title: string;
        body: string;
    }): void;
}
/** Construction options; production composition passes none. */
export interface IdealizeCronOptions {
    /** Where the task document lives; default `idealize-cron.json` under the resolved harness home. */
    storePath?: string;
    /**
     * How a fire reaches the person's screen; probed at each fire because the
     * desktop shell joins the tree after this service. Default: the
     * `desktopActions` service when it offers `notify`.
     */
    notifier?: () => CronNotifier | undefined;
}
/**
 * Probe the desktop shell's notify face without injecting it: the service is
 * absent in the browser-only composition.
 * @param ctx - any context in the host tree.
 * @returns the shell's notify face, or undefined when no desktop shell is composed.
 */
export declare function desktopNotifier(ctx: Context): CronNotifier | undefined;
/**
 * The notification body for one fire: the wall-clock time in the task's zone
 * (or the host's), e.g. `Tue 8 Sep, 14:00`.
 * @param firedAt - ISO-8601 instant of the fire.
 * @param timeZone - the zone to read it in.
 * @returns the formatted line.
 */
export declare function fireTimeLine(firedAt: string, timeZone?: string): string;
/** A task as the HTTP surface reports it. */
export interface TaskView extends CronTask {
    nextFireAt?: string;
    running: boolean;
}
/** The scheduler: durable tasks, armed timers, and run history behind `ctx.idealizeCron`. */
export declare class IdealizeCron extends Service {
    /** The durable task list and run history. */
    readonly store: CronStore;
    private readonly timers;
    private readonly running;
    /**
     * Tasks that came due while every agent was paused (feedback 495cec0a). Each
     * runs once on {@link releaseHeld}, however many of its fires the pause
     * covered. Held in memory: a one-off still owed after a restart comes due
     * again as the scheduler re-arms it.
     */
    private readonly owed;
    private readonly notifier;
    private disposed;
    constructor(ctx: Context, options?: IdealizeCronOptions);
    /** Arm (or re-arm) every enabled task from the current wall clock. */
    private armAll;
    /** Arm one task's next fire; disabled tasks just clear their timer. */
    private arm;
    /**
     * Whether every agent is paused, read from `@idealize/comm`'s pause service,
     * probed so the scheduler takes no dependency on it.
     * @returns true while a pause holds agent work.
     */
    private held;
    /**
     * A task's timer fired. A task that runs an agent waits while every agent is
     * paused, and its next fire is armed as usual; a reminder runs no agent, so
     * the person still hears it. The armed copy is current: every edit re-arms.
     * @param task - the task that came due.
     */
    private due;
    /**
     * Run, once each, the tasks that came due while every agent was paused. The
     * pause service calls this on Resume.
     * @returns the runs recorded.
     */
    releaseHeld(): Promise<CronRun[]>;
    /**
     * Tasks with computed next fires, for the HTTP surface.
     * @returns every stored task with its next fire time and running flag.
     */
    taskViews(): Promise<TaskView[]>;
    /**
     * Validate + persist one task and re-arm it. A prompt may be empty only
     * for a reminder (`remind` set): the fire then notifies and runs nothing.
     * A one-off whose instant has passed is refused unless the task already
     * recorded `done`, so renaming a fired reminder still saves.
     * @param input - Task fields from the calendar form or a calendar tool; `id` absent creates a new task.
     * @param origin - who is saving: an agent's new entry starts paused until the person approves it,
     *   and the person's own edit of one leaves it waiting.
     * @returns the stored task after defaults are applied.
     */
    saveTask(input: Partial<CronTask>, origin?: 'person' | 'agent'): Promise<CronTask>;
    /**
     * Disarm and remove one task; its run history stays.
     * @param id - The task to delete.
     * @returns whether a task with that id existed.
     */
    deleteTask(id: string): Promise<boolean>;
    /**
     * The person approves an agent's entry: it arms from here on, and needs no
     * further approval. The route is the app's alone (the launch gate keeps a
     * chat's key off it), so no agent can approve its own entry.
     * @param id - The task to approve.
     * @returns the armed task (unchanged when it was not waiting), or undefined when no task has that id.
     * @throws when a one-off's time has passed or its folder is no longer a project.
     */
    approveTask(id: string): Promise<CronTask | undefined>;
    /**
     * Flip one task's enabled flag and re-arm it. Turning on an entry that is
     * waiting for approval is the person approving it.
     * @param id - The task to toggle.
     * @returns the updated task, or undefined when no task has that id.
     */
    toggleTask(id: string): Promise<CronTask | undefined>;
    /**
     * Run one task now (used by fires; callable for a manual "run now"). A
     * reminder (empty prompt) runs no agent; a `remind` task raises the desktop
     * notification (title = task name, body = the time) beside whatever ran. A
     * one-off records `done` before its run is announced, so the pane's refetch
     * already shows it fired.
     * @param taskId - The task to run.
     * @returns the recorded run, `skipped-busy` when the task is already running.
     */
    fire(taskId: string): Promise<CronRun>;
    /** Raise the fire's desktop notification when a shell is present; a missing shell drops it silently. */
    private notify;
    /** The dsh-headless recipe, in-process, in the task's workspace. */
    /**
     * A scheduled run is an unattended chat rooted in the task's folder, and a
     * chat may write anywhere under its root; a task in the home folder or above
     * it could rewrite shell profiles while nobody watches (security audit,
     * 9 Oct 2026). A task that runs a chat runs in a project the person has
     * opened or in the app's own folder (Studio and Powell tasks); a reminder
     * runs nothing and may name any folder.
     * @param cwd - the task's absolute folder.
     */
    private assertTaskFolder;
    /**
     * List a run's chat under the project that owns its folder, as a chat the
     * person starts would be. A run outside every project, or a registry that
     * refuses, leaves the chat where it is: the run itself never fails on it.
     */
    private fileUnderProject;
    private runAgent;
}
/**
 * What a scheduled chat knows before its instructions. It reaches the model as a
 * plugin notice, so the chat can say in its own words what it could not do.
 */
export declare const SCHEDULED_CHAT_NOTICE: string;
/**
 * What a scheduled chat was stopped from doing, read from its log. A refused file
 * access says so in the tool result, and a refused action leaves its audit pair.
 * @param events - the finished run's session events.
 * @returns the sentence for the run's detail and the notification, or undefined when nothing was stopped.
 */
export declare function blockedActionOf(events: readonly {
    type: string;
    data?: unknown;
}[]): string | undefined;
export declare function apply(ctx: Context): void;
//# sourceMappingURL=index.d.ts.map