/**
 * @idealize/cron — durable scheduled agent runs (`ctx.idealizeCron`), the
 * person's one calendar.
 *
 * Tasks (name, schedule, prompt, workspace, optional model) persist in one
 * JSON document under the Harness home. At fire time the service creates an
 * agent in-process — the same recipe as the dsh-headless runner — in the
 * task's workspace, waits for the turn, and records the outcome plus the
 * session id in run history. A task with an empty prompt is a reminder: its
 * fire runs no agent. A task marked `remind` (every prompt-less task is)
 * raises a desktop notification at each fire through the desktop shell's
 * notify face, the same face `@idealize/notify`'s route uses. A one-off (`at`)
 * task fires once, then records `done` and stays listed. One run per task at
 * a time: an overdue fire while one runs is recorded `skipped-busy`. Fires
 * missed while the server was down are recorded `missed` and never replayed
 * (the spec's default); the next live fire re-arms from the wall clock.
 *
 * Two writers share the document: the Schedule pane over the routes below,
 * and every agent through the `calendar_add` / `calendar_list` /
 * `calendar_remove` tools (`./tools.ts`), whose entries run in the calling
 * chat's project. Every committed task-list write emits
 * `idealize/cron-changed`, which the host bridge forwards so the pane refetches.
 *
 * HTTP surface (loopback-fenced; mutations demand `x-idealize-auth: 1`),
 * consumed by the Schedule drawer pane in @idealize/ui-bar:
 * - `GET  /idealize/cron/tasks`      — tasks with their next fire times
 * - `POST /idealize/cron/tasks`      — JSON body: create or update a task
 * - `POST /idealize/cron/delete`     — `?id=`
 * - `POST /idealize/cron/toggle`     — `?id=` flips `enabled`
 * - `GET  /idealize/cron/runs`       — `?task=` filters
 *
 * Each completed fire also emits `idealize/cron-run` for the host bridge.
 *
 * @module @idealize/cron
 */
import { Context, Service } from '@deepseek-ai/cordis';
import { CronStore } from './store.ts';
import type { CronRun, CronTask } from './store.ts';
export { invalidReason, nextFire, WEEKDAYS, zoneWeekday } from './schedule.ts';
export type { Schedule } from './schedule.ts';
export { CronStore, cronStorePath } from './store.ts';
export type { CronRun, CronTask, RunStatus } from './store.ts';
export { CALENDAR_SECTION, createCalendarTools, describeSchedule, scheduleOf } from './tools.ts';
export type { CalendarWriter } from './tools.ts';
declare module '@deepseek-ai/cordis' {
    interface Context {
        idealizeCron: IdealizeCron;
    }
    interface Events {
        /**
         * One scheduled run finished (any status); the host bridge forwards it
         * to the shell's notification feed.
         * @mode emit
         * @param run - The recorded run: status, timing, and the session it ran in.
         * @param task - The task definition that fired.
         */
        'idealize/cron-run'(run: CronRun, task: CronTask): void;
        /**
         * The task list changed (a task was added, edited, toggled, deleted, or a
         * one-off recorded done); the host bridge forwards it so the Schedule pane
         * refetches. Carries no payload: the pane reads the routes.
         * @mode emit
         */
        'idealize/cron-changed'(): void;
    }
}
/** The desktop shell's notify face, present only when the Electron host offers it. */
export interface CronNotifier {
    notify(notification: {
        title: string;
        body: string;
    }): void;
}
/** Construction options; production composition passes none. */
export interface IdealizeCronOptions {
    /** Where the task document lives; default `idealize-cron.json` under the resolved harness home. */
    storePath?: string;
    /**
     * How a fire reaches the person's screen; probed at each fire because the
     * desktop shell joins the tree after this service. Default: the
     * `desktopActions` service when it offers `notify`.
     */
    notifier?: () => CronNotifier | undefined;
}
/**
 * Probe the desktop shell's notify face without injecting it: the service is
 * absent in the browser-only composition.
 * @param ctx - any context in the host tree.
 * @returns the shell's notify face, or undefined when no desktop shell is composed.
 */
export declare function desktopNotifier(ctx: Context): CronNotifier | undefined;
/**
 * The notification body for one fire: the wall-clock time in the task's zone
 * (or the host's), e.g. `Tue 8 Sep, 14:00`.
 * @param firedAt - ISO-8601 instant of the fire.
 * @param timeZone - the zone to read it in.
 * @returns the formatted line.
 */
export declare function fireTimeLine(firedAt: string, timeZone?: string): string;
/** A task as the HTTP surface reports it. */
export interface TaskView extends CronTask {
    nextFireAt?: string;
    running: boolean;
}
/** The scheduler: durable tasks, armed timers, and run history behind `ctx.idealizeCron`. */
export declare class IdealizeCron extends Service {
    /** The durable task list and run history. */
    readonly store: CronStore;
    private readonly timers;
    private readonly running;
    private readonly notifier;
    private disposed;
    constructor(ctx: Context, options?: IdealizeCronOptions);
    /** Arm (or re-arm) every enabled task from the current wall clock. */
    private armAll;
    /** Arm one task's next fire; disabled tasks just clear their timer. */
    private arm;
    /**
     * Tasks with computed next fires, for the HTTP surface.
     * @returns every stored task with its next fire time and running flag.
     */
    taskViews(): Promise<TaskView[]>;
    /**
     * Validate + persist one task and re-arm it. A prompt may be empty only
     * for a reminder (`remind` set): the fire then notifies and runs nothing.
     * A one-off whose instant has passed is refused unless the task already
     * recorded `done`, so renaming a fired reminder still saves.
     * @param input - Task fields from the calendar form or a calendar tool; `id` absent creates a new task.
     * @returns the stored task after defaults are applied.
     */
    saveTask(input: Partial<CronTask>): Promise<CronTask>;
    /**
     * Disarm and remove one task; its run history stays.
     * @param id - The task to delete.
     * @returns whether a task with that id existed.
     */
    deleteTask(id: string): Promise<boolean>;
    /**
     * Flip one task's enabled flag and re-arm it.
     * @param id - The task to toggle.
     * @returns the updated task, or undefined when no task has that id.
     */
    toggleTask(id: string): Promise<CronTask | undefined>;
    /**
     * Run one task now (used by fires; callable for a manual "run now"). A
     * reminder (empty prompt) runs no agent; a `remind` task raises the desktop
     * notification (title = task name, body = the time) beside whatever ran. A
     * one-off records `done` before its run is announced, so the pane's refetch
     * already shows it fired.
     * @param taskId - The task to run.
     * @returns the recorded run, `skipped-busy` when the task is already running.
     */
    fire(taskId: string): Promise<CronRun>;
    /** Raise the fire's desktop notification when a shell is present; a missing shell drops it silently. */
    private notify;
    /** The dsh-headless recipe, in-process, in the task's workspace. */
    private runAgent;
}
export declare function apply(ctx: Context): void;
//# sourceMappingURL=index.d.ts.map