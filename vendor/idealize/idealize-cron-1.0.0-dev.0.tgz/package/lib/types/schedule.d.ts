/**
 * Schedule arithmetic for IDEalize cron tasks. Four shapes: a one-off instant
 * (`at`, an ISO-8601 datetime; the task fires once and records itself done),
 * a fixed-rate interval (`every`, >= 60 seconds), a daily time-of-day
 * (`daily`, `HH:mm` in an explicit IANA zone), and a weekly time-of-day on
 * chosen weekdays (`weekly`, same `HH:mm` + zone, `days` 0 = Sunday … 6 =
 * Saturday). Cron-expression parsing is queued work. Repeating times are
 * computed against the wall clock at each arm, so a sleeping laptop
 * reschedules on wake instead of firing a burst.
 */
export type Schedule = {
    kind: 'at';
    at: string;
} | {
    kind: 'every';
    seconds: number;
} | {
    kind: 'daily';
    at: string;
    timeZone: string;
} | {
    kind: 'weekly';
    at: string;
    timeZone: string;
    days: number[];
};
/** Monday to Friday, the Schedule pane's "Every weekday" repeat. */
export declare const WEEKDAYS: readonly number[];
/**
 * Validate one schedule.
 * @param schedule - the candidate schedule.
 * @returns a human-readable reason it is invalid, or undefined when it is fine.
 */
export declare function invalidReason(schedule: Schedule): string | undefined;
/**
 * The zone's weekday at one instant.
 * @param instant - the instant to read.
 * @param timeZone - an IANA zone name.
 * @returns the weekday, 0 (Sunday) to 6 (Saturday).
 */
export declare function zoneWeekday(instant: Date, timeZone: string): number;
/**
 * Next fire time strictly after `from`; a one-off returns its instant whatever
 * `from` is, so an overdue one-off arms with no delay.
 *
 * The daily form walks forward in one-minute steps until the zone's wall clock
 * reads the target HH:mm — slower than calendar arithmetic but immune to the
 * offset-guessing bugs that plague hand-rolled zone maths. A time skipped by
 * a DST gap resolves to the first instant the wall clock shows it again (the
 * next day), which is the conservative reading of "fire at 02:30". The
 * weekly form repeats the daily walk until the zone's weekday is one of
 * `days` (at most eight walks).
 * @param schedule - a schedule `invalidReason` accepts.
 * @param from - the instant the search starts after.
 * @returns the next fire instant, strictly after `from`.
 */
export declare function nextFire(schedule: Schedule, from: Date): Date;
//# sourceMappingURL=schedule.d.ts.map