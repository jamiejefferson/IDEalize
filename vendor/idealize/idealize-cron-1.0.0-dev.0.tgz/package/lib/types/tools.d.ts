/**
 * The calendar tools (`calendar_add`, `calendar_list`, `calendar_remove`)
 * and the standing prompt section that names them. They write the same task
 * document the Schedule pane's routes write, so an entry the agent adds is on
 * the person's calendar and fires whether or not the chat that added it is
 * still open (JJ, 8 Sep 2026: a reminder set from chat neither appeared in the
 * calendar nor fired).
 */
import type { ToolDefinition } from '@deepseek-ai/dsh-tools';
import type { Schedule } from './schedule.ts';
import type { CronTask } from './store.ts';
import type { TaskView } from './index.ts';
/** The slice of the scheduler the tools use; the service implements it. */
export interface CalendarWriter {
    saveTask(input: Partial<CronTask>): Promise<CronTask>;
    taskViews(): Promise<TaskView[]>;
    deleteTask(id: string): Promise<boolean>;
}
/**
 * The standing guidance every agent's prompt carries about the calendar
 * (order 122, the tool-guidance band, after the artefact folders section).
 */
export declare const CALENDAR_SECTION: {
    readonly name: "idealize:calendar";
    readonly order: 122;
    readonly text: string;
};
/**
 * One schedule as a sentence for tool results.
 * @param schedule - the task's schedule.
 * @returns `once at <instant>`, `every <n> seconds`, `daily at HH:mm (<zone>)`, or `weekly on days [...] at HH:mm (<zone>)`.
 */
export declare function describeSchedule(schedule: Schedule): string;
/** The calendar_add arguments as the schema types them. */
interface AddArgs {
    title: string;
    at?: string;
    every_seconds?: number;
    daily_at?: string;
    weekly_at?: string;
    weekly_days?: number[];
    time_zone?: string;
    prompt?: string;
    remind?: boolean;
}
/**
 * Turn the flat `when` arguments into one schedule; exactly one of `at`,
 * `every_seconds`, `daily_at`, `weekly_at` may be present.
 * @param args - the tool arguments after schema validation.
 * @param zone - the zone for time-of-day rules when `time_zone` is absent.
 * @returns the schedule.
 * @throws when none or more than one selector is given, or weekly lacks days.
 */
export declare function scheduleOf(args: AddArgs, zone: string): Schedule;
/**
 * Build the three calendar tools over one scheduler.
 * @param cron - the scheduler the tools write through.
 * @param zone - the zone for time-of-day rules when the call names none (the host's zone).
 * @returns the registry-ready definitions, add / list / remove.
 */
export declare function createCalendarTools(cron: CalendarWriter, zone: string): ToolDefinition[];
export {};
//# sourceMappingURL=tools.d.ts.map