import type { SnapshotStore } from '@deepseek-ai/dsh-client-runtime/client';
import type { InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
/** Registration-side preference face. */
export interface ReturnToSendRowInjected {
    hooks: {
        /** Persisted Enter-to-send preference bound as useEnterToSend. */
        enterToSend: SnapshotStore<boolean>;
    };
    /** Change whether plain Enter submits. */
    setEnterToSend: (enabled: boolean) => void;
}
/** Full Settings-row props. */
export type ReturnToSendRowProps = PropsRuntime<'settings.general.item'> & PropsLocale<'conversation'> & InjectFace<ReturnToSendRowInjected>;
/**
 * Render the Enter-to-send selector.
 * @param props - composed Settings slot props.
 * @returns the preference row.
 */
export declare function ReturnToSendRow({ useEnterToSend, setEnterToSend, t }: ReturnToSendRowProps): import("react").JSX.Element;
//# sourceMappingURL=ReturnToSendRow.d.ts.map