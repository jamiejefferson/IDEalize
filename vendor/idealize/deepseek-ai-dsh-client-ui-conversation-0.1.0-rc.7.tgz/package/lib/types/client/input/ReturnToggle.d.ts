import type { SnapshotStore } from '@deepseek-ai/dsh-client-runtime/client';
import type { InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
/** Registration-side preference face. */
export interface ReturnToggleInjected {
    hooks: {
        /** Persisted Enter-to-send preference bound as useEnterToSend. */
        enterToSend: SnapshotStore<boolean>;
    };
    /** Change whether plain Enter submits. */
    setEnterToSend: (enabled: boolean) => void;
}
/** Composer-strip toggle props over the preference face. */
export type ReturnToggleProps = PropsRuntime<'conversation.input.right'> & PropsLocale<'conversation'> & InjectFace<ReturnToggleInjected>;
/**
 * Render the return-to-send toggle.
 * @param props - composed input.right slot props.
 * @returns the toggle button.
 */
export declare function ReturnToggle({ useEnterToSend, setEnterToSend, t }: ReturnToggleProps): import("react").JSX.Element;
//# sourceMappingURL=ReturnToggle.d.ts.map