/**
 * The file a prose token names: an assistant message's link destination, or
 * an inline-code token, read as a filesystem path. Whether that file opens
 * anywhere is the caller's business; this only decides what path the text
 * spells.
 */
/**
 * Read one link destination or inline-code token as a path.
 * @param value - The authored destination or token, exactly as written.
 * @returns The path it spells — absolute, `~/`, or relative to the session's
 * folder — or undefined when it names a URL of another scheme, a host other
 * than this machine, or is a relative phrase with spaces (`cat notes.md` is
 * a command, not a file). A `file:` URL becomes its decoded path; a trailing
 * `#fragment`, `?query` or `:line[:column]` is dropped.
 */
export declare function proseFilePath(value: string): string | undefined;
//# sourceMappingURL=prose-file-path.d.ts.map