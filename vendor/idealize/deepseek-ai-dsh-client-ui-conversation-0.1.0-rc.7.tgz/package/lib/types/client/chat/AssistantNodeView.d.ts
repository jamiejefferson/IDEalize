import type { ChatNodeViewProps } from '../contract/slots.ts';
import type { MarkdownFileMentions } from '@deepseek-ai/dsh-client-ui-primitives';
/**
 * One resolver over two, the first that recognizes a token answering it.
 * @param first - The higher-priority vocabulary, when there is one.
 * @param second - The fallback vocabulary, when there is one.
 * @returns The composed resolver, the only one present, or undefined.
 */
export declare function firstResolving(first: MarkdownFileMentions | undefined, second: MarkdownFileMentions | undefined): MarkdownFileMentions | undefined;
/** Streaming, settled, and interrupted Assistant states share one keyed renderer instance. */
export declare const AssistantNodeView: import("react").MemoExoticComponent<({ node, useTurnData, openFile, loadImage, fileMentions, fileLinks, t, }: ChatNodeViewProps<"assistant-step">) => import("react").JSX.Element>;
//# sourceMappingURL=AssistantNodeView.d.ts.map