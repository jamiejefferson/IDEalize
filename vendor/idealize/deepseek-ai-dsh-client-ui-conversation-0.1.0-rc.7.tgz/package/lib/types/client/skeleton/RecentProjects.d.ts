/**
 * V0's recent-project launch cards on the welcome slate: up to three
 * workspaces ranked by their sessions' last activity, each a one-click way
 * back into that project. Recency is derived client-side from the session
 * list (the host keeps no last-used stamp) — the same inputs the runtime's
 * recentWorkspaceId projection reduces to one id.
 */
import type { SessionListState, WorkspaceId, WorkspaceView } from '@deepseek-ai/dsh-client-runtime/client';
import type { ConversationSlotProps } from '../contract/slots.ts';
type HeroTranslate = ConversationSlotProps['t'];
/** Rank workspaces by their latest session activity, newest first. */
export declare function rankRecentWorkspaces(workspaces: readonly WorkspaceView[], sessions: SessionListState['byId'], limit?: number): WorkspaceView[];
export interface RecentProjectsProps {
    workspaces: readonly WorkspaceView[];
    sessions: SessionListState['byId'];
    /** The workspace this blank session already sits in — no card for it. */
    excludeId?: WorkspaceId | undefined;
    onPick: (workspaceId: WorkspaceId) => void;
    t: HeroTranslate;
}
/**
 * Render the recent-project cards, or nothing when no workspace exists yet.
 * @param props - see {@link RecentProjectsProps}.
 * @returns the card row.
 */
export declare function RecentProjects({ workspaces, sessions, excludeId, onPick, t }: RecentProjectsProps): import("react").JSX.Element | null;
export {};
//# sourceMappingURL=RecentProjects.d.ts.map