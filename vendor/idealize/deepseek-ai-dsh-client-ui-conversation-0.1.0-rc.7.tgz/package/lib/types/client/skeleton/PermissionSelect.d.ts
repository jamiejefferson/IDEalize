import type { PermissionSelect as PermissionSelectValue } from '@deepseek-ai/dsh-permission-presets/client';
import type { ComposerBarProps } from '../contract/slots.ts';
export interface PermissionSelectProps {
    value: PermissionSelectValue | undefined;
    locked: boolean;
    command: (line: string) => Promise<boolean>;
    /**
     * Keep a preset as the new-chat default; when present, the Full access
     * confirmation offers it as a second checkbox.
     */
    remember: ((preset: string) => Promise<void>) | undefined;
    /** The owning bar's locale seat, passed down as a plain prop. */
    t: ComposerBarProps['t'];
}
export declare function PermissionSelect({ value, locked, command, remember, t }: PermissionSelectProps): import("react").JSX.Element | null;
//# sourceMappingURL=PermissionSelect.d.ts.map