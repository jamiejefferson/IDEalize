/** Strict per-session header/body content inserted into the resident conversation layout. */
import type { ConversationSessionHeaderSlotProps, ConversationSessionSlotProps } from '../contract/slots.ts';
/** Full props composed from the strict session body contract. */
export type ConversationSessionProps = ConversationSessionSlotProps;
/** Full props composed from the strict session header contract. */
export type ConversationSessionHeaderProps = ConversationSessionHeaderSlotProps;
/**
 * Renders Session header chrome above the resident conversation scrollport.
 * The view ring has no tab row: a chat's active view is fixed by the space it
 * was launched into and is written into the shared chat store by the plugin
 * that owns that fact, so the header carries only the title row and its two
 * action seats.
 * @param props - Strict Session store, navigation, render, and locale shares.
 * @returns the hidden blank-session header or the visible title row.
 */
export declare function ConversationSessionHeader({ sessionId, useSession, useSessions, renderSlot, open, t, }: ConversationSessionHeaderProps): import("react").JSX.Element;
/**
 * Renders the active Session view inside the resident scrollport and keeps
 * the input draft mirrored while blank Hero chrome is visible.
 * @param props - Strict Session input/store, view ledger, and render shares.
 * @returns the active view area, or null while the blank Session shows the
 * hero (a blank Session on a non-chat view — a welcome-card launch into
 * Terminal, Gallery or Sound Stage — renders that view full-height instead,
 * under a header hidden like the hero's). `data-blank-view` carries the active
 * view's id in that case, so the hero chrome retires and a view that owns its
 * whole column can suppress the composer from its own package.
 */
export declare function ConversationSession({ sessionId, useSession, useInput, inputActions, useStore, actions, renderSlot, views, bindDraftMirror, releaseSessionImages, }: ConversationSessionProps): import("react").JSX.Element | null;
//# sourceMappingURL=ConversationSession.d.ts.map