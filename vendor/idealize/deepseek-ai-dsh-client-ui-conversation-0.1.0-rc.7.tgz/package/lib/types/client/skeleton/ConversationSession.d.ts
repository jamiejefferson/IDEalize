/** Strict per-session header/body content inserted into the resident conversation layout. */
import type { ConversationSessionHeaderSlotProps, ConversationSessionSlotProps } from '../contract/slots.ts';
/** Full props composed from the strict session body contract. */
export type ConversationSessionProps = ConversationSessionSlotProps;
/** Full props composed from the strict session header contract. */
export type ConversationSessionHeaderProps = ConversationSessionHeaderSlotProps;
/**
 * The Session title strip (JJ, 7 Oct 2026: "Kitchen quotes in Casa
 * Madrigal", so a glance says which chat and which project a prompt goes
 * to). The chat's name leads at title size; a deployment adds where the
 * chat lives through `conversation.session.header.context`. Clicking the
 * name renames the chat in place.
 *
 * The strip floats over the top of the scrollport, so a chat's transcript
 * scrolls up under it, blurred and faded; it writes its own height to the
 * root as `--dsh-session-header-height`, the scrollport's top padding, so
 * nothing starts hidden. A terminal view's grid fits below that padding, and
 * the strip turns opaque in the terminal's own colours
 * (`--dsh-terminal-bg` / `--dsh-terminal-fg`), since nothing scrolls under
 * it there. A blank chat still hides it behind the hero; a blank non-chat
 * view (a terminal chat) keeps it, so a terminal chat says where it is too.
 * @param props - Strict Session store, navigation, render, and locale shares.
 * @returns the hidden blank-session header or the visible title row.
 */
export declare function ConversationSessionHeader({ sessionId, useSession, useSessions, useStore, views, renderSlot, open, rename, t, }: ConversationSessionHeaderProps): import("react").JSX.Element;
/**
 * Renders the active Session view inside the resident scrollport and keeps
 * the input draft mirrored while blank Hero chrome is visible.
 * @param props - Strict Session input/store, view ledger, and render shares.
 * @returns the active view area, or null while the blank Session shows the
 * hero (a blank Session on a non-chat view — a welcome-card launch into
 * Terminal, Gallery or Sound Stage — renders that view full-height instead,
 * under a header hidden like the hero's). `data-blank-view` carries the active
 * view's id in that case, so the hero chrome retires and a view that owns its
 * whole column can suppress the composer from its own package.
 */
export declare function ConversationSession({ sessionId, useSession, useInput, inputActions, useStore, actions, renderSlot, views, bindDraftMirror, releaseSessionImages, }: ConversationSessionProps): import("react").JSX.Element | null;
//# sourceMappingURL=ConversationSession.d.ts.map