/**
 * @idealize/spaces — the space vocabulary and the durable record of which
 * space a chat is in.
 *
 * A space is what a chat IS: Chat, Terminal, Gallery, Sound Stage or Motion.
 * The spaces are declared in {@link SPACES}, not derived from the
 * `conversation.view` ring: a declared table states the roster whatever the
 * ring happens to carry, which is what let Motion appear as an ordinary tile
 * through the months it had no view. The ring keeps rendering the space; this
 * package owns the fact.
 *
 * The record is a session event, because the view ring's `view` field lives in
 * the browser's `localStorage` and cannot answer "which space is this chat" for
 * the sidebar, for the host, or on a second machine. `idealize/space` and
 * `idealize/brain` are appended with the envelope's `ignorable` marker and
 * projected as `space` and `brain`.
 *
 * The brain record is model-visible, not only durable:
 * {@link installBrainPrompt} contributes the logged brain's standing
 * instructions to the prompt of a chat the preset lock will no longer
 * recompose ({@link brainPersona}).
 *
 * HTTP:
 * - `POST /idealize/spaces/select` `{sessionId, space, brain?, instructions?}`
 *   records a chat's space, and its brain when one is named. Loopback-fenced
 *   and gated on `x-idealize-auth: 1`.
 * - `GET /idealize/spaces` serves the roster both welcome steps read: per
 *   space, its brain count and whether a model can serve it. The field split
 *   is the product invariant — see {@link spaceRoster}.
 * - `GET /idealize/spaces/icons/<space>.svg` serves each space's icon from
 *   `assets/icons/`, the one home of the six files every surface renders
 *   ({@link spaceIconSrc} names the URL). Loopback-only; any other path under
 *   the prefix answers 404 by table lookup, so no request text reaches the
 *   filesystem.
 *
 * Chats made before spaces existed are DERIVED, never backfilled: nothing is
 * written into an existing log ({@link deriveSpace}).
 * @module @idealize/spaces
 */
import type { Context } from '@deepseek-ai/cordis';
import { type Session } from '@deepseek-ai/dsh-session';
import { type SpaceId } from './space-table.ts';
export { CHAT_ONLY_PRESETS, DEFAULT_SPACE, deriveSpace, isSpaceId, LAUNCHABLE_SPACE_IDS, LAUNCHABLE_SPACES, presetSpaces, RETIRED_ROLE_PRESETS, SPACE_IDS, SPACES, spaceById, } from './space-table.ts';
export type { SpaceComposition, SpaceDefinition, SpaceId, SpaceRecord } from './space-table.ts';
export { brainProjectionDefinition, foldBrain, foldBrainRecord, foldSpace, resolveSessionSpace, spaceProjectionDefinition, } from './projection.ts';
export { brainPersona, installBrainPrompt } from './brain-prompt.ts';
export type { BrainPersona } from './brain-prompt.ts';
export type { BrainEventData, BrainProjection, SpaceEventData, SpaceProjection } from './projection-types.ts';
export { brainPresets, chatModelResolves, ROSTER_PATH, spaceCapabilityRequirements, spaceRoster } from './roster.ts';
export { SPACE_ICON_PATH, spaceIconSrc } from './space-icons.ts';
export type { ActivitySpacesSection, CapabilityPreset, ChatModelSections, RosterPreset, SpaceBrain, SpaceReason, SpaceRosterEntry, SpaceRosterFacts, } from './roster.ts';
/** Cordis plugin name. */
export declare const name = "idealize-spaces";
/** The route that records a chat's space. */
export declare const SELECT_PATH = "/idealize/spaces/select";
/**
 * The space an icon request names: the pathname must be exactly
 * `/idealize/spaces/icons/<space>.svg` for a declared space id. Anything else,
 * including a traversal attempt, is undefined; the id is then a table member,
 * so the file path built from it carries no request text.
 * @param pathname - the request's pathname, query already stripped.
 * @returns the declared space, or undefined when the path names none.
 */
export declare function iconSpace(pathname: string): SpaceId | undefined;
/** An accepted selection, or the refusal to send back as a 400. */
export type SpaceSelection = {
    ok: true;
    sessionId: string;
    space: SpaceId;
    brain?: string;
    instructions?: string;
} | {
    ok: false;
    error: string;
};
/**
 * Validate one POST body for the selection route. The wire is where shapes are
 * checked; the append path then trusts what it receives.
 * @param body - the parsed JSON body (wire boundary: untrusted).
 * @returns the accepted selection, or the refusal.
 */
export declare function parseSelection(body: unknown): SpaceSelection;
/**
 * Record a chat's space, and its brain when the selection names one.
 *
 * Both events carry the envelope's `ignorable` marker: a reader without this
 * vocabulary resolves the chat's space through the derivation ladder instead of
 * refusing the log. An event is skipped when the log already records the same
 * value, so re-entering a space does not grow the log.
 * @param session - the chat to record against.
 * @param selection - the validated selection.
 * @returns which events were appended.
 */
export declare function recordSelection(session: Session, selection: Extract<SpaceSelection, {
    ok: true;
}>): {
    space: boolean;
    brain: boolean;
};
/**
 * Register the space and brain projections, the selection route, and the
 * roster route.
 * @param ctx - the host plugin context.
 */
export declare function apply(ctx: Context): void;
//# sourceMappingURL=index.d.ts.map