/**
 * The one-time clean-up of blank chats. A new chat writes a log as soon as its
 * preset is chosen, whether or not anyone ever types in it, and nothing removed
 * them: on one Mac, 177 of 269 chats, every one re-read on every session list.
 *
 * Blank does not mean empty of work. A Terminal chat's prompts go straight to
 * its command-line agent, so its log stays blank for life, and any chat can show
 * its Terminal face without recording a space. So a chat moves only when
 * everything agrees it was never used, and anything unrecognised keeps it. It
 * moves to a dated folder inside the sessions folder, whole, and nothing is
 * erased: moving the folder back restores it.
 * @module @idealize/spaces/blank-chats
 */
import type { SessionEvent, SessionHeader, SessionId } from '@deepseek-ai/dsh-session';
/** What the clean-up asks of the session store. */
export interface BlankChatStore {
    list(): Promise<readonly SessionHeader[]>;
    readFrom(id: SessionId, fromSeq: number): Promise<{
        meta: SessionHeader;
        events: readonly SessionEvent[];
    }>;
    locate(meta: SessionHeader): {
        path: string;
    } | undefined;
}
/**
 * Whether a log says this chat was never used.
 * @param session - the header and events.
 * @param now - the current time.
 * @returns true only for a top-level Chat-space chat over a day old holding nothing but opening records.
 */
export declare function logSaysBlank(session: {
    header: SessionHeader;
    events: readonly SessionEvent[];
}, now: number): boolean;
/**
 * The conversation id a chat's Terminal runs a program under. This must stay
 * equal to `conversationId` in `@idealize/ui-terminal`; a test holds them
 * together, and this package cannot import that one.
 */
export declare function terminalConversationId(chat: string, program: string): string;
/**
 * Move every blank chat aside, once. A marker file records the run; a run that
 * cannot look everywhere it should moves nothing and writes no marker.
 * @param options.store - the session store.
 * @param options.isLive - whether a chat is open in this run.
 * @param options.home - the app's data folder.
 * @param options.userHome - where Claude Code and Pi keep their conversations.
 * @param options.now - the current time.
 * @param options.log - where to say what happened.
 * @returns the chat ids moved, or undefined when this already ran.
 */
export declare function setAsideBlankChats(options: {
    store: BlankChatStore;
    isLive: (id: SessionId) => boolean;
    home: string;
    userHome?: string;
    claudeDir?: string;
    now: number;
    log: (message: string) => void;
}): Promise<string[] | undefined>;
//# sourceMappingURL=blank-chats.d.ts.map