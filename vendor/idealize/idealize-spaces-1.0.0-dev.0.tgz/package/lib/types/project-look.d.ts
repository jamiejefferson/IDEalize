import type { IncomingMessage, ServerResponse } from 'node:http';
/** The route prefix every project-look request sits under. */
export declare const PROJECT_LOOK_PATH = "/idealize/project-look";
/** The largest logo the route reads or stores, in bytes. */
export declare const PROJECT_LOGO_MAX_BYTES: number;
/**
 * The files an automatic logo is looked for in, relative to the project's
 * folder, in the order they are tried: a favicon first, since a web project's
 * favicon is the mark people already know it by, then logos and icons, then
 * the same names in the folders web frameworks keep them in.
 */
export declare const AUTO_LOGO_CANDIDATES: readonly string[];
/** How a project's logo is chosen. */
export type ProjectLogoMode = 'auto' | 'custom' | 'none';
/** One project's stored look. */
export interface ProjectLookRecord {
    /** `#rrggbb`, or absent for no accent. */
    accent?: string;
    /** Absent means automatic. */
    logo?: ProjectLogoMode;
    /** The stored image's file name under the images folder, while `logo` is custom. */
    image?: string;
}
/** One project's look as the sidebar receives it. */
export interface ProjectLookView {
    accent: string | null;
    logo: ProjectLogoMode;
    /** The logo's URL with a version query, or null when the row keeps its folder. */
    iconUrl: string | null;
}
/**
 * The image type of some bytes, from their opening signature; SVG is
 * recognised by an `<svg` element near the top. Anything else is refused.
 * @param body - the file's bytes.
 * @returns the extension to store it under, or undefined.
 */
export declare function sniffImage(body: Buffer): string | undefined;
/**
 * Whether a value is an accent the store accepts.
 * @param value - the candidate.
 * @returns true for a `#rrggbb` colour.
 */
export declare function isAccent(value: unknown): value is string;
/** The registry facts the route needs: each opened project's id and folder. */
export interface ProjectDirectory {
    list(): readonly {
        id: string;
        path: string;
    }[];
}
/**
 * The project-look store and its routes' logic, over a data folder. Kept
 * free of the host context so the tests drive it over a temporary folder.
 */
export declare class ProjectLooks {
    private readonly dataDir;
    private readonly projects;
    private readonly now;
    private records;
    private writing;
    private readonly autoCache;
    /**
     * @param dataDir - the folder the store file and stored images live in.
     * @param projects - the opened projects.
     * @param now - the clock, for the automatic-logo cache.
     */
    constructor(dataDir: string, projects: ProjectDirectory, now?: () => number);
    private get file();
    private get imageDir();
    /** The stored records; a missing or damaged file reads as no looks. */
    load(): Promise<Record<string, ProjectLookRecord>>;
    private save;
    /**
     * The automatic logo in a project's folder: the first candidate that is a
     * small regular file whose real path stays inside the folder.
     * @param folder - the project's folder.
     * @returns the logo's absolute path, or undefined.
     */
    autoLogo(folder: string): Promise<string | undefined>;
    /**
     * The logo file a project shows, if any.
     * @param id - the workspace id.
     * @returns the file's path, or undefined for the folder glyph.
     */
    logoFile(id: string): Promise<string | undefined>;
    /** Every opened project's look, for the sidebar. */
    list(): Promise<Record<string, ProjectLookView>>;
    /**
     * Change a project's accent or logo mode.
     * @param id - the workspace id.
     * @param change - the fields to change; `accent: null` clears it.
     * @returns false when no opened project has that id.
     */
    update(id: string, change: {
        accent?: string | null;
        logo?: 'auto' | 'none';
    }): Promise<boolean>;
    /**
     * Store a chosen image as a project's logo.
     * @param id - the workspace id.
     * @param body - the image's bytes.
     * @returns 'ok', or why it was refused.
     */
    storeImage(id: string, body: Buffer): Promise<'ok' | 'no-project' | 'too-large' | 'not-an-image'>;
}
/**
 * Handle one request under {@link PROJECT_LOOK_PATH}.
 * @param looks - the store.
 * @param req - the request.
 * @param res - the response.
 * @param refuse - the loopback fence and mutation-header check the other IDEalize routes share.
 */
export declare function handleProjectLook(looks: ProjectLooks, req: IncomingMessage, res: ServerResponse, refuse: (req: IncomingMessage, res: ServerResponse, mutating?: boolean) => boolean): Promise<void>;
//# sourceMappingURL=project-look.d.ts.map