/**
 * Runs the blank-chat clean-up and the start-up tidy. Neither can stop the app
 * starting: a failure is logged and the files stay as they are.
 * @module @idealize/spaces/housekeeping
 */
import type { Context } from '@deepseek-ai/cordis';
/**
 * Set blank chats aside once, then tidy old files well after start-up. Both act
 * only when the store's logs are this data folder's own. A store elsewhere, such
 * as a test's or a tool's, says nothing about what this data folder holds, and
 * its run must leave no record here.
 * @param ctx - the plugin context holding the session store.
 * @param home - the app's data folder.
 * @param tidyDelayMs - how long the tidy waits.
 */
export declare function installHousekeeping(ctx: Context, home?: string, tidyDelayMs?: number): Promise<void>;
//# sourceMappingURL=housekeeping.d.ts.map