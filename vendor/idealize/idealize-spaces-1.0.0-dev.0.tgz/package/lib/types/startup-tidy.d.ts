/**
 * Start-up housekeeping for two things that otherwise grow for ever: attachments
 * no chat refers to, and old crash dumps. Both only go when they are older than
 * 30 days. An attachment goes only after every chat log, set-aside chats
 * included, has been read and none mentions it; one log that cannot be read
 * means nothing is certain, so no attachment goes that day.
 *
 * It reads every log, so it runs well after start-up, at most once a week.
 * @module @idealize/spaces/startup-tidy
 */
/** The one thing the tidy asks of the session store: see `readEveryFile` in the JSONL backend. */
export interface EveryFileReader {
    readEveryFile(): AsyncIterable<{
        path: string;
        text: string;
    }>;
}
/** What one tidy did. */
export interface TidyResult {
    attachments: number;
    dumps: number;
    /** Why attachments were left alone, when they were. */
    uncertain?: string;
}
/**
 * Where a packaged Mac app keeps crash dumps: `Crashpad` beside the `harness`
 * data folder. Anywhere else, including a data folder chosen by hand, there is
 * nothing here the tidy can be sure of.
 * @param home - the app's data folder.
 * @param platform - the operating system.
 * @param electron - the Electron version, when running inside the app.
 * @returns the folder, or undefined.
 */
export declare function crashDumpFolder(home: string, platform?: NodeJS.Platform, electron?: string | undefined): string | undefined;
/**
 * Run the tidy if it is due.
 * @param options.home - the app's data folder.
 * @param options.store - reads every chat log; absent, attachments are left alone.
 * @param options.crashDumps - the crash dump folder, when this run has one.
 * @param options.now - the current time.
 * @returns what it did, or undefined when it was not due.
 */
export declare function tidyOnStart(options: {
    home: string;
    store: EveryFileReader | undefined;
    crashDumps: string | undefined;
    now: number;
}): Promise<TidyResult | undefined>;
//# sourceMappingURL=startup-tidy.d.ts.map