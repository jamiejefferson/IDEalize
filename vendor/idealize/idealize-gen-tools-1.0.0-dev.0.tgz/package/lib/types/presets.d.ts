/**
 * The media agent presets (Gallery, Sound Stage, Video), the composition each
 * one is seeded with, and the rule every brain confined to generating spaces
 * follows. Unlike the activity agents — whose compositions derive from the
 * shipped `standard` preset and carry its full tool set — a media agent
 * composes ONLY the generation toolset (AC-06): its persona, the
 * `@idealize/gen-tools/tools` row, and the background-job controls.
 *
 * The space owns the tools and the brain owns the model and the instructions
 * (JJ, 7 Sep 2026). {@link mediaCompositionFor} is that rule as a function: a
 * brain whose every space generates gets this composition whatever its name,
 * so a custom brain placed in Images composes `generate_image` and nothing
 * that could reach for a shell.
 * @module @idealize/gen-tools/presets
 */
import { type SpaceId } from '@idealize/spaces';
/** One media agent's identity and the preset it seeds. */
export interface MediaAgentDefinition {
    /** Preset id (and directory name) under the user root. */
    id: string;
    /** Roster display name. */
    name: string;
    /** Roster description. */
    description: string;
    /** Roster sort position, after the activity agents. */
    order: number;
    /** The generating space this agent serves; the space table's `agentPreset` names this agent back. */
    space: SpaceId;
    /**
     * What the agent does, stated without its name and ending in a full stop:
     * the tool it uses and where the result lands. A custom brain in the same
     * space inherits this sentence in its default persona.
     */
    duty: string;
    /** Persona text the seeded composition carries: {@link mediaPersona} over the name and the duty. */
    persona: string;
}
/**
 * The persona a generating brain carries: its name, its duties in space order,
 * the reporting line, and the shared voice line.
 * @param name - the brain's display name.
 * @param duties - one {@link MediaAgentDefinition.duty} sentence per space the brain works in.
 * @returns the persona text, with the `{{model}}` and `{{cwd}}` placeholders the persona plugin fills.
 */
export declare function mediaPersona(name: string, duties: readonly string[]): string;
/** The three media agents, in roster order. */
export declare const MEDIA_AGENTS: readonly MediaAgentDefinition[];
/** The media agent ids in roster order. */
export declare const MEDIA_AGENT_IDS: readonly string[];
/**
 * The plugin names a generation-only composition may carry: the persona, the
 * generation tools, the background-job controls, and the per-project
 * instructions reader. Anything else (a shell, the filesystem, the web,
 * delegation) makes the composition a standard one.
 */
export declare const GENERATION_ONLY_PLUGINS: ReadonlySet<string>;
/**
 * Build one media agent's composition text ({@link renderMediaComposition}
 * over the agent's own persona).
 * @param agent - the media agent whose persona the composition carries.
 * @returns the `agent.cordis.yml` text to seed.
 */
export declare function buildMediaComposition(agent: MediaAgentDefinition): string;
/**
 * Whether every space in a list generates: non-empty, and each row of the
 * space table declares the `media` composition.
 * @param spaces - the spaces a brain works in.
 * @returns true for a brain confined to Images, Sounds and Video in any mix.
 */
export declare function generatesOnly(spaces: readonly SpaceId[]): boolean;
/**
 * The composition a brain confined to generating spaces composes.
 *
 * When `spaces` is non-empty and every one declares the `media` composition,
 * the result is the generation-only composition whose persona is
 * `instructions` when non-empty, else {@link mediaPersona} over `name` and the
 * duties of the media agents serving those spaces, in table order. A brain
 * that works in Chat or Terminal, or in no space, gets `undefined`: it derives
 * from the shipped `standard` preset instead.
 * @param spaces - the launchable spaces the brain works in.
 * @param name - the brain's display name, for the default persona.
 * @param instructions - the persona the user wrote; empty for the default.
 * @returns the `agent.cordis.yml` text, or undefined when the spaces do not all generate.
 */
export declare function mediaCompositionFor(spaces: readonly SpaceId[], name: string, instructions: string): string | undefined;
/**
 * Whether a composition carries the generation toolset and nothing outside it:
 * a top-level row list whose plugin names are all in
 * {@link GENERATION_ONLY_PLUGINS}, with the `@idealize/gen-tools/tools` row
 * among them. Text the loader's YAML dialect cannot parse, or that is not a
 * row list, is not generation-only.
 * @param text - the `agent.cordis.yml` text.
 * @returns true for a composition {@link mediaCompositionFor} would produce, or one reduced to the same rows by hand.
 */
export declare function isGenerationOnlyComposition(text: string): boolean;
/**
 * Whether a roster already carries any media agent.
 * @param ids - the preset ids the roster reports.
 * @returns true when at least one media agent id is present.
 */
export declare function hasMediaAgentPresets(ids: Iterable<string>): boolean;
/**
 * The media agent a generating space seeds, read back from the space table so
 * the two tables cannot drift: every `media` space names one of
 * {@link MEDIA_AGENTS}, and every media agent's `space` names it back.
 * @returns one agent per generating space, in table order.
 * @throws when a generating space names no media agent, or a media agent names a space that does not name it.
 */
export declare function mediaAgentsBySpace(): Map<SpaceId, MediaAgentDefinition>;
//# sourceMappingURL=presets.d.ts.map