/**
 * `add_soundtrack`: put a sound onto a video the project already holds, as a
 * new video artefact. A Studio chat composes no shell, so before this tool it
 * could make a clip and a sound and had no way to join them: JJ's first try
 * (26 Nov 2026) ended with the agent asking another chat to do it and telling
 * the person the work was under way, while that chat waited for a go-ahead.
 *
 * The join runs through the `ffmpeg` program on this computer. The video
 * stream is copied untouched, the sound replaces the clip's own audio, and the
 * result is as long as the video: a shorter sound ends in silence and a longer
 * one is cut. Neither input is changed.
 * @module @idealize/gen-tools/soundtrack
 */
import type { Context } from '@deepseek-ai/cordis';
import type { ToolDefinition } from '@deepseek-ai/dsh-tools';
/** The tool's name; `@idealize/ui-gallery` and `@idealize/comm` restate it to show the result as a Studio row. */
export declare const SOUNDTRACK_TOOL = "add_soundtrack";
/** What the tool needs from the computer; tests replace both. */
export interface SoundtrackDeps {
    /** The absolute path of `ffmpeg`, or undefined when this computer has none. */
    findFfmpeg(): Promise<string | undefined>;
    /** Run `ffmpeg` with these arguments; rejects with its last words when it fails. */
    run(program: string, args: readonly string[], signal: AbortSignal): Promise<void>;
}
/**
 * Find `ffmpeg`: the copy the app ships, which the desktop shell names in
 * `IDEALIZE_FFMPEG`, and failing that one on `PATH` or in the folders a
 * package manager installs to.
 * @param env - the environment read for the shipped copy and for `PATH`.
 * @returns the program's path, or undefined.
 */
export declare function findFfmpeg(env?: NodeJS.ProcessEnv): Promise<string | undefined>;
export declare const runProgram: SoundtrackDeps['run'];
/**
 * The `ffmpeg` arguments for one join: the video's picture copied as it is,
 * the sound as the only audio, padded with silence or cut to the video's length.
 * @param video - the video file.
 * @param audio - the sound file.
 * @param offsetSeconds - how long into the video the sound starts.
 * @param output - where the joined file is written.
 * @returns the argument list.
 */
export declare function joinArguments(video: string, audio: string, offsetSeconds: number, output: string): string[];
/**
 * Resolve one input to a file on disk: an artefact id names a stored result
 * through `ctx.artefacts`; any other value is a path under the project, and
 * one that resolves outside it is refused. The model produced the value, so
 * every step is checked.
 */
export declare function resolveInput(ctx: Context, name: 'video' | 'audio', reference: string, projectPath: string, tool?: string): Promise<string>;
/**
 * Build the tool over the host services.
 * @param ctx - the plugin context carrying `artefacts` and `workspaceRegistry`.
 * @param deps - how `ffmpeg` is found and run; the defaults use this computer.
 * @returns the registry-ready tool definition.
 */
export declare function createSoundtrackTool(ctx: Context, deps?: SoundtrackDeps): ToolDefinition;
/** The prompt section every Studio chat carries: what it can do itself, and what it must never claim. */
export declare const STUDIO_SECTION: {
    readonly name: "idealize:studio-work";
    readonly order: 122;
    readonly text: string;
};
//# sourceMappingURL=soundtrack.d.ts.map