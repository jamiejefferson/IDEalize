/**
 * The limits on what a generating chat can spend. A generation charges the
 * person's own provider account, and until 4 Nov 2026 nothing asked them first
 * or bounded a single call, so a chat that read hostile text could order a
 * thousand images in one line.
 *
 * Two parts. Hard caps on one call, which hold for everyone. And one question
 * per model: the first generation on each model that may charge waits for the
 * person's yes, which names the model and its price when the provider
 * publishes one (JJ, 24 Nov 2026: "first use of each model"). The yes is kept
 * in settings, so later generations on that model run without asking, and the
 * Models pane lists the approved models with a way to be asked again.
 * @module @idealize/gen-tools/paid
 */
import type { Session } from '@deepseek-ai/dsh-session';
import type { GenArtefact, GenCatalogEntry } from '@idealize/generate';
/**
 * The most items one call may ask for. The Images composer offers up to 4, and
 * 8 leaves room for someone asking in words for "eight options".
 */
export declare const MAX_COUNT = 8;
/**
 * The longest output one call may ask for, in seconds. 60 s of video is several
 * times the composer's longest fallback option (10 s), and 300 s of audio
 * covers a full song.
 */
export declare const MAX_SECONDS: Readonly<Record<Exclude<GenArtefact, 'image'>, number>>;
/**
 * Refuse a call over the caps, before any money or network is involved.
 * @param toolName - the tool, for the message.
 * @param artefact - what it makes.
 * @param args - the tool's own count and duration, and the provider inputs passed through `options`.
 * @param args.count - the requested number of items.
 * @param args.duration_s - the requested duration in seconds.
 * @param args.options - provider inputs by their own names.
 * @throws when the call asks for more than a cap allows.
 */
export declare function assertWithinCaps(toolName: string, artefact: GenArtefact, args: {
    count?: number | undefined;
    duration_s?: number | undefined;
    options?: Record<string, unknown> | undefined;
}): void;
/** A model with a known price of zero costs nothing; a model with no published price may cost something. */
export declare function mayCharge(entry: GenCatalogEntry): boolean;
/**
 * The key a model is approved under: its backend and its id.
 * @param entry - the model.
 * @returns `backend/model`.
 */
export declare function approvalKey(entry: GenCatalogEntry): string;
/**
 * What the person reads: the model, and its price when the provider publishes one.
 * @param entry - the model the generation will run on.
 * @returns the question shown beside Allow and Deny.
 */
export declare function paidQuestion(entry: GenCatalogEntry): string;
/** The slice of the approval service used here, read structurally: gen-tools composes without a dependency on it. */
export interface ApprovalFace {
    config?: {
        policy?: string | undefined;
    };
    overrideOf?(session: Session): string | undefined;
    request(request: {
        agent: {
            session: Session;
        };
        toolName: string;
        callId?: unknown;
        reason?: string;
        signal?: AbortSignal;
    }): Promise<string>;
}
/** Where the approved models are kept: the settings section in the app, a plain map in a test. */
export interface ApprovedModels {
    /** Whether the person has approved this model. */
    has(key: string): boolean;
    /** Record the person's yes for this model, under the name they were shown. */
    add(key: string, name: string): Promise<void>;
}
/**
 * Hold a generation on a model that may charge until the person has approved
 * that model.
 *
 * Calls already waiting on the same model share one question. A refusal is not
 * remembered, so a later call asks again. A chat on Full access has no prompt
 * to show, because its approval policy answers every request with no, so it
 * runs without asking; the caps still hold there. A composition with no
 * approval service, or with nowhere to keep the answer, has nobody to ask, and
 * every shipped profile carries both.
 * @param approval - the approval service, when composed.
 * @param approved - where approved models are kept, when composed.
 * @param request - the call that wants to generate.
 * @param request.agent - the chat making it.
 * @param request.toolName - the tool.
 * @param request.callId - the tool call.
 * @param request.signal - the call's abort signal.
 * @param entry - the model it will run on.
 * @throws when the person said no, or could not be asked.
 */
export declare function confirmPaidGeneration(approval: ApprovalFace | undefined, approved: ApprovedModels | undefined, request: {
    agent: {
        session: Session;
    };
    toolName: string;
    callId?: unknown;
    signal?: AbortSignal;
}, entry: GenCatalogEntry): Promise<void>;
//# sourceMappingURL=paid.d.ts.map