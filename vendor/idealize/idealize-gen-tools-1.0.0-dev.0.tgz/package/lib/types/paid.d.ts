/**
 * The limits on what a generating chat can spend. A generation charges the
 * person's own provider account, and until 4 Nov 2026 nothing asked them first
 * or bounded a single call, so a chat that read hostile text could order a
 * thousand images in one line.
 *
 * Two parts. Hard caps on one call, which hold for everyone. And one question
 * per launch: the first paid generation nobody typed a request for waits for
 * the person's yes in that chat. Generation tools mount once per chat, so that
 * answer lives here at module level and is forgotten when the app restarts.
 * @module @idealize/gen-tools/paid
 */
import type { Session } from '@deepseek-ai/dsh-session';
import type { GenArtefact, GenCatalogEntry } from '@idealize/generate';
/**
 * The most items one call may ask for. The Images composer offers up to 4, and
 * 8 leaves room for someone asking in words for "eight options".
 */
export declare const MAX_COUNT = 8;
/**
 * The longest output one call may ask for, in seconds. 60 s of video is several
 * times the composer's longest fallback option (10 s), and 300 s of audio
 * covers a full song.
 */
export declare const MAX_SECONDS: Readonly<Record<Exclude<GenArtefact, 'image'>, number>>;
/**
 * Whether a person typing in this turn still gets asked. False costs the person
 * least: someone who types "make me a poster" in the Images space has already
 * said yes. Set this to true to ask before the first paid generation of a
 * launch whoever started it.
 */
export declare const ASK_WHEN_PERSON_TYPED: boolean;
/**
 * Refuse a call over the caps, before any money or network is involved.
 * @param toolName - the tool, for the message.
 * @param artefact - what it makes.
 * @param args - the tool's own count and duration, and the provider inputs passed through `options`.
 * @param args.count - the requested number of items.
 * @param args.duration_s - the requested duration in seconds.
 * @param args.options - provider inputs by their own names.
 * @throws when the call asks for more than a cap allows.
 */
export declare function assertWithinCaps(toolName: string, artefact: GenArtefact, args: {
    count?: number | undefined;
    duration_s?: number | undefined;
    options?: Record<string, unknown> | undefined;
}): void;
/** A model with a known price of zero costs nothing; a model with no published price may cost something. */
export declare function mayCharge(entry: GenCatalogEntry): boolean;
/** What the person reads: the model, and its price when the provider publishes one. */
export declare function paidQuestion(entry: GenCatalogEntry): string;
/**
 * Whether the person typed in the turn this call belongs to. A note, a wake or
 * another chat's brief carries a different source, so it does not count.
 * @param session - the chat.
 * @returns true when a message of theirs opened or joined this turn.
 */
export declare function personTypedThisTurn(session: Pick<Session, 'events'>): boolean;
/** The slice of the approval service used here, read structurally: gen-tools composes without a dependency on it. */
export interface ApprovalFace {
    config?: {
        policy?: string | undefined;
    };
    overrideOf?(session: Session): string | undefined;
    request(request: {
        agent: {
            session: Session;
        };
        toolName: string;
        callId?: unknown;
        reason?: string;
        signal?: AbortSignal;
    }): Promise<string>;
}
/** Forget this launch's answer, for tests. */
export declare function forgetPaidConfirmation(): void;
/**
 * Hold a paid generation until the person has said yes once in this launch.
 *
 * Calls already running share one question, so a burst raises one prompt. A
 * refusal is not remembered, so a later call asks again. A chat on Full access
 * has no prompt to show, because its approval policy answers every request with
 * no, so it runs without asking; the caps still hold there. A composition with
 * no approval service has nobody to ask, and every shipped profile carries one.
 * @param approval - the approval service, when composed.
 * @param request - the call that wants to generate.
 * @param request.agent - the chat making it.
 * @param request.toolName - the tool.
 * @param request.callId - the tool call.
 * @param request.signal - the call's abort signal.
 * @param entry - the model it will run on.
 * @throws when the person said no, or could not be asked.
 */
export declare function confirmPaidGeneration(approval: ApprovalFace | undefined, request: {
    agent: {
        session: Session;
    };
    toolName: string;
    callId?: unknown;
    signal?: AbortSignal;
}, entry: GenCatalogEntry): Promise<void>;
//# sourceMappingURL=paid.d.ts.map