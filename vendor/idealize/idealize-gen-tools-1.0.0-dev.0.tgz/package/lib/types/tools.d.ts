/**
 * @idealize/gen-tools/tools — the three generation tools (`generate_image`,
 * `generate_video`, `generate_audio`): the Consumer role of the generation
 * seam, composed from a media agent preset so only Gallery / Sound Stage
 * sessions carry them (AC-06).
 *
 * Each call routes one task through `ctx.generation`: the media preset's
 * required capabilities filter the catalogue, the stored preset→model choice
 * (the `models` map of the `idealize-activity-pills` settings section) picks
 * the model, and a stored choice absent from the compatible catalogue falls
 * back to the first compatible entry — the stored value stays untouched, the
 * session logs `generation/rerouted`, and the tool result carries the same
 * notice (BRN routing rule). Zero compatible models is the BRN-09 unavailable
 * state: the call fails with the seam's recovery action.
 *
 * Results are committed through `ctx.artefacts` (bytes under the project,
 * durable record, `artefact/created`); a generation failure appends
 * `artefact/failed` carrying the adapter's GenerationError message (MOD-05)
 * and fails the call. `run_in_background: true` runs the generation as
 * `ctx.jobs` work and returns the job id immediately.
 * @module @idealize/gen-tools/tools
 */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import type { JsonValue } from '@deepseek-ai/dsh-session/types';
import type { ToolDefinition } from '@deepseek-ai/dsh-tools';
import type { GenAttachment } from '@idealize/generate';
export type { GenerationReroutedData } from './types.ts';
declare module '@deepseek-ai/dsh-jobs' {
    interface JobKindMap {
        generation: 'generation';
    }
}
/** Cordis plugin name. */
export declare const name = "idealize-generation-tools";
/** Required services; settings and jobs stay optional (`ctx.get`). */
export declare const inject: string[];
/** Plugin config. */
export interface Config {
    /** Expose `run_in_background` and accept background generations (default true). */
    enableRunInBackground?: boolean;
}
/** Runtime schema for {@link Config}. */
export declare const Config: z<Config>;
/**
 * Resolve a `reference_image` argument to the bytes a generation request
 * attaches: an artefact id names a stored image through `ctx.artefacts`; any
 * other value is a path under `projectPath`, and one that resolves outside it
 * is refused rather than read. The model produced the value, so every step
 * is checked.
 * @param ctx - the plugin context carrying `artefacts`.
 * @param toolName - the calling tool, for the refusal.
 * @param reference - the argument as the model sent it.
 * @param projectPath - the project the path form is fenced to.
 * @returns the attachment, base64 encoded.
 * @throws when the id is unknown or not an image, the path leaves the project, the file is missing, or its type is not an image.
 */
export declare function resolveReferenceImage(ctx: Context, toolName: string, reference: string, projectPath: string): Promise<GenAttachment>;
/**
 * The `options` a call carries, validated at the model JSON boundary: every
 * value must be a string, number or boolean, since the provider's input
 * fields are scalars and a nested value would be refused far from its cause.
 * @param toolName - the calling tool, for the refusal.
 * @param options - the `options` argument as the model sent it.
 * @returns the scalar options, empty when none were sent.
 * @throws when a value is not a scalar.
 */
export declare function scalarOptions(toolName: string, options: Record<string, JsonValue> | undefined): Record<string, string | number | boolean>;
/**
 * Build the three generation tools over the host services.
 * @param ctx - the plugin context carrying `generation`, `artefacts`, `workspaceRegistry`, and optionally `settings` and `jobs`.
 * @param config - background-run gating.
 * @returns the registry-ready tool definitions, one per artefact kind.
 */
export declare function createGenerationTools(ctx: Context, config?: Config): ToolDefinition[];
/**
 * Register the three generation tools.
 * @param ctx - the plugin context.
 * @param config - background-run gating.
 */
export declare function apply(ctx: Context, config?: Config): void;
//# sourceMappingURL=tools.d.ts.map