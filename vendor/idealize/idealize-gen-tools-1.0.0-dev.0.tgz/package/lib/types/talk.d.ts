/**
 * The `idealize` commands as tools, for the generating chats (Images, Sounds,
 * Video). Every other chat reaches its peers through the `idealize` command in
 * its shell; a generating chat composes no shell (AC-06), so it could neither
 * fetch a brief from another chat nor read the note another chat sent it,
 * and the wake notice told it to run a command it did not have (feedback
 * 553ae5fb, 13 Oct 2026). These tools call the same `ctx.idealizeComm`
 * service the shell command reaches, as the calling chat, and give it no
 * file, shell or web access.
 * @module @idealize/gen-tools/talk
 */
import type { Context } from '@deepseek-ai/cordis';
import type { ToolDefinition } from '@deepseek-ai/dsh-tools';
/** The prompt section a generating chat carries alongside the tools. */
export declare const TALK_SECTION: {
    readonly name: "idealize:talk";
    readonly order: 121;
    readonly text: string;
};
/**
 * Build the five tools over the comm service.
 * @param ctx - the agent's context; `idealizeComm` is read per call, so a late-composed service still answers.
 * @returns the tool definitions.
 */
export declare function createTalkTools(ctx: Context): ToolDefinition[];
//# sourceMappingURL=talk.d.ts.map