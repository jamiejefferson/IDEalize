/**
 * @idealize/gen-tools — host half: seeds the three media agent presets
 * (Gallery, Sound Stage, Video) into the user preset root the first time a
 * deployment runs without any of them, so the welcome card's Images, Sounds
 * and Video choices have presets to select. Each seeded composition carries
 * ONLY the generation toolset — its persona, the `@idealize/gen-tools/tools`
 * row, and the background-job controls — so a generating session composes no
 * shell, filesystem, web, or delegation tools (AC-06). Seeding never
 * overwrites: a root that holds any media agent id is left as it is, so a
 * user who deletes one keeps that deletion (the `@idealize/activity-pills`
 * seeding rule).
 *
 * The same composition is what every brain confined to generating spaces
 * gets, seeded or not: `mediaCompositionFor` builds it for
 * `@idealize/activity-pills`, which applies it when a brain is created or
 * saved into Images, Sounds or Video and repairs presets that predate the
 * rule at startup.
 *
 * The tools themselves live at `@idealize/gen-tools/tools`, registered from
 * the preset compositions rather than here — a host-plane registration would
 * put the generation tools in every session's catalogue.
 * @module @idealize/gen-tools
 */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
export { GENERATION_ONLY_PLUGINS, MEDIA_AGENTS, MEDIA_AGENT_IDS, buildMediaComposition, generatesOnly, hasMediaAgentPresets, isGenerationOnlyComposition, mediaAgentsBySpace, mediaCompositionFor, mediaPersona, } from './presets.ts';
export type { MediaAgentDefinition } from './presets.ts';
export type { GenerationReroutedData } from './types.ts';
/** Plugin config. */
export interface Config {
    /**
     * The preset root the media agents are written to. Defaults to the
     * roster's own user root (`$DSH_HOME/.agent-presets`), which is where
     * `dsh-agent-presets` reads locally authored presets from.
     */
    root?: string;
}
/** Runtime schema for {@link Config}. */
export declare const Config: z<Config>;
/** Cordis plugin name. */
export declare const name = "idealize-gen-tools";
/** Required services. */
export declare const inject: string[];
/**
 * Seed the media agent presets unless the roster already carries one.
 * @param ctx - the host plugin context (its `agentPresets` roster is consulted).
 * @param root - the preset root directory the agents are written into.
 * @returns resolves once seeding finished or was skipped.
 */
export declare function seedMediaAgents(ctx: Context, root: string): Promise<void>;
/**
 * Seed the media agents once the roster service is up.
 * @param ctx - the host plugin context.
 * @param config - the seeding root.
 */
export declare function apply(ctx: Context, config: Config): void;
//# sourceMappingURL=index.d.ts.map