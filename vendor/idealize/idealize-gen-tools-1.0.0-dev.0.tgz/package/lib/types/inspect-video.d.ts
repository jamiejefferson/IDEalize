/**
 * `inspect_video`: tell the chat model how long a video is and what happens
 * when. A Studio chat writes the prompt for a soundtrack without ever seeing
 * the clip, so its prompt could name neither the length nor the moment a door
 * opens (JJ, 26 Nov 2026). The tool reads the length and frame size from
 * `ffmpeg`, and, when the chat's model takes pictures, hands it one sheet of
 * frames taken at even steps with the time of each.
 * @module @idealize/gen-tools/inspect-video
 */
import type { Context } from '@deepseek-ai/cordis';
import type { ToolDefinition } from '@deepseek-ai/dsh-tools';
/** The tool's name. */
export declare const INSPECT_TOOL = "inspect_video";
/** What the tool needs from the computer; tests replace all three. */
export interface InspectDeps {
    /** The absolute path of `ffmpeg`, or undefined when this computer has none. */
    findFfmpeg(): Promise<string | undefined>;
    /** What `ffmpeg -i` prints about one file. */
    describe(program: string, file: string, signal: AbortSignal): Promise<string>;
    /** Run `ffmpeg` with these arguments; rejects with its last words when it fails. */
    run(program: string, args: readonly string[], signal: AbortSignal): Promise<void>;
}
/** What `ffmpeg` says about one video. */
export interface VideoFacts {
    duration_s: number;
    width?: number;
    height?: number;
    fps?: number;
    has_audio: boolean;
}
/**
 * Read a video's length, frame size, frame rate and whether it has sound from `ffmpeg -i` output.
 * @param text - what `ffmpeg` printed.
 * @returns the facts, or undefined when the output names no length.
 */
export declare function videoFacts(text: string): VideoFacts | undefined;
/**
 * The times the sheet's frames are taken at: even steps from the start.
 * @param duration - the video's length in seconds.
 * @returns each frame's time in seconds, in sheet order.
 */
export declare function frameTimes(duration: number): number[];
/**
 * The `ffmpeg` arguments that write one sheet of frames.
 * @param video - the video file.
 * @param duration - its length in seconds.
 * @param output - where the sheet is written.
 * @returns the argument list.
 */
export declare function sheetArguments(video: string, duration: number, output: string): string[];
/**
 * Build the tool over the host services.
 * @param ctx - the plugin context carrying `artefacts` and `workspaceRegistry`.
 * @param deps - how `ffmpeg` is found and run; the defaults use this computer.
 * @returns the registry-ready tool definition.
 */
export declare function createInspectVideoTool(ctx: Context, deps?: InspectDeps): ToolDefinition;
//# sourceMappingURL=inspect-video.d.ts.map