/**
 * What a sound model is for. A speech model reads its input aloud, so a
 * music or sound-effects prompt sent to one comes back as a voice reading
 * the prompt; the two kinds never stand in for each other.
 */
import type { GenModelInfo } from '@idealize/generate';
/**
 * Whether an audio model reads text aloud. The id decides first, then the
 * name and tags, then the description; a model none of them describes is
 * taken to make sound, the commoner case.
 * @param model - the catalogue row.
 * @returns true for a speech model.
 */
export declare function speaks(model: Pick<GenModelInfo, 'id' | 'name' | 'tags' | 'description'>): boolean;
//# sourceMappingURL=sound-purpose.d.ts.map