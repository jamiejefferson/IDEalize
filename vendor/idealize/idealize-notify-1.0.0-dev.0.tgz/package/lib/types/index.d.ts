/**
 * @idealize/notify — Host half of the announcement banner and the done chime.
 *
 * - Registers the `idealize-notify` settings section (chime on/off, volume,
 *   last dismissed announcement id) the browser half reads and writes
 *   through its settings scope.
 * - `GET  /idealize/notify/app` — `{appVersion}` for the banner's version gate.
 * - `GET  /idealize/notify/chime.mp3` — V0's TaskComplete chime asset.
 * - `GET  /idealize/notify/sounds` — the chime catalogue: the built-in chime
 *   plus the operating system's own alert sounds (`./sounds.ts`).
 * - `GET  /idealize/notify/sound?id=…` — one catalogue sound, by id alone.
 * - `POST /idealize/notify/native` — `{title, body}` raised as a native
 *   notification through the desktop shell's `desktopActions.notify` when
 *   that service is composed and offers it; 409 otherwise, so the browser
 *   half falls back to Web Notifications.
 * - `GET  /idealize/notify/attention` — the read-position and
 *   notification-delivery ledger.
 * - `POST /idealize/notify/attention/read` — `{project, seq}` moves a
 *   project's read position forward.
 * - `POST /idealize/notify/attention/state` — `{event, state}` records that
 *   the person opened or dismissed one alert.
 *
 * Every recorded Studio event is decided against the MVP policy table here
 * (`./attention.ts`); an event that alerts is recorded on the ledger and
 * pushed onto the host bridge as an `attention` event, which the browser half
 * raises and reports back on.
 *
 * Same loopback + `x-idealize-auth` fence as the other /idealize routes.
 * @module @idealize/notify
 */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
export { NOTIFY_SETTINGS_NAMESPACE, NotifySettingsSchema, type NotifySettings } from './settings.ts';
export { BUILT_IN_CHIME, BUILT_IN_CHIME_SOUND, CHIME_SOUND_PATH, CHIME_SOUNDS_PATH, chimeSoundUrl, decodeChimeSounds, type ChimeSound } from './chime-sounds.ts';
export { createSoundLibrary, systemSoundSources, type SoundFile, type SoundLibrary, type SoundSources } from './sounds.ts';
export { compareVersions, decodeAnnouncement, selectAnnouncement, versionInRange, type Announcement } from './announcement.ts';
export { ATTENTION_KIND, createChimeGate, type ChimeGate, type GateEvent } from './chime-gate.ts';
export { attentionNotice, notificationPolicyFor, USER_PARTICIPANT } from './attention.ts';
export type { AlertDecision, AttentionNotice, PolicyEvent, PolicyRow, PolicyTask } from './attention.ts';
export { AttentionStore, attentionLedgerPath } from './attention-store.ts';
export type { AttentionLedger, NotificationRecord, NotificationState } from './attention-store.ts';
/** Plugin config. */
export interface Config {
    /**
     * The running app's version, compared against announcement min/max bounds;
     * `IDEALIZE_APP_VERSION` (set by the desktop shell) when empty.
     */
    appVersion?: string;
}
export declare const Config: z<Config>;
/** The ledger's read path. */
export declare const ATTENTION_PATH = "/idealize/notify/attention";
/** The read-position write path. */
export declare const ATTENTION_READ_PATH = "/idealize/notify/attention/read";
/** The alert-state write path. */
export declare const ATTENTION_STATE_PATH = "/idealize/notify/attention/state";
/**
 * Where transcoded system sounds are kept, beside the attention ledger.
 * @param dshHome - the resolved harness home.
 * @returns the cache folder.
 */
export declare function chimeSoundCacheDir(dshHome: string): string;
/** The desktop shell's notify face, present only when the Electron host offers it. */
interface DesktopNotifyLike {
    notify(notification: {
        title: string;
        body: string;
    }): void;
}
/**
 * Probe the desktop shell's notify face without injecting it: the service is
 * absent in the browser-only composition and plain property access throws.
 * @param ctx - any context in the host tree.
 * @returns the shell's notify face, or undefined when no desktop shell is composed.
 */
export declare function desktopNotifier(ctx: Context): DesktopNotifyLike | undefined;
export declare function apply(ctx: Context, config: Config): void;
//# sourceMappingURL=index.d.ts.map