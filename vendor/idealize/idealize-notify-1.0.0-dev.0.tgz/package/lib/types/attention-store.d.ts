/**
 * The two records this package owns, on one durable file: where the person
 * has read to in each project's Studio timeline, and what happened to every
 * alert that left the app. The third record of the spec's trio — whether a
 * request was actually answered — belongs to `@idealize/studio`'s fold and is
 * never written here, which is what keeps a dismissed alert from resolving
 * anything (FR-P0-19).
 *
 * One JSON file under the harness home, rewritten whole through a single
 * chain, so a concurrent read-modify-write cannot lose a record. A file that
 * is not this ledger refuses loudly rather than starting empty over the top
 * of it.
 */
import type { PolicyRow } from './attention.ts';
/**
 * Where a harness home keeps the ledger.
 * @param dshHome - the harness home directory.
 * @returns the absolute path of `idealize/notify/attention.json` under it.
 */
export declare function attentionLedgerPath(dshHome: string): string;
/** What has happened to one alert since it was raised. */
export type NotificationState = 'sent' | 'opened' | 'dismissed';
/** One alert that left the app, and what became of it. */
export interface NotificationRecord {
    /** The Studio event the alert was raised for. */
    event: string;
    /** The resolved project folder that event belongs to. */
    project: string;
    /** The MVP table row that raised it. */
    row: PolicyRow;
    /** ISO-8601 instant it was raised. */
    at: string;
    state: NotificationState;
    /** ISO-8601 instant of the last state change, once the person acted. */
    changedAt?: string;
}
/** The whole ledger, as it is served and stored. */
export interface AttentionLedger {
    /** Newest seq the person has viewed, per resolved project folder. */
    read: Record<string, number>;
    /** Alerts raised, oldest first, capped at the newest {@link RECORD_CAP}. */
    notifications: NotificationRecord[];
}
/** The read-position and notification-delivery records, on one rewritten file. */
export declare class AttentionStore {
    readonly path: string;
    private ledger;
    private loading;
    private chain;
    constructor(path: string);
    /**
     * The ledger, read from disk once. A missing file is an empty ledger; any
     * other unreadable content refuses.
     * @returns the loaded ledger.
     */
    load(): Promise<AttentionLedger>;
    private read;
    /** Serialise one read-modify-write and persist the result. */
    private change;
    /**
     * Move a project's read position. It never goes backwards: a stale view
     * settling after a newer one must not re-unread what the person has seen.
     * @param project - the resolved project folder.
     * @param seq - the newest seq the person has viewed.
     * @returns the stored read position after the change.
     */
    markRead(project: string, seq: number): Promise<number>;
    /**
     * Record that an alert was raised. A second raise for the same event keeps
     * the first record, so a re-read of the timeline cannot re-alert.
     * @param input - the event, its project and the row that raised it.
     * @returns the stored record, and whether this call is the one that raised it.
     */
    recordSent(input: {
        event: string;
        project: string;
        row: PolicyRow;
    }): Promise<{
        record: NotificationRecord;
        raised: boolean;
    }>;
    /**
     * Record what the person did with an alert. Opening or dismissing changes
     * this record and nothing else — the task's attention is the fold's.
     * @param event - the Studio event id the alert named.
     * @param state - `opened` or `dismissed`.
     * @returns the updated record, or undefined when no alert was raised for it.
     */
    markState(event: string, state: NotificationState): Promise<NotificationRecord | undefined>;
}
//# sourceMappingURL=attention-store.d.ts.map