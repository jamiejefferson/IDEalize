/**
 * Announcement decoding and gating, ported from V0's `AnnouncementStore`:
 * the newest active Supabase row surfaces unless the user already dismissed
 * that exact id or the running app version falls outside its [min, max]
 * range. Pure functions; the client store owns fetching and persistence.
 */
/** One `idealize_announcements` row, decoded from the REST JSON. */
export interface Announcement {
    id: string;
    title: string;
    body: string;
    ctaLabel?: string | undefined;
    ctaUrl?: string | undefined;
    minAppVersion?: string | undefined;
    maxAppVersion?: string | undefined;
}
/**
 * Dotted-numeric version parts; missing components read as 0 ("0.1" == "0.1.0").
 * @param value - the version string; non-digits inside a component are ignored.
 * @returns the numeric components; an empty string reads as `[0]`.
 */
export declare function parseVersion(value: string): number[];
/**
 * Component-by-component version compare.
 * @param a - the left version.
 * @param b - the right version.
 * @returns negative when a < b, zero when equal, positive when a > b.
 */
export declare function compareVersions(a: string, b: string): number;
/**
 * Is the running app within the announcement's target range? An absent bound
 * is open; an unreadable app version fails open so dev builds always see
 * announcements (V0's rule).
 * @param appVersion - the running app's version, undefined when unknown.
 * @param min - the inclusive lower bound; absent or empty is open.
 * @param max - the inclusive upper bound; absent or empty is open.
 * @returns true when the announcement applies to this app version.
 */
export declare function versionInRange(appVersion: string | undefined, min?: string, max?: string): boolean;
/**
 * Decode one REST row.
 * @param row - one element of the announcements response.
 * @returns the announcement, or undefined when `id`, `title`, or `body` is missing or mistyped.
 */
export declare function decodeAnnouncement(row: unknown): Announcement | undefined;
/**
 * Pick the announcement to show from the route's response (newest first):
 * skipped when dismissed already or out of the version range.
 * @param rows - the `/idealize/announcements` JSON body.
 * @param appVersion - the running app's version, undefined when unknown.
 * @param lastSeenId - the dismissed announcement id persisted in settings.
 * @returns the announcement to show, or undefined when there is none to show.
 */
export declare function selectAnnouncement(rows: unknown, appVersion: string | undefined, lastSeenId: string): Announcement | undefined;
//# sourceMappingURL=announcement.d.ts.map