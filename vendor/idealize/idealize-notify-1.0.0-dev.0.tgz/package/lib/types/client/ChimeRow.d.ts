/** General Settings row for the task-complete chime: on/off, volume, preview (V0's Sound section). */
import type { SnapshotStore } from '@deepseek-ai/dsh-client-runtime/client';
import type { InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
/** The row's view of the chime preference. */
export interface ChimePreference {
    enabled: boolean;
    /** 0…1 */
    volume: number;
}
/** Registration-side face. */
export interface ChimeRowInjected {
    hooks: {
        /** Live chime preference (settings-backed). */
        chime: SnapshotStore<ChimePreference>;
    };
    setEnabled: (enabled: boolean) => void;
    setVolume: (volume: number) => void;
    /** Play the chime at the current volume regardless of the enabled toggle. */
    preview: () => void;
}
/** Full Settings-row props. */
export type ChimeRowProps = PropsRuntime<'settings.general.item'> & PropsLocale<'idealize-notify'> & InjectFace<ChimeRowInjected>;
/**
 * Render the chime preference row.
 * @param props - composed Settings slot props.
 */
export declare function ChimeRow({ useChime, setEnabled, setVolume, preview, t }: ChimeRowProps): import("react").JSX.Element;
//# sourceMappingURL=ChimeRow.d.ts.map