/**
 * @idealize/notify, browser half.
 *
 * - The announcement banner on the frame's `shell.banner` strip: the newest
 *   active row from `/idealize/announcements`, gated by the app version
 *   (`/idealize/notify/app`) and the dismissed id persisted in the
 *   `idealize-notify` settings section (V0's `AnnouncementStore`).
 * - The done chime: the host bridge's SSE feed is seeded with the newest
 *   retained sequence before it is read live, so work that finished before
 *   this page attached (app restore, tab reload) never chimes; each fresh
 *   `agent-finished` plays the chime at the settings volume and raises a
 *   notification (native through the host when the desktop shell offers it,
 *   Web Notifications otherwise).
 * - The chime row in General settings: on/off, the sound (the built-in
 *   chime or one of the operating system's own alert sounds, listed by
 *   `/idealize/notify/sounds`), volume slider, preview.
 * - The Studio's alerts: an `attention` frame on the same feed raises one
 *   notification the person can answer — clicking it opens that Studio event
 *   and records `opened`, letting it go records `dismissed`. The Askbar
 *   window skips them, so one event alerts once.
 */
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
import { type NotifyKey } from './locales.ts';
export { AnnouncementBanner } from './AnnouncementBanner.tsx';
export { ChimeRow } from './ChimeRow.tsx';
export type { NotifyKey } from './locales.ts';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** The announcement banner's and chime row's copy. */
        'idealize-notify': NotifyKey;
    }
}
/**
 * The output-device service other plugins reach (`ctx.idealizeNotify`):
 * raise a notification or the done chime without importing this plugin's
 * components (the client bundle purity gate forbids cross-plugin value
 * imports — services are the sanctioned channel).
 */
export interface IdealizeNotify {
    /** Raise one notification (native through the desktop shell when present, Web Notifications otherwise). */
    notify(title: string, body: string): void;
    /** Play the done chime at the user's settings volume; silent when the chime preference is off. */
    chime(): void;
}
declare module '@deepseek-ai/cordis' {
    interface Context {
        /** The notify plugin's output devices (this plugin owns the concrete value). */
        idealizeNotify: IdealizeNotify;
    }
}
/** Required services. */
export declare const inject: string[];
/**
 * Client plugin body.
 * @param ctx - client root context.
 */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map