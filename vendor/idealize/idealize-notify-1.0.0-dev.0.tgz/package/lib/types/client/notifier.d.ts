/**
 * The browser half's output devices: the chime (an Audio element over the
 * host-served asset, volume from settings) and the notification (the desktop
 * shell's native notifier through the host route when present, the Web
 * Notifications API otherwise). Both fail silently: a missed chime is never
 * worth an error.
 */
/** The host-served chime asset. */
export declare const CHIME_URL = "/idealize/notify/chime.mp3";
/**
 * Play the chime. Resolves when playback starts or fails; never rejects.
 * @param volume - playback volume, clamped to 0…1.
 */
export declare function playChime(volume: number): Promise<void>;
/**
 * Raise one notification: native through the desktop shell when the host
 * offers it, else a Web Notification once permission is granted.
 * @param title - the notification title.
 * @param body - the notification body.
 */
export declare function notify(title: string, body: string): Promise<void>;
/** What the person can do with one alert; the caller records both. */
export interface AlertHandlers {
    /** The alert was clicked: bring the window forward and open the event. */
    open: () => void;
    /** The alert was closed without being opened. */
    dismiss: () => void;
}
/**
 * Raise one alert the person can answer. The browser's own notification is
 * preferred over the desktop route because it is the half that reports a
 * click back: in the packaged app it is a native macOS notification either
 * way. Without permission the desktop route still raises it, and the alert
 * then carries no way back to the event.
 * @param title - the alert title.
 * @param body - the alert body.
 * @param handlers - what to run when the person opens or dismisses it.
 */
export declare function notifyAttention(title: string, body: string, handlers: AlertHandlers): Promise<void>;
/** Ask for Web Notification permission from a user gesture (the Preview button). */
export declare function requestNotificationPermission(): void;
//# sourceMappingURL=notifier.d.ts.map