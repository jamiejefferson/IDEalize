/** `idealize-notify` namespace dictionaries: the announcement banner and the chime row. */
/** Simplified Chinese dictionary (the key-set source of truth). */
export declare const zh: {
    readonly 'banner.dismiss': "关闭";
    readonly 'banner.dismiss.help': "关闭——稍后可在公告中查看";
    readonly 'chime.title': "任务完成提示音";
    readonly 'chime.description': "代理完成任务时播放一声轻柔的提示音。";
    readonly 'chime.volume': "音量";
    readonly 'chime.preview': "试听";
    readonly 'chime.notification.title': "代理已完成";
    readonly 'chime.notification.body': "有回复等待查看。";
    readonly 'chime.notification.failedTitle': "代理已停止";
    readonly 'chime.notification.failedBody': "本轮因错误结束，请打开对话查看。";
};
/** Translation key set. */
export type NotifyKey = keyof typeof zh;
/** English dictionary. */
export declare const en: Record<NotifyKey, string>;
//# sourceMappingURL=locales.d.ts.map