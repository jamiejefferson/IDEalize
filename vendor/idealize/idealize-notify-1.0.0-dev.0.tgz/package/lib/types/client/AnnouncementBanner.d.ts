/** V0's announcement banner: a dismissible strip pinned above the columns. */
import type { SnapshotStore } from '@deepseek-ai/dsh-client-runtime/client';
import type { InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { Announcement } from '../announcement.ts';
/** Registration-side face. */
export interface AnnouncementBannerInjected {
    hooks: {
        /** The announcement to show right now, or undefined (nothing new / already seen). */
        announcement: SnapshotStore<Announcement | undefined>;
    };
    /** Dismiss the current banner and remember its id so it never reappears. */
    dismiss: () => void;
    /** Open the announcement's call-to-action link. */
    openLink: (url: string) => void;
}
/** Full slot props. */
export type AnnouncementBannerProps = PropsRuntime<'shell.banner'> & PropsLocale<'idealize-notify'> & InjectFace<AnnouncementBannerInjected>;
/**
 * Render the banner when an announcement is current; nothing otherwise.
 * @param props - composed slot props.
 */
export declare function AnnouncementBanner({ useAnnouncement, dismiss, openLink, t }: AnnouncementBannerProps): import("react").JSX.Element | null;
//# sourceMappingURL=AnnouncementBanner.d.ts.map