/**
 * The chime library: the operating system's own alert sounds, listed once
 * and served by id, so the person can pick a done chime without the package
 * shipping a single new asset (feedback af0917f0).
 *
 * - macOS: `/System/Library/Sounds/*.aiff` (Glass, Ping, Hero, Submarine…).
 *   Chromium cannot decode AIFF, so each is transcoded once with the system's
 *   own `afconvert` into a cache folder under the harness home and served as
 *   WAV; a sound afconvert refuses is left out of the catalogue.
 * - Windows: `%SystemRoot%\Media\Windows *.wav` under 1 MB, the short alerts
 *   (the longer files there are start-up jingles and ringtones).
 * - Linux: `/usr/share/sounds/freedesktop/stereo/*.oga` when the theme is installed.
 *
 * Every id is `system:<name>`, and a sound is served only by looking its id up
 * in the catalogue this module built: no request ever names a path.
 */
import { type ChimeSound } from './chime-sounds.ts';
/** What the library reads from the machine; the tests hand in a fake. */
export interface SoundSources {
    platform: NodeJS.Platform;
    env: Readonly<Record<string, string | undefined>>;
    /** The names in a folder; rejects when the folder is not there. */
    readdir(dir: string): Promise<string[]>;
    /** A file's size in bytes. */
    size(path: string): Promise<number>;
    exists(path: string): Promise<boolean>;
    mkdir(dir: string): Promise<void>;
    /** Transcode one AIFF to 16-bit WAV; rejects when the converter refuses. */
    transcode(input: string, output: string): Promise<void>;
}
/**
 * The real machine.
 * @returns sources over the file system and `afconvert`.
 */
export declare function systemSoundSources(): SoundSources;
/** One catalogue sound and where it is served from. */
export interface SoundFile {
    path: string;
    contentType: string;
}
/** The library: the catalogue and the file behind one id. */
export interface SoundLibrary {
    /** The catalogue, the built-in chime first, then the system's sounds by name. */
    list(): Promise<ChimeSound[]>;
    /** The file behind one catalogue id, or undefined for anything the catalogue does not hold. */
    file(id: string): Promise<SoundFile | undefined>;
}
/**
 * Build the library. The machine is read once, on the first call, and the
 * catalogue then stands for the host's lifetime.
 * @param cacheDir - where transcoded sounds are kept (under the harness home).
 * @param sources - the machine; defaults to the real one.
 * @returns the library.
 */
export declare function createSoundLibrary(cacheDir: string, sources?: SoundSources): SoundLibrary;
//# sourceMappingURL=sounds.d.ts.map