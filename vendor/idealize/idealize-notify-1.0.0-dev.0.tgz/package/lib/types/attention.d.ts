/**
 * The MVP notification policy: which Studio events interrupt the person with
 * an operating-system alert, and what that alert says. Pure — the host half
 * wires it, the browser half raises it, and neither decides here.
 *
 * The product spec's MVP table has three columns. The Askbar column is the
 * chip's own fold (`@idealize/askbar`'s `chipStateOf` reads the same task
 * attention) and the Studio column is the timeline record itself, which
 * `@idealize/studio` owns; the column nobody owned is the alert, so that is
 * what this module decides. Every row of the table is a {@link PolicyRow},
 * recorded on the ledger so a raised alert names the rule that raised it.
 * @module @idealize/notify/attention
 */
/** The participant id the person holds on a Studio timeline. */
export declare const USER_PARTICIPANT = "user";
/** Which row of the spec's MVP table an event matched. */
export type PolicyRow = 'progress' | 'mention' | 'needs-input' | 'needs-action' | 'blocked-other' | 'blocked-user' | 'done' | 'failed' | 'other';
/** Whether one event interrupts the person, and under which row. */
export interface AlertDecision {
    /** The matched row of the MVP table. */
    row: PolicyRow;
    /** True when the row's operating-system column is on for this event. */
    alert: boolean;
}
/** The event fields the policy reads; the timeline record carries more. */
export interface PolicyEvent {
    kind: string;
    subtype?: string | undefined;
    /** The addressed participant, or the owner the event names. */
    target?: string | undefined;
    author: string;
    body?: string | undefined;
}
/** The folded task fields the policy reads, when the event names a task. */
export interface PolicyTask {
    /** Who asked for the work: the assignment's author. */
    requester: string;
    goal: string;
}
/**
 * Decide one event against the MVP table.
 * @param event - the recorded Studio event.
 * @param task - the folded task the event names, when it names one.
 * @returns the matched row and whether it raises an operating-system alert.
 */
export declare function notificationPolicyFor(event: PolicyEvent, task?: PolicyTask): AlertDecision;
/** One alert's words. */
export interface AttentionNotice {
    title: string;
    body: string;
}
/**
 * The words one alert carries.
 * @param row - the matched policy row.
 * @param event - the recorded Studio event.
 * @param task - the folded task the event names, when it names one.
 * @returns the alert's title and body; the body falls back to the task's goal.
 */
export declare function attentionNotice(row: PolicyRow, event: PolicyEvent, task?: PolicyTask): AttentionNotice;
//# sourceMappingURL=attention.d.ts.map