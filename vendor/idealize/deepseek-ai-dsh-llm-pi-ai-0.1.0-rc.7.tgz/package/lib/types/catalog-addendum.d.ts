/**
 * Catalog entries for models released after the installed pi-ai. IDEalize fork
 * seam: pi-ai 0.99 reshaped its image and transcript types, so moving past
 * 0.85.1 is its own piece of work, while users asked for these models now
 * (feedback 32d1ec28, 5 Oct 2026).
 *
 * Each entry is copied from pi-ai 1.1.0's `providers/data` catalog, trimmed to
 * the fields 0.85.1's `Model` type describes. Anthropic's list prices agree
 * with the published rates (Opus 5.5 $4 / $20, Sonnet 5.5 $2 / $10 per MTok,
 * cache reads $0.20). An installed entry with the same id always wins, so a
 * later pi-ai bump supersedes this list without anyone deleting it.
 *
 * Neither model can turn thinking off (`off: null`): Opus 5.5 and Sonnet 5.5
 * both answer a disabled-thinking request with a 400.
 *
 * @module dsh-llm-pi-ai/catalog-addendum
 */
import type { Api, Model } from '@earendil-works/pi-ai';
/**
 * A model a route's own live directory lists, in the fields a directory
 * states. The wire protocol, endpoint and compatibility switches are this
 * module's to fill in, per route.
 */
export interface LiveCatalogModel {
    id: string;
    name: string;
    /** Whether the model reads pictures as well as text. */
    vision: boolean;
    reasoning: boolean;
    contextWindow: number;
    maxTokens: number;
    /** USD per million tokens. */
    cost: {
        input: number;
        output: number;
        cacheRead: number;
        cacheWrite: number;
    };
}
/**
 * Record the models a route's live directory lists now. Models the installed
 * catalog and the addendum above lack join the route; an entry either already
 * holds always wins. A route with no live shape is ignored.
 * @param provider - provider route key.
 * @param rows - the directory's chat models.
 * @param listedIds - every model id the directory lists, chat or otherwise; a shipped model missing from it is retired.
 * @returns whether the recorded list changed.
 */
export declare function setLiveCatalog(provider: string, rows: readonly LiveCatalogModel[], listedIds?: readonly string[]): boolean;
/**
 * The shipped models a route's live directory has stopped listing. A directory
 * that lists fewer than half the shipped models is read as a broken answer and
 * retires nothing, so a bad read cannot empty the picker.
 * @param provider - provider route key.
 * @param shipped - ids the installed catalog and the addendum describe for that route.
 * @returns the retired ids; empty when no directory has been read.
 */
export declare function retiredModels(provider: string, shipped: Iterable<string>): Set<string>;
/**
 * The live model closest to a retired one. A free model is only ever replaced
 * by a free one, so nobody starts paying because a model was withdrawn. After
 * that the tests run in the order a person would apply them: the same maker,
 * the same variant, a version no older than the retired one, a model that
 * still reads pictures and still reasons when the old one did, the same family
 * name, then the nearest price.
 * @param retired - the retired model as the app shipped it.
 * @param candidates - the models the route serves today.
 * @returns the closest live model, or nothing when the route serves none that fits.
 */
export declare function closestLiveModel(retired: Model<Api>, candidates: readonly Model<Api>[]): Model<Api> | undefined;
/**
 * Hear when a route's live list changes, so resolved routes can be rebuilt.
 * @param listener - called after each change.
 * @returns a function that stops the listening.
 */
export declare function onLiveCatalogChange(listener: () => void): () => void;
/**
 * Addendum models for one route that the installed catalog does not already
 * describe: the entries above, then the route's live directory.
 * @param provider - provider route key.
 * @param installed - ids the installed catalog ships for that route.
 * @returns the missing models, addendum entries first.
 */
export declare function catalogAddendum(provider: string, installed: ReadonlySet<string>): Model<Api>[];
//# sourceMappingURL=catalog-addendum.d.ts.map