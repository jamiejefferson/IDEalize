/**
 * What the adapter may send to an address, and whether an address can still be
 * reached. Both read the same fact about a URL: whether it is on this computer.
 */
/**
 * Whether an address is on this computer. LM Studio and Ollama serve plain http
 * here, and the traffic never leaves the machine. 0.0.0.0 is how some of them
 * print their own address; connecting to it reaches this computer.
 * @param baseUrl - a URL.
 * @returns true for loopback addresses, false for everything else, including a URL that cannot be parsed.
 */
export declare function isLoopbackAddress(baseUrl: string): boolean;
/**
 * Whether sending a key to this address could expose it on the network.
 * @param baseUrl - the provider's address; empty when the provider decides it itself.
 * @returns true for an unencrypted address off this computer.
 */
export declare function exposesKey(baseUrl: string): boolean;
/**
 * Refuse to send a stored key over an unencrypted connection. Anyone on the
 * network path can read it there, and a settings file edited by something else
 * could point a stored key at any server.
 * @param provider - the route, named in the message.
 * @param baseUrl - the address the key would go to.
 * @throws LlmError when the address would expose the key.
 */
export declare function assertKeyMayGoTo(provider: string, baseUrl: string): void;
/**
 * Whether the provider's server can be reached at all. Any answer counts, a 404
 * included, and it goes through the same network stack as the model request, so
 * it follows the same proxy.
 * @param baseUrl - the provider's address.
 * @param timeoutMs - how long to wait for an answer.
 * @returns false only when nothing answered.
 */
export declare function isReachable(baseUrl: string, timeoutMs?: number): Promise<boolean>;
//# sourceMappingURL=address.d.ts.map