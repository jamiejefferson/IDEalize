/**
 * pi-ai assistant event translation into the Harness streaming protocol.
 *
 * pi-ai tool-call arguments are parsed objects while the Harness keeps their
 * raw JSON representation. pi-ai also reports failures as terminal stream
 * events, which this module maps into Harness finish chunks.
 *
 * pi-ai spells a caller's abort two ways. An abort that interrupts an open
 * request ends the stream with `stopReason: 'aborted'`. An abort that lands
 * before dispatch — pi-ai resolves the route's auth under the request signal
 * first — rejects that setup step, and pi-ai's lazy stream wrapper reports a
 * setup failure as `stopReason: 'error'` with the abort reason as its message.
 * The agent loop distinguishes a cancel from a provider failure, so this module
 * reads both spellings as `aborted` when the caller's own signal is aborted.
 *
 * @module dsh-llm-pi-ai/stream
 */
import type { FinishReason, StreamChunk, TokenUsage } from '@deepseek-ai/dsh-llm';
import type { AssistantMessage, AssistantMessageEvent, Usage as PiUsage } from '@earendil-works/pi-ai';
/**
 * Map pi-ai usage (reasoning folded into output by pi-ai).
 * @param usage - cumulative usage from the terminal pi-ai event.
 * @returns harness counts; cache fields appear only when non-zero (pi-ai reports zeros, not absence).
 */
export declare function mapUsage(usage: PiUsage): TokenUsage;
/**
 * Map a terminal pi-ai event to the harness finish reason.
 * @param message - the assistant message carried by the `done` or `error` event.
 * @param contextWindow - resolved catalog capacity for usage-based overflow detection.
 * @returns the mapped harness reason. Recognized error text, `stop` usage above
 *   `contextWindow`, and zero-output `length` usage that fills the window map
 *   to `CONTEXT_WINDOW_EXCEEDED`; a `stop` with no content blocks maps to an
 *   `EMPTY_RESPONSE` error.
 */
export declare function mapStopReason(message: AssistantMessage, contextWindow?: number): FinishReason;
/**
 * Translate the pi-ai event stream into StreamChunks. pi-ai never throws
 * mid-stream — failures arrive as `error` events, which become error/aborted
 * `finish` chunks (the harness protocol's other error-delivery style).
 * @param events - one assistant turn's pi-ai event stream.
 * @param contextWindow - resolved catalog capacity for usage-based overflow detection.
 * @param callerSignal - the caller's own abort signal; an `error` event that
 *   arrives while it is aborted finishes as `aborted`. Pass the caller's
 *   signal alone, never one an adapter-owned timeout also aborts.
 * @returns the harness chunks, ending with `usage` then `finish`; throws
 *   `LlmError` (`STREAM_CLOSED`) if the source ends without a terminal event.
 */
export declare function toStreamChunks(events: AsyncIterable<AssistantMessageEvent>, contextWindow?: number, callerSignal?: AbortSignal): AsyncGenerator<StreamChunk>;
//# sourceMappingURL=stream.d.ts.map