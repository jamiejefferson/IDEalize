/**
 * The V0 service-hatch half of the hatch routes: resolve the IDEalize source
 * checkout, report it, and accept an edit. The edit persists into the
 * settings user layer over the composed `serviceSource` config, so a new path
 * takes effect on the next probe without a restart and survives restarts.
 */
import type { IncomingMessage, ServerResponse } from 'node:http';
/**
 * The message a caught value carries, for an error body or a report field.
 * @param error - the caught value; a thrown non-Error is stringified.
 * @returns the message to report.
 */
export declare function describeError(error: unknown): string;
/** Write a JSON body with its status.
 * @param res - the response to complete.
 * @param status - HTTP status code.
 * @param body - value serialized as the JSON body.
 */
export declare function sendJson(res: ServerResponse, status: number, body: unknown): void;
/** Collect a request body as UTF-8 text.
 * @param req - the incoming request.
 * @returns the concatenated body.
 */
export declare function readBody(req: IncomingMessage): Promise<string>;
/** A directory counts as the service source when it carries the fork markers.
 * @param path - candidate directory.
 * @returns whether `FORK.md` and `package.json` both exist there.
 */
export declare function isServiceSource(path: string): boolean;
/**
 * Resolve the service source checkout: the configured path when set,
 * otherwise the conventional dev location.
 * @param configured - the effective `serviceSource` value, if any.
 * @returns the candidate path plus whether it passes the fork-marker check.
 */
export declare function resolveServiceSource(configured: string | undefined): {
    path: string;
    valid: boolean;
};
/** What the service route needs from the hosting plugin. */
export interface ServiceRouteDeps {
    /** The effective `serviceSource`: settings user layer over composed config. */
    currentSource: () => string | undefined;
    /**
     * Persist a new source into the settings user layer, or `undefined` while
     * no settings provider is mounted (the route then refuses the edit loudly).
     */
    writeSource: () => ((path: string) => Promise<void>) | undefined;
    /** The workspace already open at a path, if any. */
    resolveWorkspace: (path: string) => Promise<{
        id: string;
    } | undefined>;
}
/**
 * Handle `/idealize/hatch/service`. GET reports the source checkout; POST
 * `{path}` validates the fork markers, persists the path, and answers with
 * the fresh report, so the caller renders exactly what the next GET would
 * say. POST demands the `x-idealize-auth` header (the route registers as
 * non-mutating for GET's sake).
 * @param deps - source resolution, persistence, and workspace lookup.
 * @param req - the incoming request.
 * @param res - the response to complete.
 */
export declare function handleServiceRoute(deps: ServiceRouteDeps, req: IncomingMessage, res: ServerResponse): Promise<void>;
//# sourceMappingURL=service.d.ts.map