/**
 * The IDEalize hatch: a maintenance surface over the cordis composition.
 * Shows every profile's layer stack (bundle patches → profile patch → home
 * patch) and the effective entry list they compose to, and lets the home
 * patch be edited safely: every save snapshots the previous content and
 * validates the new YAML through the same loader app-boot uses, and any
 * snapshot can be rolled back. Composition changes apply on restart.
 *
 * HTTP surface (loopback-fenced; mutations demand the header):
 * - GET  /idealize/hatch — the inspector page.
 * - GET  /idealize/hatch/composition — profiles, layers, effective entries.
 * - GET  /idealize/hatch/home-patch — the home patch file, verbatim.
 * - POST /idealize/hatch/home-patch — {content} validate + snapshot + save.
 * - GET  /idealize/hatch/snapshots — snapshot list, newest first.
 * - POST /idealize/hatch/rollback?name= — restore one snapshot (snapshotting
 *   the current content first, so a rollback is itself reversible).
 * - GET  /idealize/hatch/service — the service source checkout and whether it
 *   is already open as a project (V0's service-hatch half).
 * - POST /idealize/hatch/service — {path} validate the fork markers and
 *   persist the source into the settings user layer (applies immediately).
 * - POST /idealize/hatch/amend — open the service source as a project so an
 *   amend chat can start there; the repo's AGENTS.md briefs the agent.
 */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
/** Plugin config. */
export interface Config {
    /** Absolute path of the IDEalize source checkout the amend flow opens. */
    serviceSource?: string;
}
export declare const Config: z<Config>;
export declare function apply(ctx: Context, config: Config): void;
//# sourceMappingURL=index.d.ts.map