/**
 * The /idealize/hatch page. Two halves in plain language: the V0 service
 * hatch (amend the running app from a chat rooted in its own source) and the
 * harness composability view (what the app is made of, home-patch editing
 * with snapshots and rollback).
 */
/**
 * Render the service hatch page.
 * @returns the complete HTML document.
 */
export declare function hatchPage(): string;
//# sourceMappingURL=hatch-page.d.ts.map