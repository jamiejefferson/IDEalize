/**
 * @idealize/gen-fixture — a configurable in-memory generation backend for
 * keyless tests. Registering it makes its models selectable through the
 * generation seam and the media preset routes with zero mode-code change
 * (AC-13); `generate` returns a fixed tiny payload per artefact.
 * @module @idealize/gen-fixture
 */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import type { GenArtefact, GenerationBackend, GenModality } from '@idealize/generate';
/** One configured fixture model. */
export interface FixtureModel {
    /** The model id the fixture backend publishes. */
    id: string;
    /** The artefact kind it produces; decides which silent or blank payload it returns. */
    artefact: GenArtefact;
    /** Input modalities it accepts; defaults to text only. */
    inputModalities?: GenModality[];
}
/** Plugin config. */
export interface Config {
    /** Registry id the backend registers under. */
    backendId?: string;
    /** The models the backend publishes. */
    models?: FixtureModel[];
}
/** Runtime schema for {@link Config}. */
export declare const Config: z<Config>;
/** Cordis plugin name. */
export declare const name = "idealize-gen-fixture";
/** Required services. */
export declare const inject: string[];
/**
 * Build a fixture backend from configured models.
 * @param config - registry id and model list.
 * @returns the backend to register with `ctx.generation`.
 */
export declare function createFixtureBackend(config: Config): GenerationBackend;
/**
 * Register the fixture backend.
 * @param ctx - the host plugin context.
 * @param config - registry id and model list.
 */
export declare function apply(ctx: Context, config: Config): void;
//# sourceMappingURL=index.d.ts.map