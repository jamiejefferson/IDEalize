/**
 * The in-process half of the confined read denial. A confined chat's shell is
 * refused by the kernel; its `read`, `read_image`, `edit`, `write`,
 * `str_replace_editor`, `grep` and `glob` tools run in the app, outside the
 * kernel sandbox, so this listener refuses them over the same rule list.
 *
 * The check runs on the path the filesystem seam resolves, so a symlink in the
 * project that points at a key is refused by where it lands. `grep` shells out
 * to ripgrep, which walks folders: a search that starts above a closed
 * location is refused unless every route to it crosses a hidden folder, which
 * `grep` skips. `glob` returns names only, so it is refused only inside a
 * closed location.
 *
 * Under full access, and on Windows, there are no rules and nothing is refused.
 *
 * @module @deepseek-ai/dsh-fs-sandbox/read-fence
 */
import { Context } from '@deepseek-ai/cordis';
import type { FileSystem } from '@deepseek-ai/dsh-fs';
/**
 * Register the read fence.
 * @param ctx - the provider's context, which holds `sandboxPolicy`.
 * @param fs - the provider, used to canonicalise paths the way the tools do.
 */
export declare function installReadFence(ctx: Context, fs: Pick<FileSystem, 'resolve'>): void;
//# sourceMappingURL=read-fence.d.ts.map