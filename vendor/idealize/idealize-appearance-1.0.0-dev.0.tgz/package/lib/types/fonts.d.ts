/**
 * Installed font families for the panel's font pickers (V0
 * `AppSettings.allFontFamilies()` / `monospacedFontFamilies()`, which asked
 * NSFontManager). A browser cannot enumerate the machine's fonts, so the
 * Host reads the family name (OpenType `name` table, id 1) and the
 * fixed-pitch flag (`post` table `isFixedPitch`) out of every font file in
 * the platform font directories. TrueType collections contribute each
 * face's family.
 */
/**
 * Font directories per platform.
 * @param platform - the OS the directories are for; defaults to the running process's.
 * @param home - the user's home directory, the root of the per-user font folders.
 * @returns absolute directories in scan order; none is checked for existence.
 */
export declare function fontDirectories(platform?: NodeJS.Platform, home?: string): string[];
/**
 * Whether one sfnt face declares itself fixed-pitch (`post` table
 * `isFixedPitch`, the flag NSFontManager's fixed-pitch trait reads).
 * @param buffer - the font file.
 * @param offset - the face's offset table position.
 * @returns true for a monospaced face; false when the flag is absent or zero.
 */
export declare function isFixedPitchFace(buffer: Buffer, offset: number): boolean;
/**
 * The family name (name id 1, English preferred) of one sfnt face starting at `offset`.
 * @param buffer - the font file.
 * @param offset - the face's offset table position.
 * @returns the family, or undefined when the face has no readable name table.
 */
export declare function familyOfFace(buffer: Buffer, offset: number): string | undefined;
/**
 * Every family name in one font file (one per face for a collection).
 * @param buffer - the font file.
 * @returns family names, deduplicated, in face order.
 */
export declare function familiesInFile(buffer: Buffer): string[];
/** The font families a machine offers, with the fixed-pitch subset called out for the terminal picker. */
export interface FontInventory {
    /** Every installed family, sorted. */
    families: string[];
    /** The families with at least one fixed-pitch face, in {@link families} order. */
    monospaced: string[];
}
/**
 * Every installed family across the platform font directories, sorted,
 * hidden system faces (names starting with a dot) left out, fixed-pitch
 * families listed separately.
 * @param directories - directories to scan; defaults to the platform's.
 * @returns the inventory.
 */
export declare function listFontFamilies(directories?: string[]): Promise<FontInventory>;
//# sourceMappingURL=fonts.d.ts.map