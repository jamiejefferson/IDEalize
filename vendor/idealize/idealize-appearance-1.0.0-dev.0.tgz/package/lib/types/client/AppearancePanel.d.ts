import type { InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import { type ActionAppearance, type AppearanceSettings, type PresetId, type SurfaceAppearance, type SurfaceId, type TerminalAppearanceSettings } from '../appearance-settings.ts';
import { type PanelScalars } from '../surface-css.ts';
import { type AppearanceStore, type ModeId, type SectionId } from './store.ts';
/** Registration-side face: the state hook plus the writes the panel can ask for. */
export interface AppearancePanelInjected {
    hooks: {
        /** The panel state (arrives as the `useAppearance` selector hook). */
        appearance: AppearanceStore;
    };
    /** Hide the panel. */
    close: () => void;
    /** Switch tab. */
    setSection: (section: SectionId) => void;
    /** Switch light/dark/system (ui-theme's preference). */
    setMode: (mode: ModeId) => void;
    /** Choose a preset; single-scheme presets also set the mode. */
    choosePreset: (preset: PresetId) => void;
    /** Set or clear (empty string) the user's ground. */
    setGround: (hex: string) => void;
    /** Patch the action colour. */
    setAction: (patch: Partial<ActionAppearance>) => void;
    /** Set the interface font family; empty is the platform stack. */
    setUiFont: (family: string) => void;
    /** Set the interface size in points. */
    setUiSize: (size: number) => void;
    /** Patch one surface's override. */
    setSurface: (id: SurfaceId, patch: Partial<SurfaceAppearance>) => void;
    /** Patch the chat panel's scalars. */
    setScalars: (patch: Partial<PanelScalars>) => void;
    /** Patch the terminal grid's appearance. */
    setTerminal: (patch: Partial<TerminalAppearanceSettings>) => void;
    /** Restore one tab's settings to their defaults (the Theme tab includes the mode). */
    resetSection: (section: SectionId) => void;
}
/** Full props of the panel as a root-scoped slot occupant (a host composes these). */
export type AppearancePanelProps = PropsRuntime<'shell.drawer'> & PropsLocale<'idealize-appearance'> & InjectFace<AppearancePanelInjected>;
/** The props the panel itself consumes (a host may supply them without the slot runtime). */
export type AppearancePanelComponentProps = Pick<AppearancePanelProps, 'useAppearance' | 't'> & Omit<AppearancePanelInjected, 'hooks'>;
/**
 * Whether the Theme tab differs from the defaults (mode excluded: it is
 * ui-theme's). A panel's own colours count, because the tab's Reset clears
 * them: on 15 Sep 2026 JJ's document carried light panel colours and nothing
 * else, and the tab read "Following IDEalize" with no Reset to press.
 */
export declare function themeCustomised(settings: AppearanceSettings): boolean;
export declare function AppearancePanel(props: AppearancePanelComponentProps): import("react").JSX.Element | null;
//# sourceMappingURL=AppearancePanel.d.ts.map