/**
 * IDEalize appearance panel, browser half. Owns the `idealize-appearance`
 * settings scope and projects it onto the app: preset, ground and action
 * colour as a ui-theme override layer (both schemes, so a layer never goes
 * illegible on a mode switch; every preset, IDEalize included, lays the full
 * `PRESET_TOKEN_KEYS` set), the interface font through the same layer,
 * interface size as a root zoom, and the per-surface typography, backgrounds
 * and chat-panel scalars as one injected stylesheet over the frame's
 * `data-idealize-surface` hooks. The panel itself is seated by a host: the
 * tool rail shows it as a pane of the docked drawer. Light/dark/system stays
 * ui-theme's preference, written through `ctx.theme.setTheme`.
 *
 * `ctx.appearance` is the cross-plugin face: `open()`/`toggle()` flip the
 * store's `open` flag, and `Component` + `face()` + `store` let the host seat
 * the panel and follow that flag. V0's ⌘⌥A (Ctrl+Alt+A elsewhere) toggles it.
 */
import type React from 'react';
import type { Context } from '@deepseek-ai/cordis';
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
import { type TerminalPaint } from '../terminal-themes.ts';
import { type AppearancePanelComponentProps, type AppearancePanelInjected } from './AppearancePanel.tsx';
import { type AppearanceStore } from './store.ts';
import { type AppearanceKey } from './locales.ts';
export { AppearancePanel } from './AppearancePanel.tsx';
export type { AppearancePanelComponentProps, AppearancePanelInjected, AppearancePanelProps } from './AppearancePanel.tsx';
export { createAppearanceStore, SECTIONS } from './store.ts';
export type { AppearanceState, AppearanceStore, ModeId, SectionId } from './store.ts';
export type { AppearanceKey } from './locales.ts';
export { applyAppearanceDom } from './dom-applier.ts';
export type { TerminalPaint, TerminalTheme } from '../terminal-themes.ts';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** The appearance panel's copy. */
        'idealize-appearance': AppearanceKey;
    }
}
/** The appearance face other plugins reach (`ctx.appearance`): open the panel, or host it. */
export interface AppearanceService {
    /** Show the panel. */
    open: () => void;
    /** Hide the panel. */
    close: () => void;
    /** Show or hide the panel. */
    toggle: () => void;
    /** Whether the panel is shown. */
    isOpen: () => boolean;
    /** The panel component; the host (the drawer) seats it and renders it while {@link store} says open. */
    Component: (props: AppearancePanelComponentProps) => React.JSX.Element | null;
    /** The wired face for {@link Component}; a host binds `useAppearance` from {@link store} and supplies its own `t`. */
    face: () => AppearancePanelInjected;
    /** The panel's state store. */
    store: AppearanceStore;
    /**
     * The terminal grid's resolved appearance under the current settings.
     * `@idealize/ui-terminal` reads it here and re-reads on {@link store}
     * changes; the terminal keeps its own scheme, independent of the app theme.
     * @returns the resolved paint.
     */
    terminalPaint: () => TerminalPaint;
}
declare module '@deepseek-ai/cordis' {
    interface Context {
        appearance: AppearanceService;
    }
}
/** Id of the injected per-surface stylesheet. */
export declare const SHEET_ID = "idealize-appearance-surfaces";
/** Required services: locale for the panel's copy, settings transport, the theme registry. */
export declare const inject: string[];
/**
 * Open the appearance panel from any plugin that injects `appearance`.
 * @param ctx - a context that has acquired the `appearance` service.
 */
export declare function openAppearancePanel(ctx: Context): void;
/**
 * Client plugin body: the appearance service and the settings projection.
 * @param ctx - client root context.
 */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map