/**
 * Colour arithmetic for the appearance panel: hex parsing, WCAG contrast,
 * sRGB blends (V0's `Theme.blend`), and the deepen-along-hue readability
 * rule. Pure functions over `#RRGGBB` strings; no DOM.
 *
 * The readability rule (V0's Y2K palette note, Theme.swift): a colour that
 * cannot be read against its ground is deepened along its own hue — hue and
 * saturation stay, lightness walks toward black on a light ground or white
 * on a dark one — until it clears the target contrast. It is never
 * desaturated or blended toward grey, so the user's colour keeps its identity.
 */
/** One sRGB colour, channels 0–255. */
export interface Rgb {
    r: number;
    g: number;
    b: number;
}
/** WCAG 2 minimum for body text against its ground. */
export declare const TEXT_CONTRAST = 4.5;
/** WCAG 2 minimum for UI components and large text against their ground. */
export declare const UI_CONTRAST = 3;
/**
 * Parse `#RRGGBB` / `RRGGBB` (case-insensitive, surrounding whitespace
 * tolerated).
 * @param hex - candidate colour string.
 * @returns the colour, or undefined for an empty or malformed string.
 */
export declare function parseHex(hex: string): Rgb | undefined;
/**
 * Parse a hex the caller guarantees is well-formed (preset tables, values
 * already accepted by {@link parseHex}).
 * @param hex - `#RRGGBB` string.
 * @returns the colour.
 */
export declare function requireHex(hex: string): Rgb;
/**
 * Format a colour as upper-case `#RRGGBB`.
 * @param rgb - colour; channels are rounded and clamped.
 * @returns the hex string.
 */
export declare function toHex(rgb: Rgb): string;
/**
 * Format a colour as `rgba(r, g, b, a)`.
 * @param rgb - colour.
 * @param alpha - opacity 0–1.
 * @returns the CSS rgba() string.
 */
export declare function toRgba(rgb: Rgb, alpha: number): string;
/**
 * Linear sRGB blend (V0's `Theme.blend`): t=0 gives `a`, t=1 gives `b`.
 * @param a - start colour.
 * @param b - end colour.
 * @param t - blend fraction 0–1.
 * @returns the blended colour.
 */
export declare function blend(a: Rgb, b: Rgb, t: number): Rgb;
/**
 * WCAG relative luminance of an sRGB colour.
 * @param rgb - colour.
 * @returns luminance 0 (black) to 1 (white).
 */
export declare function relativeLuminance(rgb: Rgb): number;
/**
 * WCAG contrast ratio between two colours.
 * @param a - one colour.
 * @param b - the other colour.
 * @returns ratio 1 (identical) to 21 (black on white).
 */
export declare function contrast(a: Rgb, b: Rgb): number;
/**
 * Whether a ground reads as dark (V0's `Theme.isDark`: perceived luma below
 * one half).
 * @param ground - the background colour.
 * @returns true for a dark ground.
 */
export declare function isDark(ground: Rgb): boolean;
/** Hue 0–360, saturation and lightness 0–1. */
export interface Hsl {
    h: number;
    s: number;
    l: number;
}
/**
 * Convert sRGB to HSL.
 * @param rgb - colour.
 * @returns the HSL triple (hue 0 for greys).
 */
export declare function toHsl(rgb: Rgb): Hsl;
/**
 * Convert HSL to sRGB.
 * @param hsl - hue 0–360, saturation and lightness 0–1.
 * @returns the colour.
 */
export declare function fromHsl(hsl: Hsl): Rgb;
/**
 * The deepen-along-hue rule: return `colour` unchanged when it already reads
 * at `target` against `ground`; otherwise walk its HSL lightness — hue and
 * saturation fixed — toward black (light ground) or white (dark ground) in
 * 0.005 steps and return the first step that reads. When even the extreme
 * fails the target, the extreme is returned.
 * @param colour - the user's colour.
 * @param ground - the ground it must read against.
 * @param target - minimum contrast ratio.
 * @returns a colour of the same hue that clears the target where reachable.
 */
export declare function deepenAlongHue(colour: Rgb, ground: Rgb, target: number): Rgb;
/**
 * {@link deepenAlongHue} for a colour read against several grounds at once: a
 * gradient's stops, or a ground plus the cards that sit on it. The colour
 * stands when it clears `target` against every ground. Otherwise its HSL
 * lightness walks outward in 0.005 steps in both directions, hue and
 * saturation fixed, and the nearest step that clears every ground wins, so the
 * colour moves as little as it can. When no lightness clears them all, the
 * result is black or white of that hue, whichever keeps the higher worst-case
 * ratio.
 * @param colour - the colour to keep readable.
 * @param grounds - every ground it is read against; at least one.
 * @param target - minimum contrast ratio against each.
 * @returns a colour of the same hue, clearing the target where reachable.
 */
export declare function deepenAgainstAll(colour: Rgb, grounds: readonly Rgb[], target: number): Rgb;
//# sourceMappingURL=colour.d.ts.map