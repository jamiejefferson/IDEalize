/**
 * The terminal grid's colour schemes, ported verbatim from V0
 * `Theme.terminalThemes` (Theme.swift): background, foreground, cursor,
 * selection and the 16 ANSI colours of Linen, Ink, Y2K, IDEalize Dark,
 * IDEalize Light and Solarized Dark. The grid keeps its own scheme,
 * independent of the app theme. `resolveTerminalPaint` layers the user's
 * custom background over the chosen theme (V0 `Theme.withBackground`:
 * selection re-derives from the new ground; ink, cursor and palette stay)
 * and folds in the type settings as the one object the terminal view needs.
 */
import { type TerminalAppearanceSettings, type TerminalThemeId } from './appearance-settings.ts';
/** One terminal colour scheme. */
export interface TerminalTheme {
    id: TerminalThemeId;
    /** Display name (a proper name, shown untranslated like the preset names). */
    name: string;
    /** Grid ground `#RRGGBB`. */
    background: string;
    /** Body ink. */
    foreground: string;
    /** Cursor (V0: also the theme accent). */
    cursor: string;
    /** Selection highlight. */
    selection: string;
    /** The 16 ANSI colours, 0–7 normal and 8–15 bright. */
    ansi: readonly string[];
}
/** The terminal themes in V0's panel order (`[.linen, .ink, .y2k] + all`). */
export declare const TERMINAL_THEMES: readonly TerminalTheme[];
/**
 * Look up a terminal theme.
 * @param id - theme id (the schema bounds stored values to known ids).
 * @returns the theme.
 */
export declare function terminalTheme(id: TerminalThemeId): TerminalTheme;
/**
 * Everything the terminal view needs to paint one grid: the resolved colours
 * plus the type settings. `@idealize/ui-terminal` reads it through
 * `ctx.appearance.terminalPaint()` (services, not value imports, carry
 * cross-plugin collaboration).
 */
export interface TerminalPaint {
    /** Grid ground `#RRGGBB` (also paints the margin). */
    background: string;
    /** Body ink. */
    foreground: string;
    /** Cursor colour (the cursor is always V0's bar style; no setting). */
    cursor: string;
    /** Selection highlight. */
    selection: string;
    /** The 16 ANSI colours, 0–7 normal and 8–15 bright. */
    ansi: readonly string[];
    /** CSS font-family stack, monospace-terminated. */
    fontFamily: string;
    /** Grid font size in px. */
    fontSize: number;
    /** Line height as a multiple of the font's natural height (xterm `lineHeight`). */
    lineHeight: number;
    /** Padding around the grid in px, painted in {@link background}. */
    margin: number;
}
/**
 * A CSS font-family value for a terminal family, quoted and followed by the
 * platform monospace stack so a missing face degrades to a working grid.
 * @param family - font family name; empty means the default stack.
 * @returns the font-family value.
 */
export declare function terminalFontStack(family: string): string;
/**
 * Resolve the stored terminal settings into the paint object. A parsable
 * custom background replaces the theme's ground and re-derives the selection
 * from it (V0 `withBackground`'s 0.14 ink blend); everything else is the
 * theme's own.
 * @param settings - the durable terminal section.
 * @returns the resolved paint.
 */
export declare function resolveTerminalPaint(settings?: TerminalAppearanceSettings): TerminalPaint;
//# sourceMappingURL=terminal-themes.d.ts.map