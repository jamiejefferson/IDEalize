/**
 * The terminal grid's colour schemes, ported verbatim from V0
 * `Theme.terminalThemes` (Theme.swift): background, foreground, cursor,
 * selection and the 16 ANSI colours of Linen, Ink, Y2K, IDEalize Dark,
 * IDEalize Light and Solarized Dark. The grid keeps its own scheme,
 * independent of the app theme. `resolveTerminalPaint` layers the user's
 * custom background over the chosen theme (V0 `Theme.withBackground`:
 * selection re-derives from the new ground; ink, cursor and palette stay),
 * deepens the selection until it shows ({@link legibleSelection}) and folds in
 * the type settings as the one object the terminal view needs. Classic Dark
 * and Classic Light are V1's own rows: the OG app preset's grounds and inks
 * under the standard terminal palette.
 */
import { type Rgb } from './colour.ts';
import { type TerminalAppearanceSettings, type TerminalThemeId } from './appearance-settings.ts';
/** One terminal colour scheme. */
export interface TerminalTheme {
    id: TerminalThemeId;
    /** Display name (a proper name, shown untranslated like the preset names). */
    name: string;
    /** Grid ground `#RRGGBB`. */
    background: string;
    /** Body ink. */
    foreground: string;
    /** Cursor (V0: also the theme accent). */
    cursor: string;
    /** Selection highlight as placed by hand; {@link legibleSelection} deepens it where it cannot be seen. */
    selection: string;
    /** The 16 ANSI colours, 0–7 normal and 8–15 bright. */
    ansi: readonly string[];
    /**
     * The stops of V0's background wash, when the theme has one. The grid paints
     * the flat {@link background}; the selection still clears every stop, so the
     * highlight matches V0's and survives the wash being painted.
     */
    wash?: readonly string[];
}
/** The terminal themes in V0's panel order (`[.linen, .ink, .y2k] + all`), then V1's Classic pair. */
export declare const TERMINAL_THEMES: readonly TerminalTheme[];
/**
 * Look up a terminal theme.
 * @param id - theme id (the schema bounds stored values to known ids).
 * @returns the theme.
 */
export declare function terminalTheme(id: TerminalThemeId): TerminalTheme;
/**
 * Everything the terminal view needs to paint one grid: the resolved colours
 * plus the type settings. `@idealize/ui-terminal` reads it through
 * `ctx.appearance.terminalPaint()` (services, not value imports, carry
 * cross-plugin collaboration).
 */
export interface TerminalPaint {
    /** Grid ground `#RRGGBB` (also paints the margin). */
    background: string;
    /** Body ink. */
    foreground: string;
    /** Cursor colour (the cursor is always V0's bar style; no setting). */
    cursor: string;
    /** Selection highlight, deepened by {@link legibleSelection}. */
    selection: string;
    /** The colour selected text is drawn in: the ink or the ground, whichever reads better on {@link selection}. */
    selectionForeground: string;
    /** The 16 ANSI colours, 0–7 normal and 8–15 bright. */
    ansi: readonly string[];
    /** CSS font-family stack, monospace-terminated. */
    fontFamily: string;
    /** Grid font size in px. */
    fontSize: number;
    /** Line height as a multiple of the font's natural height (xterm `lineHeight`). */
    lineHeight: number;
    /** Padding around the grid in px, painted in {@link background}. */
    margin: number;
}
/**
 * A CSS font-family value for a terminal family, quoted and followed by the
 * platform monospace stack so a missing face degrades to a working grid.
 * @param family - font family name; empty means the default stack.
 * @returns the font-family value.
 */
export declare function terminalFontStack(family: string): string;
/** How far the selection highlight must stand off every ground stop (V0 `Theme.selectionContrast`). */
export declare const SELECTION_CONTRAST = 1.5;
/** How readable the theme's ink or ground must be on the highlight (V0 `Theme.selectionTextContrast`). */
export declare const SELECTION_TEXT_CONTRAST = 3;
/** The colours {@link legibleSelection} reads a selection against. */
export interface SelectionGround {
    /** Every ground the grid paints: the flat ground plus any wash stops. */
    grounds: readonly Rgb[];
    /** Body ink. */
    foreground: Rgb;
    /** The flat ground, the other candidate for selected text. */
    background: Rgb;
    /** The 16 ANSI colours; slot 0 (light ground) or 15 (dark ground) is the colour the walk heads for. */
    ansi: readonly string[];
}
/** A selection highlight and the text colour drawn on it. */
export interface LegibleSelection {
    /** The highlight. */
    selection: Rgb;
    /** The ink or the ground, whichever the highlight carries better. */
    foreground: Rgb;
}
/**
 * V0's selection rule (`Theme.selectionColor`, `selectedTextColor`). The
 * theme's own selection colour stands when it clears
 * {@link SELECTION_CONTRAST} against every ground stop and the ink or the
 * ground reads on it at {@link SELECTION_TEXT_CONTRAST}. Otherwise it walks in
 * 0.005 blend steps toward the theme's own black slot (its bright-white slot
 * on a dark ground), so each step mixes two colours the theme already owns,
 * and returns the first step that passes both. A palette that cannot reach
 * continues to pure black or white.
 * @param selection - the hand-placed selection colour.
 * @param ground - the grounds, ink and palette it is read against.
 * @returns the highlight and the selected-text colour.
 */
export declare function legibleSelection(selection: Rgb, ground: SelectionGround): LegibleSelection;
/**
 * Resolve the stored terminal settings into the paint object. A parsable
 * custom background replaces the theme's ground, drops its wash and re-derives
 * the selection from it (V0 `withBackground`'s 0.14 ink blend); the selection
 * then passes through {@link legibleSelection}. Everything else is the theme's
 * own.
 * @param settings - the durable terminal section.
 * @returns the resolved paint.
 */
export declare function resolveTerminalPaint(settings?: TerminalAppearanceSettings): TerminalPaint;
//# sourceMappingURL=terminal-themes.d.ts.map