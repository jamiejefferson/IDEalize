/**
 * App presets and the token derivation shared by presets, the brand skin and
 * the user's own colours. A preset is a ground, an ink and an accent per
 * colour scheme (V0's Theme.swift values); every `--dsw-alias-*` surface
 * derives from those three through V0's blend fractions, so a preset, the
 * shipped skin and a custom palette are built the same way and the
 * readability rule applies to all of them.
 *
 * Every derivation emits exactly {@link PRESET_TOKEN_KEYS}: one preset never
 * leaves a token another preset or the skin set, so switching presets repaints
 * every themed surface.
 */
import { type Rgb } from './colour.ts';
import type { PresetId } from './appearance-settings.ts';
/** The three seeds a scheme derives from. */
export interface Palette {
    /** Ground (`--dsw-alias-bg-base`). */
    ground: string;
    /** Ink (`--dsw-alias-label-primary`). */
    ink: string;
    /** Accent (brand and button fill). */
    accent: string;
    /** Plain ground: every surface and the sidebar paint the ground itself. */
    flat?: boolean;
    /**
     * Crisper contrast: every `--dsw-alias-border-l*` alpha rises by
     * {@link CRISP_BORDER_STEP} and the secondary label blends
     * {@link CRISP_SECONDARY_BLEND} toward the ground (V0's plain blend is
     * .30), so dividers and captions read heavier on the same ground.
     */
    crisp?: boolean;
}
/** One preset: a palette per colour scheme. */
export interface Preset {
    id: PresetId;
    light: Palette;
    dark: Palette;
    /**
     * The scheme a preset chooses when the user picks it. `system` keeps the
     * user's mode and swaps between the two palettes.
     */
    scheme: 'light' | 'dark' | 'system';
}
/** Presets in panel order. */
export declare const PRESET_LIST: readonly Preset[];
/**
 * Look up a preset.
 * @param id - preset id.
 * @returns the preset.
 */
export declare function preset(id: PresetId): Preset;
/**
 * The palette a preset shows in one scheme.
 * @param id - preset id.
 * @param scheme - colour scheme.
 * @returns the palette.
 */
export declare function presetPalette(id: PresetId, scheme: 'light' | 'dark'): Palette;
/**
 * Every alias token a theme layer sets, in emission order. The skin sheet and
 * {@link deriveTokens} both cover exactly this list, so no preset leaves a
 * token painted by the one before it.
 */
export declare const PRESET_TOKEN_KEYS: readonly string[];
/** Alias-token dictionary for one scheme. */
export type Tokens = Record<string, string>;
/** How far a `crisp` palette raises each `--dsw-alias-border-l*` alpha above the V0 value. */
export declare const CRISP_BORDER_STEP = 0.04;
/** How far a `crisp` palette blends the secondary label toward the ground; V0's plain blend is .30. */
export declare const CRISP_SECONDARY_BLEND = 0.26;
/**
 * The ink or the ground, whichever reads better on a fill: the text colour
 * for buttons painted in the accent.
 * @param fill - the button fill.
 * @param ink - the scheme's ink.
 * @param ground - the scheme's ground.
 * @returns the colour to write on the fill.
 */
export declare function onFill(fill: Rgb, ink: Rgb, ground: Rgb): Rgb;
/**
 * The hover shade of a button fill: 15% toward white on a dark ground, toward
 * black on a light one.
 * @param fill - the button fill.
 * @param dark - whether the ground reads as dark.
 * @returns the hover colour.
 */
export declare function hoverOf(fill: Rgb, dark: boolean): Rgb;
/**
 * Derive every themed alias token from a palette. Surfaces follow V0's
 * `Theme` blends (chrome .045, surface .055, hover .095, elevated .08, border
 * .16, secondary ink .30). On a light ground layer 1 is white and layer 3
 * sits .01 below the ground: the step a chip needs is layer 3 against a white
 * card, and the ground's distance from white supplies it. A white ground has
 * no such distance, so there layer 3 takes the surface fraction (.055) and a
 * chip still reads on a card; the sidebar (.03) and the bubble (.05) sit 7
 * and 11 channel values below a white ground and keep their fractions. Ink
 * is deepened along its hue until it reads at 4.5:1 on the ground; the accent
 * is used verbatim as a fill (the primary buttons and the send button's info
 * pair) and deepened along its hue to 3:1 wherever it carries text or a
 * border (`brand-primary`, the business highlight); the three state colours
 * deepen from design-platform's seeds the same way. Nothing is desaturated.
 * A `crisp` palette adds {@link CRISP_BORDER_STEP} to each border alpha and
 * blends the secondary label {@link CRISP_SECONDARY_BLEND} toward the ground.
 * The result carries exactly {@link PRESET_TOKEN_KEYS}.
 * @param palette - ground, ink and accent as hex, plus the `flat` and `crisp` switches.
 * @returns the token dictionary.
 */
export declare function deriveTokens(palette: Palette): Tokens;
/**
 * A token dictionary as CSS declarations, one per line, for a stylesheet
 * block.
 * @param tokens - token name → value.
 * @returns the declaration lines, each indented two spaces and ending in `;`.
 */
export declare function tokenDeclarations(tokens: Tokens): string;
/** The resolved appearance for one scheme, ready for ui-theme's override layer. */
export interface ResolvedScheme {
    /** Alias tokens; the IDEalize preset's equal the skin's own sheet. */
    tokens: Tokens;
    /** The palette the tokens derive from (swatches and the readability readout). */
    palette: Palette;
}
/** What the panel resolved for both schemes plus the mode the choice demands. */
export interface Resolved {
    light: ResolvedScheme;
    dark: ResolvedScheme;
    /**
     * The colour scheme the selection forces, or undefined when the user's
     * light/dark/system mode stands. A custom ground forces its own scheme.
     */
    forcedScheme: 'light' | 'dark' | undefined;
}
/**
 * The layer-1 surface colour of a resolved scheme (the far end of a seeded
 * background gradient).
 * @param side - one resolved scheme.
 * @returns the `--dsw-alias-bg-layer-1` hex.
 */
export declare function surfaceHex(side: ResolvedScheme): string;
/**
 * Resolve preset plus custom colours into per-scheme tokens. A custom ground
 * replaces both schemes' grounds and forces the scheme its luminance reads
 * as; a custom accent replaces both schemes' accents.
 * @param id - selected preset.
 * @param groundHex - the user's ground, or empty.
 * @param accentHex - the user's accent, or empty.
 * @returns both schemes and the forced scheme, if any.
 */
export declare function resolveAppearance(id: PresetId, groundHex: string, accentHex: string): Resolved;
//# sourceMappingURL=presets.d.ts.map