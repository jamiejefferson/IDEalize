/**
 * The appearance section of the Host user-settings document — V0's
 * AppSettings appearance fields (AppearanceDefaults, PanelAppearance,
 * ActionAppearance) carried over: preset, interface font and size, the
 * action colour, the user's ground, one typography + background override per
 * surface, and the chat panel's own scalars. Light/dark/system stays in
 * ui-theme's own `ui-theme.preference` field; this section layers over it.
 */
import z from '@deepseek-ai/schemastery';
/** Settings namespace owned by the appearance plugin. */
export declare const APPEARANCE_SETTINGS_NAMESPACE = "idealize-appearance";
/** App presets offered by the panel. */
export declare const PRESETS: readonly ["idealize", "og", "ink", "linen"];
/** One of {@link PRESETS}. */
export type PresetId = typeof PRESETS[number];
/**
 * The individually themeable surfaces (V0 PanelKind minus the terminal, which
 * the web shell does not host): the projects rail, the files drawer, the
 * chat column, the document deck.
 */
export declare const SURFACES: readonly ["sessions", "files", "chat", "doc"];
/** One of {@link SURFACES}. */
export type SurfaceId = typeof SURFACES[number];
/** How a surface background is filled (V0 FillMode). */
export declare const FILL_MODES: readonly ["inherit", "solid", "gradient"];
/** One of {@link FILL_MODES}. */
export type FillMode = typeof FILL_MODES[number];
/** Gradient shapes (V0 GradientType). */
export declare const GRADIENT_TYPES: readonly ["linear", "radial", "angular"];
/** One of {@link GRADIENT_TYPES}. */
export type GradientType = typeof GRADIENT_TYPES[number];
/** V0 AppearanceWeights: 0 inherits, 1–9 map to CSS 100–900. */
export declare const FONT_WEIGHTS: readonly ["inherit", "100", "200", "300", "400", "500", "600", "700", "800", "900"];
/** One colour stop of a multi-stop gradient. */
export interface GradientStop {
    /** `#RRGGBB`. */
    colorHex: string;
    /** Position 0–1. */
    location: number;
}
/** The scheme a surface's colours belong to; `''` on a record written before the field existed. */
export type SurfaceScheme = '' | 'light' | 'dark';
/**
 * Per-surface typography + background override; every field defaults to
 * "inherit". The colours (text and background) belong to the scheme they were
 * chosen in ({@link surfaceScheme}) and paint only there: a light ground and
 * black ink picked over the light theme would leave the dark theme's own
 * chrome unreadable (JJ, 15 Sep 2026), so the other scheme keeps its own
 * colours until the person picks some for it. Typography applies in both.
 */
export interface SurfaceAppearance {
    /** Font family; empty inherits the interface font. */
    fontName: string;
    /** Font size in points; 0 keeps the surface's natural size. */
    fontSize: number;
    /** 0 inherits; 1–9 are CSS weights 100–900. */
    fontWeight: number;
    /** Letter-spacing in px. */
    tracking: number;
    /** Extra line spacing in px. */
    lineSpacing: number;
    /** Text colour; empty keeps the theme ink. */
    textColorHex: string;
    /** Background fill mode. */
    bgMode: FillMode;
    /** Solid fill colour; empty keeps the theme ground. */
    bgColorHex: string;
    /** Linear/angular gradient angle in degrees. */
    gradientAngle: number;
    /** Background opacity 0–1. */
    bgOpacity: number;
    /** Gradient shape. */
    bgGradientType: GradientType;
    /** Gradient stops; empty seeds from the theme's ground and surface. */
    bgGradientStops: GradientStop[];
    /** The scheme the text and background colours were chosen in; `''` reads it from the colours. */
    scheme: SurfaceScheme;
}
/** The colour fields of a surface, the ones {@link surfaceScheme} binds to one scheme. */
export declare const SURFACE_COLOUR_FIELDS: readonly ["textColorHex", "bgMode", "bgColorHex", "bgGradientStops", "scheme"];
/**
 * Whether a surface carries a text colour or a background of its own.
 * @param surface - the override.
 * @returns true when either is set.
 */
export declare function surfaceColoured(surface: SurfaceAppearance): boolean;
/**
 * The scheme a surface's colours paint in: the recorded one, or, for a record
 * written before the field existed, the scheme its colours were evidently
 * chosen over — a dark background or a light ink means dark, otherwise light.
 * @param surface - the override.
 * @returns the scheme, or undefined for a surface with no colours.
 */
export declare function surfaceScheme(surface: SurfaceAppearance): 'light' | 'dark' | undefined;
/**
 * The surface with its colours returned to the theme's own; typography stays.
 * @param surface - the override.
 * @returns the surface without text colour, background or scheme.
 */
export declare function clearSurfaceColours(surface: SurfaceAppearance): SurfaceAppearance;
/** Terminal theme ids in V0's panel order (`Theme.terminalThemes`), then V1's Classic pair; the colours live in `terminal-themes.ts`. */
export declare const TERMINAL_THEME_IDS: readonly ["linen", "ink", "y2k", "idealize-dark", "idealize-light", "solarized-dark", "classic-dark", "classic-light"];
/** One of {@link TERMINAL_THEME_IDS}. */
export type TerminalThemeId = typeof TERMINAL_THEME_IDS[number];
/**
 * The terminal grid's own appearance (V0 AppSettings terminal fields),
 * independent of the app theme. The cursor is V0's bar in the theme's cursor
 * colour and carries no setting.
 */
export interface TerminalAppearanceSettings {
    /** Selected terminal theme. */
    theme: TerminalThemeId;
    /** Custom grid background `#RRGGBB`, or empty for the theme's own. */
    bgHex: string;
    /** Grid font family (V0 `fontName`). */
    fontName: string;
    /** Grid font size in px, 9–28 (V0 `fontSize`). */
    fontSize: number;
    /** Line height as a multiple of the font's natural height, 1–3 (V0 `terminalLineSpacing`). */
    lineSpacing: number;
    /** Padding around the grid in px, 0–80, painted in the terminal ground (V0 `terminalMargin`). */
    margin: number;
}
/** The terminal section as it ships (V0 AppearanceDefaults). */
export declare const TERMINAL_DEFAULTS: TerminalAppearanceSettings;
/**
 * Whether the terminal section differs from its defaults. The theme *choice*
 * does not count and Reset keeps it (V0's rule: choices are never reset,
 * only the values layered over them).
 * @param terminal - the terminal section.
 * @returns true when any non-theme field is set.
 */
export declare function terminalCustomised(terminal: TerminalAppearanceSettings): boolean;
/** The global action colour for primary buttons and selection highlights (V0 ActionAppearance). */
export interface ActionAppearance {
    /** `solid` or `gradient`. */
    mode: 'solid' | 'gradient';
    /** Solid colour; empty keeps the theme accent. */
    colorHex: string;
    /** Gradient angle in degrees. */
    angle: number;
    /** Opacity 0–1. */
    opacity: number;
    /** Gradient shape. */
    gradientType: GradientType;
    /** Gradient stops; empty seeds from the theme accent. */
    gradientStops: GradientStop[];
}
/** Durable appearance section. */
export interface AppearanceSettings {
    /** Selected app preset. */
    preset: PresetId;
    /** Interface font family; empty is the platform UI stack. */
    uiFont: string;
    /** Interface size in points; 13 is the unscaled default. */
    uiSize: number;
    /** The user's own ground colour as `#RRGGBB`, or empty for the preset's. */
    groundHex: string;
    /** The action colour. */
    action: ActionAppearance;
    /** The terminal grid's own appearance. */
    terminal: TerminalAppearanceSettings;
    /** Per-surface overrides. */
    surfaces: Record<SurfaceId, SurfaceAppearance>;
    /** Composer card opacity 0.3–1. */
    chatInputOpacity: number;
    /** Composer shadow strength 0–0.8. */
    chatShadowOpacity: number;
    /** Chat margins in px, 8–40. */
    chatMargin: number;
    /** Document view margins in px, 0–64. */
    docMargin: number;
}
/** V0's interface size default (AppearanceDefaults.uiFontSize). */
export declare const DEFAULT_UI_SIZE = 13;
/** V0's interface size range (Appearance ▸ Interface size slider). */
export declare const UI_SIZE_MIN = 10;
/** Upper bound of the interface size slider. */
export declare const UI_SIZE_MAX = 18;
/** An untouched surface. */
export declare const EMPTY_SURFACE: SurfaceAppearance;
/** The theme's own action colour. */
export declare const EMPTY_ACTION: ActionAppearance;
/** Defaults applied when the document has no override (V0 AppearanceDefaults). */
export declare const APPEARANCE_DEFAULTS: AppearanceSettings;
/** Durable schema; also the wire envelope the browser scope validates against. */
export declare const AppearanceSettingsSchema: z<AppearanceSettings>;
/** The platform UI stack ui-theme's base sheet declares (what an empty `uiFont` means). */
export declare const SYSTEM_FONT_STACK = "-apple-system, BlinkMacSystemFont, 'Segoe UI', 'PingFang SC', 'Hiragino Sans GB', 'Microsoft YaHei', 'Helvetica Neue', Helvetica, Arial, sans-serif";
/**
 * A CSS font-family value for a family name, quoted and followed by the
 * platform stack so a missing face degrades to the default.
 * @param family - font family name; empty means the platform stack.
 * @returns the font-family value.
 */
export declare function fontStack(family: string): string;
/**
 * The zoom factor an interface size maps to: V0 scaled every interface font
 * by `uiFontSize / 13`; the web shell scales its root the same way.
 * @param uiSize - interface size in points.
 * @returns the scale factor, 1 at the default.
 */
export declare function uiScale(uiSize: number): number;
/**
 * Whether a surface override differs from "inherit everything".
 * @param surface - the override.
 * @returns true when any field is set.
 */
export declare function surfaceCustomised(surface: SurfaceAppearance): boolean;
/**
 * Whether the action colour differs from the theme's own.
 * @param action - the action appearance.
 * @returns true when any field is set.
 */
export declare function actionCustomised(action: ActionAppearance): boolean;
//# sourceMappingURL=appearance-settings.d.ts.map