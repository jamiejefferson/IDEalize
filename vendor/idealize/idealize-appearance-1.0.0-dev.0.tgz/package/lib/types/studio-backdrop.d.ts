/**
 * The Studio's backdrop: the view drawn as a photo studio's wall and floor,
 * with one lamp, a clouded canvas texture and fine grain, and the Studio's
 * text and panels coloured to sit on it. JJ settled the three backdrops'
 * values on a tuning page on 26 Nov 2026 (`_AppDev/IDEalize/studio-tuner`);
 * {@link backdropPaint} reproduces that page's CSS so the view matches what
 * was tuned. A backdrop carries a full {@link Backdrop}; the user's own
 * adjustments are a sparse {@link BackdropTweaks} layered over it, kept per
 * backdrop.
 */
/** The backdrop dials a preset sets and the user may adjust. Percentages are 0–100. */
export interface BackdropSettings {
    /** How far the corners darken away from the lamp, in percent. */
    vignette: number;
    /** The lamp's level, in percent. Zero leaves the wall unlit. */
    light: number;
    /** Where the lamp points, across the view: 0 is the left edge, 100 the right. */
    lightX: number;
    /** Where the lamp points, down the view: 0 is the top edge, 100 the bottom. */
    lightY: number;
    /** Width of the lit pool, as a percentage of the view's width. */
    lightW: number;
    /** Height of the lit pool, as a percentage of the view's height. */
    lightH: number;
    /** Strength of the clouded, hand-painted canvas pattern, in percent. */
    mottle: number;
    /** Size of the clouds in px; smaller reads as dappled cloth. */
    mottleScale: number;
    /** Fine fibre grain strength, in percent. */
    grain: number;
    /** Grain tile size in px; smaller is finer. */
    grainScale: number;
    /** Whether a floor is drawn; off leaves one continuous wall. */
    floor: boolean;
    /** Where the wall meets the floor, in percent from the top. */
    horizon: number;
    /** How much of the lamp spills onto the floor, in percent. */
    floorLight: number;
    /** Distance in px the floor fades in over; high values curve the wall into the floor. */
    seamSoft: number;
    /** The dark band where the wall drops behind the floor, in percent. */
    seamShade: number;
    /** Brushed streaks on the floor, in percent. */
    floorTexture: number;
    /** Text size in px. */
    size: number;
    /** Text weight, 400–600. */
    weight: number;
    /** Line height as a multiple of the text size. */
    leading: number;
    /** Space between letters in em. */
    tracking: number;
    /** Text opacity in percent; below 100 the backdrop shows through the text. */
    inkOpacity: number;
    /** How solid the panels are, in percent. Zero leaves them as outlines. */
    panelFill: number;
    /** Blur of the backdrop behind a panel in px. */
    panelBlur: number;
    /** Strength of the panels' hairline, drawn in the text colour, in percent. */
    panelEdge: number;
}
/** The colours of a backdrop, each `#RRGGBB`. */
export interface BackdropColours {
    /** The unlit wall. */
    wall: string;
    /** The colour the lamp throws. */
    lightColour: string;
    /** The floor before the lamp reaches it. */
    floorColour: string;
    /** Titles, names and messages. */
    ink: string;
    /** Times, hints and message detail. */
    secondary: string;
    /** Agent names and links. */
    accent: string;
    /** The summary card and the message box. */
    panel: string;
}
/** A whole backdrop: every dial and colour. */
export type Backdrop = BackdropSettings & BackdropColours;
/** The user's adjustments to one backdrop: only the dials and colours they changed. */
export type BackdropTweaks = Partial<Backdrop>;
/** The backdrops JJ tuned, in the order the panel lists them. */
export declare const STUDIO_BACKDROP_IDS: readonly ["grey", "blue", "white"];
/** One of {@link STUDIO_BACKDROP_IDS}. */
export type StudioBackdropId = typeof STUDIO_BACKDROP_IDS[number];
/** A backdrop the panel offers. */
export interface StudioBackdrop {
    id: StudioBackdropId;
    /** The name shown in the panel. */
    name: string;
    backdrop: Backdrop;
}
/**
 * JJ's settled values (26 Nov 2026): a lit charcoal wall, a clouded teal canvas, a white cove. The walls,
 * light, texture and floor are from the tuning page; the text and panels were retuned in the app the same day.
 */
export declare const STUDIO_BACKDROPS: readonly StudioBackdrop[];
/**
 * Look a backdrop up by id.
 * @param id - the backdrop's id.
 * @returns the backdrop; an id that is not listed reads as the first.
 */
export declare function studioBackdrop(id: string): StudioBackdrop;
/** The colour dials in the order the panel lists them. */
export declare const BACKDROP_COLOURS: readonly (keyof BackdropColours)[];
/** The backdrop dials that are numbers (every one but the floor switch). */
export type BackdropNumberKey = {
    [K in keyof BackdropSettings]: BackdropSettings[K] extends number ? K : never;
}[keyof BackdropSettings];
/** One number dial's bounds and slider step. */
export interface BackdropRange {
    min: number;
    max: number;
    step: number;
}
/**
 * Bounds for every number dial, shared by the settings schema and the panel's
 * sliders; they are the tuning page's. Text opacity stops at 40 so text
 * cannot be tuned out of sight.
 */
export declare const BACKDROP_RANGES: Readonly<Record<BackdropNumberKey, BackdropRange>>;
/**
 * One backdrop with the user's adjustments over it.
 * @param backdrop - the preset's own values.
 * @param tweaks - the user's adjustments for that backdrop, if any.
 * @returns the backdrop to draw.
 */
export declare function tweakedBackdrop(backdrop: Backdrop, tweaks: BackdropTweaks | undefined): Backdrop;
/**
 * Record one adjusted dial or colour for one backdrop. A value equal to the
 * backdrop's own, or an empty colour, removes the adjustment, and a backdrop
 * left with none drops out, so untouched settings stay equal to the defaults.
 * @param all - every backdrop's adjustments, keyed by backdrop id.
 * @param id - the backdrop being adjusted.
 * @param key - the dial or colour.
 * @param value - its new value.
 * @param own - the backdrop's own value for it.
 * @returns the next adjustments record.
 */
export declare function withBackdropTweak<K extends keyof BackdropTweaks>(all: Readonly<Record<string, BackdropTweaks>>, id: string, key: K, value: NonNullable<BackdropTweaks[K]>, own: NonNullable<BackdropTweaks[K]>): Record<string, BackdropTweaks>;
/** The backdrop as CSS the Studio view can place without knowing the dials. */
export interface StudioBackdropPaint {
    /** `background-color` of the unlit wall. */
    wall: string;
    /** `background-image` of the lamp's pool. */
    light: string;
    /** `background-image` darkening the corners. */
    vignette: string;
    /** The floor and the shade above it, absent when the floor is off. */
    floor?: {
        /** `background-image` of the band where the wall drops behind the floor. */
        seam: string;
        /** `top` of the floor, a percentage of the view. */
        top: string;
        /** `background-color` of the floor. */
        colour: string;
        /** `background-image` of the lamp's spill on the floor. */
        image: string;
        /** `mask-image` fading the floor in from the seam. */
        mask: string;
        /** Opacity of the brushed streaks, 0–1; absent at zero. */
        streaks?: number;
    };
    /** Clouded canvas layer, absent at zero strength. */
    mottle?: {
        opacity: number;
        size: number;
    };
    /** Grain layer, absent at zero strength. */
    grain?: {
        opacity: number;
        size: number;
    };
    /** Custom properties for the view's root: the text and panel values. */
    variables: Record<string, string>;
}
/** The text colours a backdrop is drawn with, each checked against the ground it sits on. */
export interface BackdropInks {
    /** The chat's title, on the wall at the head of the view. */
    title: string;
    /** The line under the message box, on the floor at the foot of the view. */
    foot: string;
    /** Text straight on the backdrop anywhere in the view, and its secondary. */
    open: string;
    open2: string;
    /** Text on a panel (a message row, a tile, the message box), its secondary and its accent. */
    panel: string;
    panel2: string;
    panelAccent: string;
    /** The failure colour on a panel: the app's red, moved along its hue until it reads there. */
    panelError: string;
    /** The fill of a control that stands proud of a panel (a chosen segment, a button), which panel text reads on. */
    raised: string;
}
/** The contrast every backdrop text colour is held to against its ground. */
export declare const BACKDROP_TEXT_CONTRAST = 4.5;
/** Panel text is held a little higher, because controls lay a faint wash of the text colour under it. */
export declare const BACKDROP_PANEL_CONTRAST = 5;
/**
 * Work out the colours a backdrop's text is drawn in. JJ's colours stand
 * wherever they read; where one does not clear the contrast floor against
 * the ground it sits on, its lightness moves along its own hue until it does
 * (the deepen-along-hue rule). The grounds are the wall and the floor, unlit,
 * under the lamp and in the corner falloff; a panel's grounds are its colour
 * laid over each of those at its fill.
 *
 * Until 26 Nov 2026 the view drew JJ's text colour everywhere. On Grey and
 * Blue that put near-white text on a panel that is more than half white, and
 * on controls with a white fill of their own (JJ: "this is still unusable").
 * @param backdrop - the backdrop (preset values with any adjustments).
 * @returns the text colours as hex.
 */
export declare function backdropInks(backdrop: Backdrop): BackdropInks;
/**
 * Turn a backdrop into the CSS the Studio view draws. The expressions match
 * the tuning page's.
 * @param backdrop - the backdrop to draw (preset values with any adjustments).
 * @param fontFamily - the CSS `font-family` for the Studio's text; omitted keeps the interface font.
 * @returns the CSS-ready paint.
 */
export declare function backdropPaint(backdrop: Backdrop, fontFamily?: string): StudioBackdropPaint;
//# sourceMappingURL=studio-backdrop.d.ts.map