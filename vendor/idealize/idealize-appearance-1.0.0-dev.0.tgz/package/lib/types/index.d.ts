/**
 * @idealize/appearance — Host half of the appearance panel: registers the
 * durable `idealize-appearance` settings section (preset, interface font and
 * size, the action colour, the user's ground, per-surface overrides, the
 * chat panel scalars), bootstraps font and size into the served index, and
 * serves the installed font families for the pickers:
 * - `GET /idealize/appearance/fonts` — `{ families: string[], monospaced:
 *   string[] }`, loopback only.
 * The panel itself is the browser half (`./client`).
 * @module @idealize/appearance
 */
import type { Context } from '@deepseek-ai/cordis';
export { actionCustomised, APPEARANCE_DEFAULTS, CHAT_TITLE_DEFAULTS, CHAT_TITLE_SIZE_MAX, CHAT_TITLE_SIZE_MIN, parseTitleWeight, type ChatTitleAppearance, APPEARANCE_SETTINGS_NAMESPACE, AppearanceSettingsSchema, EMPTY_ACTION, EMPTY_SURFACE, FILL_MODES, FONT_WEIGHTS, fontStack, GRADIENT_TYPES, PRESETS, SURFACES, surfaceCustomised, resolveStudioPaint, STUDIO_BACKDROP_CHOICES, STUDIO_DEFAULTS, studioCustomised, type StudioAppearanceSettings, type StudioBackdropChoice, TERMINAL_DEFAULTS, TERMINAL_THEME_IDS, terminalCustomised, uiScale, type ActionAppearance, type AppearanceSettings, type FillMode, type GradientStop, type GradientType, type PresetId, type SurfaceAppearance, type SurfaceId, type TerminalAppearanceSettings, type TerminalThemeId, } from './appearance-settings.ts';
export { PAPER_RANGES, PAPER_SWITCHES, paperGrounds, paperPaint, tweakedPaper, withPaperTweak, type PaperNumberKey, type PaperRange, type PaperSettings, type PaperSwitchKey, type PaperTweaks, type TerminalPaperPaint, type ThemePaper, } from './blueprint-paper.ts';
export { BACKDROP_RANGES, backdropInks, backdropPaint, STUDIO_BACKDROPS, studioBackdrop, tweakedBackdrop, withBackdropTweak, type Backdrop, type BackdropTweaks, type StudioBackdrop, type StudioBackdropId, type StudioBackdropPaint, } from './studio-backdrop.ts';
export { resolveTerminalPaint, TERMINAL_THEMES, terminalFontStack, terminalTheme, type TerminalPaint, type TerminalTheme, } from './terminal-themes.ts';
export { actionAccent, actionTokens, appearanceStylesheet, chatTitleCss, panelScalarsCss, TITLE_ATTRIBUTE, TITLE_PART_ATTRIBUTE, COMPOSER_ATTRIBUTE, gradientCss, seedStops, SURFACE_ATTRIBUTE, SURFACE_BASE_SIZE, SURFACE_EXEMPT_ATTRIBUTE, surfaceCss, type ActionAccent, type SurfaceDefaults, } from './surface-css.ts';
export { familiesInFile, familyOfFace, fontDirectories, isFixedPitchFace, listFontFamilies, type FontInventory } from './fonts.ts';
export { CRISP_BORDER_STEP, CRISP_SECONDARY_BLEND, deriveTokens, hoverOf, onFill, PRESET_LIST, PRESET_TOKEN_KEYS, preset, presetPalette, resolveAppearance, surfaceHex, tokenDeclarations, type Palette, type Preset, type Resolved, type ResolvedScheme, type Tokens, } from './presets.ts';
export { contrast, deepenAlongHue, parseHex, toHex, TEXT_CONTRAST, UI_CONTRAST } from './colour.ts';
export { BOOT_STYLE_ID, injectBootAppearance } from './boot-appearance.ts';
/**
 * Register the durable appearance section, the index bootstrap and the font
 * route when their optional Host services are composed.
 * @param ctx - Host context that may acquire settings and HTTP services.
 */
export declare function apply(ctx: Context): void;
//# sourceMappingURL=index.d.ts.map