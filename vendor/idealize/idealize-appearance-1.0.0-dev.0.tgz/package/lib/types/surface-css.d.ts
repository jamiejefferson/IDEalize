/**
 * The per-surface and chat-panel projection as CSS text (V0 PanelStyle and
 * ActionStyle, expressed as a stylesheet over the `data-idealize-surface`
 * hooks the frame and the conversation column carry). Pure: settings in,
 * stylesheet out; the client applies it through one `<style>` element.
 *
 * Typography: the font family, letter-spacing and weight cascade from the
 * surface root (code keeps its own face); size is a zoom relative to the
 * surface's natural size, as V0 scaled per-panel type by `fontSize / base`;
 * the text colour rewrites the surface's ink tokens (secondary at 55%, V0's
 * `secondaryTextColor`). Background: the surface root paints the fill and
 * its own ground tokens go transparent so nothing inside covers it. Both
 * colours paint only in the scheme they were chosen in (`surfaceScheme`);
 * the other scheme keeps the theme's own. On a fill of its own, the surface's
 * ink tokens are held to a contrast floor against it ({@link surfaceInk}).
 */
import { type Rgb } from './colour.ts';
import { type ActionAppearance, type GradientStop, type GradientType, type SurfaceAppearance, type SurfaceId } from './appearance-settings.ts';
import { type Tokens } from './presets.ts';
/** Each surface's natural text size, the divisor of its size override (V0 PanelStyle.baseSize). */
export declare const SURFACE_BASE_SIZE: Readonly<Record<SurfaceId, number>>;
/**
 * Each surface's unstressed body leading as an em ratio, the base the
 * line-spacing slider adds onto (spacing 0 leaves the surface exactly as
 * shipped). Chat is the assistant flow's 16px/28px
 * (AssistantMarkdown.module.css); the other surfaces set no explicit body
 * line-height, so they render at the browser's `normal` (~1.45), which the
 * rail's 13/18 and 14/20 rows sit on.
 */
export declare const SURFACE_BASE_LEADING: Readonly<Record<SurfaceId, number>>;
/** Attribute the frame and conversation column mark their surfaces with. */
export declare const SURFACE_ATTRIBUTE = "data-idealize-surface";
/**
 * Attribute an element inside a surface carries to keep the surface's
 * typography and ink off itself and its subtree: the appearance panel sets it
 * on its root so it stays legible while the person edits the surface hosting it.
 */
export declare const SURFACE_EXEMPT_ATTRIBUTE = "data-idealize-surface-exempt";
/** Attribute the conversation's composer card already carries. */
export declare const COMPOSER_ATTRIBUTE = "data-composer-card";
/** Attribute the conversation's sticky composer seat already carries. */
export declare const COMPOSER_SEAT_ATTRIBUTE = "data-composer-seat";
/** The ink tokens a surface text colour rewrites and an exempt subtree restores. */
declare const INK_TOKENS: readonly ["--dsw-alias-label-primary", "--dsw-alias-label-secondary", "--dsw-alias-label-tertiary", "--dsw-alias-label-caption"];
/**
 * A CSS gradient image for stops, shape and angle (V0 makeGradientStyle).
 * @param stops - colour stops, any order.
 * @param type - gradient shape.
 * @param angle - degrees, used by linear and angular.
 * @param opacity - 0–1 folded into every stop.
 * @param fallback - hex used for a stop whose colour does not parse.
 * @returns the gradient image value.
 */
export declare function gradientCss(stops: readonly GradientStop[], type: GradientType, angle: number, opacity: number, fallback: string): string;
/**
 * Seed stops from two colours (V0 defaultStops).
 * @param first - hex at 0.
 * @param second - hex at 1.
 * @returns the two stops.
 */
export declare function seedStops(first: string, second: string): GradientStop[];
/** The theme values a surface falls back to when it inherits. */
export interface SurfaceDefaults {
    /** Theme ground hex (gradient seed start). */
    ground: string;
    /** Theme surface hex (gradient seed end). */
    surface: string;
    /** The scheme's resolved layer: an exempt subtree takes its ink tokens back from here. */
    tokens: Tokens;
    /** The scheme being painted; a surface's colours apply only when they belong to it. */
    scheme: 'light' | 'dark';
}
/**
 * The contrast each ink token holds against a surface's own ground: primary
 * carries running text; secondary, tertiary and caption carry icons, chip
 * labels, placeholders and small notes. {@link surfaceInk} lowers a floor to
 * what the theme's own token holds on the theme's own ground where that is
 * less (IDEalize Light's 45% tertiary sits at 2.8:1 on white), so a surface's
 * ground never makes ink fainter than the theme has it, and a theme's faint
 * ink is not second-guessed.
 */
export declare const INK_FLOORS: Readonly<Record<typeof INK_TOKENS[number], number>>;
/**
 * The opaque colours a surface's own background paints, each composited over
 * the theme ground at the background's opacity: one for a solid fill, one per
 * stop for a gradient.
 * @param surface - override.
 * @param defaults - theme fallbacks.
 * @returns the grounds, or undefined when the surface paints none in this scheme.
 */
export declare function surfaceGrounds(surface: SurfaceAppearance, defaults: SurfaceDefaults): Rgb[] | undefined;
/** One ink token held to its floor. */
export interface FlooredInk {
    /** CSS value: the source value when it already reads, otherwise the opaque deepened colour. */
    value: string;
    /** Lowest contrast of the source colour across the grounds. */
    ratio: number;
    /** Lowest contrast of {@link value} across the grounds; below the floor only when no shade of the hue reaches it. */
    painted: number;
    /** Whether the value was deepened along its hue. */
    deepened: boolean;
}
/**
 * Hold a surface's ink tokens to {@link INK_FLOORS} against a set of grounds,
 * each floor capped at the ratio the theme's own token holds on the theme
 * ground. The source of each token is the surface's text colour at the token's
 * opacity, or the theme's own token when the surface sets no text colour. A
 * source that reads on every ground stands; one that does not restarts from
 * the lightness it shows at over the ground it reads worst on, in its own hue
 * and saturation, and is deepened ({@link deepenAgainstAll}) until it does. Nothing is desaturated or swapped.
 * The stylesheet and the panel's readout share this.
 * @param surface - override.
 * @param theme - the scheme's ground and resolved layer.
 * @param grounds - the opaque grounds the ink is read against.
 * @returns each ink token floored.
 */
export declare function surfaceInk(surface: SurfaceAppearance, theme: Pick<SurfaceDefaults, 'ground' | 'tokens'>, grounds: readonly Rgb[]): Record<typeof INK_TOKENS[number], FlooredInk>;
/**
 * The stylesheet for one surface's override.
 * @param id - surface.
 * @param surface - override.
 * @param defaults - theme fallbacks for gradient seeds.
 * @returns CSS text, empty when the surface inherits everything.
 */
export declare function surfaceCss(id: SurfaceId, surface: SurfaceAppearance, defaults: SurfaceDefaults): string;
/** The accent the action colour yields for text, borders and icons. */
export interface ActionAccent {
    /** CSS colour: the person's colour at their opacity when that reads, otherwise the opaque deepened shade. */
    value: string;
    /** The person's colour composited over the ground at their opacity. */
    composite: Rgb;
    /** Contrast of the composite against the ground. */
    ratio: number;
    /** Whether the value was deepened along its hue to reach {@link UI_CONTRAST}. */
    deepened: boolean;
}
/**
 * The accent an action colour gives to text, borders and icons: the colour at
 * the chosen opacity when its composite over the ground reads at 3:1,
 * otherwise the solid colour deepened along its hue until it does. The panel's
 * readout and {@link actionTokens} share this so what the readout says is
 * what the borders paint.
 * @param solid - the action colour.
 * @param opacity - the action opacity 0–1.
 * @param ground - the scheme's ground.
 * @returns the accent, its composite ratio and whether it was deepened.
 */
export declare function actionAccent(solid: Rgb, opacity: number, ground: Rgb): ActionAccent;
/**
 * The action colour as token overrides (V0 ActionStyle.fill / softFill): the
 * button fills (`button-primary` and the send circle's `button-info` pair)
 * take the solid colour or the gradient image at the action's opacity; the
 * soft selection fills take the solid colour at 18% and 12%; the accent used
 * as text, borders, icons and the composer/tab highlights
 * (`--dsw-alias-brand-primary`, `--dsw-alias-state-business-primary`) takes
 * {@link actionAccent}, so every accent border agrees with the buttons. With
 * an ink, the text written on the fill (`brand-primary-invert`) is whichever
 * of ink and ground reads better on it.
 * @param action - the action appearance.
 * @param accent - the theme accent hex the action falls back to.
 * @param ground - the scheme's ground hex the deepen rule reads against.
 * @param ink - the scheme's ink hex; without it the fill's text token is left to the layer.
 * @returns token name → CSS value, empty when neither the action nor the accent parses.
 */
export declare function actionTokens(action: ActionAppearance, accent: string, ground: string, ink?: string): Record<string, string>;
/**
 * The panel scalars a surface's own card asks for beyond typography and
 * background (V0 Chat ▸ Chat panel card, plus the document view's margin).
 */
export interface PanelScalars {
    chatInputOpacity: number;
    chatShadowOpacity: number;
    chatMargin: number;
    docMargin: number;
}
/**
 * The panel-scalar stylesheet: each margin feeds its column's spacing
 * variable, and the chat's opacity and shadow land on the composer card.
 * @param panels - the scalars.
 * @returns CSS text.
 */
export declare function panelScalarsCss(panels: PanelScalars): string;
/**
 * The whole per-surface + chat stylesheet.
 * @param surfaces - every surface's override.
 * @param panels - the per-panel scalars.
 * @param defaults - theme fallbacks for gradient seeds.
 * @returns CSS text.
 */
export declare function appearanceStylesheet(surfaces: Readonly<Record<SurfaceId, SurfaceAppearance>>, panels: PanelScalars, defaults: SurfaceDefaults): string;
export {};
//# sourceMappingURL=surface-css.d.ts.map