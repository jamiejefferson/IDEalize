/** `idealize-tasks` namespace dictionary: the task column beside the tool rail. */
/** Simplified Chinese dictionary (the key-set source of truth). */
export declare const zh: {
    readonly 'column.title': "任务";
    readonly 'column.progress': "{done}/{total}";
    readonly 'column.collapse': "收起任务";
    readonly 'column.expand': "展开任务";
    readonly 'column.empty': "这个对话还没有任务列表。";
};
/** English dictionary. */
export declare const en: Record<TasksKey, string>;
/** Keys of this plugin's dictionary. */
export type TasksKey = keyof typeof zh;
/** Dictionary namespace owned by this plugin. */
export declare const NS = "idealize-tasks";
/** The copy face the task column reads. */
export type Translate = (key: TasksKey, params?: Record<string, unknown>) => string;
//# sourceMappingURL=locales.d.ts.map