/**
 * The task column, browser half. Fills the frame's `shell.aside` seat — the
 * full-height column immediately left of the tool rail — with the current
 * chat's task list.
 *
 * JJ, 24 Aug 2026: a chat working through several tasks should show the
 * agent's list as a column beside the work. The list itself is the `todos`
 * projection the harness computes from `todo_write`, so nothing here is
 * fetched or stored. The column is the one place the list shows: the
 * composer's own plan strip (ui-conversation's `TodoPanel`, the dock entry
 * `todo`) is shadowed with an empty occupant, since the same list twice on
 * one screen reads as two lists (JJ, 8 Sep 2026: "we seem to have two of them").
 */
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
import type { TasksKey } from './locales.ts';
export { TaskColumn, TaskAside } from './TaskColumn.tsx';
export type { TaskColumnProps, TaskAsideProps } from './TaskColumn.tsx';
export type { TasksKey, Translate } from './locales.ts';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** The task column's copy. */
        'idealize-tasks': TasksKey;
    }
}
/** Required services: the slot registry and copy. */
export declare const inject: string[];
/**
 * Mount the task column.
 * @param ctx - client root context.
 */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map