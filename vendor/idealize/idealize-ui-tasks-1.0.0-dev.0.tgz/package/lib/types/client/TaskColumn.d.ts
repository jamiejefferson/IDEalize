/**
 * The task column: the agent's current task list as a full-height column
 * immediately left of the tool rail.
 *
 * The list is the `todos` projection the harness already computes from
 * `todo_write` (whole-list snapshot, cleared on the next turn), so this view
 * reads it and renders nothing of its own. The composer's plan strip shows the
 * same list folded into one line; this column is the version JJ asked for on
 * 24 Aug 2026, where a chat working through several tasks shows all of them at
 * once beside the work.
 *
 * An empty list renders nothing at all, which is what keeps the column out of
 * the layout: the aside track is sized by its occupant.
 */
import type { TodoItem } from '@deepseek-ai/dsh-tool-todo/client';
import type { PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { Translate } from './locales.ts';
/** What the column renders: one chat's task list and the copy face. */
export interface TaskColumnProps {
    /** The chat's current task list; an empty list renders nothing. */
    todos: readonly TodoItem[];
    t: Translate;
}
/**
 * Render one chat's task column.
 * @param props - the task list and the copy face.
 * @returns the column, or nothing while the chat has no list.
 */
export declare function TaskColumn({ todos, t }: TaskColumnProps): import("react").JSX.Element | null;
/** Full props of the aside seat: the session-maybe kit plus the locale seat. */
export type TaskAsideProps = PropsRuntime<'shell.aside'> & PropsLocale<'idealize-tasks'>;
/**
 * The aside adapter: reads the host-computed `todos` projection and renders
 * the column. No session, or no list, renders nothing, which leaves the aside
 * track at zero width.
 * @param props - the framework's projection reader and the copy face.
 * @returns the task column.
 */
export declare function TaskAside({ useProjection, t }: TaskAsideProps): import("react").JSX.Element;
//# sourceMappingURL=TaskColumn.d.ts.map