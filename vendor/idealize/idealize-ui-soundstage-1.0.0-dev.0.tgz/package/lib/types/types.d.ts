/**
 * Wire vocabulary shared by the Sound Stage's two halves: one row of the
 * sounds listing the host serves and the browser half renders. Types only —
 * no runtime code, so the Client bundle imports it without loading the Host
 * services.
 * @module @idealize/ui-soundstage/src/types
 */
/**
 * One stored sound as `GET /idealize/soundstage/sounds` reports it: the
 * artefact identity the player streams by, its storage facts, and the
 * generation provenance the row prints. `prompt` and `durationS` are the
 * generation settings the producing task recorded, absent when it recorded
 * none of that kind.
 */
export interface SoundListing {
    readonly id: string;
    readonly mediaType: string;
    /** Project-relative storage path, used as the row's fallback title. */
    readonly relPath: string;
    readonly bytes: number;
    /** ISO-8601 creation instant, stamped by the artefact store. */
    readonly createdAt: string;
    readonly provider: string;
    readonly model: string;
    readonly prompt?: string;
    readonly durationS?: number;
}
/** Response body of `GET /idealize/soundstage/sounds`, newest creation first. */
export interface SoundsResponse {
    readonly sounds: readonly SoundListing[];
}
//# sourceMappingURL=types.d.ts.map