/**
 * The Sound Stage's generation setting on the composer: a length picker that
 * appears only while the chat's active view is the Sound Stage. It reads the
 * chat store's `view` through the shared chat entry store, the same way the
 * Chat⇄Terminal shortcut does, and it renders nothing in every other view —
 * so the seat costs an ordinary chat no layout.
 *
 * The chosen length reaches the model as one trailing English sentence in the
 * composer draft, which the Sound Stage agent passes to `generate_audio` as
 * its duration. Writing it into the draft keeps the setting visible and
 * editable: the user can see exactly what will be sent, and clearing the
 * picker takes the sentence back out.
 */
import type { Translate } from './locales.ts';
/** The view id whose ring entry this control belongs to. */
export declare const SOUNDSTAGE_VIEW = "soundstage";
/**
 * The trailing generation directive, with or without its blank-line lead.
 * Anchored to the draft's end, so only the sentence this control wrote is
 * ever replaced.
 */
export declare const LENGTH_DIRECTIVE: RegExp;
/**
 * The lengths the picker offers, in seconds. A presentation vocabulary (like
 * the terminal grid's cursor style), not a deployment tunable: the model
 * accepts any duration the user types in prose, and this row is the shortcut
 * for the three that cover almost every ask.
 */
export declare const LENGTHS: readonly number[];
/**
 * Rewrite a draft's trailing length directive.
 * @param draft - the current composer draft.
 * @param seconds - the chosen length, or null to clear the directive.
 * @returns the next draft; applying it twice with the same length is a no-op.
 */
export declare function withLength(draft: string, seconds: number | null): string;
/**
 * The length the draft currently states.
 * @param draft - the current composer draft.
 * @returns the directive's seconds, or null when the draft carries none.
 */
export declare function lengthOf(draft: string): number | null;
/** What the control reads: the ring's active view, the draft, and the draft writer. */
export interface SoundLengthProps {
    useStore: <T>(selector: (state: {
        view: string | null;
    }) => T) => T;
    useInput: <T>(selector: (state: {
        draft: string;
    }) => T) => T;
    inputActions: {
        setDraft: (text: string) => void;
    };
    t: Translate;
}
/**
 * Render the length picker while the Sound Stage is the active view.
 * @param props - the store hooks, the draft writer, and copy.
 * @returns the control row, or null in every other view.
 */
export declare function SoundLength({ useStore, useInput, inputActions, t }: SoundLengthProps): import("react").JSX.Element | null;
//# sourceMappingURL=SoundLength.d.ts.map