/**
 * The Sound Stage's row model: a pure projection from the sounds listing and
 * the conversation's generation facts onto the ordered list the view renders.
 * Generations still in flight lead, failures follow, and the stored sounds
 * fill the rest — newest first inside each group, so the row the user just
 * asked for is always the one at the top.
 * @module @idealize/ui-soundstage/src/client/rows
 */
import type { SoundListing } from '../types.ts';
/** The generation tool whose calls the Sound Stage tracks (the Sound Stage agent's only generator). */
export declare const SOUND_TOOL = "generate_audio";
/** The artefact media-type prefix this view owns. */
export declare const SOUND_MEDIA_PREFIX = "audio/";
/** One `generate_audio` call still running: the row that shows work in flight. */
export interface GeneratingRow {
    readonly kind: 'generating';
    readonly key: string;
    readonly callId: string;
    readonly prompt: string;
    /** Unix epoch ms the call was logged at. */
    readonly startedAt: number;
}
/**
 * One generation that failed, carrying the adapter's provider cause. `prompt`
 * is present when the failing call is still in the conversation window, which
 * is what makes Retry possible.
 */
export interface ErrorRow {
    readonly kind: 'error';
    readonly key: string;
    readonly prompt?: string;
    readonly cause: string;
}
/** One stored sound, played from the artefact raw route. */
export interface SoundRow {
    readonly kind: 'sound';
    readonly key: string;
    readonly listing: SoundListing;
}
/** One row of the Sound Stage list. */
export type StageRow = GeneratingRow | ErrorRow | SoundRow;
/** A `generate_audio` call the conversation reports as still running. */
export interface RunningCallFacts {
    readonly callId: string;
    readonly name: string;
    readonly argsRaw: string;
    readonly time: number;
}
/** A settled `generate_audio` call, with the tool result's text as its cause when it failed. */
export interface SettledCallFacts {
    readonly callId: string;
    readonly name: string;
    readonly argsRaw: string;
    readonly failed: boolean;
    readonly cause: string;
    readonly time: number;
}
/** One `artefact/failed` event's facts, as the chat node carries them. */
export interface ArtefactFailureFacts {
    readonly id: string;
    readonly mediaType: string;
    readonly error: string;
}
/** Everything {@link buildRows} projects the list from. */
export interface RowInput {
    readonly sounds: readonly SoundListing[];
    readonly running: readonly RunningCallFacts[];
    readonly settled: readonly SettledCallFacts[];
    readonly failures: readonly ArtefactFailureFacts[];
}
/**
 * Read the `prompt` argument out of a tool call's raw JSON arguments.
 * @param argsRaw - the call's arguments exactly as the model emitted them.
 * @returns the prompt, or undefined when the arguments are unparsable or carry none.
 */
export declare function promptOf(argsRaw: string): string | undefined;
/**
 * Project the Sound Stage's ordered rows.
 * @param input - the sounds listing plus the conversation's generation facts.
 * @returns generations in flight, then failures, then stored sounds; newest first inside each group.
 */
export declare function buildRows(input: RowInput): StageRow[];
//# sourceMappingURL=rows.d.ts.map