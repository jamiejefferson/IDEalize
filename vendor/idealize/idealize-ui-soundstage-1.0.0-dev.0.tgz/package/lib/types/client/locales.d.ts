/** `idealize-soundstage` namespace dictionaries: the Sound Stage view. */
/** Simplified Chinese dictionary (the key-set source of truth). */
export declare const zh: {
    readonly 'view.soundstage': "声音";
    readonly 'stage.empty.title': "这个对话还没有声音。";
    readonly 'stage.empty.body': "在下面描述你想要的声音，生成结果会出现在这里。";
    readonly 'row.generating': "正在生成…";
    readonly 'row.thinking': "正在思考…";
    readonly 'row.nothing': "这一轮没有生成任何内容。";
    readonly 'row.turnFailed': "这一轮失败了：{reason}";
    readonly 'row.stopped': "已停止。";
    readonly 'row.failed': "生成失败";
    readonly 'row.retry': "重试";
    readonly 'row.untitled': "未命名的声音";
    readonly 'row.play': "播放";
    readonly 'row.keep': "保留";
    readonly 'row.archive': "归档";
    readonly 'row.reveal': "显示文件";
    readonly 'stage.archived.fold': "已归档 {count} 个";
};
/** English dictionary. */
export declare const en: Record<SoundstageKey, string>;
/** Keys of this plugin's dictionary. */
export type SoundstageKey = keyof typeof zh;
/** Dictionary namespace owned by this plugin. */
export declare const NS = "idealize-soundstage";
/** The copy face the Sound Stage components read. */
export type Translate = (key: SoundstageKey, params?: Record<string, unknown>) => string;
//# sourceMappingURL=locales.d.ts.map