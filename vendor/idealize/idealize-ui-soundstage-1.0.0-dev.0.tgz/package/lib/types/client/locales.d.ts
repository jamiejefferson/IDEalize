/** `idealize-soundstage` namespace dictionaries: the Sound view's name in the ring. */
/** Simplified Chinese dictionary (the key-set source of truth). */
export declare const zh: {
    readonly 'view.soundstage': "声音";
};
/** English dictionary. */
export declare const en: Record<SoundstageKey, string>;
/** Keys of this plugin's dictionary. */
export type SoundstageKey = keyof typeof zh;
/** Dictionary namespace owned by this plugin. */
export declare const NS = "idealize-soundstage";
//# sourceMappingURL=locales.d.ts.map