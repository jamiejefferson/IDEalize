/**
 * Reading the Sound Stage's generation facts out of one conversation
 * snapshot: the `generate_audio` calls still running, the ones that settled
 * (with the tool result's text as the failure cause), and the `artefact/*`
 * chat nodes — the created count that tells the list to re-read, and the
 * failures a background generation reports without a failing call.
 * @module @idealize/ui-soundstage/src/client/facts
 */
import type { ConversationSnapshot } from '@deepseek-ai/dsh-client-runtime/client';
import type { ArtefactFailureFacts, RunningCallFacts, SettledCallFacts } from './rows.ts';
/** Everything one snapshot contributes to the Sound Stage's rows. */
export interface SoundFacts {
    readonly running: readonly RunningCallFacts[];
    readonly settled: readonly SettledCallFacts[];
    readonly failures: readonly ArtefactFailureFacts[];
    /** How many artefacts this session has committed; a change re-reads the listing. */
    readonly created: number;
}
/**
 * Concatenate a tool result's text blocks. Content blocks are
 * merge-extensible, so anything that is not a text block is skipped rather
 * than switched on.
 * @param content - the result's content blocks.
 * @returns the joined text, empty when the result carried none.
 */
export declare function resultText(content: readonly {
    readonly type: string;
    readonly text?: unknown;
}[]): string;
/**
 * Read one conversation snapshot's generation facts.
 * @param snapshot - the session's conversation snapshot.
 * @returns the running calls, settled calls, artefact failures, and created count.
 */
export declare function selectSoundFacts(snapshot: ConversationSnapshot): SoundFacts;
//# sourceMappingURL=facts.d.ts.map