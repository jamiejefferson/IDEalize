/**
 * The Sound Stage list, as a pure function of one chat's generation rows and
 * turns: a scrolling column of sounds, each with its own player streaming the
 * bytes from the artefact raw route, interleaved by log position with the
 * turns the model is still thinking about, the generations still running, the
 * turns that ended with nothing made (the model's reply stands in for the
 * sound) and the ones that failed. A failure prints the adapter's provider
 * cause and offers Retry, which re-sends the prompt that produced it.
 *
 * Sounds are this chat's, not the project's (JJ, 4 Sep 2026: the galleries for
 * sound, image and video are all chat-specific). Each carries the same Keep /
 * Archive verdict the Images grid does, beside a Reveal that opens the Files
 * pane on the file, and archived sounds fold below the list rather than
 * leaving it.
 */
import type { GalleryArtefact, GalleryRow, GalleryTurn } from '@idealize/ui-gallery/client';
import type { Translate } from './locales.ts';
/** The raw-route URL for one artefact id (same origin as the serving host). */
export declare function rawUrl(id: string): string;
/** `123456` bytes as a short human figure. */
export declare function formatBytes(bytes: number): string;
/** An epoch instant as the row's short local date and time. */
export declare function formatWhen(at: number): string;
/** One sound on screen: the generation that made it, and the artefact itself. */
export interface Shown {
    readonly row: GalleryRow;
    readonly artefact: GalleryArtefact;
}
/** What the Sound Stage list renders and the gestures it reports. */
export interface SoundstageViewProps {
    /** This chat's `generate_audio` rows, newest first. */
    rows: readonly GalleryRow[];
    /** This chat's turns, newest first; the list shows those still thinking or ended without a generation. */
    turns?: readonly GalleryTurn[];
    t: Translate;
    /** Re-send one failed generation's prompt through the composer. */
    onRetry: (prompt: string) => void;
    /** Keep or archive one sound; the store moves the file and logs the verdict. */
    setDisposition: (artefactId: string, disposition: 'kept' | 'archived') => Promise<string | null>;
}
/**
 * Render the Sound Stage for one chat.
 * @param props - the chat's rows and turns, copy, and the two gestures.
 * @returns the stage: the list or the empty state, with archived sounds folded beneath.
 */
export declare function SoundstageView({ rows, turns, t, onRetry, setDisposition }: SoundstageViewProps): import("react").JSX.Element;
//# sourceMappingURL=SoundstageView.d.ts.map