/**
 * The Sound Stage view-ring entry: reads this chat's generation rows out of
 * the conversation snapshot and renders the audio ones.
 *
 * The rows come from the same per-chat source the Images and Video grids read
 * (`@idealize/ui-gallery`'s Definition publishes every generation the chat
 * ran, whatever it made), so a sound appears the moment its artefact event
 * lands and no listing has to be re-read. Before 4 Sep 2026 this view listed
 * the whole project's sounds over a host route, which showed a chat work it
 * had not done; JJ settled it as chat-specific along with the other two.
 */
import type { ConversationSnapshot } from '@deepseek-ai/dsh-client-runtime/client';
import type { Translate } from './locales.ts';
/** What the ring entry needs: the snapshot hook, the composer, the verdict, and copy. */
export interface SoundstageEntryProps {
    sessionId: string;
    useSession: <S>(selector: (snapshot: ConversationSnapshot) => S, eq?: (a: S, b: S) => boolean) => S;
    /** The composer's public action face; Retry writes and sends through it. */
    inputActions: {
        setDraft: (text: string) => void;
        submit: () => void;
    };
    /** Keep or archive one sound through the artefact store's route. */
    setDisposition: (artefactId: string, disposition: 'kept' | 'archived') => Promise<string | null>;
    t: Translate;
}
/**
 * Render one session's Sound Stage.
 * @param props - the snapshot hook, the composer actions, the verdict, and copy.
 * @returns the stage list.
 */
export declare function SoundstageEntry({ useSession, inputActions, setDisposition, t }: SoundstageEntryProps): import("react").JSX.Element;
//# sourceMappingURL=SoundstageEntry.d.ts.map