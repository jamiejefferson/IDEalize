/**
 * Sound Stage, browser half. Adds a `soundstage` entry to the conversation
 * view ring: this chat's generated sounds as a list with a player per row,
 * over the generations still running and the ones that failed.
 *
 * The rows are `@idealize/ui-gallery`'s per-chat generation rows filtered to
 * `audio`, so the three media spaces read one source and each shows its own
 * kind. The composer's length control is `@idealize/ui-gallery`'s generation
 * settings strip, which renders on the `soundstage` view id; this package
 * registers no composer seat of its own.
 */
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
import { type SoundstageKey } from './locales.ts';
export { SoundstageView, formatBytes, formatWhen, rawUrl } from './SoundstageView.tsx';
export type { SoundstageViewProps } from './SoundstageView.tsx';
export { SoundstageEntry } from './SoundstageEntry.tsx';
export type { SoundstageEntryProps } from './SoundstageEntry.tsx';
export type { Shown } from './SoundstageView.tsx';
export type { SoundstageKey } from './locales.ts';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** The Sound Stage's copy. */
        'idealize-soundstage': SoundstageKey;
    }
}
/** The view id of the ring entry; `@idealize/ui-gallery`'s settings strip renders its length control on this id. */
export declare const SOUNDSTAGE_VIEW = "soundstage";
/** Required services: the slot registry and copy. */
export declare const inject: string[];
/**
 * Client plugin body.
 * @param ctx - client root context.
 */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map