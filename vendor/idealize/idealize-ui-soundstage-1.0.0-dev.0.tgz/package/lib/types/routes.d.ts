/**
 * Route and media constants shared by the Sound Stage's two halves. Kept in
 * its own runtime-free module so the Client bundle can import the path
 * without pulling the Host plugin (and its Node imports) in with it.
 * @module @idealize/ui-soundstage/src/routes
 */
/** The loopback route the browser half lists the project's sounds from. */
export declare const SOUNDS_ROUTE = "/idealize/soundstage/sounds";
/** The artefact media-type family the Sound Stage lists (`audio/*`). */
export declare const SOUND_MEDIA_TYPE = "audio";
//# sourceMappingURL=routes.d.ts.map