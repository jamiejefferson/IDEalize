/**
 * Browser trajectory plugin: the target-specific Event Definitions, the
 * Trajectory view builder, and the ledger itself published as the
 * `trajectorySection` service.
 */
import type { Context } from '@deepseek-ai/cordis';
import type { SessionId } from '@deepseek-ai/dsh-client-runtime/client';
import type { PropsLocale } from '@deepseek-ai/dsh-client-ui-slots';
import { TrajectoryView, type TrajectoryViewInjected } from './TrajectoryView.tsx';
/**
 * The ledger as a service (IDEalize fork seam): Trajectory left the
 * conversation view ring for a tool-rail drawer pane, and the client bundle
 * purity gate forbids cross-plugin value imports, so the consuming surface
 * takes the component and its per-chat wired face through the Context. Same
 * pattern as `modelsSettingsSection` and `agentPresetSection`.
 */
export interface TrajectorySectionHost {
    /** The ledger component, rendered by the consuming surface. */
    Component: typeof TrajectoryView;
    /**
     * Wire the ledger for one chat.
     * @param sessionId - the chat whose ledger renders.
     * @returns the wired face, or undefined while that chat has no binding.
     */
    face: (sessionId: SessionId) => TrajectorySectionFace | undefined;
}
/**
 * The wired face: every prop the ledger needs except the inspect handoff,
 * which belongs to whichever surface routes a chat's Inspect click here.
 */
export type TrajectorySectionFace = TrajectoryViewInjected & PropsLocale<'trajectory'>;
declare module '@deepseek-ai/cordis' {
    interface Context {
        trajectorySection: TrajectorySectionHost;
    }
}
/** Required services: the registries, ordinary Session paging, and the locale service. */
export declare const inject: string[];
/**
 * Client plugin body: register the Definitions and publish the ledger.
 * @param ctx - client root context.
 */
export declare function apply(ctx: Context): void;
//# sourceMappingURL=index.d.ts.map