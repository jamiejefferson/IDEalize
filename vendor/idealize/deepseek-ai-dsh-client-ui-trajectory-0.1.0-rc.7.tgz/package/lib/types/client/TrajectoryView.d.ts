/** Trajectory view: compact summary over a turn-aware event ledger. */
import type { ConvViewOwnerProps } from '@deepseek-ai/dsh-client-ui-conversation/client';
import type { PropsLocale, SnapshotSelectorHook } from '@deepseek-ai/dsh-client-ui-slots';
import type { ConversationSnapshot } from '@deepseek-ai/dsh-client-runtime/client';
/**
 * Everything the ledger reads for one chat, wired by this plugin's
 * `trajectorySection` service. The ledger renders wherever the consuming
 * surface seats it (the IDEalize tool rail's drawer pane), so nothing here
 * comes from a slot's standard kit.
 */
export interface TrajectoryViewInjected {
    /** Selector hook over this chat's conversation snapshot. */
    useSession: SnapshotSelectorHook<ConversationSnapshot>;
    /** Selector hook over the browser-wide recorded-duration preference. */
    useDuration: SnapshotSelectorHook<boolean>;
    /**
     * Load one older history page.
     * @returns whether the Trajectory snapshot changed.
     */
    loadOlder: () => Promise<boolean>;
    /**
     * Record the browser-wide recorded-duration preference.
     * @param actualDuration - true for recorded durations, false for equal widths.
     */
    setActualDuration: (actualDuration: boolean) => void;
}
/** Full ledger props: the wired face plus the cross-surface inspect handoff. */
export type TrajectoryViewProps = TrajectoryViewInjected & ConvViewOwnerProps & PropsLocale<'trajectory'>;
export declare function TrajectoryView({ useSession, useDuration, loadOlder, setActualDuration, inspect, onInspectDone, t, }: TrajectoryViewProps): import("react").JSX.Element;
//# sourceMappingURL=TrajectoryView.d.ts.map