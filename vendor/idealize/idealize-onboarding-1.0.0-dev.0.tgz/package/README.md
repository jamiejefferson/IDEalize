# @idealize/onboarding

First-run onboarding: a five-step, full-screen wizard — **agents**, **projects folder**, **documentation folder**, **skills folder**, **finish** — that runs ahead of the showcase tour on first launch. Every step can be completed or skipped individually, the whole flow can be skipped from the persistent "Skip setup" control, and each completed step celebrates with a rainbow burst and a friendly toast line.

## What the plugin does

- **Settings section `idealize-onboarding`** (host half) — `{ done, steps, completedAt? }`: `done` closes the flow for good, `steps` records each step's `'done' | 'skipped'` outcome so a relaunch resumes on the first unresolved step, and `completedAt` timestamps a completed run. The schemastery schema validates step keys against the step-id union, so a hand-edited `settings.yaml` with an unknown step fails the registration.
- **The agents routes** (host half, loopback-fenced; the mutation demands the `x-idealize-auth` header) — `GET /idealize/onboarding/agents` reports Claude Code CLI detection (the subprocess seam's executable resolution, so a miss is a verdict, not an error) and OpenRouter credential presence; `POST /idealize/onboarding/openrouter` verifies a typed key against OpenRouter's models listing **before** anything persists (a rejected key stores nothing), then stores the credential and writes the `openrouter` provider route's only needed configuration — its `apiKeyEnv` binding — into the `llm-pi-ai` section.
- **The owl clips route** (host half, loopback-fenced) — `GET /idealize/onboarding/owl/<clip>.<hash>.webm` serves each clip as immutable `video/webm` with byte ranges, so the client bundle carries URLs alone; the hash in the file name comes from the clip's bytes, so a changed clip gets a new URL. Regenerate `src/owl-clips.ts` (bytes, host only) and `src/owl-clip-urls.ts` (URLs, both faces) with `pnpm tsx scripts/gen-owl-clips.ts "<OnboardingOwls/transparent dir>"`.
- **The wizard** (browser half) — one `shell.overlay` occupant (`idealize-onboarding`, order 95) renders an opaque full-screen panel per step: the per-step owl clip (transparent WebM, streamed from the owl clips route; parked on its first frame under reduced motion), a headline and one-line sub in en+zh, a six-dot progress indicator, Back / Continue navigation, a per-step "Skip this step" link, and the top-right "Skip setup". Each step body reports whether Continue may engage and registers its save-on-Continue action.
- **The agents step** — two provider cards: Claude Code (detected on entry and on "Check again", with the resolved path shown) and OpenRouter (key field, save refusals rendered in place). Continue stays disabled until at least one is connected; connections persist at connect time, so the step saves nothing on Continue.
- **The folder steps** — each captures one folder through the Host directory picker or a typed path, probes it live through `POST /idealize/setup/alias` (a successful probe also persists the alias; orientation re-confirms at finish), renders the probe's refusal verbatim, and gates Continue on a successful probe of the current path. An existing `idealize-setup` alias pre-fills the field, so a returning user confirms in one tap. The skills folder step (JJ, 15 Sep 2026) captures the `skills` alias the same way; its folder is stored at the probe and never re-confirmed by orientation, which stays on the two folders the first project needs.
- **The finish step** — the optional first-project name (locale default; omitted when emptied), then Continue runs `POST /idealize/setup/orientation` with a progress line, renders a 400's per-field refusals verbatim, selects the created project, and completes the flow (final burst, `done` + `completedAt`).
- **The Settings re-run row** — a `settings.general.item` row ("First-run setup") resets the section to `done: false` / `steps: {}` so the wizard re-arms on next launch.
- **The rainbow burst** — every step completion fires a full-screen, click-through celebration: expanding conic rainbow rings over a soft radial flash plus the per-step toast ("Agents connected!", …), pure CSS keyframes over ~800ms. Under `prefers-reduced-motion` the rings swap for a brief static tint; the toast stays. Skips never celebrate.
- **Tour sequencing** — the plugin takes `ctx.tour.holdFirstRun()` at start and releases it exactly once when the flow closes (finished, skipped, already done, or settings unavailable on a remote browser), so the showcase tour fires as onboarding's final step through the tour's own first-run trigger. (`@idealize/setup`'s client overlay, the previous hold-holder, is retired — this package is now the wizard's only surface.)

## Model Experience

None, as the wizard writes settings, credentials and the model choices of brains through host routes; the brains it configures own every model-facing effect of those choices.

#### KV Cache effect

Independent: nothing here enters a chat request. A model choice saved through `POST /idealize/activity/agent` or `POST /idealize/brains/media` changes which model later requests go to, not any request's prefix.

## Known Limitations and Deferred Work

- The alias route doubles as the folder steps' probe, so a successful probe persists the alias before the finish step's orientation re-confirms it; a user who abandons the wizard between a folder step and finish keeps the probed alias.
- Saving an LLM activity row round-trips the preset's current persona (`instructions` from `GET /idealize/activity/agents`): the save route replaces the persona with its generic template when `instructions` is absent.
- The re-run row resets the seed for the NEXT launch — the gate decides once per session, so a reset mid-session does not re-open the wizard in place.
- The owl clips' ~635KB of WebM rides the host bundle as base64 (`src/owl-clips.ts`); each clip decodes on its first request, and the client bundle must never import that module.
