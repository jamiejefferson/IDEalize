/**
 * The wizard's owl: the per-step transparent WebM clip from owl-clips.ts
 * (generated; inlined as data URIs). `data-owl-art` keys the element per step
 * for future retargeting. Under reduced motion the clip stays parked on its
 * first frame (no autoplay).
 */
import type { OnboardingStepId } from './steps.ts';
/** Props for {@link OwlArt}. */
export interface OwlArtProps {
    /** The step the clip plays for. */
    step: OnboardingStepId;
    /** True parks the clip on its first frame (reduced motion). */
    reduced: boolean;
}
/** The per-step owl clip (decorative; the step copy carries the meaning). */
export declare function OwlArt({ step, reduced }: OwlArtProps): import("react").JSX.Element;
//# sourceMappingURL=OwlArt.d.ts.map