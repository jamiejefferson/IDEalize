/**
 * The per-step owl clips (transparent WebM, 24fps, 720×544), inlined as data
 * URIs so the client bundle carries them without a loader change. GENERATED
 * by scripts/gen-owl-clips.ts from sources outside the repo — do not edit by
 * hand; regenerate with:
 *
 *   pnpm tsx scripts/gen-owl-clips.ts "<OnboardingOwls/transparent dir>"
 */
import type { OnboardingStepId } from './steps.ts';
/** The clip for each wizard step, keyed for OwlArt's per-step hook. */
export declare const OWL_CLIPS: Record<OnboardingStepId, string>;
//# sourceMappingURL=owl-clips.d.ts.map