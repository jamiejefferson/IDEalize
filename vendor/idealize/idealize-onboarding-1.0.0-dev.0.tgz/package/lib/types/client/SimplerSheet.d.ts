import type { InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { SnapshotStore } from '@deepseek-ai/dsh-client-runtime/client';
import type { OnboardingApi } from './api.ts';
import type { SimplerSheetState } from './simpler.ts';
/** Registration-side face. */
export interface SimplerSheetInjected {
    hooks: {
        /** Whether the sheet is on screen. */
        sheet: SnapshotStore<SimplerSheetState>;
    };
    /** The host route client. */
    api: OnboardingApi;
    /** Close the sheet for good and record it as seen. */
    close: () => void;
}
export type SimplerSheetProps = PropsRuntime<'shell.overlay'> & PropsLocale<'idealize-onboarding'> & InjectFace<SimplerSheetInjected>;
export declare function SimplerSheet(props: SimplerSheetProps): import("react").JSX.Element | null;
//# sourceMappingURL=SimplerSheet.d.ts.map