import type { OnboardingStepId } from './steps.ts';
/** The burst's on-screen lifetime; mirrors the keyframe durations in RainbowBurst.module.css. */
export declare const BURST_LIFETIME_MS = 800;
/** Props for {@link RainbowBurst}. */
export interface RainbowBurstProps {
    /** The completed step (per-step DOM hook). */
    step: OnboardingStepId;
    /** The celebration line shown with the burst. */
    label: string;
    /** True renders the static tint (no motion) instead of the rings. */
    reduced: boolean;
    /** Called once the burst's lifetime ends. */
    onDone: () => void;
}
export declare function RainbowBurst({ step, label, reduced, onDone }: RainbowBurstProps): import("react").JSX.Element;
//# sourceMappingURL=RainbowBurst.d.ts.map