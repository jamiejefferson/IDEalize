import type { ReactNode } from 'react';
import type { OnboardingKey } from './locales.ts';
import type { CodingRow, SetupCompany } from './setup-model.ts';
import type { Setup } from './use-setup.ts';
/** The namespace translator the parts take. */
type Translate = (key: OnboardingKey) => string;
/** Props for {@link CodingAppList}. */
export interface CodingAppListProps {
    /** The rows, one per company. */
    rows: readonly CodingRow[];
    /** The selected row's launch choice id. */
    selected: string | null;
    /** Select a row. */
    onSelect: (id: string) => void;
    /** The namespace translator. */
    t: Translate;
}
/**
 * The coding-subscription radio list: one row per company, Kimi behind a
 * "Show Kimi" link until asked for or selected. A row whose app is not
 * installed cannot be selected.
 */
export declare function CodingAppList({ rows, selected, onSelect, t }: CodingAppListProps): import("react").JSX.Element;
/** Props for {@link KeyBlock}. */
export interface KeyBlockProps {
    /** The block's title. */
    title: string;
    /** The sentence saying what the key unlocks. */
    reason: string;
    /** Whether the key is optional; an optional block carries the tag. */
    optional?: boolean;
    /** Whether a key is already connected; a connected block shows a tick in place of the field. */
    connected: boolean;
    /** The pasted key. */
    value: string;
    /** Change the pasted key. */
    onChange: (value: string) => void;
    /** The field's placeholder. */
    placeholder: string;
    /** The page where the service issues keys. */
    keysUrl: string;
    /** The save's refusal, shown under the field. */
    error: string | null;
    /** Which key this is; lands on the field as `data-setup-<name>`. */
    name: 'openrouter' | 'fal';
    /** The namespace translator. */
    t: Translate;
    /** A line under the field. */
    children?: ReactNode;
}
/** One key's block: what it unlocks, then the paste field or the connected tick. */
export declare function KeyBlock(props: KeyBlockProps): import("react").JSX.Element;
/** Props for the two key blocks bound to the shared set-up state. */
export interface SetupKeyProps {
    /** The shared set-up state. */
    setup: Setup;
    /** Whether a key is connected. */
    connected: boolean;
    /** The namespace translator. */
    t: Translate;
}
/**
 * The OpenRouter block. Once a coding app is selected it says which company's
 * models Chat will start on.
 */
export declare function OpenRouterBlock({ setup, connected, t, matching }: SetupKeyProps & {
    matching: SetupCompany | undefined;
}): import("react").JSX.Element;
/**
 * The fal block, tagged Optional. Its reason names how many models the key
 * adds only when the host states a count.
 */
export declare function FalBlock({ setup, connected, t, modelCount }: SetupKeyProps & {
    modelCount: number | null;
}): import("react").JSX.Element;
export {};
//# sourceMappingURL=SetupParts.d.ts.map