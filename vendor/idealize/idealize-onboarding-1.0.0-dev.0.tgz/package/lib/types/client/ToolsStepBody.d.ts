import type { StepBodyProps } from './AgentsStepBody.tsx';
/** Tools-step additions to the callbacks every step body receives. */
interface ToolsStepBodyProps extends StepBodyProps {
    /** Return to the Agents step, whose OpenRouter card stores the missing key. */
    onAddOpenRouterKey: () => void;
    /** Choices retained by the overlay while this body visits another step. */
    drafts: Record<string, string>;
    /** Retain changed choices outside this body's mount lifetime. */
    onDraftsChange: (drafts: Record<string, string>) => void;
}
export declare function ToolsStepBody({ api, t, registerCommit, onAddOpenRouterKey, drafts, onDraftsChange, }: ToolsStepBodyProps): import("react").JSX.Element;
export {};
//# sourceMappingURL=ToolsStepBody.d.ts.map