import type { StepBodyProps } from './AgentsStepBody.tsx';
/** Props for {@link FinishStepBody}. */
export interface FinishStepBodyProps extends StepBodyProps {
    /** The two folders the folder steps captured. */
    folders: {
        projects: string;
        documentation: string;
    };
    /** Select the created first project (host workspace id). */
    selectProject: (workspaceId: string) => void;
}
export declare function FinishStepBody({ api, t, registerCommit, folders, selectProject }: FinishStepBodyProps): import("react").JSX.Element;
//# sourceMappingURL=FinishStepBody.d.ts.map