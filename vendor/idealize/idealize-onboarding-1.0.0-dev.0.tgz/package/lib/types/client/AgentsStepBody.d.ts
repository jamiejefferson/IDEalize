import type { OnboardingKey } from './locales.ts';
import type { OnboardingApi } from './api.ts';
/** What every step body receives from the overlay. */
export interface StepBodyProps {
    /** The route client. */
    api: OnboardingApi;
    /** The namespace translator. */
    t: (key: OnboardingKey) => string;
    /**
     * Report whether the step's Continue may engage; called on mount and on
     * every change. Steps without a gate never call it (the overlay's default
     * is ready).
     */
    onReadyChange: (ready: boolean) => void;
    /**
     * Register the step's commit action — called by Continue and answering
     * whether the step may complete. Steps with nothing to save on Continue
     * register nothing.
     */
    registerCommit: (commit: (() => Promise<boolean>) | null) => void;
}
export declare function AgentsStepBody({ api, t, onReadyChange, registerCommit }: StepBodyProps): import("react").JSX.Element;
//# sourceMappingURL=AgentsStepBody.d.ts.map