import type { InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
/** Registration-side face. */
export interface OnboardingRowInjected {
    /** Reset the onboarding section (`done: false`, `steps: {}`); the wizard re-arms on next launch. */
    rerun: () => void;
}
export type OnboardingRowProps = PropsRuntime<'settings.general.item'> & PropsLocale<'idealize-onboarding'> & InjectFace<OnboardingRowInjected>;
export declare function OnboardingRow({ rerun, t }: OnboardingRowProps): import("react").JSX.Element;
//# sourceMappingURL=OnboardingRow.d.ts.map