/**
 * IDEalize first-run onboarding, browser half. One occupant on the frame's
 * shell.overlay seat renders the five-step wizard, gated by the
 * `idealize-onboarding` settings seed exactly as the tour is gated by
 * `hasSeenTour`. The flow runs BEFORE the showcase tour: a
 * `ctx.tour.holdFirstRun()` hold is taken at plugin start and released exactly
 * once — when the seed says the flow is closed, when settings are unavailable
 * (a remote browser), or when the user finishes or skips the wizard.
 */
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
import { type OnboardingKey } from './locales.ts';
export { deriveStep, advance, skipAll, stepBefore, ONBOARDING_STEP_IDS } from './steps.ts';
export type { OnboardingSeedLike, OnboardingStepId, OnboardingStepOutcome } from './steps.ts';
export { createOnboardingApi } from './api.ts';
export type { AgentsState, OnboardingApi, OrientOutcome, SaveOutcome, ToolsState } from './api.ts';
export { OnboardingOverlay } from './OnboardingOverlay.tsx';
export type { OnboardingInjected, OnboardingOverlayProps, OnboardingCelebration, OnboardingViewState } from './OnboardingOverlay.tsx';
export { OnboardingRow } from './OnboardingRow.tsx';
export type { OnboardingRowInjected } from './OnboardingRow.tsx';
export type { OnboardingKey } from './locales.ts';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** The onboarding wizard's copy. */
        'idealize-onboarding': OnboardingKey;
    }
}
/** Required services. */
export declare const inject: string[];
/**
 * Client plugin body: the gate over the settings seed, the overlay occupant,
 * and the tour hold that sequences onboarding before the showcase.
 * @param ctx - client root context.
 */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map