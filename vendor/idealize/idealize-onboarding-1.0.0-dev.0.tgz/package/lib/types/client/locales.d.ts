/** `idealize-onboarding` namespace dictionaries: the first-run wizard and its celebrations. */
/** Simplified Chinese dictionary (the key-set source of truth). */
export declare const zh: {
    'onboarding.title': string;
    'step.agents.title': string;
    'step.agents.sub': string;
    'step.projects-folder.title': string;
    'step.projects-folder.sub': string;
    'step.documentation-folder.title': string;
    'step.documentation-folder.sub': string;
    'step.skills-folder.title': string;
    'step.skills-folder.sub': string;
    'step.finish.title': string;
    'step.finish.sub': string;
    'nav.continue': string;
    'nav.back': string;
    'nav.finish': string;
    'nav.busy': string;
    'skip.step': string;
    'skip.all': string;
    'agents.loading': string;
    'agents.loadError': string;
    'agents.hint': string;
    'agents.claude.title': string;
    'agents.claude.sub': string;
    'agents.claude.missing': string;
    'agents.claude.recheck': string;
    'agents.openrouter.title': string;
    'agents.openrouter.sub': string;
    'agents.openrouter.reads': string;
    'agents.openrouter.connected': string;
    'agents.openrouter.placeholder': string;
    'agents.openrouter.connect': string;
    'agents.openrouter.replace': string;
    'agents.openrouter.unreachable': string;
    'folder.choose': string;
    'folder.manual': string;
    'folder.manualPlaceholder': string;
    'folder.notChosen': string;
    'folder.probing': string;
    'folder.probeError': string;
    'finish.project.label': string;
    'finish.project.hint': string;
    'finish.project.default': string;
    'finish.progress': string;
    'finish.folderMissing': string;
    'finish.generalError': string;
    'settings.rerun.title': string;
    'settings.rerun.description': string;
    'settings.rerun.action': string;
    'settings.rerun.armed': string;
    'celebrate.agents': string;
    'celebrate.projects-folder': string;
    'celebrate.documentation-folder': string;
    'celebrate.skills-folder': string;
    'celebrate.finish': string;
};
/** English dictionary. */
export declare const en: Record<OnboardingKey, string>;
/** The namespace's key set. */
export type OnboardingKey = keyof typeof zh;
//# sourceMappingURL=locales.d.ts.map