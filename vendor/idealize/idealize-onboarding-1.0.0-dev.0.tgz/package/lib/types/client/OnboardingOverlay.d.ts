import type { InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { SnapshotStore } from '@deepseek-ai/dsh-client-runtime/client';
import type { OnboardingStepId } from './steps.ts';
import type { OnboardingApi } from './api.ts';
import type { OnboardingViewState } from './flow.ts';
export type { OnboardingCelebration, OnboardingViewState } from './flow.ts';
/** Registration-side face. */
export interface OnboardingInjected {
    hooks: {
        /** The wizard state. */
        view: SnapshotStore<OnboardingViewState>;
    };
    /** The wizard's host route client. */
    api: OnboardingApi;
    /** Open the Host directory picker; null when cancelled or unavailable. */
    pickDirectory: () => Promise<string | null>;
    /** The pre-fill source for the folder steps: the `idealize-setup` aliases, when they stand. */
    readSetupAliases: () => {
        projectsRoot?: string;
        documentation?: string;
    };
    /** Select the created first project (host workspace id) after orientation. */
    selectProject: (workspaceId: string) => void;
    /** Mark one step done, fire its burst, and advance. */
    completeStep: (step: OnboardingStepId) => void;
    /** Record one step as skipped and advance without a burst. */
    skipStep: (step: OnboardingStepId) => void;
    /** Skip the whole flow: persist `done` and close. */
    quitAll: () => void;
    /** Return to the previous step without touching recorded outcomes. */
    back: () => void;
    /** Retain unsaved Tools choices while its key recovery visits Agents. */
    setToolDrafts: (drafts: Record<string, string>) => void;
    /** The finish step's completion: persist `done` + `completedAt`, final burst. */
    finish: () => void;
    /** The burst's lifetime ended; a final burst closes the flow. */
    celebrationDone: () => void;
    /** Whether the user asked for reduced motion (drives the static burst). */
    prefersReducedMotion: () => boolean;
}
export type OnboardingOverlayProps = PropsRuntime<'shell.overlay'> & PropsLocale<'idealize-onboarding'> & InjectFace<OnboardingInjected>;
export declare function OnboardingOverlay(props: OnboardingOverlayProps): import("react").JSX.Element | null;
//# sourceMappingURL=OnboardingOverlay.d.ts.map