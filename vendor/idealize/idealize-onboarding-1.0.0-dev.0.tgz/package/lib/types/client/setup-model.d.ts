/**
 * The set-up step's pure rules: which coding-subscription rows the Terminal's
 * launch choices produce, which row starts selected, and which app the
 * Terminal's current launch command belongs to. No React and no fetch, so the
 * step, the welcome sheet and their specs share one reading of the catalogue.
 * @module @idealize/onboarding/client/setup-model
 */
import type { LaunchChoice } from './api.ts';
import type { OnboardingKey } from './locales.ts';
/** The companies whose subscriptions the set-up step offers, in display order. */
export declare const SETUP_COMPANIES: readonly ["claude", "chatgpt", "gemini", "kimi"];
/** One company the set-up step offers. */
export type SetupCompany = (typeof SETUP_COMPANIES)[number];
/** One row of the coding-subscription list. */
export interface CodingRow {
    /** The company the subscription is with. */
    company: SetupCompany;
    /** The launch choice id this row selects, which the align route takes as `cli`. */
    id: string;
    /** Whether the app is installed; null where the check cannot run. */
    installed: boolean | null;
}
/** Each company's name on its row. */
export declare const COMPANY_LABEL: Record<SetupCompany, OnboardingKey>;
/** The app name on each company's row. */
export declare const COMPANY_APP: Record<SetupCompany, OnboardingKey>;
/** The name of the models Chat starts on for each company's subscription. */
export declare const COMPANY_MODELS: Record<SetupCompany, OnboardingKey>;
/**
 * Build the coding-subscription rows from the Terminal's launch choices. A
 * company none of whose apps the catalogue lists gets no row.
 * @param catalog - the launch choices with their installed flags.
 * @returns the rows, in {@link SETUP_COMPANIES} order.
 */
export declare function codingRows(catalog: readonly LaunchChoice[]): CodingRow[];
/**
 * The row that starts selected: the first whose app is installed.
 * @param rows - the coding-subscription rows.
 * @returns the row's launch choice id, or null when nothing is installed.
 */
export declare function firstInstalled(rows: readonly CodingRow[]): string | null;
/**
 * The launch choice the Terminal's current default command belongs to: the
 * choice with the same command, else the first whose program name matches.
 * @param command - the Terminal's default launch command.
 * @param catalog - the launch choices.
 * @returns the choice, or undefined for a command no choice accounts for.
 */
export declare function launchChoiceOf(command: string, catalog: readonly LaunchChoice[]): LaunchChoice | undefined;
//# sourceMappingURL=setup-model.d.ts.map