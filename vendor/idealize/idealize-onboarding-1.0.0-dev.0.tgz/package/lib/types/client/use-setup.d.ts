/**
 * The set-up state the wizard's step and the welcome sheet share: what the
 * host reports (installed coding apps, connected keys, the Terminal's launch
 * command), what the person has chosen and pasted, and the saves behind the
 * primary button. Keys are saved when the primary button is pressed, never as
 * they are typed.
 * @module @idealize/onboarding/client/use-setup
 */
import type { LaunchChoice, OnboardingApi } from './api.ts';
import type { OnboardingKey } from './locales.ts';
import type { CodingRow } from './setup-model.ts';
/** What the host reported at the last read. */
export interface SetupFacts {
    /** The coding-subscription rows. */
    rows: CodingRow[];
    /** The Terminal's launch choices. */
    catalog: LaunchChoice[];
    /** The Terminal's default launch command. */
    launchCommand: string;
    /** Whether an OpenRouter key is connected. */
    openrouter: boolean;
    /** Whether a fal key is connected. */
    fal: boolean;
    /** How many models a fal key adds; null when the host states no count. */
    falModelCount: number | null;
    /** Whether a key gateway is connected. */
    gateway: boolean;
}
/** The shared set-up state and its actions. */
export interface Setup {
    /** The host's report; null until the first read lands. */
    facts: SetupFacts | null;
    /** True when the first read failed. */
    loadFailed: boolean;
    /** The selected coding app's launch choice id. */
    selected: string | null;
    /** Select a coding app. */
    select: (id: string) => void;
    /** The pasted OpenRouter key. */
    openrouterDraft: string;
    /** Change the pasted OpenRouter key. */
    setOpenrouterDraft: (value: string) => void;
    /** The OpenRouter save's refusal, shown under its field. */
    openrouterError: string | null;
    /** The pasted fal key. */
    falDraft: string;
    /** Change the pasted fal key. */
    setFalDraft: (value: string) => void;
    /** The fal save's refusal, shown under its field. */
    falError: string | null;
    /** The align call's refusal, shown under the coding list. */
    alignError: string | null;
    /** Read the host again. */
    refresh: () => void;
    /**
     * Save each pasted key through its route. A saved key's field empties and
     * its part reads as connected; a refused key's reason shows under its field.
     * @returns false when a key was refused.
     */
    saveKeys: () => Promise<boolean>;
    /**
     * Make the selected coding app the Terminal's default and start Chat on the
     * same company's models. Does nothing when no app is selected.
     * @returns false when the host refused.
     */
    alignSelected: () => Promise<boolean>;
}
/**
 * Hold the set-up state for one mounted surface.
 * @param api - the route client.
 * @param t - the namespace translator.
 * @returns the state and its actions.
 */
export declare function useSetup(api: OnboardingApi, t: (key: OnboardingKey) => string): Setup;
//# sourceMappingURL=use-setup.d.ts.map