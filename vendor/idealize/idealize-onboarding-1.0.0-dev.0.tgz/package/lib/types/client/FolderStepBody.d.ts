import type { StepBodyProps } from './AgentsStepBody.tsx';
/** Props for {@link FolderStepBody}. */
export interface FolderStepBodyProps extends StepBodyProps {
    /** Which alias this step captures. */
    alias: 'projectsRoot' | 'documentation' | 'skills';
    /** The current path (the overlay holds every folder so the finish step can read them). */
    value: string;
    /** Update the path. */
    onChange: (path: string) => void;
    /** The pre-fill source: the `idealize-setup` aliases, when they stand. */
    readSetupAliases: () => {
        projectsRoot?: string;
        documentation?: string;
        skills?: string;
    };
    /** Open the Host directory picker; null when cancelled or unavailable. */
    pickDirectory: () => Promise<string | null>;
}
export declare function FolderStepBody(props: FolderStepBodyProps): import("react").JSX.Element;
//# sourceMappingURL=FolderStepBody.d.ts.map