/**
 * The onboarding routes: the agents step's detection and the OpenRouter key
 * save. Both are loopback-fenced; the mutation demands the `x-idealize-auth`
 * header, matching every other `/idealize/*` mutation.
 *
 * - `GET  /idealize/onboarding/agents` — `{ claudeCode: { installed, path? },
 *   openrouter: { connected } }`. Claude Code detection reuses the subprocess
 *   seam's executable resolution (the same call subagent-claude-code starts
 *   runs with); a miss throws there, so detection is resolve-and-catch.
 * - `POST /idealize/onboarding/openrouter` `{ apiKey }` — verify the key
 *   against OpenRouter's models listing BEFORE anything persists, then store
 *   the credential and bind the `openrouter` provider route to it. The route
 *   is a pi-ai catalog provider: the profile needs only `apiKeyEnv`, the
 *   smallest write that makes the stored credential the one requests use
 *   (without it the route falls back to pi-ai's ambient env discovery).
 * - `GET  /idealize/onboarding/owl/<clip>.<hash>.webm` — one owl clip's bytes
 *   (`video/webm`, byte ranges honoured). The file name carries a hash of the
 *   bytes (see ./owl-clip-urls.ts), so the answer caches as immutable and a
 *   changed clip gets a new URL; any other name under the prefix answers 404.
 *
 * @module @idealize/onboarding/routes
 */
import type { Context } from '@deepseek-ai/cordis';
/** The credential reference the OpenRouter save stores and the detection reads. */
export declare const OPENROUTER_KEY_ENV = "OPENROUTER_API_KEY";
/**
 * Mount the onboarding routes while the web server, settings, credentials, and
 * subprocess services are composed.
 * @param ctx - the plugin context.
 * @param openrouterBaseURL - the OpenRouter API base URL (Config-owned).
 */
export declare function installOnboardingRoutes(ctx: Context, openrouterBaseURL: string): void;
//# sourceMappingURL=routes.d.ts.map