/**
 * The onboarding routes: the set-up step's detection, the OpenRouter key
 * save, and the alignment of the Terminal and the default chat model with the
 * chosen coding app. All are loopback-fenced; the mutations demand the
 * `x-idealize-auth` header, matching every other `/idealize/*` mutation.
 *
 * - `GET  /idealize/onboarding/agents` — `{ claudeCode: { installed, path? },
 *   openrouter: { connected }, fal: { connected }, launchCommand? }`. Claude
 *   Code detection reuses the subprocess seam's executable resolution (the
 *   same call subagent-claude-code starts runs with); a miss throws there, so
 *   detection is resolve-and-catch. `launchCommand` is the Terminal's default
 *   launch command, absent while the Terminal's settings section is not
 *   registered.
 * - `POST /idealize/onboarding/align` `{ cli? }` — `cli` is the id of one of
 *   the Terminal's launch choices. The route stores that choice's command as
 *   the Terminal's default launch command and, when an OpenRouter key is
 *   connected, points the default chat model at a model of the same company
 *   on the `openrouter` route (see {@link chooseCompanyModel}). It answers
 *   `{ launchCommand?, defaultModel?, note? }`; `note` says why a write did
 *   not happen. A `cli` naming no launch choice answers 400 and writes
 *   nothing.
 * - `POST /idealize/onboarding/openrouter` `{ apiKey }` — verify the key
 *   against OpenRouter's models listing BEFORE anything persists, then store
 *   the credential and bind the `openrouter` provider route to it. The route
 *   is a pi-ai catalog provider: the profile needs only `apiKeyEnv`, the
 *   smallest write that makes the stored credential the one requests use
 *   (without it the route falls back to pi-ai's ambient env discovery).
 * - `GET  /idealize/onboarding/owl/<clip>.<hash>.webm` — one owl clip's bytes
 *   (`video/webm`, byte ranges honoured). The file name carries a hash of the
 *   bytes (see ./owl-clip-urls.ts), so the answer caches as immutable and a
 *   changed clip gets a new URL; any other name under the prefix answers 404.
 *
 * @module @idealize/onboarding/routes
 */
import type { Context } from '@deepseek-ai/cordis';
/** The credential reference the OpenRouter save stores and the detection reads. */
export declare const OPENROUTER_KEY_ENV = "OPENROUTER_API_KEY";
/**
 * Mount the onboarding routes while the web server, settings, credentials, and
 * subprocess services are composed.
 * @param ctx - the plugin context.
 * @param openrouterBaseURL - the OpenRouter API base URL (Config-owned).
 */
export declare function installOnboardingRoutes(ctx: Context, openrouterBaseURL: string): void;
//# sourceMappingURL=routes.d.ts.map