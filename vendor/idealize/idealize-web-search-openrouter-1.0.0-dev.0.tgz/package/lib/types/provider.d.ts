/**
 * `OpenRouterSearchProvider`: a `WebSearchProvider` over OpenRouter's chat
 * completions endpoint with the `web` plugin attached. One request asks a model
 * to answer the query from a live web search; the assistant text becomes
 * `content` and every `url_citation` annotation becomes a source. The key is
 * resolved per search from the credential store, so a key stored through the
 * app's Services panel is used without a restart.
 * @module @idealize/web-search-openrouter/provider
 */
import type { WebSearchProvider, WebSearchRequest, WebSearchResult, WebSearchSource } from '@deepseek-ai/dsh-web';
import type { CredentialRef } from '@deepseek-ai/dsh-credentials';
import type { OpenRouterAnnotation, OpenRouterSearchResponse } from './types.ts';
/** Stable id this provider registers under; the same id as the chat route, so one key serves both. */
export declare const OPENROUTER_PROVIDER_ID = "openrouter";
/** Default endpoint base; `/chat/completions` is the operation. */
export declare const OPENROUTER_DEFAULT_BASE_URL = "https://openrouter.ai/api/v1";
/** Default model that reads the search results and answers. */
export declare const OPENROUTER_DEFAULT_MODEL = "deepseek/deepseek-v4-flash";
/** Default page count the web plugin may read when a request names no bound. */
export declare const OPENROUTER_DEFAULT_MAX_RESULTS = 5;
/** Resolved provider options (the plugin's `apply` supplies credential and constant defaults). */
export interface OpenRouterSearchProviderOptions {
    /** Literal OpenRouter key; when present it wins over {@link resolveApiKey}. */
    apiKey?: string;
    /** Resolves the key for one search; undefined means no key is stored. */
    resolveApiKey?: () => Promise<string | undefined>;
    /** Credential reference named by missing-credential diagnostics. */
    apiKeyEnv: CredentialRef;
    /** Endpoint base; `/chat/completions` is appended. */
    baseURL: string;
    /** Model that reads the search results and answers. */
    model: string;
    /** Page count the web plugin may read when the request names no bound. */
    maxResults: number;
}
/**
 * The instruction sent with the query. The model answers from what the web
 * plugin read; the answer text is returned as the result's `content`.
 * @param query - the model-facing search query.
 * @returns the user message content.
 */
export declare function searchPrompt(query: string): string;
/**
 * Map one annotation to a source, or undefined when it is not a page citation
 * or names no URL.
 * @param annotation - one entry of the assistant message's `annotations[]`.
 * @returns the normalised source, or undefined.
 */
export declare function mapAnnotation(annotation: OpenRouterAnnotation): WebSearchSource | undefined;
/**
 * Map a chat completions response to a search result: the first choice's text
 * as `content` when it has any, and its citations as sources, deduplicated by
 * URL in first-seen order.
 * @param response - the parsed response body.
 * @returns the normalised result; the seam owns `maxResults` truncation, so `truncated` is false.
 */
export declare function mapOpenRouterResponse(response: OpenRouterSearchResponse): WebSearchResult;
/** The OpenRouter-backed search provider; HTTP redirects fail as `WEB_PROVIDER_ERROR`. */
export declare class OpenRouterSearchProvider implements WebSearchProvider {
    private readonly resolveOptions;
    readonly id = "openrouter";
    /**
     * @param resolveOptions - the options for the next search, read once per search so a
     *   settings change lands on the following request rather than mid-flight.
     */
    constructor(resolveOptions: () => OpenRouterSearchProviderOptions);
    available(): boolean;
    search(request: WebSearchRequest, signal?: AbortSignal): Promise<WebSearchResult>;
}
//# sourceMappingURL=provider.d.ts.map