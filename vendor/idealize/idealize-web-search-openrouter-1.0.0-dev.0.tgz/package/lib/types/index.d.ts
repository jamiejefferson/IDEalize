/**
 * `@idealize/web-search-openrouter`: registers an OpenRouter-backed
 * `WebSearchProvider` with `ctx.web`, so the one OpenRouter key an IDEalize
 * user connects also serves web search (JJ, 16 Sep 2026: "remove the reliance
 * on a deep seek subscription"). A function plugin: it registers into the seam
 * owned by `@deepseek-ai/dsh-web`, exactly as the Exa and Perplexity providers do.
 *
 * @module @idealize/web-search-openrouter
 */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import type { OpenRouterSearchProviderOptions } from './provider.ts';
export { OPENROUTER_DEFAULT_BASE_URL, OPENROUTER_DEFAULT_MAX_RESULTS, OPENROUTER_DEFAULT_MODEL, OPENROUTER_PROVIDER_ID, OpenRouterSearchProvider, mapAnnotation, mapOpenRouterResponse, searchPrompt, } from './provider.ts';
export type { OpenRouterSearchProviderOptions } from './provider.ts';
/** Cordis plugin name used by loader diagnostics. */
export declare const name = "web-search-openrouter";
/** The web seam this provider registers into. */
export declare const inject: string[];
/** Plugin config (all optional; `apply` fills credential and constant defaults). */
export interface Config {
    /** Literal OpenRouter key; prefer {@link apiKeyEnv} so no secret enters configuration files. */
    apiKey?: string;
    /** Credential reference resolved for each search; defaults to `OPENROUTER_API_KEY`, the chat route's key. */
    apiKeyEnv?: string;
    /** Endpoint base; `/chat/completions` is appended. Defaults to the public API. */
    baseURL?: string;
    /** Model that reads the search results and answers. Defaults to `deepseek/deepseek-v4-flash`. */
    model?: string;
    /** Page count the web plugin may read when a request names no bound. Defaults to 5. */
    maxResults?: number;
}
export declare const Config: z<Config>;
/**
 * Project the config into the options one search runs with. The key resolves
 * through the credential seam when it is mounted, else the launch environment;
 * every other field falls back to the package constant when the config, read
 * outside the schema, names none.
 * @param ctx - plugin context supplying the credential and environment planes.
 * @param config - the plugin config.
 * @returns options for one search.
 */
export declare function resolveOptions(ctx: Context, config: Config): OpenRouterSearchProviderOptions;
/**
 * Register the OpenRouter search provider with `ctx.web`.
 * @param ctx - plugin context carrying the web seam.
 * @param config - the plugin config.
 */
export declare function apply(ctx: Context, config: Config): void;
//# sourceMappingURL=index.d.ts.map