/**
 * The routing decision: score every candidate for one reading of the task
 * under the user's priorities, then let a better one through three gates.
 * Pure. Jev (or the local rules) supplies the reading; the arithmetic lives
 * here because a decision model compares numbers unreliably, and because a
 * rationale the user can check has to come from figures the app holds.
 */
import type { ScoreRow } from './score-table.ts';
import type { TaskReading } from './tasks.ts';
export interface Weights {
    cost: number;
    speed: number;
    intelligence: number;
}
export type Aggressiveness = 'conservative' | 'balanced' | 'aggressive';
export interface Gates {
    /** The least confidence in the reading that lets a switch through. */
    confidence: number;
    /** The least gain in weighted score, 0 to 1. */
    improvement: number;
    /** The least time between two switches in one chat. */
    seconds: number;
}
/** The presets of the settings' one control (spec §4.1, §4.2). */
export declare const PRESETS: Record<Aggressiveness, Gates>;
/** No preset switches sooner than this after the last switch (spec §4.1). */
export declare const HARD_THROTTLE_SECONDS = 30;
/** A switch inside this window costs the next one confidence, so marginal readings cannot flip a chat back and forth (spec §10.2). */
export declare const STABILITY_WINDOW_SECONDS = 120;
export declare const STABILITY_PENALTY = 0.1;
/** USD per million tokens, or `free`; undefined when no price is known. */
export type Price = 'free' | {
    input: number;
    output: number;
} | undefined;
/** One model the chat could use, with what the app knows about it. */
export interface Candidate {
    provider: string;
    model: string;
    /** The name a badge shows. */
    label: string;
    price: Price;
    contextWindow?: number | undefined;
    /** Whether it takes image input; undefined when the catalogue does not say. */
    images?: boolean | undefined;
}
export interface Scored extends Candidate {
    family: string;
    /** False for a model no row of the table matches. */
    known: boolean;
    /** Capability fit for the task, 0 to 1. */
    fit: number;
    speed: number;
    /** 1 for free, falling with price on a log scale. */
    thrift: number;
    /** The weighted total the gates compare. */
    total: number;
}
/**
 * The table row for a model. The free-tokens route is one candidate whatever
 * model id it carries, because the engine chooses the provider per call.
 * @param candidate - the model to look up.
 * @param table - the user's rows first, then the shipped ones.
 * @returns the row, and whether the table knew the model.
 */
export declare function rowFor(candidate: {
    provider: string;
    model: string;
}, table?: readonly ScoreRow[]): {
    row: Omit<ScoreRow, 'pattern'>;
    known: boolean;
};
/** Price to a 0 to 1 thrift score: free is 1, $1 a million sits near 0.85, $100 a million is 0. */
export declare function thriftOf(price: Price): number;
/**
 * Score one candidate for a reading.
 * @param candidate - the model.
 * @param reading - the task and its difficulty.
 * @param weights - the user's or the brain's priorities, any non-negative scale.
 * @param table - the capability table.
 * @returns the candidate with its scores.
 */
export declare function score(candidate: Candidate, reading: Pick<TaskReading, 'task' | 'difficulty'>, weights: Weights, table?: readonly ScoreRow[]): Scored;
/** What the chat brings to the decision besides the message. */
export interface Situation {
    current: Candidate;
    candidates: Candidate[];
    reading: TaskReading;
    weights: Weights;
    gates: Gates;
    /** Seconds since this chat last switched; undefined when it never has. */
    sinceLastSwitch?: number | undefined;
    /** Only free models may be switched to. */
    preferFree: boolean;
    /** Tokens the chat holds; a candidate with a smaller window would lose some. */
    contextTokens?: number | undefined;
    /** The chat holds images, so a candidate must take them. */
    hasImages: boolean;
    table?: readonly ScoreRow[];
}
export type StayReason = 'no-recommendation' | 'throttle-failed' | 'confidence-gate-failed' | 'improvement-gate-failed' | 'needs-payment' | 'loses-context'
/** Jev was asked and did not answer in time or at all; the turn keeps its model. */
 | 'jev-unavailable';
export interface Decision {
    /** The model the turn runs on. */
    use: Candidate;
    switched: boolean;
    /** Why the chat stayed; absent on a switch. */
    stayed?: StayReason;
    /** The better model a gate or a warning held back, for the badge's offer. */
    recommended?: Scored | undefined;
    currentModelConfidence: number;
    switchConfidence: number;
    improvement: number;
    gates: {
        throttle: boolean;
        confidence: boolean;
        improvement: boolean;
    };
    rationale: string;
    scored: Scored[];
}
/**
 * The sentence a badge shows. Written from the figures, never from a model.
 * @param to - the recommended model.
 * @param from - the chat's current model.
 * @param reading - the task reading.
 * @returns one sentence.
 */
export declare function rationaleFor(to: Scored, from: Scored, reading: TaskReading): string;
/**
 * Decide one turn.
 * @param situation - the chat's model, its alternatives, the reading and the settings.
 * @returns the model to use and the full account of why.
 */
export declare function decide(situation: Situation): Decision;
//# sourceMappingURL=decide.d.ts.map