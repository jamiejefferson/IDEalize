/**
 * The models a chat could be moved to: every model of a connected route,
 * with what the app holds about each (price, image input, a display name).
 * Context size is read later and only for the models a decision turns on,
 * because resolving it costs one adapter call per model.
 */
import type { Candidate } from './decide.ts';
export declare const FREE_PROVIDER = "freetokens";
/** How a route is paid for, as the Brains pane already tells them apart. */
export type RouteAuth = 'free' | 'oauth' | 'apiKey';
export interface ConnectedRoute {
    provider: string;
    auth: RouteAuth;
    models: ReadonlyArray<{
        id: string;
        name?: string | undefined;
        inputModalities?: readonly string[] | undefined;
    }>;
}
/** Per provider then model, USD per million tokens. */
export type PriceTable = Readonly<Record<string, Readonly<Record<string, {
    input: number;
    output: number;
}>>>>;
/**
 * The candidate list.
 * @param routes - the connected routes and their models.
 * @param prices - the effective price table.
 * @returns one candidate per model; the free-tokens route is a single candidate, because its engine chooses the provider per call.
 */
export declare function candidatesFrom(routes: readonly ConnectedRoute[], prices: PriceTable): Candidate[];
//# sourceMappingURL=candidates.d.ts.map