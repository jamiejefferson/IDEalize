/**
 * The two models a dislike offers. They are the best-suited models the person
 * has not rated for this kind of work, so every test fills a gap in what the
 * router knows (JJ, 28 Oct 2026); starred models step in only when too few
 * unrated ones fit. A model barred with one star, the model that gave the
 * disliked answer, and the free-token engine (which picks its own provider
 * per call, so there is no one model to rate) are never offered.
 */
import type { Candidate, Scored, Weights } from './decide.ts';
import type { Standing } from './ratings.ts';
import type { ScoreRow } from './score-table.ts';
import type { TaskReading } from './tasks.ts';
export interface AlternativesInput {
    /** The model that gave the answer the person disliked. */
    current: {
        provider: string;
        model: string;
    };
    candidates: readonly Candidate[];
    reading: Pick<TaskReading, 'task' | 'difficulty'>;
    weights: Weights;
    /** The chat holds images, so an alternative must take them. */
    hasImages: boolean;
    table?: readonly ScoreRow[] | undefined;
    standingOf?: ((candidate: Candidate) => Standing) | undefined;
}
/**
 * Pick the alternatives.
 * @param input - the disliked model, the candidates and the reading.
 * @param count - how many to offer.
 * @returns up to `count` models, unrated first, one per family where the list allows.
 */
export declare function alternativesFor(input: AlternativesInput, count?: number): Scored[];
//# sourceMappingURL=alternatives.d.ts.map