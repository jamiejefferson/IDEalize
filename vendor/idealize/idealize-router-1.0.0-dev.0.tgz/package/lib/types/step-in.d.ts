/**
 * The router stepping in. A chat's model can stop being able to answer in the
 * middle of a turn: its sign-in lapsed, its key went, its credit ran out, or the
 * provider stayed busy through the host's retries. Left alone the turn fails on
 * screen, so the router hands it to the best other connected model, a free one
 * first and a paid one when nothing free can answer (JJ, 4 Nov 2026: a working
 * key must answer). A model that would cut the chat's context is only offered,
 * and so is one at another company: a chat can hold client work under NDA, so its
 * history moves to a new company only when the person says so (JJ, 4 Nov 2026).
 * Pure, like the routing decision: the host supplies the candidates and the
 * model facts.
 */
import type { Candidate, Scored, Weights } from './decide.ts';
import type { Standing } from './ratings.ts';
import type { ScoreRow } from './score-table.ts';
import type { TaskReading } from './tasks.ts';
/** The name the free-tokens route goes by. */
export declare const FREE_LABEL = "Free tokens";
/** No turn tries more than this many stand-ins, so a broken network is not walked through the whole catalogue. */
export declare const MAX_STAND_INS = 3;
/**
 * Whether a failure is one the router steps in for. A dropped connection and a
 * timeout are left out: they usually mean the person's own network, which no
 * other model would cure.
 * @param code - the failure's code.
 * @returns true when another model could answer where this one cannot.
 */
export declare const canStepIn: (code: string) => boolean;
export interface StepInInput {
    /** The model that just failed the turn. */
    failed: {
        provider: string;
        model: string;
    };
    /** The failure's code. */
    code: string;
    /** Every model this turn has already failed on. */
    tried: ReadonlyArray<{
        provider: string;
        model: string;
    }>;
    candidates: readonly Candidate[];
    reading: Pick<TaskReading, 'task' | 'difficulty'>;
    weights: Weights;
    /** Free models go first; a paid one takes the turn only when no free one can. */
    preferFree: boolean;
    /** Tokens the chat holds; a candidate with a smaller window would lose some. */
    contextTokens?: number | undefined;
    /** The chat holds images, so a stand-in must take them. */
    hasImages: boolean;
    /** No model has answered in this chat yet, so it holds no history for a company to receive. */
    nothingSent?: boolean | undefined;
    table?: readonly ScoreRow[] | undefined;
    standingOf?: ((candidate: Candidate) => Standing) | undefined;
}
export type StepIn = 
/** This model takes the turn. */
{
    kind: 'use';
    to: Scored;
}
/** The turn fails as it would have, and this model waits for the person to accept it. */
 | {
    kind: 'offer';
    to: Scored;
    reason: 'loses-context' | 'other-company';
}
/** Nothing else can answer. */
 | {
    kind: 'none';
};
/**
 * Choose who takes the turn.
 * @param input - the failure, the models and the settings.
 * @param contextWindow - the model's context size, when the adapter knows it; read only for models the choice can land on.
 * @returns the stand-in, an offer, or nothing.
 */
export declare function chooseStandIn(input: StepInInput, contextWindow: (candidate: Candidate) => Promise<number | undefined>): Promise<StepIn>;
/**
 * The sentence the chat shows. Written from the facts, never from a model.
 * @param failedLabel - the name of the model that failed.
 * @param code - the failure's code.
 * @param choice - what the router did about it.
 * @returns one or two sentences.
 */
export declare function stepInRationale(failedLabel: string, code: string, choice: Exclude<StepIn, {
    kind: 'none';
}>): string;
//# sourceMappingURL=step-in.d.ts.map