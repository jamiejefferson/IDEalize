/**
 * The criteria a routed turn is decided under. Since 25 Nov 2026 every chat reads
 * one app-wide set: how readily a chat moves, and the weights of the Cheaper to
 * Smarter slider ({@link leanWeights}). The per-brain rows below ({@link criteriaFor},
 * {@link SHIPPED_CRITERIA}) stay for callers that still read them; the router's own
 * decisions no longer do. Pure.
 */
import type { Aggressiveness, Weights } from './decide.ts';
/** What a brain's sheet saves; every field optional, so a partial entry still reads. */
export interface BrainCriteria {
    aggressiveness?: Aggressiveness;
    cost?: number;
    speed?: number;
    intelligence?: number;
}
/** The criteria one turn is decided under. */
export interface Criteria {
    aggressiveness: Aggressiveness;
    weights: Weights;
}
/** The starting points of the shipped brains, from the spec's §3.2 examples, on the sliders' 0 to 100 scale. */
export declare const SHIPPED_CRITERIA: Readonly<Record<string, BrainCriteria>>;
/**
 * The criteria for one brain's turn.
 * @param saved - the `brains` map of the router's settings.
 * @param brain - the chat's brain, when it runs one.
 * @param fallback - the app-wide values.
 * @returns the brain's saved fields over its shipped row over the fallback.
 */
export declare function criteriaFor(saved: Readonly<Record<string, BrainCriteria>> | undefined, brain: string | undefined, fallback: Criteria): Criteria;
/** The request header that carries a turn's vector to the free-token engine. */
export declare const ROUTING_HEADER = "x-idealize-routing";
/** Where the Cheaper to Smarter slider sits until a person moves it. */
export declare const DEFAULT_LEAN = 35;
/**
 * The slider's position as a whole number from 0 to 100.
 * @param value - what the settings or a request hold.
 * @returns the position, or undefined when the value is no number.
 */
export declare function leanOf(value: unknown): number | undefined;
/**
 * The weights the one Cheaper to Smarter slider stands for: 0 weighs cost alone and 100
 * weighs intelligence alone. Speed keeps the app-wide weight, which the slider does not move.
 * @param lean - the slider's position, 0 to 100.
 * @param speed - the app-wide speed weight.
 * @returns the weights every routed turn is scored under.
 */
export declare function leanWeights(lean: number | undefined, speed: number): Weights;
/** The free-token engine's weight vector. */
export interface EngineWeights {
    reliability: number;
    speed: number;
    intelligence: number;
}
/**
 * The free-token engine's vector for a brain's priorities. Every model inside
 * the engine costs nothing, so cost has no say there: reliability keeps the
 * balanced preset's half, and speed and intelligence split the other half in
 * the brain's own proportion. Even priorities give the engine's balanced preset.
 * @param weights - the brain's priorities.
 * @returns a vector that sums to 1.
 */
export declare function engineWeights(weights: Weights): EngineWeights;
/**
 * The header value for a vector: three figures to three places, in the engine's axis order.
 * @param vector - the engine's vector.
 * @returns `reliability,speed,intelligence`.
 */
export declare const routingHeaderValue: (vector: EngineWeights) => string;
//# sourceMappingURL=criteria.d.ts.map