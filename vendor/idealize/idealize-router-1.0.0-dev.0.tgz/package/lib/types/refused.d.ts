/**
 * Models that refused a routed turn. A route's catalogue can list a model the
 * user's account cannot run (a ChatGPT sign-in lists Codex models its plan
 * does not serve), and only the provider's answer says so. A model that failed
 * a turn the router gave it is left out of the candidates for a week, so the
 * router learns the account's real list one refusal at a time. A rate limit
 * says only that the model is busy (a free OpenRouter model shares one pool
 * with everyone), so that keeps it out for an hour. Kept in the harness data
 * folder so a restart does not repeat the lesson.
 */
export declare const REFUSED_FILE = "router-refused.json";
/** Why a model is left out: the account cannot run it, or it was only busy. */
export type RefusalCause = 'refused' | 'rate-limited';
/** Route key (`provider/model`) to the time the refusal lapses, in epoch milliseconds. */
export type Refusals = Record<string, number>;
export declare const routeKey: (model: {
    provider: string;
    model: string;
}) => string;
/**
 * The refusals still in force.
 * @param home - the harness data folder.
 * @param now - the current time.
 * @returns the live refusals; an absent or unreadable file reads as none.
 */
export declare function readRefusals(home: string, now?: number): Promise<Refusals>;
/**
 * Record one refusal.
 * @param home - the harness data folder.
 * @param refusals - the refusals in force, changed in place.
 * @param model - the model that failed the turn.
 * @param cause - a refusal holds for a week, a rate limit for an hour.
 * @param now - the current time.
 */
export declare function noteRefusal(home: string, refusals: Refusals, model: {
    provider: string;
    model: string;
}, cause?: RefusalCause, now?: number): Promise<void>;
//# sourceMappingURL=refused.d.ts.map