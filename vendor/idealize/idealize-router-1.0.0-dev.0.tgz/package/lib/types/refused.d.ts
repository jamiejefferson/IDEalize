/**
 * Models that refused a routed turn. A route's catalogue can list a model the
 * user's account cannot run (a ChatGPT sign-in lists Codex models its plan
 * does not serve), and only the provider's answer says so. A model that failed
 * a turn the router gave it is left out of the candidates for a week, so the
 * router learns the account's real list one refusal at a time. Kept in the
 * harness data folder so a restart does not repeat the lesson.
 */
export declare const REFUSED_FILE = "router-refused.json";
/** Route key (`provider/model`) to the time the refusal lapses, in epoch milliseconds. */
export type Refusals = Record<string, number>;
export declare const routeKey: (model: {
    provider: string;
    model: string;
}) => string;
/**
 * The refusals still in force.
 * @param home - the harness data folder.
 * @param now - the current time.
 * @returns the live refusals; an absent or unreadable file reads as none.
 */
export declare function readRefusals(home: string, now?: number): Promise<Refusals>;
/**
 * Record one refusal.
 * @param home - the harness data folder.
 * @param refusals - the refusals in force, changed in place.
 * @param model - the model that failed the turn.
 * @param now - the current time.
 */
export declare function noteRefusal(home: string, refusals: Refusals, model: {
    provider: string;
    model: string;
}, now?: number): Promise<void>;
//# sourceMappingURL=refused.d.ts.map