/**
 * Models that refused a routed turn. A route's catalogue can list a model the
 * user's account cannot run (a ChatGPT sign-in lists Codex models its plan
 * does not serve), and only the provider's answer says so. A model that failed
 * a turn the router gave it is left out of the candidates for a week, so the
 * router learns the account's real list one refusal at a time. A rate limit
 * says only that the model is busy (a free OpenRouter model shares one pool
 * with everyone), so that keeps it out for an hour, and so do a timeout and a
 * server error. A dropped connection says nothing about the model: the route's
 * address did not answer (a gateway the office network blocks, 11 Nov 2026), so
 * the whole route sits out for ten minutes and no model on it is blamed. Kept
 * in the harness data folder so a restart does not repeat the lesson.
 */
export declare const REFUSED_FILE = "router-refused.json";
/** Why a model is left out: the account cannot run it, it was only busy, or its route did not answer at all. */
export type RefusalCause = 'refused' | 'rate-limited' | 'unreachable';
/** How long each cause keeps a model out, as the log says it. */
export declare const REFUSAL_SPAN: Readonly<Record<RefusalCause, string>>;
/**
 * What a failure says about the model that gave it.
 * @param code - the failure's code.
 * @returns the cause to record.
 */
export declare function refusalCause(code: string): RefusalCause;
/** Route key (`provider/model`) to the time the refusal lapses, in epoch milliseconds. */
export type Refusals = Record<string, number>;
export declare const routeKey: (model: {
    provider: string;
    model: string;
}) => string;
/**
 * Whether a model sits out now, on its own account or with its whole route.
 * @param refusals - the refusals in force.
 * @param model - the model asked about.
 * @param now - the current time.
 * @returns true while either refusal holds.
 */
export declare function sitsOut(refusals: Refusals, model: {
    provider: string;
    model: string;
}, now?: number): boolean;
/**
 * The refusals still in force.
 * @param home - the harness data folder.
 * @param now - the current time.
 * @returns the live refusals; an absent or unreadable file reads as none.
 */
export declare function readRefusals(home: string, now?: number): Promise<Refusals>;
/**
 * Record one refusal.
 * @param home - the harness data folder.
 * @param refusals - the refusals in force, changed in place.
 * @param model - the model that failed the turn.
 * @param cause - a refusal holds for a week, a rate limit for an hour, and an unreachable route for ten minutes.
 * @param now - the current time.
 */
export declare function noteRefusal(home: string, refusals: Refusals, model: {
    provider: string;
    model: string;
}, cause?: RefusalCause, now?: number): Promise<void>;
/** Which key gateway the gateway refusals were learned against. */
export declare const GATEWAY_SEEN_FILE = "router-gateway-seen.json";
/**
 * Forget what a key gateway's models refused once the gateway itself changes. A refusal
 * learned against one address or key says nothing about the next, and it would otherwise
 * keep the new gateway's models out for a week (JJ, 11 Nov 2026: six sat out after the
 * gateway moved address).
 * @param home - the harness data folder.
 * @param refusals - the refusals in force, changed in place.
 * @param identity - the connected gateway's address and key ending.
 * @returns whether any refusal was dropped.
 */
export declare function forgetGatewayRefusals(home: string, refusals: Refusals, identity: string): Promise<boolean>;
//# sourceMappingURL=refused.d.ts.map