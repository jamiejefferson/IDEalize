/**
 * The reply check: after a chat's model finishes a turn, Jev reads the
 * person's message and the reply and says whether the model did the work. A
 * model that answers "I can't see pictures" or "this is beyond me" returns a
 * successful turn, so no failure code ever reaches the router; this is how it
 * hears one. Only a model that said the work was beyond it is answered, with a
 * model offered for the person to try (JJ, 9 Nov 2026). A missing tool, key or
 * file is not cured by another model, and a refusal on principle is the
 * model's to make, so those are read and left alone.
 */
import type { AskOptions, JevFailure, JevRequest } from './jev.ts';
/** What a reply can be read as. */
export declare const REPLY_OUTCOMES: {
    readonly done: "The reply does the work, makes real progress on it, or answers the question.";
    readonly asked: "The reply asks the person a question, or for a choice or a detail, before going on.";
    readonly 'model-limit': "The reply says the assistant cannot do the work because of what it can take in or do itself: it cannot see pictures, read this kind of file, hear sound, or manage work this hard.";
    readonly 'tool-missing': "The reply says the work cannot go ahead because a tool, service, key, file or permission it needs is missing or failed.";
    readonly declined: "The reply refuses on principle, safety or policy.";
};
export type ReplyOutcome = keyof typeof REPLY_OUTCOMES;
/** Below this, a "model-limit" reading is too unsure to put an offer in front of the person. */
export declare const REPLY_CHECK_CONFIDENCE = 0.7;
/** The check runs after the turn has ended, so it can wait longer than the reading that holds a turn up. */
export declare const REPLY_CHECK_TIMEOUT_MS = 5000;
/**
 * The request for one finished turn.
 * @param ask - the person's message.
 * @param reply - the model's reply to it.
 * @returns the body to post.
 */
export declare function replyCheckRequest(ask: string, reply: string): JevRequest;
export interface ReplyCheck {
    outcome?: ReplyOutcome;
    /** Jev's own certainty in the outcome, from 0 to 1. */
    confidence?: number;
    failure?: JevFailure;
    cost?: number;
    ms: number;
}
/**
 * Ask Jev about one finished turn. Never throws.
 * @param ask - the person's message.
 * @param reply - the model's reply.
 * @param options - the user's OpenRouter key and the transport.
 * @returns the outcome and Jev's confidence, or the failure.
 */
export declare function checkReply(ask: string, reply: string, options: AskOptions): Promise<ReplyCheck>;
/**
 * Whether a check should put a model in front of the person.
 * @param check - Jev's reading of the turn.
 * @returns true for a confident reading that the model said the work was beyond it.
 */
export declare const saidItCannot: (check: ReplyCheck) => boolean;
//# sourceMappingURL=reply-check.d.ts.map