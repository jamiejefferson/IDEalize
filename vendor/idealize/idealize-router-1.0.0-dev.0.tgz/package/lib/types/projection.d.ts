/**
 * The router's session events folded: the projection the composer reads, and
 * the two facts the host needs per turn (is the chat locked, and which switch
 * still holds).
 * @module @idealize/router/projection
 */
import type { SessionEvent } from '@deepseek-ai/dsh-session';
import type { ProjectionDefinition } from '@deepseek-ai/dsh-session-projection';
import type { RouterEventData, RouterProjection } from './projection-types.ts';
export type { RoutedModel, RouterEventData, RouterLockEventData, RouterProjection } from './projection-types.ts';
export declare const routerProjectionDefinition: ProjectionDefinition<'router', RouterProjection>;
/**
 * Whether the chat is locked against routing.
 * @param events - the session's event log, oldest first.
 * @returns the latest lock; unlocked when none is recorded.
 */
export declare function foldLocked(events: readonly SessionEvent[]): boolean;
/**
 * The switch that still holds, and when the chat last switched.
 * @param events - the session's event log, oldest first.
 * @returns the latest switch unless a reset follows it, and the time of the latest switch or reset.
 */
export declare function foldRouted(events: readonly SessionEvent[]): {
    routed?: RouterEventData;
    lastSwitchAt?: string;
};
/**
 * The model the chat is on before this turn is routed. The host resolves the
 * model the user or the brain chose; a switch the router made earlier holds
 * over it until the user chooses another, which shows as a resolved model that
 * is neither end of that switch.
 * @param resolved - what the request would run on without the router.
 * @param routed - the switch that still holds, from {@link foldRouted}.
 * @returns the chat's current model, and whether the earlier switch was dropped.
 */
export declare function currentModel<T extends {
    provider: string;
    model: string;
}>(resolved: T, routed: RouterEventData | undefined): {
    current: {
        provider: string;
        model: string;
    };
    dropped: boolean;
};
//# sourceMappingURL=projection.d.ts.map