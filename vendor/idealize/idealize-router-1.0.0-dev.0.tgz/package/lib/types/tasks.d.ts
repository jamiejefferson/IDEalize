/**
 * The task types the router tells apart, what each asks of a model, and the
 * local reading of a message that stands in when Jev cannot be asked. The
 * local reading is keyword rules by design: it has to answer in under a
 * millisecond, and it only has to be right enough to route until Jev answers.
 */
/** What a model is scored on; every score is 0 to 1. */
export type Capability = 'reasoning' | 'coding' | 'math' | 'writing' | 'instructions' | 'multilingual';
export declare const CAPABILITIES: readonly Capability[];
export type TaskType = 'code' | 'reasoning' | 'math' | 'writing' | 'summarise' | 'translate' | 'quick';
/** How much the task asks of the model; it scales how far capability counts against cost and speed. */
export type Difficulty = 'simple' | 'moderate' | 'hard';
export interface TaskDefinition {
    /** The line Jev chooses by, and the phrase the rationale uses ("better for …"). */
    label: string;
    /** What Jev reads as this option's meaning. */
    criterion: string;
    /** The capabilities the task draws on, weighted. */
    needs: Partial<Record<Capability, number>>;
}
export declare const TASKS: Record<TaskType, TaskDefinition>;
export declare const TASK_TYPES: TaskType[];
/** A reading of one message: the task, how hard it is, and how sure the reader is. */
export interface TaskReading {
    task: TaskType;
    difficulty: Difficulty;
    /** 0 to 1. Jev's is calibrated; the local rules' is a fixed, modest figure. */
    confidence: number;
    /** Who read it, for the log and the settings' own account of itself. */
    source: 'jev' | 'rules' | 'brain';
}
/**
 * Read a message with keyword rules. Length and structure set the difficulty:
 * a long or multi-part ask is harder than a one-liner whatever its subject.
 * @param message - the user's latest message.
 * @param brainId - the chat's brain, when it has one.
 * @returns the local reading.
 */
export declare function readLocally(message: string, brainId?: string): TaskReading;
//# sourceMappingURL=tasks.d.ts.map