/**
 * What the chat box's model chip shows and writes: how the router behaves
 * (`mode`), where the Cheaper to Smarter slider sits (`lean`), and the list of
 * the chat's company's models with a tick each (JJ, 24 Nov 2026). Pure: the
 * host supplies the connected models and the chat's own model.
 */
import type { Candidate } from './decide.ts';
import type { RoutedModel, RouterChoices, RouterMode } from './projection-types.ts';
export type { RouterChoice, RouterChoices, RouterMode } from './projection-types.ts';
/** Every mode, in the order the chip shows them. */
export declare const ROUTER_MODES: readonly RouterMode[];
/**
 * The mode a stored or posted value names.
 * @param value - what the settings or a request hold.
 * @returns the mode, or undefined when the value names none.
 */
export declare function modeOf(value: unknown): RouterMode | undefined;
/** The fields of the router's settings the chip writes. */
export interface ChoiceSettings {
    mode?: RouterMode;
    lean?: number;
    excluded?: string[];
}
/**
 * The chip's share of a `POST /idealize/router/settings` body.
 * @param body - the parsed request body.
 * @returns the valid fields; a field of the wrong shape is left out.
 */
export declare function choiceSettings(body: Readonly<Record<string, unknown>>): ChoiceSettings;
export interface ChoicesInput {
    mode: RouterMode | undefined;
    lean: number | undefined;
    excluded: readonly string[];
    sameCompany: boolean;
    /** The chat's own model. */
    own: RoutedModel;
    /** The routed model while a switch holds, else the chat's own. */
    answering: RoutedModel;
    /** Every connected model. */
    candidates: readonly Candidate[];
}
/**
 * Compose the chip's answer.
 * @param input - the settings, the chat's models and the connected models.
 * @returns the settings and the company's models, cheapest first. An unticked model is listed
 * with `allowed: false`, and the answering model is listed even when no connected route names it.
 */
export declare function choicesFor(input: ChoicesInput): RouterChoices;
//# sourceMappingURL=choices.d.ts.map