/**
 * The person's own ratings of models: stars per kind of work, set on a model's
 * card or from the line a heart brings up, and quiet marks left by picks after
 * a dislike. They stay on this machine and steer only this person's router
 * (JJ, 28 Oct 2026). The kinds of work are the model browser's Good at
 * vocabulary, one list per kind of model, so a rating and a filter chip name
 * the same thing.
 *
 * A model is keyed by what it is, not the route it came through: a chat model
 * by its facts key (OpenRouter's `anthropic/claude-sonnet-5.5` and a direct
 * `claude-sonnet-5-5` are one model), a media model by its endpoint id.
 */
import type { TaskType } from './tasks.ts';
export declare const RATINGS_FILE = "model-ratings.json";
/** The kinds of model a rating can belong to. */
export type RatingKind = 'chat' | 'image' | 'video' | 'audio';
export declare const RATING_KINDS: readonly RatingKind[];
/** The tags a kind of model can be rated for, in the browser's order. */
export declare const RATING_TAGS: Readonly<Record<RatingKind, readonly string[]>>;
/**
 * The chat tag a router reading rates. The router tells seven kinds of work
 * apart; the Good at list names six of them and folds maths into reasoning
 * and summarising into reading long documents.
 */
export declare const TASK_TAG: Readonly<Record<TaskType, string>>;
export type Stars = 1 | 2 | 3 | 4 | 5;
/** One model's standing for one kind of work. */
export interface TagRating {
    /** Set by the person. */
    stars?: Stars | undefined;
    /** Picks after a dislike: up for a kept alternative, down for the answer passed over. */
    marks?: number | undefined;
    at: string;
}
export interface ModelRatings {
    kind: RatingKind;
    /** The name the person saw when they rated it. */
    label?: string | undefined;
    tags: Record<string, TagRating>;
}
export interface RatingsFile {
    version: 1;
    /** By {@link ratingKey}. */
    models: Record<string, ModelRatings>;
}
/** A model as a rating names it. */
export interface RatedModel {
    kind: RatingKind;
    /** The chat route or the media backend; not part of the key. */
    provider: string;
    model: string;
}
/**
 * The key a model's ratings are filed under.
 * @param model - the model and its kind.
 * @returns `kind:key`, the key being the chat facts key or the media endpoint id.
 */
export declare function ratingKey(model: Pick<RatedModel, 'kind' | 'model'>): string;
export declare const isRatingKind: (value: unknown) => value is RatingKind;
export declare const isStars: (value: unknown) => value is Stars;
export declare const isTag: (kind: RatingKind, tag: unknown) => tag is string;
/**
 * The ratings on disk. An absent file is no ratings; a damaged one is set
 * aside as `.damaged` and reads as none, so one bad write never stops routing.
 * @param home - the harness data folder.
 * @returns the ratings.
 */
export declare function readRatings(home: string): Promise<RatingsFile>;
/**
 * Change the ratings on disk: read, change, write through a temporary file.
 * @param home - the harness data folder.
 * @param change - edits the file in place.
 * @returns the ratings as written.
 */
export declare function updateRatings(home: string, change: (file: RatingsFile) => void): Promise<RatingsFile>;
/**
 * Set or clear one star rating. The tag's quiet marks are kept and count
 * again once the stars are cleared; while stars stand, they outweigh the marks.
 * @param file - the ratings, changed in place.
 * @param model - the model.
 * @param tag - the kind of work.
 * @param stars - the rating, or undefined to clear it.
 * @param at - when.
 * @param label - the model's display name.
 */
export declare function setStars(file: RatingsFile, model: RatedModel, tag: string, stars: Stars | undefined, at: string, label?: string): void;
/** Quiet marks stop counting past this many either way. */
export declare const MAX_MARKS = 3;
/**
 * Leave one quiet mark. A tag the person has starred keeps its stars; the
 * mark is still kept, but {@link standing} reads stars first.
 * @param file - the ratings, changed in place.
 * @param model - the model.
 * @param tag - the kind of work.
 * @param delta - +1 for a kept alternative, -1 for the answer passed over.
 * @param at - when.
 * @param label - the model's display name.
 */
export declare function addMark(file: RatingsFile, model: RatedModel, tag: string, delta: 1 | -1, at: string, label?: string): void;
/** What one model's rating for one tag does to its score. */
export interface Standing {
    /** Added to the weighted total the router compares, -0.1 to +0.2. */
    bonus: number;
    /** One star: never picked for this kind of work again. */
    barred: boolean;
    /** The person starred it for this tag. */
    starred: boolean;
    stars?: Stars | undefined;
}
/**
 * Star weights, on the scale of the weighted totals the router compares. Close
 * rivals sit within about 0.05 of each other there (28 Oct 2026, the shipped
 * table under even priorities), and a switch must gain 0.15 on the balanced
 * setting. Five stars add 0.2, so a 5-star model wins against a close rival on
 * its rating, which is the strong nudge JJ ruled for; a cautious setting (0.3)
 * still asks it to be strong in its own right. A quiet mark is a tenth of that.
 */
export declare const STAR_BONUS: Readonly<Record<Stars, number>>;
export declare const MARK_BONUS = 0.02;
/**
 * A model's standing for one tag.
 * @param file - the ratings.
 * @param model - the model.
 * @param tag - the kind of work.
 * @returns the bonus it earns, and whether it is barred.
 */
export declare function standing(file: RatingsFile, model: Pick<RatedModel, 'kind' | 'model'>, tag: string): Standing;
/** One model's ratings for the card: every tag it has stars or marks for. */
export declare function ratingsOf(file: RatingsFile, model: Pick<RatedModel, 'kind' | 'model'>): Record<string, TagRating>;
//# sourceMappingURL=ratings.d.ts.map