/**
 * One turn, routed: read the message (Jev first, the local rules when Jev
 * cannot answer), decide, and say what the chat should record. Everything the
 * host supplies arrives as an argument, so the whole path runs in a test.
 */
import type { Aggressiveness, Candidate, Decision, Weights } from './decide.ts';
import type { JevFailure, JevResult } from './jev.ts';
import type { RouterEventData } from './projection-types.ts';
import type { RatingsFile } from './ratings.ts';
import type { ScoreRow } from './score-table.ts';
import type { TaskReading } from './tasks.ts';
export interface TurnInput {
    /** What the request would run on without the router. */
    resolved: {
        provider: string;
        model: string;
    };
    /** The earlier switch that still holds. */
    routed?: RouterEventData | undefined;
    lastSwitchAt?: string | undefined;
    message: string;
    hasImages: boolean;
    brain?: {
        id: string;
        instructions?: string | undefined;
    } | undefined;
    contextTokens?: number | undefined;
    candidates: Candidate[];
    weights: Weights;
    aggressiveness: Aggressiveness;
    preferFree: boolean;
    /** On: a move the router would make is offered, and the turn answers on the model the chat is on. */
    ask?: boolean | undefined;
    table?: readonly ScoreRow[] | undefined;
    /** The person's ratings; a 5-star model for the work read is nudged up, a 1-star one left out. */
    ratings?: RatingsFile | undefined;
    now: Date;
}
export interface TurnDeps {
    /** Ask Jev; undefined when Jev is switched off. Never throws. */
    askJev?: ((message: string, brain: TurnInput['brain']) => Promise<JevResult>) | undefined;
    /** The model's context size, when the adapter knows it. */
    contextWindow(candidate: Candidate): Promise<number | undefined>;
}
export interface TurnResult {
    use: {
        provider: string;
        model: string;
    };
    /** The chat's model before this turn was routed. */
    from: Candidate;
    decision: Decision;
    reading: TaskReading;
    jev?: JevResult | undefined;
    jevFailure?: JevFailure | undefined;
    /** What the chat's log should record, when the turn switched, made an offer, or dropped an earlier switch. */
    events: RouterEventData[];
}
/**
 * Whether a model costs more per token than the one the chat is on. Said only when both
 * prices are known: an unlisted price is no ground for a warning.
 * @param to - the model offered.
 * @param from - the model the chat is on.
 * @returns true when `to` is the dearer of the two.
 */
export declare function costsMore(to: Pick<Candidate, 'price'>, from: Pick<Candidate, 'price'>): boolean;
/**
 * Route one turn.
 * @param input - the chat's state, the message and the settings.
 * @param deps - Jev and the adapter's model facts.
 * @returns the model to run on and what to record.
 */
export declare function routeTurn(input: TurnInput, deps: TurnDeps): Promise<TurnResult>;
//# sourceMappingURL=route.d.ts.map