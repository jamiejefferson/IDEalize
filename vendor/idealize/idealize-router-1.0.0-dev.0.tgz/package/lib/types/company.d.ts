/**
 * The company behind a model, and the two limits a person sets on where the
 * router may move a chat: inside the company of the chat's own model, and
 * among the models they left ticked (JJ, 24 Nov 2026: a chat runs on one
 * company's models). Pure.
 */
/**
 * The company that receives what a route is sent. OpenRouter's model ids name their maker
 * (`~anthropic/claude-haiku-latest`), a key gateway's route reaches the company of the route
 * it fronts, and any other route answers for itself. The free-tokens engine picks a provider
 * per call, so it is a company of its own.
 * @param provider - the route's id.
 * @param model - the model's id on that route.
 * @returns the company's name, in the spelling OpenRouter uses for it.
 */
export declare function companyOf(provider: string, model: string): string;
/** A model by its route. */
interface Routed {
    provider: string;
    model: string;
}
/**
 * Whether a person unticked this model. A model reached through a key gateway follows the
 * tick of the route the gateway fronts, because the list shows one row for both.
 * @param model - the model asked about.
 * @param excluded - the unticked `provider/model` keys.
 * @returns true when the router must leave it alone.
 */
export declare function isExcluded(model: Routed, excluded: readonly string[]): boolean;
/** What limits a routed move. */
export interface MoveLimits {
    /** On: only models of the company of the chat's own model. */
    sameCompany: boolean;
    /** The `provider/model` keys the person unticked. */
    excluded: readonly string[];
}
/**
 * The models a routed turn may consider.
 * @param candidates - every connected model.
 * @param own - the chat's own model, whose company sets the limit.
 * @param limits - the person's two limits.
 * @param keep - models the chat is on now, which stay in the list so they keep their name and price.
 * @returns the candidates inside the limits, in their order.
 */
export declare function withinLimits<T extends Routed>(candidates: readonly T[], own: Routed, limits: MoveLimits, keep?: readonly Routed[]): T[];
export {};
//# sourceMappingURL=company.d.ts.map