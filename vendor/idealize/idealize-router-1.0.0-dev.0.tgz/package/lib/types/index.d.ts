/**
 * IDEalize's model router. Each message a person sends in a chat is read for
 * the kind of work it asks for by Jev, through the user's own OpenRouter key.
 * When Jev gives no reading (no key, a timeout, an error) the chat keeps its
 * model: a hang never costs the user more than Jev's limit, and the router
 * never moves a chat on a guess (JJ, 21 Sep 2026). Every connected model is scored for
 * that work under the user's cost, speed and intelligence weights, and a
 * clearly better model takes the turn. The switch happens in the agent's
 * `agent/request` waterfall, which replaces one call's provider and model for
 * one chat; the app-wide default model is never touched.
 *
 * Only the latest message leaves the machine, with the brain's name and
 * instructions. No history, files or images (JJ, 21 Sep 2026).
 *
 * Each brain carries its own criteria (how readily its chats move, and the
 * three weights), set in its sheet. The app-wide values serve a chat that runs
 * no brain. A turn that runs on free tokens sends the brain's weights to the
 * engine in a header, so the engine picks its provider on the same criteria.
 *
 * Three things stop switching: a chat's lock, a brain listed in `offBrains`,
 * and `enabled: false`. Terminal chats run a command-line agent the router
 * cannot reach, and the generating spaces choose their own models.
 *
 * When a chat's own model cannot answer (its sign-in or key went, its credit ran
 * out, or it stayed busy through the retries), the router hands the turn to the
 * best other connected model instead of letting it fail. It needs no reading from
 * Jev to do so: Jev's limit protects a chat that works, and this turn has already failed.
 *
 * HTTP surface (loopback-fenced; mutations demand the header):
 * - GET  /idealize/router/state — settings, the weights it reads, whether Jev is reachable, the last Jev failure, and the capability table.
 * - POST /idealize/router/settings — any of {enabled, aggressiveness, preferFree, showRationale, useJev, offBrains}.
 * - POST /idealize/router/brain — {brain, aggressiveness?, cost?, speed?, intelligence?}: one brain's own criteria.
 * - POST /idealize/router/lock — {sessionId, locked}.
 * - POST /idealize/router/reset — {sessionId}: the user took the model back; the earlier switch no longer holds.
 * - GET  /idealize/router/log?limit=n — the newest decisions, newest first.
 * - GET  /idealize/router/ratings — the tag list per kind of model and every rating the person holds.
 * - POST /idealize/router/ratings — {kind, provider, model, tag, stars (1 to 5, or null to clear), label?}.
 * - GET  /idealize/router/rate-target?sessionId= — the model behind the chat's last answer and the tag its line opens on.
 * - GET  /idealize/router/offer?sessionId= — after a dislike: the two models to try, and what both runs should cost.
 * - POST /idealize/router/compare — {sessionId, alternatives}: run them; the steps land in the log as `idealize/router-compare`.
 * - POST /idealize/router/pick — {sessionId, id, index}: keep an alternative (or -1, the first answer).
 *
 * The generating spaces: when the person has starred a media model, each
 * generation's prompt is read as one kind of work, and the call moves to the
 * model they rated highest for it (`generation/choose-model`). A model kept
 * after a dislike serves the rest of that chat's generations of its kind.
 */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import type { BrainCriteria } from './criteria.ts';
import type { Aggressiveness } from './decide.ts';
export { candidatesFrom } from './candidates.ts';
export { criteriaFor, engineWeights, ROUTING_HEADER, routingHeaderValue, SHIPPED_CRITERIA } from './criteria.ts';
export type { BrainCriteria, Criteria, EngineWeights } from './criteria.ts';
export { decide, PRESETS, rationaleFor, score } from './decide.ts';
export type { Aggressiveness, Candidate, Decision, Scored, StayReason, Weights } from './decide.ts';
export { askJev, requestFor } from './jev.ts';
export { currentModel, foldLocked, foldRouted, routerProjectionDefinition } from './projection.ts';
export type { RoutedModel, RouterEventData, RouterLockEventData, RouterProjection } from './projection-types.ts';
export { routeTurn } from './route.ts';
export { canStepIn, chooseStandIn, stepInRationale } from './step-in.ts';
export { SHIPPED_SCORES } from './score-table.ts';
export type { ScoreRow } from './score-table.ts';
export { alternativesFor } from './alternatives.ts';
export { askBefore, compareCost, foldCompare, foldMediaKept, keptNote, lastReply } from './compare.ts';
export { decideMedia, hasStarsFor, mediaAlternativesFor, mediaCost, mediaTagFor, readableTags } from './media.ts';
export { addMark, RATING_TAGS, ratingKey, ratingsOf, readRatings, setStars, standing, TASK_TAG, updateRatings } from './ratings.ts';
export type { RatedModel, RatingKind, RatingsFile, Stars, TagRating } from './ratings.ts';
export { readLocally, TASKS } from './tasks.ts';
export type { TaskReading, TaskType } from './tasks.ts';
/** Cordis plugin name used by loader diagnostics. */
export declare const name = "idealize-router";
export interface RouterConfig {
    /** Off: every chat stays on the model it has. */
    enabled?: boolean;
    /** How sure and how much better a model must be, and how long after the last switch. */
    aggressiveness?: Aggressiveness;
    /** On: the router moves a chat only to a model that costs nothing more, and offers a paid one for the user to accept. */
    preferFree?: boolean;
    /** On: the composer's badge carries the sentence of why. */
    showRationale?: boolean;
    /** Off: keyword rules on this machine read every message and nothing leaves it. Config only; the app offers no control for it. */
    useJev?: boolean;
    /** Brains whose chats are never routed. */
    offBrains?: string[];
    /** Each brain's own criteria, by brain id; a brain without an entry starts from its shipped row, then the app-wide values. */
    brains?: Record<string, BrainCriteria>;
    /** OpenRouter marks the Decisions endpoint alpha, so its address is config. An installed app ignores it (see {@link jevAddress}). */
    jevUrl?: string;
    /** The longest a turn waits on Jev, in milliseconds. */
    jevTimeoutMs?: number;
    /** Off: a finished reply is not read, so a model that says the work is beyond it gets no offer of another. */
    replyCheck?: boolean;
}
export declare const Config: z<RouterConfig>;
export declare function apply(ctx: Context, config?: RouterConfig): void;
//# sourceMappingURL=index.d.ts.map