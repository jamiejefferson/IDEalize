/**
 * IDEalize's model router. Each message a person sends in a chat is read for
 * the kind of work it asks for by Jev, through the user's own OpenRouter key.
 * When Jev gives no reading (no key, a timeout, an error) the chat keeps its
 * model: a hang never costs the user more than Jev's limit, and the router
 * never moves a chat on a guess (JJ, 21 Sep 2026). Every connected model is scored for
 * that work under the user's cost, speed and intelligence weights, and a
 * clearly better model takes the turn. The switch happens in the agent's
 * `agent/request` waterfall, which replaces one call's provider and model for
 * one chat; the app-wide default model is never touched.
 *
 * Only the latest message leaves the machine, with the brain's name and
 * instructions. No history, files or images (JJ, 21 Sep 2026).
 *
 * Each brain carries its own criteria (how readily its chats move, and the
 * three weights), set in its sheet. The app-wide values serve a chat that runs
 * no brain. A turn that runs on free tokens sends the brain's weights to the
 * engine in a header, so the engine picks its provider on the same criteria.
 *
 * Three things stop switching: a chat's lock, a brain listed in `offBrains`,
 * and `enabled: false`. Terminal chats run a command-line agent the router
 * cannot reach, and the generating spaces choose their own models.
 *
 * HTTP surface (loopback-fenced; mutations demand the header):
 * - GET  /idealize/router/state — settings, the weights it reads, whether Jev is reachable, the last Jev failure, and the capability table.
 * - POST /idealize/router/settings — any of {enabled, aggressiveness, preferFree, showRationale, useJev, offBrains}.
 * - POST /idealize/router/brain — {brain, aggressiveness?, cost?, speed?, intelligence?}: one brain's own criteria.
 * - POST /idealize/router/lock — {sessionId, locked}.
 * - POST /idealize/router/reset — {sessionId}: the user took the model back; the earlier switch no longer holds.
 * - GET  /idealize/router/log?limit=n — the newest decisions, newest first.
 */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import type { BrainCriteria } from './criteria.ts';
import type { Aggressiveness } from './decide.ts';
export { candidatesFrom } from './candidates.ts';
export { criteriaFor, engineWeights, ROUTING_HEADER, routingHeaderValue, SHIPPED_CRITERIA } from './criteria.ts';
export type { BrainCriteria, Criteria, EngineWeights } from './criteria.ts';
export { decide, PRESETS, rationaleFor, score } from './decide.ts';
export type { Aggressiveness, Candidate, Decision, Scored, StayReason, Weights } from './decide.ts';
export { askJev, requestFor } from './jev.ts';
export { currentModel, foldLocked, foldRouted, routerProjectionDefinition } from './projection.ts';
export type { RoutedModel, RouterEventData, RouterLockEventData, RouterProjection } from './projection-types.ts';
export { routeTurn } from './route.ts';
export { SHIPPED_SCORES } from './score-table.ts';
export type { ScoreRow } from './score-table.ts';
export { readLocally, TASKS } from './tasks.ts';
export type { TaskReading, TaskType } from './tasks.ts';
/** Cordis plugin name used by loader diagnostics. */
export declare const name = "idealize-router";
export interface RouterConfig {
    /** Off: every chat stays on the model it has. */
    enabled?: boolean;
    /** How sure and how much better a model must be, and how long after the last switch. */
    aggressiveness?: Aggressiveness;
    /** On: the router moves a chat only to a model that costs nothing more, and offers a paid one for the user to accept. */
    preferFree?: boolean;
    /** On: the composer's badge carries the sentence of why. */
    showRationale?: boolean;
    /** Off: keyword rules on this machine read every message and nothing leaves it. Config only; the app offers no control for it. */
    useJev?: boolean;
    /** Brains whose chats are never routed. */
    offBrains?: string[];
    /** Each brain's own criteria, by brain id; a brain without an entry starts from its shipped row, then the app-wide values. */
    brains?: Record<string, BrainCriteria>;
    /** OpenRouter marks the Decisions endpoint alpha, so its address is config. */
    jevUrl?: string;
    /** The longest a turn waits on Jev, in milliseconds. */
    jevTimeoutMs?: number;
}
export declare const Config: z<RouterConfig>;
export declare function apply(ctx: Context, config?: RouterConfig): void;
//# sourceMappingURL=index.d.ts.map