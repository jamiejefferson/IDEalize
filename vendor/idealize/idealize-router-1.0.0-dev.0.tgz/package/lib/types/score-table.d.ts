/**
 * The shipped capability table. Scores are editorial estimates on a 0 to 1
 * scale, written by family so a new version inherits its family's row until
 * someone scores it. They are not benchmark figures. A user's own table in
 * the harness home (`router-scores.json`, same shape) is read over this one.
 *
 * Order matters: the first row whose pattern matches the model id wins, so a
 * family's small variants sit above the family's general row.
 */
import type { Capability } from './tasks.ts';
export interface ScoreRow {
    /** Matched against the lower-cased model id, maker prefix included. */
    pattern: string;
    /** Shown in the settings' table and in a rationale. */
    family: string;
    scores: Record<Capability, number>;
    /** How quickly the family answers, 0 to 1. Price and context size come live; speed has no live source. */
    speed: number;
}
export declare const SHIPPED_SCORES: readonly ScoreRow[];
/**
 * What an unscored model gets. Every figure sits under every shipped row's
 * weakest general model, so an unknown model is never preferred over a known
 * one, and the router leaves a chat that is already on it alone unless a
 * known model clearly fits better.
 */
export declare const NEUTRAL: Omit<ScoreRow, 'pattern'>;
/**
 * The free-tokens route answers with whichever free provider the engine finds
 * healthy, so it is scored as the middle of what those providers serve.
 */
export declare const FREE_TOKENS: Omit<ScoreRow, 'pattern'>;
//# sourceMappingURL=score-table.d.ts.map