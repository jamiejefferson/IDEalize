/**
 * The router's log: one JSON line per decided turn, in the harness data
 * folder. It holds the reading and the figures, never the message, so the
 * file can be shared when a switch needs explaining.
 */
import type { Decision, StayReason } from './decide.ts';
import type { JevFailure } from './jev.ts';
import type { TaskReading } from './tasks.ts';
export declare const ROUTER_LOG_FILE = "router-log.jsonl";
export interface LogEntry {
    at: string;
    session: string;
    brain?: string | undefined;
    reading: TaskReading;
    /** Why Jev did not read this turn, when the local rules did. */
    jevFailure?: JevFailure | undefined;
    jevMs?: number | undefined;
    jevCost?: number | undefined;
    from: string;
    to: string;
    switched: boolean;
    stayed?: StayReason | undefined;
    recommended?: string | undefined;
    improvement: number;
    switchConfidence: number;
    rationale: string;
}
/**
 * One decision as a log line.
 * @param session - the chat's id.
 * @param decision - what the router decided.
 * @param reading - the reading it decided on.
 * @param extra - the brain and what the Jev call cost.
 * @returns the entry.
 */
export declare function entryFor(session: string, decision: Decision, reading: TaskReading, extra: {
    brain?: string | undefined;
    jevFailure?: JevFailure | undefined;
    jevMs?: number | undefined;
    jevCost?: number | undefined;
    from: {
        provider: string;
        model: string;
    };
    now?: Date;
}): LogEntry;
/**
 * Append one entry. A log that cannot be written never fails a turn.
 * @param home - the harness data folder.
 * @param entry - the line to add.
 */
export declare function appendLog(home: string, entry: LogEntry): Promise<void>;
/**
 * The newest entries, newest first, for the settings' log view.
 * @param home - the harness data folder.
 * @param limit - how many to return.
 * @returns the entries; an absent or unreadable log reads as empty.
 */
export declare function readLog(home: string, limit?: number): Promise<LogEntry[]>;
//# sourceMappingURL=log.d.ts.map