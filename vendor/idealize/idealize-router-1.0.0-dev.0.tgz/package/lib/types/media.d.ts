/**
 * The router in the generating spaces. Each prompt is read as one kind of work
 * from that kind of model's list (illustration, lip-sync, music), and the call
 * moves to a model only when the person has rated one for that work above the
 * stored choice (JJ, 28 Oct 2026: with no ratings, the router works as today,
 * so media keeps the brain's model). Jev reads the prompt; no reading, no
 * switch. A pick kept after a dislike holds for the rest of that chat.
 */
import type { GenCatalogEntry } from '@idealize/generate';
import type { Aggressiveness } from './decide.ts';
import type { AskOptions, JevFailure } from './jev.ts';
import type { RatingKind, RatingsFile, Stars } from './ratings.ts';
/** The media preset each kind of model serves. */
export declare const PRESET_KIND: Readonly<Record<string, Exclude<RatingKind, 'chat'>>>;
/**
 * The tags one call can be read as.
 * @param kind - the kind of model.
 * @param hasReference - the call carries a reference picture.
 */
export declare function readableTags(kind: Exclude<RatingKind, 'chat'>, hasReference: boolean): string[];
/**
 * Jev's request for one prompt.
 * @param prompt - what the generation tool was asked to make.
 * @param kind - the kind of model.
 * @param tags - the tags this call can be read as.
 */
export declare function mediaRequestFor(prompt: string, kind: Exclude<RatingKind, 'chat'>, tags: readonly string[]): {
    state: string;
    model: string;
    questions: {
        tag: {
            type: "choice";
            instructions: string;
            criteria: {
                [k: string]: string;
            };
        };
    };
};
export interface MediaReading {
    tag: string;
    confidence: number;
}
/** The least confidence a media reading needs before it moves a call. */
export declare const MEDIA_CONFIDENCE = 0.6;
/**
 * Ask Jev which tag a prompt is. Never throws.
 * @param prompt - the prompt.
 * @param kind - the kind of model.
 * @param tags - the readable tags.
 * @param options - the key and transport, as {@link askJev} takes them.
 * @returns the reading, or the failure.
 */
export declare function readPrompt(prompt: string, kind: Exclude<RatingKind, 'chat'>, tags: readonly string[], options: AskOptions): Promise<{
    reading?: MediaReading;
    failure?: JevFailure;
}>;
/** The fewest stars that move a call, by the brain's flexibility. */
export declare const MEDIA_MIN_STARS: Readonly<Record<Aggressiveness, Stars>>;
export interface MediaDecision {
    use: GenCatalogEntry;
    switched: boolean;
    stars?: Stars | undefined;
    rationale?: string | undefined;
}
/**
 * Decide one media call.
 * @param input - the stored choice, the runnable models, the tag read, the ratings and the brain's flexibility.
 * @returns the model to run on, and the sentence of why when it moved.
 */
export declare function decideMedia(input: {
    kind: Exclude<RatingKind, 'chat'>;
    stored: GenCatalogEntry;
    candidates: readonly GenCatalogEntry[];
    tag: string;
    ratings: RatingsFile;
    aggressiveness: Aggressiveness;
}): MediaDecision;
/**
 * The two media models a dislike offers. Models the person has not rated for
 * this kind of work come first, so each test fills a gap (JJ, 28 Oct 2026);
 * within each group the ones whose facts say they suit the work lead, then the
 * cheaper output. A model barred with one star, the model that made the
 * disliked output, and models that need a picture to start from are left out.
 * @param input - the kind, the model that made the output, the runnable models, the tag and the ratings.
 * @param count - how many to offer.
 * @returns up to `count` models, one per maker where the list allows.
 */
export declare function mediaAlternativesFor(input: {
    kind: Exclude<RatingKind, 'chat'>;
    current: {
        backend: string;
        model: string;
    };
    candidates: readonly GenCatalogEntry[];
    tag: string;
    ratings: RatingsFile;
}, count?: number): GenCatalogEntry[];
/**
 * What the media runs should cost.
 * @param entries - the alternatives.
 * @param outputs - how many outputs each run makes.
 * @returns the sum in US dollars, or `unknown` when a model publishes no price per output.
 */
export declare function mediaCost(entries: readonly GenCatalogEntry[], outputs: number): {
    amount: number;
} | {
    unknown: true;
};
/**
 * The tag a media model's line opens on when the router read no prompt: the
 * tag the person rated it highest for, then the first work its facts name,
 * then the kind's first tag.
 * @param kind - the kind of model.
 * @param model - the endpoint id.
 * @param ratings - the person's ratings.
 * @returns a tag on the kind's list.
 */
export declare function mediaTagFor(kind: Exclude<RatingKind, 'chat'>, model: string, ratings: RatingsFile): string;
/**
 * Whether the person has starred any model of a kind. Without one, the router
 * leaves media alone and asks Jev nothing.
 * @param ratings - the person's ratings.
 * @param kind - the kind of model.
 */
export declare function hasStarsFor(ratings: RatingsFile, kind: Exclude<RatingKind, 'chat'>): boolean;
//# sourceMappingURL=media.d.ts.map