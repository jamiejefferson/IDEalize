/**
 * Jev, TypeSafe's decision model, reached through OpenRouter's Decisions
 * endpoint with the user's own OpenRouter key. Jev answers closed questions
 * about a text and writes none, so the router asks it the two things only a
 * reader of the message can know (what kind of task this is, and how hard)
 * and does the rest itself. The endpoint is marked alpha by OpenRouter; its
 * address is config so a move does not need a release.
 */
import type { TaskReading } from './tasks.ts';
export declare const JEV_URL = "https://openrouter.ai/api/alpha/decisions";
/**
 * Whether this process is the installed app. The desktop shell sets the version
 * only when packaged, and a plain Node run has no Electron version.
 */
export declare function isPackagedApp(env?: Readonly<Record<string, string | undefined>>, electron?: string | undefined): boolean;
/**
 * The address the router sends messages and the person's OpenRouter key to.
 * It is a settings field so a move by OpenRouter needs no release in a
 * development run, and an installed app ignores it: one edited line in the
 * settings file would otherwise send every message and the key to any server.
 * @param configured - the settings field.
 * @param packaged - whether this is the installed app.
 * @returns the address to use.
 */
export declare function jevAddress(configured: string | undefined, packaged?: boolean): string;
/**
 * Whether a provider's address is on this computer. The free-tokens engine also
 * listens on this computer, but passes each request to outside companies, so
 * its route never counts.
 * @param provider - the route name.
 * @param baseURL - the route's address, when it has its own.
 * @returns true for a model that runs on this computer.
 */
export declare function isLocalModelRoute(provider: string, baseURL: unknown): boolean;
/** OpenRouter's alias for the newest Jev. */
export declare const JEV_MODEL = "~typesafe/jev-latest";
/** A turn never waits longer than this on the router; past it the local rules answer. */
export declare const JEV_TIMEOUT_MS = 1500;
interface ChoiceQuestion {
    type: 'choice';
    instructions: string;
    criteria: Record<string, string>;
}
export interface JevRequest {
    state: string;
    model: string;
    questions: Record<string, ChoiceQuestion>;
}
interface ChoiceAnswer {
    choice?: string;
    confidence?: number;
    probabilities?: Record<string, number>;
}
export interface JevResponse {
    answers?: Record<string, ChoiceAnswer>;
    usage?: {
        input_tokens?: number;
        cost?: number;
    };
}
/**
 * The request for one message.
 * @param message - the user's latest message, the only user content that leaves the machine.
 * @param brain - the chat's brain name and instructions, which say what the chat is for.
 * @returns the body to post.
 */
export declare function requestFor(message: string, brain?: {
    name: string;
    instructions?: string | undefined;
}): JevRequest;
/**
 * Jev's answers as a reading. The confidence is Jev's own for the task, held
 * down by an unsure difficulty: a task known at 0.9 whose difficulty is a
 * coin toss is not a 0.9 reading of what the turn needs.
 * @param response - the parsed reply.
 * @returns the reading, or undefined when the reply names no known task.
 */
export declare function readingFrom(response: JevResponse): TaskReading | undefined;
export type JevFailure = 'no-key' | 'refused-key' | 'no-credit' | 'rate-limited' | 'timeout' | 'unreachable' | 'unreadable';
export interface JevResult {
    reading?: TaskReading;
    failure?: JevFailure;
    /** What OpenRouter charged for the call, in USD, when it says. */
    cost?: number;
    inputTokens?: number;
    ms: number;
}
export interface AskOptions {
    key: string | undefined;
    url?: string;
    timeoutMs?: number;
    fetch?: typeof globalThis.fetch;
    now?: () => number;
}
/** What one call to Jev came back with: its answers, or the reason there are none. */
export interface JevCall {
    body?: JevResponse;
    failure?: Exclude<JevFailure, 'unreadable'>;
    ms: number;
}
/**
 * Send one request to Jev. Never throws: every failure comes back named.
 * @param request - the body to post.
 * @param options - the user's OpenRouter key and the transport.
 * @returns the parsed answers or the failure, with the time the call took.
 */
export declare function postJev(request: JevRequest, options: AskOptions): Promise<JevCall>;
/**
 * What OpenRouter charged and how much Jev read, when the reply says.
 * @param body - the parsed reply.
 * @returns the cost and input tokens that are present.
 */
export declare function usageOf(body: JevResponse | undefined): {
    cost?: number;
    inputTokens?: number;
};
/**
 * Ask Jev about one message. Never throws: every failure comes back named, so
 * the caller falls to the local rules and the settings can say why.
 * @param request - the body from {@link requestFor}.
 * @param options - the user's OpenRouter key and the transport.
 * @returns the reading or the failure, with the time the call took.
 */
export declare function askJev(request: JevRequest, options: AskOptions): Promise<JevResult>;
export {};
//# sourceMappingURL=jev.d.ts.map