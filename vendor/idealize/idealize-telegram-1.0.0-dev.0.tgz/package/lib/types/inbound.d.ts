/**
 * Routes each Telegram update. `/pair <code>` from a private chat is the only
 * thing a stranger can do; every other message and button press is ignored
 * unless it comes from the paired person in the paired chat. From them, a message older than the
 * stale limit is refused (it was sent while the app was closed), a question
 * waiting for typed input takes the text, a command runs, and anything else
 * is posted to the Studio exactly as if typed in the Studio chat.
 * @module @idealize/telegram/inbound
 */
import type { TelegramUpdate } from './api.ts';
import type { PairingClaim, PairingClaimant } from './pairing.ts';
import { type Messenger, type Services } from './ports.ts';
import type { Relay } from './relay.ts';
import type { Typing } from './typing.ts';
/** What the router needs from its owner. */
export interface InboundOptions {
    messenger: Messenger;
    services: Services;
    relay: Pick<Relay, 'press' | 'takeText' | 'pendingCount'>;
    /** The phone's "typing…", started once a note reaches the Studio coordinator. */
    typing: Pick<Typing, 'start'>;
    /** The paired chat id; empty when unpaired. */
    pairedChat(): string;
    /** The paired user id; empty when unpaired. */
    pairedUser(): string;
    /** Try a pairing code; a match waits for the person to allow the claimant in the app window. */
    claimPairing(claimant: PairingClaimant, code: string): Promise<PairingClaim>;
    /** Messages older than this, in milliseconds, are refused. */
    staleAfterMs: number;
    /** The clock (tests pin it). */
    now?(): number;
}
/** The update router. */
export declare class Inbound {
    private readonly options;
    constructor(options: InboundOptions);
    /**
     * Route one update.
     * @param update - the update from `getUpdates`.
     */
    handle(update: TelegramUpdate): Promise<void>;
    /** Whether a message or press comes from the paired person in the paired chat. */
    private isPaired;
    private onMessage;
    private onPress;
    private roster;
    private post;
    private status;
    private askToStop;
    private stop;
}
//# sourceMappingURL=inbound.d.ts.map