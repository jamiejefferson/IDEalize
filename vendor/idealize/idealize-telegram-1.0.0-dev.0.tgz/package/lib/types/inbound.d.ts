/**
 * Routes each Telegram update. `/pair <code>` is the only thing a stranger's
 * chat can do; every other message and button press is ignored unless it
 * comes from the paired chat. From the paired chat, a message older than the
 * stale limit is refused (it was sent while the app was closed), a question
 * waiting for typed input takes the text, a command runs, and anything else
 * is posted to the Studio exactly as if typed in the Studio chat.
 * @module @idealize/telegram/inbound
 */
import type { TelegramUpdate } from './api.ts';
import type { PairingClaim } from './pairing.ts';
import { type Messenger, type Services } from './ports.ts';
import type { Relay } from './relay.ts';
import type { Typing } from './typing.ts';
/** What the router needs from its owner. */
export interface InboundOptions {
    messenger: Messenger;
    services: Services;
    relay: Pick<Relay, 'press' | 'takeText' | 'pendingCount'>;
    /** The phone's "typing…", started once a note reaches the Studio coordinator. */
    typing: Pick<Typing, 'start'>;
    /** The paired chat id; empty when unpaired. */
    pairedChat(): string;
    /** Try a pairing code for a chat, binding it on success. */
    claimPairing(chatId: string, code: string): Promise<PairingClaim>;
    /** Messages older than this, in milliseconds, are refused. */
    staleAfterMs: number;
    /** The clock (tests pin it). */
    now?(): number;
}
/** The update router. */
export declare class Inbound {
    private readonly options;
    constructor(options: InboundOptions);
    /**
     * Route one update.
     * @param update - the update from `getUpdates`.
     */
    handle(update: TelegramUpdate): Promise<void>;
    private onMessage;
    private onPress;
    private roster;
    private post;
    private status;
    private askToStop;
    private stop;
}
//# sourceMappingURL=inbound.d.ts.map