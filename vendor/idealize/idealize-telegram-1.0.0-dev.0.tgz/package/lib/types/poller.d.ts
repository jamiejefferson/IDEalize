/**
 * The long-poll loop: hold `getUpdates` open, hand each update to the router
 * in order, advance the offset past it, and back off on failure. Telegram
 * forgets an update once a later poll names an offset past it, so a crash
 * mid-batch re-delivers only what was not yet acknowledged.
 * @module @idealize/telegram/poller
 */
import { type BotApi, type TelegramUpdate } from './api.ts';
/** Why the loop is not receiving messages. */
export type PollerProblem = 
/** No bot token is stored; the loop waits for one. */
{
    kind: 'no-token';
}
/** Another client polls this bot; the loop keeps retrying on its backoff without taking the updates. */
 | {
    kind: 'conflict';
}
/** Telegram refused the token; the loop waits for a new one. */
 | {
    kind: 'unauthorized';
    message: string;
}
/** A retryable failure. */
 | {
    kind: 'failed';
    message: string;
};
/** What the loop needs from its owner. */
export interface PollerOptions {
    /** How long Telegram may hold each poll open, in seconds. */
    holdSeconds: number;
    /** Waits between consecutive failures; the last entry repeats. */
    retryDelaysMs: readonly number[];
    /** A client for the current token, resolved before every poll; undefined when no token is stored. */
    bot(): Promise<BotApi | undefined>;
    /** Handle one update. A rejection is reported through `onError` and the loop moves past the update. */
    onUpdate(update: TelegramUpdate): Promise<void>;
    /** The loop's current problem; undefined once a poll succeeds. */
    onProblem(problem: PollerProblem | undefined): void;
    /** An update handler failed. */
    onError(error: unknown): void;
    /** Wait, resolving early when the signal aborts (tests replace it). */
    sleep?(ms: number, signal: AbortSignal): Promise<void>;
}
/** Runs one polling loop at a time. */
export declare class Poller {
    private readonly options;
    private readonly loop;
    constructor(options: PollerOptions);
    /** Start the loop, or restart it so the next poll uses the current token. */
    restart(): void;
    /**
     * Stop the loop.
     * @returns once the in-flight poll has unwound.
     */
    stop(): Promise<void>;
    private run;
}
//# sourceMappingURL=poller.d.ts.map