/**
 * @idealize/telegram — direct the Studio from a phone. A Telegram bot the
 * person creates is polled from inside the running app (no server, no public
 * URL), so the bot answers only while IDEalize is open.
 *
 * - Inbound: text from the paired chat is posted to the Studio as if typed in
 *   the Studio chat; `/status`, `/agents` and `/stop` read and stop agents;
 *   buttons answer approvals and questions.
 * - Outbound: coordinator posts, task endings, attention alerts, agent errors,
 *   and every pending approval and question, each behind a settings toggle.
 *
 * The bot token is a credential (`IDEALIZE_TELEGRAM_BOT_TOKEN`), resolved on
 * every poll. The paired chat id and the toggles live in the
 * `idealize-telegram` settings section. The routes are in `./routes.ts`.
 *
 * This plugin declares no required injection: every service it calls is
 * optional, read through `ctx.get` when used, and a composition without one
 * loses that feature only.
 * @module @idealize/telegram
 */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import { type PollerProblem } from './poller.ts';
export { BotApi, MESSAGE_LIMIT, splitText, TelegramApiError } from './api.ts';
export type { InlineButton, TelegramErrorKind, TelegramUpdate } from './api.ts';
export { PAIR_PATH, STATUS_PATH, TOKEN_PATH } from './routes.ts';
export { FORWARD_KEYS, TELEGRAM_SETTINGS_NAMESPACE, TelegramSettingsSchema } from './settings.ts';
export type { ForwardKey, TelegramSettings, TelegramStatus } from './settings.ts';
export declare const name = "idealize-telegram";
/** The credential the bot token is stored under. */
export declare const TOKEN_ENV = "IDEALIZE_TELEGRAM_BOT_TOKEN";
/** Validated configuration: where Telegram is and how patiently to talk to it. */
export interface Config {
    /** The Bot API origin, without a trailing slash. */
    apiBase: string;
    /** How long Telegram may hold each poll open, in seconds. */
    holdSeconds: number;
    /** Longest wait for an ordinary Bot API call, in milliseconds. */
    requestTimeoutMs: number;
    /** Waits between consecutive polling failures, in milliseconds; the last repeats. */
    retryDelaysMs: number[];
    /** Messages older than this are refused as sent while the app was closed, in minutes. */
    staleAfterMinutes: number;
    /** How long a pairing code stays claimable, in minutes. */
    pairCodeTtlMinutes: number;
    /** Wrong pairing codes accepted before the live code is withdrawn. */
    maxWrongPairCodes: number;
    /** Wait before reopening the approvals stream after it ends, in milliseconds. */
    muxReopenDelayMs: number;
}
export declare const Config: z<Config>;
/**
 * The plain-words problem the Settings row shows.
 * @param problem - the poller's problem.
 * @returns the line, or empty when there is nothing to say.
 */
export declare function problemText(problem: PollerProblem | undefined): string;
/**
 * Compose the bot: poller, relay, forwarders and routes.
 * @param ctx - the Cordis context.
 * @param config - the validated configuration.
 */
export declare function apply(ctx: Context, config: Config): void;
//# sourceMappingURL=index.d.ts.map