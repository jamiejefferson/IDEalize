/**
 * The {@link Messenger} bound to the current token and paired chat, both
 * resolved on every call so a changed token or an unpair takes effect on the
 * next message.
 * @module @idealize/telegram/messenger
 */
import type { BotApi } from './api.ts';
import type { Messenger } from './ports.ts';
/** Where the messenger reads its token and chat. */
export interface MessengerSource {
    /** A client for the current token; undefined when none is stored. */
    bot(): Promise<BotApi | undefined>;
    /** The paired chat id; empty when unpaired. */
    chatId(): string;
}
/**
 * Bind a messenger to its source.
 * @param source - the token and chat lookups.
 * @returns the messenger.
 */
export declare function createMessenger(source: MessengerSource): Messenger;
//# sourceMappingURL=messenger.d.ts.map