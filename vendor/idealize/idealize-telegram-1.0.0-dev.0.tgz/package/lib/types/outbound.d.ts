/**
 * What the app tells the paired chat without being asked: the Studio
 * coordinator's posts, task endings on project timelines, the Studio's
 * attention alerts and agent errors. Each kind has its own settings toggle.
 *
 * Task endings on the Studio's own timeline are not sent separately: the
 * Studio already posts those as messages there, which arrive as coordinator
 * posts. The bridge's `agent-finished` is not sent at all, because it fires
 * every time an agent goes idle, which is every turn.
 * @module @idealize/telegram/outbound
 */
import type { BridgeEvent } from '@idealize/host-bridge';
import { type StudioEvent } from '@idealize/studio';
import { type Messenger, type Services } from './ports.ts';
import type { TelegramSettings } from './settings.ts';
import type { Typing } from './typing.ts';
/** What the forwarder needs from its owner. */
export interface OutboundOptions {
    messenger: Messenger;
    services: Services;
    /** The phone's "typing…", stopped when the coordinator's reply goes out or its turn ends. */
    typing: Pick<Typing, 'stop'>;
    /** The settings in force, read per event. */
    settings(): TelegramSettings;
}
/** Forwards Studio events and bridge events to the paired chat. */
export declare class Outbound {
    private readonly options;
    constructor(options: OutboundOptions);
    /**
     * Forward one committed Studio event when a toggle asks for it.
     * @param event - the recorded event.
     */
    onStudioEvent(event: StudioEvent): Promise<void>;
    /**
     * Forward one bridge event when a toggle asks for it.
     * @param event - the bridge event.
     */
    onBridgeEvent(event: BridgeEvent): Promise<void>;
    private name;
    private isStudioCoordinator;
}
//# sourceMappingURL=outbound.d.ts.map