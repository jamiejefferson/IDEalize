/**
 * Restartable background loops for the poller and the approvals relay: one
 * run at a time, a restart aborts the current run and starts the next once
 * it has unwound, and waits end early when the run is stopped.
 * @module @idealize/telegram/loop
 */
/**
 * Wait, resolving early when the signal aborts.
 * @param ms - how long to wait.
 * @param signal - ends the wait early.
 * @returns once the time has passed or the signal has aborted.
 */
export declare function abortableSleep(ms: number, signal: AbortSignal): Promise<void>;
/**
 * Whether the signal has aborted, read when called. A run checks this after
 * every await; reading `signal.aborted` directly would be narrowed to the
 * value seen at the loop condition, which an await can change.
 * @param signal - the run's signal.
 * @returns whether the run was stopped.
 */
export declare function aborted(signal: AbortSignal): boolean;
/** Runs one background loop at a time. */
export declare class RestartableLoop {
    private readonly body;
    private controller;
    private running;
    /** @param body - one run; it must return once its signal aborts. */
    constructor(body: (signal: AbortSignal) => Promise<void>);
    /** Start a run, or stop the current one and start the next once it has unwound. */
    restart(): void;
    /**
     * Stop the current run.
     * @returns once the run has unwound.
     */
    stop(): Promise<void>;
}
//# sourceMappingURL=loop.d.ts.map