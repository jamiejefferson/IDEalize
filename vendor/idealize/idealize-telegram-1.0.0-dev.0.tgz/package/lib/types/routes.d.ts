/**
 * The Settings row's loopback routes. `GET /idealize/telegram/status` answers
 * what the row shows; `POST /idealize/telegram/token` checks and stores a bot
 * token (an empty token removes it); `POST /idealize/telegram/pair` issues a
 * pairing code and `DELETE /idealize/telegram/pair` unpairs. A new token and a
 * claimed pairing take effect only after `POST /idealize/telegram/confirm`,
 * which the Settings row sends when the person presses Allow or Decline.
 * Mutations carry the `x-idealize-auth: 1` header.
 * @module @idealize/telegram/routes
 */
import type { Context } from '@deepseek-ai/cordis';
import type { TelegramStatus } from './settings.ts';
/** Status path. */
export declare const STATUS_PATH = "/idealize/telegram/status";
/** Token path. */
export declare const TOKEN_PATH = "/idealize/telegram/token";
/** Pairing path. */
export declare const PAIR_PATH = "/idealize/telegram/pair";
/** Confirmation path. */
export declare const CONFIRM_PATH = "/idealize/telegram/confirm";
/** An HTTP answer the runtime chose. */
export interface RouteOutcome {
    status: number;
    body: TelegramStatus | {
        error: string;
    };
}
/** The operations behind the routes. */
export interface TelegramRoutesRuntime {
    status(): Promise<TelegramStatus>;
    setToken(token: string): Promise<RouteOutcome>;
    pair(): Promise<RouteOutcome>;
    /** Allow or decline what waits in the app window. */
    confirm(what: 'token' | 'pairing', allow: boolean): Promise<RouteOutcome>;
    unpair(): Promise<RouteOutcome>;
}
/**
 * Mount the routes once a web server is composed.
 * @param ctx - the plugin context.
 * @param runtime - the operations the routes perform.
 */
export declare function installTelegramRoutes(ctx: Context, runtime: TelegramRoutesRuntime): void;
//# sourceMappingURL=routes.d.ts.map