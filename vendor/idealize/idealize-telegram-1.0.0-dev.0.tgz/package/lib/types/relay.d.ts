/**
 * Approvals and questions over Telegram. The relay reads the API proxy's mux
 * stream in-process, the same stream the app window reads, so it sees every
 * pending approval and question with the id that answers it. It sends each
 * one to the paired chat with buttons and answers through `respond`. The
 * first answer wins: when the window answers first, `respond` reports the
 * request as no longer pending and the relay says so on the phone; when the
 * phone answers first, the window receives the resolved frame and clears.
 *
 * Buttons carry a short id into this process's table, because Telegram caps
 * button data at 64 bytes. After a restart the table is empty, the old
 * buttons answer "no longer waiting", and the mux replay sends the requests
 * still pending as new messages.
 * @module @idealize/telegram/relay
 */
import type { ApiProxy, MuxFrame, RpcRequest } from '@deepseek-ai/dsh-host-apiproxy';
import type { Messenger } from './ports.ts';
/** The API proxy calls the relay makes. */
export type ApiProxyPort = Pick<ApiProxy, 'events' | 'respond'>;
/** What the relay needs from its owner. */
export interface RelayOptions {
    messenger: Messenger;
    /** The API proxy; undefined when the composition lacks it. */
    api(): ApiProxyPort | undefined;
    /** The name a person knows a session by. */
    nameOf(sessionId: string): Promise<string>;
    /** Whether approvals and questions are forwarded; read when a request arrives. */
    enabled(): boolean;
    /** Wait before reopening a mux stream that ended or failed. */
    reopenDelayMs: number;
    onError(error: unknown): void;
    /** Wait, resolving early when the signal aborts (tests replace it). */
    sleep?(ms: number, signal: AbortSignal): Promise<void>;
}
/** Forwards pending approvals and questions and settles them from button presses. */
export declare class Relay {
    private readonly options;
    private readonly entries;
    private readonly byKey;
    private counter;
    private readonly loop;
    constructor(options: RelayOptions);
    /**
     * How many approvals and questions are on the phone waiting for an answer.
     * @returns the count of sent, unsettled requests.
     */
    pendingCount(): number;
    /** Open the mux stream, or reopen it so every still-pending request is offered again. */
    restart(): void;
    /**
     * Close the mux stream.
     * @returns once the stream has unwound.
     */
    stop(): Promise<void>;
    private run;
    /**
     * Act on one mux frame. Frames other than the four approval and question
     * frames are ignored.
     * @param envelope - the frame with its server-request id.
     */
    handle(envelope: RpcRequest<MuxFrame>): Promise<void>;
    private dispatch;
    /**
     * Act on a button press whose data belongs to the relay.
     * @param queryId - the callback query to acknowledge.
     * @param data - the button's data.
     * @returns false when the data is not an approval or question button.
     */
    press(queryId: string, data: string): Promise<boolean>;
    /**
     * Hand a text message to the question waiting for typed input.
     * @param text - the message.
     * @returns false when no question is waiting for text.
     */
    takeText(text: string): Promise<boolean>;
    private answerApproval;
    private pressQuestion;
    /** Show the next question, or send the answers once every question has one. */
    private advance;
    private settle;
    private claim;
    private forget;
}
//# sourceMappingURL=relay.d.ts.map