/**
 * The "typing…" shown on the phone while the Studio coordinator works on a
 * note from there (JJ, 15 Sep 2026: "there's no 'typing' message in telegram
 * so it doesn't look like its working"). Telegram shows a chat action for
 * about five seconds, so the indicator is a repeated action: started when a
 * note reaches the coordinator, stopped when its reply is forwarded or its
 * turn ends, and capped so a turn that ends unseen cannot leave the phone
 * "typing" forever.
 * @module @idealize/telegram/typing
 */
import type { Messenger } from './ports.ts';
/** What the indicator needs from its owner. */
export interface TypingOptions {
    messenger: Pick<Messenger, 'typing'>;
    /** Milliseconds between repeats; Telegram clears an action after about five seconds. */
    intervalMs?: number;
    /** Milliseconds after which an indicator nobody stopped stops itself. */
    maxMs?: number;
    /** Where a failed action goes; the indicator never throws into its caller. */
    onError: (error: unknown) => void;
}
/** One paired chat's typing indicator. */
export declare class Typing {
    private readonly options;
    private timer;
    private cap;
    constructor(options: TypingOptions);
    /** Show typing now and keep showing it until {@link stop} or the cap; a repeat start restarts the cap. */
    start(): void;
    /** Stop repeating; the action Telegram already shows fades on its own. */
    stop(): void;
    /** Whether the indicator is running. */
    get active(): boolean;
    private show;
}
//# sourceMappingURL=typing.d.ts.map