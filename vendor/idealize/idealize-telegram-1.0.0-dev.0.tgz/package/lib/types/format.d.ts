/**
 * Every line the bot sends. Kept in one module so the wording is reviewed in
 * one place and the routers stay free of copy.
 * @module @idealize/telegram/format
 */
import type { AskUserQuestionItem } from '@deepseek-ai/dsh-user-questions';
import { type StudioChatPost, type StudioOverviewProject } from '@idealize/studio';
import type { PairingClaim } from './pairing.ts';
import { type Keyboard, type RosterRow } from './ports.ts';
/** The reply to `/help`, `/start` and any unknown command. */
export declare const HELP_TEXT: string;
/** Replies to `/pair <code>`, by outcome. */
export declare const PAIR_REPLIES: Readonly<Record<PairingClaim, string>>;
/** Lines the update router sends. */
export declare const INBOUND_TEXT: {
    readonly stale: "IDEalize was closed when you sent this, so nothing happened. Send it again.";
    readonly noStudio: "The Studio is not running in this app, so the message has nowhere to go.";
    readonly stopWho: "Say which agent to stop, for example /stop Ada.";
    readonly notRunning: (name: string) => string;
    readonly confirmStop: (name: string) => string;
    readonly stopButton: "Stop";
    readonly keepButton: "Keep running";
    readonly stopped: (name: string) => string;
    readonly keptRunning: "Left running.";
};
/** Button labels and toasts for approvals and questions. */
export declare const ANSWER_TEXT: {
    readonly allow: "Allow once";
    readonly deny: "Deny";
    readonly allowed: "Allowed";
    readonly denied: "Denied";
    readonly already: "Already answered in the app.";
    readonly gone: "No longer waiting.";
    readonly typeIt: "Type your answer as a message.";
    readonly answered: "Answered.";
    readonly cancelled: "Withdrawn before anyone answered.";
    readonly other: "Other (type it)";
    readonly done: "Done";
};
/**
 * The name a person knows a project by.
 * @param project - the timeline key.
 * @returns `Studio` for the Studio's own timeline, else the folder name.
 */
export declare function projectName(project: string): string;
/**
 * The approval request message.
 * @param name - who asks.
 * @param toolName - the tool it wants to run.
 * @param reason - why the tool needs approval, when the ask gives one.
 * @returns the message text.
 */
export declare function approvalText(name: string, toolName: string, reason?: string): string;
/**
 * The approval message once settled.
 * @param name - who asked.
 * @param toolName - the tool.
 * @param outcome - how it settled.
 * @returns the replacement text.
 */
export declare function approvalOutcomeText(name: string, toolName: string, outcome: string): string;
/**
 * One question's message.
 * @param name - who asks.
 * @param item - the question.
 * @param index - its position, from 0.
 * @param total - how many questions the request holds.
 * @returns the message text.
 */
export declare function questionText(name: string, item: AskUserQuestionItem, index: number, total: number): string;
/**
 * One question's buttons: one row per option, then Other, then Done on a
 * multi-select question. A question with no options has no buttons; the
 * next message answers it.
 * @param short - the relay's id for the request.
 * @param item - the question.
 * @param selected - options already ticked.
 * @returns the keyboard rows.
 */
export declare function questionKeyboard(short: string, item: AskUserQuestionItem, selected: readonly string[]): Keyboard;
/**
 * The reply to `/status`.
 * @param overview - every project's folded state.
 * @param roster - every agent.
 * @param waiting - approvals and questions on the phone.
 * @returns the message text.
 */
export declare function statusText(overview: readonly StudioOverviewProject[], roster: readonly RosterRow[], waiting: number): string;
/**
 * The reply to `/agents`.
 * @param roster - every agent.
 * @returns the message text.
 */
export declare function agentsText(roster: readonly RosterRow[]): string;
/**
 * What to tell the person after a message is posted to the Studio. A plain
 * delivery to the coordinator needs no reply, because its answer follows.
 * @param post - where the post landed.
 * @param roster - every agent, for names.
 * @returns the reply, or undefined when none is needed.
 */
export declare function chatPostReply(post: StudioChatPost, roster: readonly RosterRow[]): string | undefined;
/**
 * A coordinator post.
 * @param name - the author.
 * @param body - the post.
 * @returns the message text.
 */
export declare function studioPostText(name: string, body: string): string;
/**
 * A task ending on a project timeline.
 * @param words - how the Studio says the task ended.
 * @param project - the timeline key.
 * @param goal - the task's goal, when known.
 * @param outcome - the outcome the agent gave.
 * @returns the message text.
 */
export declare function taskEndingText(words: string, project: string, goal: string | undefined, outcome: string): string;
/**
 * A Studio attention alert.
 * @param title - the alert title.
 * @param body - the alert detail.
 * @returns the message text.
 */
export declare function alertText(title: string, body: string): string;
/**
 * An agent error.
 * @param name - the agent, when the error names a session.
 * @param detail - the error message.
 * @returns the message text.
 */
export declare function errorText(name: string | undefined, detail: string): string;
//# sourceMappingURL=format.d.ts.map