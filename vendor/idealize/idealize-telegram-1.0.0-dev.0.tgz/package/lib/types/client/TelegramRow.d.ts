import type { SnapshotStore } from '@deepseek-ai/dsh-client-runtime/client';
import type { InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import { type ForwardKey, type TelegramStatus } from '../settings.ts';
/** What the row renders. */
export interface TelegramRowState {
    /** The host's answer; undefined until the first read. */
    status: TelegramStatus | undefined;
    forward: Record<ForwardKey, boolean>;
    /** A route call is in flight. */
    busy: boolean;
    /** The last route refusal, in the host's words; empty when none. */
    error: string;
}
/** Registration-side face. */
export interface TelegramRowInjected {
    hooks: {
        telegram: SnapshotStore<TelegramRowState>;
    };
    /** Re-read the host status. */
    refresh: () => void;
    /** Check and store a token; empty removes it. */
    saveToken: (token: string) => void;
    pair: () => void;
    unpair: () => void;
    setForward: (key: ForwardKey, value: boolean) => void;
}
/** Full Settings-row props. */
export type TelegramRowProps = PropsRuntime<'settings.general.item'> & PropsLocale<'idealize-telegram'> & InjectFace<TelegramRowInjected>;
/**
 * Render the Telegram remote row.
 * @param props - composed Settings slot props.
 */
export declare function TelegramRow({ useTelegram, refresh, saveToken, pair, unpair, setForward, t }: TelegramRowProps): import("react").JSX.Element;
//# sourceMappingURL=TelegramRow.d.ts.map