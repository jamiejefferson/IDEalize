/** `idealize-telegram` namespace dictionaries: the Settings row. */
/** Simplified Chinese dictionary (the key-set source of truth). */
export declare const zh: {
    readonly 'telegram.title': "Telegram 远程控制";
    readonly 'telegram.description': "IDEalize 打开时，在手机上指挥工作室并处理审批。";
    readonly 'telegram.token.label': "机器人令牌";
    readonly 'telegram.token.placeholder': "粘贴 @BotFather 给你的令牌";
    readonly 'telegram.token.save': "连接";
    readonly 'telegram.token.remove': "移除令牌";
    readonly 'telegram.token.shadowed': "令牌由环境变量设置，无法在此更改。";
    readonly 'telegram.connected': "已连接到";
    readonly 'telegram.pair': "配对";
    readonly 'telegram.pair.send': "在 Telegram 中向机器人发送：";
    readonly 'telegram.pair.expires': "该代码几分钟后失效。";
    readonly 'telegram.paired': "已与你的 Telegram 聊天配对。";
    readonly 'telegram.unpair': "取消配对";
    readonly 'telegram.forward.forwardStudioReplies': "工作室协调员的回复";
    readonly 'telegram.forward.forwardTaskEndings': "任务结束";
    readonly 'telegram.forward.forwardAttention': "需要你关注的提醒和错误";
    readonly 'telegram.forward.forwardApprovals': "审批和问题";
};
/** Translation key set. */
export type TelegramKey = keyof typeof zh;
/** English dictionary. */
export declare const en: Record<TelegramKey, string>;
//# sourceMappingURL=locales.d.ts.map