/**
 * @idealize/telegram, browser half: the Telegram remote row in General
 * settings. The row reads the host status route, stores a token through the
 * token route (the token never enters the settings document), issues and
 * withdraws pairing codes, and flips the forward toggles in the
 * `idealize-telegram` settings section. While a pairing code is live it
 * re-reads the status so the row turns to "paired" once the phone sends the
 * code.
 */
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
import { type TelegramKey } from './locales.ts';
export { TelegramRow } from './TelegramRow.tsx';
export type { TelegramKey } from './locales.ts';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** The Telegram remote row's copy. */
        'idealize-telegram': TelegramKey;
    }
}
/** Required services. */
export declare const inject: string[];
/**
 * Client plugin body.
 * @param ctx - client root context.
 */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map