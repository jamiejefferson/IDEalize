/** The Settings row's calls to the host routes. */
import type { TelegramStatus } from '../settings.ts';
/**
 * Call one Telegram route.
 * @param method - `GET` reads; the others mutate and carry the auth header.
 * @param path - the route.
 * @param body - the JSON body.
 * @returns the status the route answers.
 */
export declare function telegramCall(method: 'GET' | 'POST' | 'DELETE', path: string, body?: object): Promise<TelegramStatus>;
//# sourceMappingURL=api.d.ts.map