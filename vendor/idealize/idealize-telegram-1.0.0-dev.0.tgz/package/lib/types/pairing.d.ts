/**
 * One-time pairing codes. The app shows a code; the person sends `/pair <code>`
 * to the bot; the chat that sent a live code becomes the only chat the bot
 * obeys. Codes are single-use, expire, and die after too many wrong guesses,
 * because anyone who learns the bot's username can message it.
 * @module @idealize/telegram/pairing
 */
/** A code waiting to be claimed. */
export interface PairingCode {
    code: string;
    /** Epoch milliseconds after which the code no longer pairs. */
    expiresAt: number;
}
/** The outcome of one `/pair` attempt. */
export type PairingClaim = 'paired' | 'no-code' | 'expired' | 'wrong';
/** Issues and checks pairing codes. At most one code is live. */
export declare class Pairing {
    private readonly ttlMs;
    private readonly maxWrongGuesses;
    private readonly now;
    private live;
    private wrongGuesses;
    /**
     * @param ttlMs - how long a code stays claimable.
     * @param maxWrongGuesses - wrong codes accepted before the live code is withdrawn.
     * @param now - the clock (tests pin it).
     */
    constructor(ttlMs: number, maxWrongGuesses: number, now?: () => number);
    /**
     * Issue a fresh six-digit code, replacing any live one.
     * @returns the code and its expiry.
     */
    issue(): PairingCode;
    /**
     * The live code, when one is claimable.
     * @returns the code, or undefined when none is live or it has expired.
     */
    pending(): PairingCode | undefined;
    /** Withdraw the live code. */
    cancel(): void;
    /**
     * Try a code. A match consumes it.
     * @param code - what the person sent.
     * @returns whether it paired, or why not.
     */
    claim(code: string): PairingClaim;
}
//# sourceMappingURL=pairing.d.ts.map