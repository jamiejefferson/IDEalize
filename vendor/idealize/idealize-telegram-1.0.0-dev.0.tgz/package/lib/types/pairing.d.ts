/**
 * One-time pairing codes. The app shows a code; the person sends `/pair <code>`
 * to the bot from a private chat; the app window names who sent it and asks the
 * person to allow them; that person in that chat becomes the only one the bot
 * obeys. Codes are single-use, expire, and die after too many wrong guesses,
 * because anyone who learns the bot's username can message it.
 * @module @idealize/telegram/pairing
 */
/** A code waiting to be claimed. */
export interface PairingCode {
    code: string;
    /** Epoch milliseconds after which the code no longer pairs. */
    expiresAt: number;
}
/** The outcome of one `/pair` attempt. */
export type PairingClaim = 'confirm' | 'not-private' | 'no-code' | 'expired' | 'wrong';
/** Who sent a code, held until the person allows or declines them in the app window. */
export interface PairingClaimant {
    /** The private chat, as decimal text. */
    chatId: string;
    /** The Telegram user, as decimal text. */
    userId: string;
    /** Their name as Telegram gives it: untrusted text, shown so the person can recognise it. */
    name: string;
}
/**
 * Who a stored pairing obeys. The bot obeys one person in one private chat.
 * A pairing stored before the user id was kept has only a chat id. In a private
 * chat Telegram uses the person's id as the chat id, so a positive chat id names
 * its user and keeps working. A negative id is a group, where anyone in the group
 * could direct the app, so that pairing stops working until the person pairs again.
 * @param stored - the stored pairing.
 * @param stored.chatId - the paired chat id; empty when unpaired.
 * @param stored.userId - the paired user id; empty on an older pairing.
 * @returns the chat and user to obey; undefined when none is valid.
 */
export declare function pairedIdentity(stored: {
    chatId: string;
    userId: string;
}): {
    chatId: string;
    userId: string;
} | undefined;
/** Issues and checks pairing codes. At most one code is live. */
export declare class Pairing {
    private readonly ttlMs;
    private readonly maxWrongGuesses;
    private readonly now;
    private live;
    private wrongGuesses;
    /**
     * @param ttlMs - how long a code stays claimable.
     * @param maxWrongGuesses - wrong codes accepted before the live code is withdrawn.
     * @param now - the clock (tests pin it).
     */
    constructor(ttlMs: number, maxWrongGuesses: number, now?: () => number);
    /**
     * Issue a fresh six-digit code, replacing any live one.
     * @returns the code and its expiry.
     */
    issue(): PairingCode;
    /**
     * The live code, when one is claimable.
     * @returns the code, or undefined when none is live or it has expired.
     */
    pending(): PairingCode | undefined;
    /** Withdraw the live code. */
    cancel(): void;
    /**
     * Try a code. A match consumes it.
     * @param code - what the person sent.
     * @returns `confirm` when the code matched, or why it did not.
     */
    claim(code: string): PairingClaim;
}
//# sourceMappingURL=pairing.d.ts.map