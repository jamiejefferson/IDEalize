/**
 * A thin client for the Telegram Bot API methods this plugin calls. Every
 * call is one HTTPS POST of JSON to `<apiBase>/bot<token>/<method>`; the
 * token sits in the URL, so no error message this module raises quotes the
 * URL.
 * @module @idealize/telegram/api
 */
/** Telegram's cap on one message's text, in UTF-16 code units (protocol constant). */
export declare const MESSAGE_LIMIT = 4096;
/** A chat as Telegram describes it. */
export interface TelegramChat {
    id: number;
    type: string;
}
/** One message, as far as this plugin reads it. */
export interface TelegramMessage {
    message_id: number;
    /** Unix seconds the message was sent. */
    date: number;
    chat: TelegramChat;
    text?: string;
}
/** A button press on an inline keyboard. */
export interface TelegramCallbackQuery {
    id: string;
    /** The button's `callback_data`. */
    data?: string;
    /** The message the keyboard belongs to; absent when Telegram no longer has it. */
    message?: TelegramMessage;
}
/** One entry from `getUpdates`. */
export interface TelegramUpdate {
    update_id: number;
    message?: TelegramMessage;
    callback_query?: TelegramCallbackQuery;
}
/** One inline-keyboard button. `data` is at most 64 bytes (protocol constant). */
export interface InlineButton {
    text: string;
    data: string;
}
/** What went wrong with a call, in the terms the poller acts on. */
export type TelegramErrorKind = 
/** Another client is polling the same bot (HTTP 409). */
'conflict'
/** The token is wrong or revoked (HTTP 401, or 404 for a malformed token). */
 | 'unauthorized'
/** Telegram asked the client to wait (HTTP 429). */
 | 'rate-limited'
/** Anything else: network failure, timeout, or another API refusal. */
 | 'failed';
/** A failed Bot API call. */
export declare class TelegramApiError extends Error {
    readonly kind: TelegramErrorKind;
    readonly retryAfterSeconds?: number | undefined;
    /**
     * @param kind - what the caller should do about it.
     * @param message - a plain description that never quotes the request URL.
     * @param retryAfterSeconds - the wait Telegram asked for, on `rate-limited`.
     */
    constructor(kind: TelegramErrorKind, message: string, retryAfterSeconds?: number | undefined);
}
/** How a client reaches Telegram. */
export interface BotApiOptions {
    token: string;
    /** The Bot API origin, without a trailing slash. */
    apiBase: string;
    fetchImpl: typeof fetch;
    /** Longest wait for an ordinary call, in milliseconds; a long poll adds its own hold on top. */
    requestTimeoutMs: number;
}
/**
 * Split text into pieces Telegram accepts, breaking at the last newline
 * inside the limit when there is one.
 * @param text - the whole message.
 * @param limit - the longest piece.
 * @returns the pieces in order; one empty piece for empty text.
 */
export declare function splitText(text: string, limit?: number): string[];
/** One bot's Bot API calls. */
export declare class BotApi {
    private readonly options;
    constructor(options: BotApiOptions);
    /**
     * Call one Bot API method.
     * @param method - the method name.
     * @param params - the JSON body.
     * @param signal - cancels the call.
     * @param holdMs - extra time the call may legitimately take (a long poll's hold).
     * @returns the `result` field.
     */
    call(method: string, params: object, signal?: AbortSignal, holdMs?: number): Promise<unknown>;
    /**
     * Check the token and learn the bot's name.
     * @param signal - cancels the call.
     * @returns the bot's id and @username.
     */
    getMe(signal?: AbortSignal): Promise<{
        id: number;
        username: string;
    }>;
    /**
     * Hold a long poll for new messages and button presses.
     * @param offset - one past the last update already handled.
     * @param holdSeconds - how long Telegram may hold the request open.
     * @param signal - cancels the poll.
     * @returns the updates, oldest first.
     */
    getUpdates(offset: number, holdSeconds: number, signal: AbortSignal): Promise<TelegramUpdate[]>;
    /**
     * Send text, split to Telegram's limit. Buttons ride on the last piece.
     * @param chatId - the chat.
     * @param text - the whole message.
     * @param buttons - inline keyboard rows.
     * @returns the id of the last message sent, which carries the buttons.
     */
    sendMessage(chatId: string, text: string, buttons?: readonly (readonly InlineButton[])[]): Promise<number>;
    /**
     * Replace a message's text and keyboard; no buttons removes the keyboard.
     * @param chatId - the chat.
     * @param messageId - the message.
     * @param text - the new text, cut to the limit.
     * @param buttons - the new keyboard rows.
     */
    editMessageText(chatId: string, messageId: number, text: string, buttons?: readonly (readonly InlineButton[])[]): Promise<void>;
    /**
     * Show a chat action ("typing…") in a chat; Telegram clears it after about
     * five seconds or at the bot's next message, so a longer wait repeats it.
     * @param chatId - the chat.
     * @param action - the action; `typing` unless given.
     */
    sendChatAction(chatId: string, action?: string): Promise<void>;
    /**
     * Stop a pressed button's spinner, optionally with a short toast.
     * @param queryId - the callback query.
     * @param text - the toast.
     */
    answerCallbackQuery(queryId: string, text?: string): Promise<void>;
}
//# sourceMappingURL=api.d.ts.map