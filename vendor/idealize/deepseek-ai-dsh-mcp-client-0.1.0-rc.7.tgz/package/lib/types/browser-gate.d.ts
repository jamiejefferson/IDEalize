/**
 * Asks the person before a chat runs a script in a Hatch page or moves Hatch to
 * a new site. Hatch's canvases can be logged in, and text inside a page reaches
 * the chat, so a hidden instruction on a page could have the chat read a
 * logged-in page with `evaluate` and then visit an attacker's address with the
 * data in the link. Saved passwords already ask, in Hatch itself.
 *
 * This runs on the "ask" approval setting only. A chat on Full access has chosen
 * not to be asked, and an ask there would be rejected outright. A place the person
 * allowed stays allowed for that chat until the app restarts, and the machine's
 * own dev servers and a chat's own project never ask.
 *
 * Tools live on the host, so generating chats (Images, Sounds, Video) hold these
 * too, and the gate covers them. A click on a page's own link, and a page's own
 * scripts, stay outside it, because Hatch alone sees where those lead.
 *
 * Turn it off with `browserGate: false` on the Hatch entry in the composition.
 *
 * @module @deepseek-ai/dsh-mcp-client/browser-gate
 */
import type { Context } from '@deepseek-ai/cordis';
/** The MCP server this gate watches. */
export declare const BROWSER_SERVER = "hatch";
/** Where an address leads, as the gate judges it. */
type Destination = 
/** Stays on this machine's dev servers, in a Hatch project, or inside the chat's folder. */
{
    kind: 'home';
}
/** A web site, by host name. */
 | {
    kind: 'site';
    host: string;
}
/** Anything else: a file elsewhere, another scheme, or a saved link's title. */
 | {
    kind: 'other';
    label: string;
};
/**
 * Judge one address in any form Hatch takes: a `hatch:` project address, a full
 * link, a bare domain, an absolute path, or the title of a saved link.
 * @param to - the address.
 * @param cwd - the chat's working folder.
 * @returns where it leads.
 */
export declare function destinationOf(to: string, cwd: string | undefined): Destination;
/**
 * Register the gate.
 * @param ctx - the plugin context.
 * @param serverName - the MCP server this client connects to.
 */
export declare function installBrowserGate(ctx: Context, serverName: string): void;
export {};
//# sourceMappingURL=browser-gate.d.ts.map