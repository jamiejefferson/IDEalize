/**
 * Writing the two trust fields IDEalize owns onto notes on disk.
 *
 * `generated` is stamped by the host after an agent's file tool has written a
 * Markdown file inside the documentation folder, so the record never depends
 * on a model remembering to write it. The hook is the `fs/observed` event the
 * file tools emit once a write or edit has landed: its actor is the tool
 * execution, which names the tool and the agent it ran for. A read emits the
 * same event, so only the mutating tools count, and a call with no agent (a
 * person or a host job writing through the registry) is left alone.
 *
 * `verified` gains the user's entry when the user asks for it from the Files
 * pane ("Mark as checked").
 */
import type { Context } from '@deepseek-ai/cordis';
/** Folders the stamp leaves alone when the setting is unset: chat transcripts, which the host writes. */
export declare const DEFAULT_STAMP_EXCLUDE: readonly string[];
/** The actor recorded when the user marks a note as checked. IDEalize holds no name or account for the user. */
export declare const USER_ACTOR = "human:user";
/** What the stamp reads off a tool execution's agent, kept structural so this package needs no agent runtime types. */
interface StampAgent {
    session: {
        header: {
            agentPreset?: string;
        };
        events: ReadonlyArray<{
            type: string;
            data?: unknown;
        }>;
        requestHeader(): {
            config: {
                model?: string;
            };
        } | undefined;
    };
}
/**
 * The agent whose file tool just changed a file, read from an `fs/observed` actor.
 * @param actor - the event's opaque actor, normally the tool execution.
 * @returns the agent when the execution is an agent's write or edit; `undefined` for a read, another tool, or a call with no agent.
 */
export declare function mutatingAgent(actor: object | undefined): StampAgent | undefined;
/**
 * The actor id of an IDEalize agent: `idealize/<brain>/<model>`. The brain is
 * the chat's recorded brain, else the agent preset it runs; the model is the
 * one its latest request went to.
 * @param agent - the agent that wrote the file.
 * @returns the actor id; a part the session does not record is left out, and a session that records neither reads `idealize/agent`.
 */
export declare function agentActor(agent: StampAgent): string;
/**
 * A file's path inside a folder, with symlinks resolved on both sides.
 * @param folder - the folder.
 * @param path - the file's path.
 * @returns the `/`-separated relative path, or `undefined` when the file is outside the folder or either path cannot be resolved.
 */
export declare function pathWithin(folder: string, path: string): Promise<string | undefined>;
/**
 * Whether a note sits in a folder the stamp leaves alone.
 * @param relPath - the note's `/`-separated path inside the documentation folder.
 * @param exclude - folder names or paths; each matches a folder of that name at any depth.
 * @returns true when one entry names a folder on the note's path.
 */
export declare function isStampExcluded(relPath: string, exclude: readonly string[]): boolean;
/** The settings the stamp reads at the moment a write lands. */
export interface StampSource {
    /** The configured documentation folder, or `undefined` before setup. */
    folder(): string | undefined;
    /** The folders to leave alone. */
    stampExclude(): readonly string[];
}
/**
 * Stamp `generated` on Markdown files an agent's file tool writes inside the
 * documentation folder. The stamp runs after the tool has returned, on a
 * file still at the version the tool left; a file changed again in between
 * is left for that later write's own stamp. The new version is then recorded
 * for the same agent, so its next edit of the note is not refused as stale.
 * @param ctx - a context with `ctx.fs`.
 * @param source - the documentation folder and excluded folders in force.
 * @param now - the clock; tests pin it.
 */
export declare function applyGeneratedStamp(ctx: Context, source: StampSource, now?: () => Date): void;
/** The outcome of marking one note as checked. */
export type MarkCheckedResult = {
    ok: true;
    by: string;
    at: string;
} | {
    ok: false;
    reason: 'not-markdown' | 'unreadable';
};
/**
 * Add the user to one note's `verified` list with the current instant.
 * @param path - absolute path of the note; the caller has already confined it to a folder the user chose.
 * @param now - the instant to record.
 * @returns who and when was recorded, or why nothing was written.
 */
export declare function markChecked(path: string, now?: Date): Promise<MarkCheckedResult>;
export {};
//# sourceMappingURL=stamp.d.ts.map