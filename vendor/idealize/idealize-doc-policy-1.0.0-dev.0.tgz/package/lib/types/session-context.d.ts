/**
 * The project map a chat starts with: the parts of a project's `_index.md`
 * that say where the work stands, a list of the notes beside it, and one line
 * for every section left out.
 *
 * A project index puts Decisions, Traps and the session log last, and those
 * sections grow without limit, so a clip at a fixed length removed exactly the
 * sections a chat most needs to know exist. The map is built from named
 * sections instead, every omission is stated with its size and the note's
 * path, and the complete notice stays under {@link NOTICE_CEILING}.
 *
 * Every value comes from the files: the order of the note list follows each
 * file's modification time with its name as the tiebreak, and nothing reads
 * the clock. Two builds over unchanged files return identical text, which
 * keeps a model's cached prefix valid across chats in one project.
 */
/** The most characters the session-start notice carries, wrapper included. */
export declare const NOTICE_CEILING = 8000;
/** The most characters of the conventions the notice for a repository with no note carries. */
export declare const CONVENTIONS_LIMIT = 2000;
/** The most characters of project map a terminal agent's standing rules carry. */
export declare const TERMINAL_MAP_LIMIT = 6000;
/**
 * A note's text as a labelled data block. Anyone who can write to a project can
 * reach its note (commit subjects land in it, and so can text a chat copied from
 * a page), so its words reach a chat as something to read about the project and
 * carry no authority of their own.
 * @param path - the note's path, named on the block.
 * @param text - the note's text.
 * @returns the block; text that imitates its closing tag is broken up.
 */
export declare function noteDataBlock(path: string, text: string): string;
/** One `## ` section of a project index. */
export interface IndexSection {
    /** The heading's text, without the `## `. */
    heading: string;
    /** Everything under the heading, trimmed. */
    body: string;
}
/** A project index split into the parts the map is built from. */
export interface IndexParts {
    /** The frontmatter block with its `---` lines, or an empty string. */
    front: string;
    /** The title and opening lines, up to the first `## ` heading. */
    intro: string;
    /** Every `## ` section, in the note's order. */
    sections: IndexSection[];
}
/**
 * Split a project index at its `## ` headings. A heading inside a fenced code
 * block is text and starts no section.
 * @param markdown - the complete note text.
 * @returns the frontmatter, the opening lines and the sections.
 */
export declare function splitIndex(markdown: string): IndexParts;
/**
 * The first line of each item in a section: a top-level list item, or a
 * paragraph when the section is prose. Continuation lines and nested items are
 * left out.
 * @param body - the section's text.
 * @returns one line per item, each cut to a fixed length.
 */
export declare function firstLines(body: string): string[];
/** One note beside the project index. */
export interface NeighbourNote {
    /** The file's name inside the project folder. */
    name: string;
    /** The file's modification time, in milliseconds. */
    modified: number;
    /** Its frontmatter `description`, else its first heading, when it has either. */
    description?: string;
}
/** One folder beside the project index. */
export interface NeighbourFolder {
    /** The folder's name. */
    name: string;
    /** How many Markdown files sit directly in it. */
    notes: number;
}
/** What sits beside a project index. */
export interface Neighbours {
    /** The other Markdown notes, newest first. */
    notes: NeighbourNote[];
    /** The folders, by name. */
    folders: NeighbourFolder[];
    /** The size of the project's `log.md` in characters, when it has one. */
    logSize?: number;
}
/**
 * A note's one-line description from its opening text.
 * @param head - the start of the note.
 * @returns the frontmatter `description`, else the first heading, else `undefined`.
 */
export declare function describeNote(head: string): string | undefined;
/**
 * List what sits beside a project index: the other notes with their
 * descriptions, the folders with their note counts, and the session log.
 * The order depends only on the files: newest modification time first, then
 * name.
 * @param folder - the project's folder in the documentation folder.
 * @returns the notes, the folders and the log's size.
 */
export declare function readNeighbours(folder: string): Promise<Neighbours>;
/** Everything {@link projectMap} is built from. */
export interface ProjectMapInput {
    /** The project index's path, named on every line that points back to it. */
    notePath: string;
    /** The project index's complete text. */
    index: string;
    /** What sits beside the index. */
    neighbours: Neighbours;
    /** The most characters the map may hold. */
    budget: number;
    /** How the reader searches the notes: `docs_search` in a chat, `rg or grep` in a terminal. */
    search: string;
}
/**
 * Build a project's map: its index (whole when it fits, else its frontmatter,
 * State or Status, Next actions and the first line of each open thread), the
 * notes beside it, and one line for each section left out. The result never
 * exceeds the budget.
 * @param input - the index, its neighbours, the budget and the search wording.
 * @returns the map's text.
 */
export declare function projectMap(input: ProjectMapInput): string;
/**
 * The start of the conventions, for the notice a repository with no note receives.
 * @param conventions - the canonical conventions text.
 * @returns at most {@link CONVENTIONS_LIMIT} characters, ending with a cut line when shortened.
 */
export declare function conventionsExcerpt(conventions: string): string;
/**
 * The session-start notice for a project that has a note: the project's map
 * inside a data block. The conventions stay out (JJ, 16 Nov 2026): the standing
 * prompt section names `CONVENTIONS.md`, and the map takes the space.
 * @param notePath - the project's `_index.md`.
 * @returns the notice, never longer than {@link NOTICE_CEILING}.
 */
export declare function projectNotice(notePath: string): Promise<string>;
/**
 * The project's map for a command-line agent in the built-in terminal, which
 * has no `docs_search` and searches with the shell.
 * @param notePath - the project's `_index.md`.
 * @returns the map inside a data block.
 */
export declare function terminalProjectMap(notePath: string): Promise<string>;
//# sourceMappingURL=session-context.d.ts.map