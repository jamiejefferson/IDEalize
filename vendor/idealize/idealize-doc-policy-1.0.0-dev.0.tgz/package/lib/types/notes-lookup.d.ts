/**
 * Structure-reading project-note lookup: find the `Projects/<name>/_index.md`
 * whose `repo:` frontmatter names a given repository. Moved here from
 * `@idealize/vault` because the `_index.md`/`repo:` convention is canonical
 * structure this package owns; vault keeps the commit-evidence writes built
 * on top of these lookups.
 */
/** One project note: its path and parsed pointers. */
export interface ProjectNote {
    path: string;
    repo: string;
    lastTouched: string | undefined;
}
/**
 * Resolve a working directory to its git toplevel.
 * @param cwd - any directory.
 * @returns the repository toplevel through realpath, or `undefined` outside a repo.
 */
export declare function gitToplevel(cwd: string): Promise<string | undefined>;
/**
 * Parse the `repo:` and `last_touched:` pointers of one note.
 * @param markdown - complete note text.
 * @returns the pointer fields present in the note's frontmatter.
 */
export declare function parseNotePointers(markdown: string): {
    repo?: string;
    lastTouched?: string;
};
/**
 * Scan each project folder under the vault's Projects/ for an `_index.md` carrying `repo:`.
 * @param folder - absolute path of the documentation folder.
 * @returns every project note with a repo pointer.
 */
export declare function projectNotes(folder: string): Promise<ProjectNote[]>;
/**
 * The checkout paths a hand-written `repo:` pointer names. People annotate the
 * field (`/dev/app (V1); V0 frozen at /old/app`), and an annotated pointer read
 * as one path matches no repository, so the project silently loses its
 * documentation context. Each `;`-separated part yields the text from its first
 * `/` or `~/`, as written and with a trailing parenthetical removed.
 * @param pointer - the raw `repo:` value.
 * @returns candidate absolute paths, most literal first.
 */
export declare function repoPaths(pointer: string): string[];
/**
 * The note whose `repo:` names this repository, resolved through realpath.
 * @param folder - absolute path of the documentation folder.
 * @param repoToplevel - realpath'd repository toplevel.
 * @returns the matching note, or `undefined`.
 */
export declare function noteForRepo(folder: string, repoToplevel: string): Promise<ProjectNote | undefined>;
/** Where a project's documentation folder was found. */
export interface ProjectDocsFolder {
    /** Absolute path of the project's folder inside the documentation folder. */
    path: string;
    /** `note`: its `_index.md` names the project in `repo:`; `name`: `Projects/<name>` matches the project folder's name. */
    source: 'note' | 'name';
}
/**
 * The folder holding one project's documentation. The project note's `repo:`
 * pointer decides first, because a note can sit under any name; a project
 * with no note falls back to the `Projects/` entry whose name equals the
 * project folder's, compared without case.
 * @param folder - absolute path of the documentation folder.
 * @param projectPath - absolute path of the project's own folder.
 * @returns the project's documentation folder, or `undefined` when the documentation folder holds none.
 */
export declare function projectDocsFolder(folder: string, projectPath: string): Promise<ProjectDocsFolder | undefined>;
//# sourceMappingURL=notes-lookup.d.ts.map