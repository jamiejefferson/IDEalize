/**
 * Structure-reading project-note lookup: find the `Projects/<name>/_index.md`
 * whose `repo:` frontmatter names a given repository. Moved here from
 * `@idealize/vault` because the `_index.md`/`repo:` convention is canonical
 * structure this package owns; vault keeps the commit-evidence writes built
 * on top of these lookups.
 */
/** One project note: its path and parsed pointers. */
export interface ProjectNote {
    path: string;
    repo: string;
    lastTouched: string | undefined;
}
/**
 * Resolve a working directory to its git toplevel.
 * @param cwd - any directory.
 * @returns the repository toplevel through realpath, or `undefined` outside a repo.
 */
export declare function gitToplevel(cwd: string): Promise<string | undefined>;
/**
 * Parse the `repo:` and `last_touched:` pointers of one note.
 * @param markdown - complete note text.
 * @returns the pointer fields present in the note's frontmatter.
 */
export declare function parseNotePointers(markdown: string): {
    repo?: string;
    lastTouched?: string;
};
/**
 * Scan each project folder under the vault's Projects/ for an `_index.md` carrying `repo:`.
 * @param folder - absolute path of the documentation folder.
 * @returns every project note with a repo pointer.
 */
export declare function projectNotes(folder: string): Promise<ProjectNote[]>;
/**
 * The note whose `repo:` names this repository, resolved through realpath.
 * @param folder - absolute path of the documentation folder.
 * @param repoToplevel - realpath'd repository toplevel.
 * @returns the matching note, or `undefined`.
 */
export declare function noteForRepo(folder: string, repoToplevel: string): Promise<ProjectNote | undefined>;
//# sourceMappingURL=notes-lookup.d.ts.map