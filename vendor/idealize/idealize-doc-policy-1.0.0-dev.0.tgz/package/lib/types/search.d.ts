/**
 * Full-text retrieval index over the scanned documentation folder (DOC-04):
 * an in-memory SQLite FTS5 table rebuilt on every scan. Derived, disposable
 * data — nothing here persists, so there is no schema versioning or file
 * management; the authoritative content stays on disk in the user's folder.
 * MATCH input follows the session-query-sqlite posture: caller text is always
 * quoted, as one phrase or word by word, so FTS5 query syntax stays inert data.
 */
import type { IndexedDoc } from './scan.ts';
/** One `docs_search` hit. */
export interface DocsSearchHit {
    /** Vault-relative path of the matching document. */
    path: string;
    /** The document's canonical kind. */
    kind: string;
    /** Document title. */
    title: string;
    /** Whitespace-normalized excerpt around the first match. */
    snippet: string;
    /** The note's frontmatter `type`, when it carries one. */
    type?: string;
    /** The note's frontmatter `status`, when it carries one. */
    status?: string;
    /** The note's frontmatter `description`, when it carries one. */
    description?: string;
    /** Present and true when the note is past its `stale_after`. */
    stale?: boolean;
}
/**
 * How a query's words are matched: `phrase` finds the words together in the
 * order given, `all` finds notes holding every word in any order, `any` finds
 * notes holding at least one.
 */
export type DocsMatch = 'phrase' | 'all' | 'any';
/** Every match mode, in the order the tool schema lists them. */
export declare const DOCS_MATCH_MODES: readonly DocsMatch[];
/** The in-memory FTS5 docs index. One instance per docPolicy service. */
export declare class DocsIndex {
    private db;
    private opening;
    private closed;
    private ensure;
    /**
     * Replace the whole corpus with one scan's document set.
     * @param docs - the scan's indexable documents.
     */
    replaceAll(docs: readonly IndexedDoc[]): Promise<void>;
    /**
     * Current corpus size.
     * @returns the number of indexed documents.
     */
    count(): Promise<number>;
    /**
     * Search the corpus. Notes whose status is `deprecated` or
     * `archived`, and notes past their `stale_after`, rank below every other
     * hit; within each group the best match comes first.
     * @param query - caller text; never read as FTS5 syntax.
     * @param limit - maximum hits.
     * @param options - how to match and when.
     * @param options.match - `phrase` (the default), `all` or `any`.
     * @param options.now - the instant `stale_after` is compared with, in epoch milliseconds.
     * @returns best-first hits with snippets.
     */
    search(query: string, limit: number, options?: {
        match?: DocsMatch;
        now?: number;
    }): Promise<DocsSearchHit[]>;
    /** Release the in-memory database. Idempotent. */
    close(): void;
}
//# sourceMappingURL=search.d.ts.map