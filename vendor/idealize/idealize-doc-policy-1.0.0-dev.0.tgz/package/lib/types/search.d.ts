/**
 * Full-text retrieval index over the scanned documentation folder (DOC-04):
 * an in-memory SQLite FTS5 table rebuilt on every scan. Derived, disposable
 * data — nothing here persists, so there is no schema versioning or file
 * management; the authoritative content stays on disk in the user's folder.
 * MATCH input follows the session-query-sqlite posture: caller text is quoted
 * as one phrase so FTS5 query syntax stays inert data.
 */
import type { IndexedDoc } from './scan.ts';
/** One `docs_search` hit. */
export interface DocsSearchHit {
    /** Vault-relative path of the matching document. */
    path: string;
    /** The document's canonical kind. */
    kind: string;
    /** Document title. */
    title: string;
    /** Whitespace-normalized excerpt around the first match. */
    snippet: string;
}
/** The in-memory FTS5 docs index. One instance per docPolicy service. */
export declare class DocsIndex {
    private db;
    private opening;
    private closed;
    private ensure;
    /**
     * Replace the whole corpus with one scan's document set.
     * @param docs - the scan's indexable documents.
     */
    replaceAll(docs: readonly IndexedDoc[]): Promise<void>;
    /**
     * Current corpus size.
     * @returns the number of indexed documents.
     */
    count(): Promise<number>;
    /**
     * Phrase-match the corpus.
     * @param query - caller text; treated as one literal phrase.
     * @param limit - maximum hits.
     * @returns best-first hits with snippets.
     */
    search(query: string, limit: number): Promise<DocsSearchHit[]>;
    /** Release the in-memory database. Idempotent. */
    close(): void;
}
//# sourceMappingURL=search.d.ts.map