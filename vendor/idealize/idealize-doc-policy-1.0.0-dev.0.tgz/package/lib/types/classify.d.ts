/**
 * Classification and per-document validation against the packaged canonical
 * ruleset (DOC-02/05): map a vault-relative path to its document kind, and
 * check a managed document's frontmatter against the rules derived from the
 * pinned canonical repository.
 */
/** Document kinds the canonical structure recognizes. */
export type DocKind = 'project-index' | 'project-note' | 'decision' | 'reference' | 'person' | 'template' | 'meta' | 'unmanaged';
/** One policy finding from a scan or validation. */
export interface Finding {
    /** Vault-relative path of the offending file or folder. */
    path: string;
    /** Stable rule id (e.g. `invalid-status`). */
    rule: string;
    /** `error` breaks the canonical structure; `warning` flags drift. */
    severity: 'error' | 'warning';
    /** What is wrong, stated so an agent can propose the edit. */
    message: string;
}
/**
 * Classify one vault-relative Markdown path against the canonical structure.
 * @param relPath - path relative to the documentation folder, `/`-separated.
 * @returns the document kind; `unmanaged` when outside the canonical layout.
 */
export declare function classifyPath(relPath: string): DocKind;
/**
 * Validate one managed document against the packaged rules.
 * @param relPath - vault-relative path, `/`-separated.
 * @param kind - the path's classification.
 * @param content - complete document text.
 * @returns findings for every violated rule (empty when conformant).
 */
export declare function validateDoc(relPath: string, kind: DocKind, content: string): Finding[];
//# sourceMappingURL=classify.d.ts.map