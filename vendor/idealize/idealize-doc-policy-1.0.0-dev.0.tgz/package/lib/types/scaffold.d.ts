/**
 * Canonical vault scaffolding (DOC-05, one source): directories, the
 * CONVENTIONS/AGENTS texts, and the project-index template, all derived from
 * the packaged ruleset. Scaffolding is additive and idempotent — an existing
 * file is never overwritten, so adopting a live vault is safe. Moved here
 * from `@idealize/vault` so structure authority has exactly one home.
 */
/**
 * The CONVENTIONS.md text written into a scaffolded vault and injected as
 * model-facing context. Assembled from the packaged ruleset constants so the
 * text can never disagree with what the scanner enforces.
 * @returns the conventions document.
 */
export declare function conventionsText(): string;
/**
 * The AGENTS.md text written into a scaffolded vault.
 * @returns the agents document.
 */
export declare function agentsText(): string;
/**
 * Instantiate the canonical project-index template for one repository.
 * @param name - project short name.
 * @param repo - absolute path to the working checkout.
 * @param date - ISO date stamped into `created`/`last_touched`.
 * @returns the filled `_index.md` content.
 */
export declare function projectNoteFor(name: string, repo: string, date: string): string;
/**
 * Create the canonical vault structure; existing files and directories are kept.
 * @param folder - absolute path of the documentation folder.
 * @returns the names actually created (empty when the vault was complete).
 */
export declare function scaffoldVault(folder: string): Promise<string[]>;
//# sourceMappingURL=scaffold.d.ts.map