/**
 * Durable storage-domain declaration for scan history (DOC-04/07): each scan
 * or maintenance job records its findings and the policy-package version it
 * applied.
 * @module @idealize/doc-policy/src/spec
 */
import { z } from 'zod';
/** Runtime schema of one recorded finding. */
export declare const docFindingSchema: z.ZodObject<{
    path: z.ZodString;
    rule: z.ZodString;
    severity: z.ZodUnion<readonly [z.ZodLiteral<"error">, z.ZodLiteral<"warning">]>;
    message: z.ZodString;
}, z.core.$strip>;
/** Runtime schema of one recorded scan. */
export declare const docScanRecordSchema: z.ZodObject<{
    at: z.ZodString;
    policyVersion: z.ZodString;
    docCount: z.ZodNumber;
    findings: z.ZodArray<z.ZodObject<{
        path: z.ZodString;
        rule: z.ZodString;
        severity: z.ZodUnion<readonly [z.ZodLiteral<"error">, z.ZodLiteral<"warning">]>;
        message: z.ZodString;
    }, z.core.$strip>>;
}, z.core.$strip>;
/** One recorded scan, inferred from its durable schema. */
export type DocScanRecord = z.infer<typeof docScanRecordSchema>;
/** Recorded scans kept before the oldest are pruned. */
export declare const SCAN_HISTORY_CAP = 20;
/** Scan-history domain: one record per scan, keyed by scan time + nonce. */
export declare const docPolicyDomainSpec: {
    name: string;
    version: number;
    tables: {
        scans: import("@deepseek-ai/dsh-storage-domain").DomainTableSpec<string, {
            at: string;
            policyVersion: string;
            docCount: number;
            findings: {
                path: string;
                rule: string;
                severity: "error" | "warning";
                message: string;
            }[];
        }>;
    };
};
//# sourceMappingURL=spec.d.ts.map