/**
 * The standing documentation guidance every agent's system prompt carries.
 *
 * The session-start notice reaches only a chat whose repository already has a
 * project note, so a chat anywhere else was never told the documentation
 * folder exists: it wrote plans and handoffs into the repository and no
 * project ever gained its first note (JJ, 17 Sep 2026). This section holds the
 * rule itself — where documentation goes, how the folder is laid out, how to
 * find a note — for every chat, with or without a note.
 */
/** Section name and band: the tool-guidance band, after `idealize:artefacts` (121). */
export declare const DOCUMENTATION_SECTION_NAME = "idealize:documentation";
export declare const DOCUMENTATION_SECTION_ORDER = 122;
/**
 * The guidance text for the folder in force.
 * @param folder - the configured documentation folder, or `undefined` before setup.
 * @returns the section text.
 */
export declare function documentationGuidance(folder: string | undefined): string;
/**
 * The session-start notice for a repository the folder holds no note for.
 * @param folder - the configured documentation folder.
 * @param repoToplevel - the chat's repository toplevel.
 * @returns the notice text.
 */
export declare function missingNoteNotice(folder: string, repoToplevel: string): string;
/**
 * The standing guidance for a command-line agent in the built-in terminal
 * (Claude Code, say). It reads no harness prompt and has no `docs_search`, so
 * the text names the project's note outright and points at the shell's search.
 * @param folder - the configured documentation folder, or `undefined` before setup.
 * @param project - the shell's repository and the note found for it; omitted outside a repository.
 * @param project.repoToplevel - the repository toplevel.
 * @param project.notePath - the project note's path, or `undefined` when the folder holds none.
 * @returns the guidance text.
 */
export declare function terminalDocumentationGuidance(folder: string | undefined, project?: {
    repoToplevel: string;
    notePath: string | undefined;
}): string;
//# sourceMappingURL=guidance.d.ts.map