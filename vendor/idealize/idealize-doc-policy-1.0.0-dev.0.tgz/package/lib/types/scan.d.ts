/**
 * Folder scan against the canonical structure (DOC-04/06/07): walk the
 * configured documentation folder, classify and validate every Markdown
 * document, and report structural findings plus the indexable document set.
 * Read-only — no structural moves happen automatically in V1; findings feed
 * agent-proposed edits and the settings surface.
 */
import type { DocKind, Finding } from './classify.ts';
/** One document the scan indexes for retrieval. */
export interface IndexedDoc {
    /** Vault-relative path, `/`-separated. */
    path: string;
    /** The path's classification. */
    kind: DocKind;
    /** First `# ` heading, or the file name without extension. */
    title: string;
    /** Complete document text. */
    text: string;
}
/** Complete result of one folder scan. */
export interface ScanResult {
    /** Scan time (ISO). */
    at: string;
    /** The applied policy-package version (DOC-07). */
    policyVersion: string;
    /** Every structural or per-document violation found. */
    findings: Finding[];
    /** Every managed Markdown document, ready for indexing. */
    docs: IndexedDoc[];
}
/**
 * Fingerprint of everything {@link scanFolder} reads: the root listing, every
 * directory and Markdown file under the canonical directories with its size
 * and modification time, and the local date (the stale-note rule compares
 * `last_touched` with today). Two equal fingerprints mean a scan would return
 * the same findings and documents, so the caller may keep its last result.
 * One `stat` per file replaces reading and indexing every document.
 * @param folder - absolute path of the configured documentation folder.
 * @returns a hex digest; it differs after any add, remove, rename or edit.
 */
export declare function fingerprintFolder(folder: string): Promise<string>;
/**
 * Scan one documentation folder against the canonical structure.
 * @param folder - absolute path of the configured documentation folder.
 * @returns findings and the indexable document set, stamped with the policy version.
 */
export declare function scanFolder(folder: string): Promise<ScanResult>;
//# sourceMappingURL=scan.d.ts.map