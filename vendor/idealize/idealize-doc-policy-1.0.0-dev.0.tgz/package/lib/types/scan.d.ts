/**
 * Folder scan against the canonical structure (DOC-04/06/07): walk the
 * configured documentation folder, classify and validate every Markdown
 * document, and report structural findings plus the indexable document set.
 * Read-only — no structural moves happen automatically in V1; findings feed
 * agent-proposed edits and the settings surface.
 */
import type { DocKind, Finding } from './classify.ts';
/** Length past which a project `_index.md` raises `index-oversize`: the share of the session-start notice an index is given. */
export declare const INDEX_OVERSIZE_CHARS = 6000;
/** One document the scan indexes for retrieval. */
export interface IndexedDoc {
    /** Vault-relative path, `/`-separated. */
    path: string;
    /** The path's classification. */
    kind: DocKind;
    /** First `# ` heading, or the file name without extension. */
    title: string;
    /** Complete document text. */
    text: string;
    /** Frontmatter `type`, as the writer wrote it. */
    type?: string;
    /** Frontmatter `status`, as the writer wrote it. */
    status?: string;
    /** Frontmatter `description`: one sentence on what the note holds. */
    description?: string;
    /** The note's `stale_after` instant in epoch milliseconds, when it carries a readable one. */
    staleAt?: number;
}
/** Complete result of one folder scan. */
export interface ScanResult {
    /** Scan time (ISO). */
    at: string;
    /** The applied policy-package version (DOC-07). */
    policyVersion: string;
    /** Every structural or per-document violation found. */
    findings: Finding[];
    /** Every managed Markdown document, ready for indexing. */
    docs: IndexedDoc[];
    /** The earliest `stale_after` still ahead of the scan, in epoch milliseconds: the instant this result stops being current. */
    nextStaleAt?: number;
}
/**
 * Fingerprint of everything {@link scanFolder} reads: the root listing, every
 * directory and Markdown file under the canonical directories with its size
 * and modification time, and the local date (the stale-note rule compares
 * `last_touched` with today). Two equal fingerprints mean a scan would return
 * the same findings and documents, so the caller may keep its last result.
 * One `stat` per file replaces reading and indexing every document.
 * @param folder - absolute path of the configured documentation folder.
 * @returns a hex digest; it differs after any add, remove, rename or edit.
 */
export declare function fingerprintFolder(folder: string): Promise<string>;
/**
 * Scan one documentation folder against the canonical structure. Beside the
 * structural and per-document rules it raises two advisory warnings: `stale`
 * for a note past its `stale_after`, and `index-oversize` for a project
 * `_index.md` longer than {@link INDEX_OVERSIZE_CHARS} characters.
 * @param folder - absolute path of the configured documentation folder.
 * @param now - the instant `stale_after` is compared with.
 * @returns findings and the indexable document set, stamped with the policy version.
 */
export declare function scanFolder(folder: string, now?: Date): Promise<ScanResult>;
//# sourceMappingURL=scan.d.ts.map