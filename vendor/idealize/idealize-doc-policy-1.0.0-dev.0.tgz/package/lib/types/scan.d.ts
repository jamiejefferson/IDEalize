/**
 * Folder scan against the canonical structure (DOC-04/06/07): walk the
 * configured documentation folder, classify and validate every Markdown
 * document, and report structural findings plus the indexable document set.
 * Read-only — no structural moves happen automatically in V1; findings feed
 * agent-proposed edits and the settings surface.
 */
import type { DocKind, Finding } from './classify.ts';
/** One document the scan indexes for retrieval. */
export interface IndexedDoc {
    /** Vault-relative path, `/`-separated. */
    path: string;
    /** The path's classification. */
    kind: DocKind;
    /** First `# ` heading, or the file name without extension. */
    title: string;
    /** Complete document text. */
    text: string;
}
/** Complete result of one folder scan. */
export interface ScanResult {
    /** Scan time (ISO). */
    at: string;
    /** The applied policy-package version (DOC-07). */
    policyVersion: string;
    /** Every structural or per-document violation found. */
    findings: Finding[];
    /** Every managed Markdown document, ready for indexing. */
    docs: IndexedDoc[];
}
/**
 * Scan one documentation folder against the canonical structure.
 * @param folder - absolute path of the configured documentation folder.
 * @returns findings and the indexable document set, stamped with the policy version.
 */
export declare function scanFolder(folder: string): Promise<ScanResult>;
//# sourceMappingURL=scan.d.ts.map