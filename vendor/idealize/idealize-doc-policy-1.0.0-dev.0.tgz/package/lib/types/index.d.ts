/**
 * @idealize/doc-policy — the canonical documentation policy as product
 * behaviour (`ctx.docPolicy`).
 *
 * The service initialises from the packaged, versioned ruleset (derived from
 * JJ's canonical repository — see `src/policy/ruleset.ts` and the README pin)
 * plus the configured documentation folder (settings section `idealize-docs`,
 * field `documentationFolder`). With a folder configured the plugin:
 *
 * - scaffolds the canonical structure additively (existing files kept);
 * - scans the folder against the canonical structure on init, on settings
 *   change, on demand (`ctx.docPolicy.scan()` — vault calls it after
 *   appending commit evidence), and throttled on `session/flush`;
 * - records each scan's findings and applied `policyVersion` to the
 *   `idealize_docs` storage domain when the storage-domain form is composed;
 * - rebuilds an in-memory FTS5 index from every scan and serves it through
 *   the `docs_search` tool;
 * - contributes the standing `idealize:documentation` system-prompt section:
 *   where documentation goes, the folder's layout, and how to find a note,
 *   for every chat (it says so when no folder is set);
 * - stamps `generated` on a Markdown file an agent's file tool writes inside
 *   the folder (`src/stamp.ts`), and adds the user to `verified` on request
 *   (`ctx.docPolicy.markChecked`);
 * - injects a map of the matching project's
 *   notes (`src/session-context.ts`) as model-facing context on
 *   `agent/session-start`, or the way to create the project's note when the
 *   repository has none;
 * - serves `GET /idealize/docs/state` (loopback only): folder + scan state
 *   for the settings surface (DOC-08).
 *
 * @module @idealize/doc-policy
 */
import { Context, Service } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import type { KvTable } from '@deepseek-ai/dsh-storage-domain';
import type { RulesetVersion } from './policy/ruleset.ts';
import type { DocsMatch, DocsSearchHit } from './search.ts';
import type { ProjectDocsFolder } from './notes-lookup.ts';
import type { MarkCheckedResult } from './stamp.ts';
import type { DocScanRecord } from './spec.ts';
export { CANONICAL_DIRS, CANONICAL_ROOT_FILES, DECISION_FILE_RE, DECISION_HEADING_RE, ISO_DATE_RE, NOTE_OPTIONAL_FIELDS, PROJECT_INDEX_REQUIRED_FIELDS, PROJECT_INDEX_OPTIONAL_FIELDS, PROJECT_INDEX_TEMPLATE, CONVENTIONS_SOURCE, RULESET_VERSION, STALE_ACTIVE_DAYS, STATUS_VOCABULARY, } from './policy/ruleset.ts';
export type { RulesetVersion } from './policy/ruleset.ts';
export { parseFrontmatter } from './frontmatter.ts';
export type { Frontmatter } from './frontmatter.ts';
export { classifyPath, validateDoc } from './classify.ts';
export type { DocKind, Finding } from './classify.ts';
export { INDEX_OVERSIZE_CHARS, fingerprintFolder, scanFolder } from './scan.ts';
export { addVerified, isActor, isStale, parseInstant, readTrust, stampGenerated, validateTrust } from './trust.ts';
export type { NoteTrust, TrustEvent } from './trust.ts';
export { DEFAULT_STAMP_EXCLUDE, USER_ACTOR, agentActor, applyGeneratedStamp, isStampExcluded, markChecked, mutatingAgent, pathWithin } from './stamp.ts';
export type { MarkCheckedResult, StampSource } from './stamp.ts';
export type { IndexedDoc, ScanResult } from './scan.ts';
export { DOCS_MATCH_MODES, DocsIndex } from './search.ts';
export type { DocsMatch, DocsSearchHit } from './search.ts';
export { agentsText, conventionsText, projectNoteFor, scaffoldVault } from './scaffold.ts';
export { gitToplevel, noteForCwd, noteForRepo, parseNotePointers, projectDocsFolder, projectNotes, repoPaths } from './notes-lookup.ts';
export type { CwdNote } from './notes-lookup.ts';
export { DOCUMENTATION_SECTION_NAME, DOCUMENTATION_SECTION_ORDER, documentationGuidance, missingNoteNotice, terminalDocumentationGuidance } from './guidance.ts';
export type { ProjectNote } from './notes-lookup.ts';
export { CONVENTIONS_LIMIT, NOTICE_CEILING, TERMINAL_MAP_LIMIT, conventionsExcerpt, describeNote, firstLines, noteDataBlock, projectMap, projectNotice, readNeighbours, splitIndex, terminalProjectMap, } from './session-context.ts';
export { PROJECT_LOG_FILE } from './project-log.ts';
export type { IndexParts, IndexSection, NeighbourFolder, NeighbourNote, Neighbours, ProjectMapInput } from './session-context.ts';
export { SCAN_HISTORY_CAP, docPolicyDomainSpec, docScanRecordSchema } from './spec.ts';
export type { DocScanRecord } from './spec.ts';
export declare const name = "idealize-doc-policy";
/** Plugin configuration: the one user-facing choice (DOC-08). */
export interface DocPolicyConfig {
    /** Absolute path of the user's documentation folder (their vault). */
    documentationFolder?: string;
    /**
     * Folders inside the documentation folder whose notes never gain a
     * `generated` stamp. Each entry names a folder at any depth (`sessions/`,
     * `Projects/acme/drafts/`). Unset means {@link DEFAULT_STAMP_EXCLUDE}.
     */
    stampExclude?: string[];
}
export declare const Config: z<DocPolicyConfig>;
declare module '@deepseek-ai/cordis' {
    interface Context {
        docPolicy: DocPolicy;
    }
}
/** Folder + scan state as the settings surface reads it (DOC-08). */
export interface DocsState {
    /** Whether a documentation folder is configured. */
    configured: boolean;
    /** The configured folder, when present. */
    folder?: string;
    /** The packaged policy version this build applies. */
    policyVersion: string;
    /** The most recent scan, when one has run. */
    lastScan?: DocScanRecord;
}
/**
 * The canonical documentation service. Scans are serialized on one chain;
 * reads (`state`, `search`) are safe at any time.
 */
export declare class DocPolicy extends Service {
    private source;
    private readonly index;
    private chain;
    private scans;
    private last;
    private lastRecorded;
    private scanCounter;
    /** Folder and fingerprint the last completed scan covered, and the instant a note in it next turns stale. */
    private lastScanned;
    constructor(ctx: Context, config: DocPolicyConfig);
    /**
     * The configured documentation folder, or `undefined` before setup.
     * @returns the absolute folder path, or `undefined` when unconfigured.
     */
    folder(): string | undefined;
    /**
     * The folders whose notes never gain a `generated` stamp.
     * @returns the `stampExclude` setting, or its default when unset.
     */
    stampExclude(): readonly string[];
    /**
     * Add the user to one note's `verified` list, dated now ("Mark as checked").
     * The caller confines the path to a folder the user chose; this method
     * writes only a Markdown file and changes only its `verified` field.
     * @param path - absolute path of the note.
     * @returns who and when was recorded, or why nothing was written.
     */
    markChecked(path: string): Promise<MarkCheckedResult>;
    /**
     * The packaged ruleset version this build applies.
     * @returns the pinned ruleset version.
     */
    rulesetVersion(): RulesetVersion;
    /**
     * The canonical conventions text (the DOC-05 authority).
     * @returns the ruleset's conventions text.
     */
    conventions(): string;
    /**
     * The documentation rule for a command-line agent the built-in terminal
     * launches in `cwd`. `@idealize/ui-terminal` probes for this method and
     * appends the text to the agent's prompt, because such an agent reads no
     * harness prompt and no session-start notice.
     * @param cwd - the shell's working directory.
     * @returns the guidance; when the folder holds the project's note, it names the note and ends with the project's map.
     */
    terminalKnowledge(cwd: string): Promise<string>;
    /**
     * The folder holding one project's documentation inside the configured
     * documentation folder: the folder of the note whose `repo:` names the
     * project, else `Projects/<project folder name>` when it exists.
     * @param projectPath - absolute path of the project's own folder.
     * @returns the folder and how it was found, or `undefined` with no documentation folder or no match.
     */
    projectFolder(projectPath: string): Promise<ProjectDocsFolder | undefined>;
    /**
     * Scaffold and scan the configured folder, rebuild the retrieval index,
     * and record the scan to the storage domain when attached (DOC-04/06/07).
     * Serialized: concurrent calls run one at a time in order. A call that
     * finds the folder's {@link fingerprintFolder} unchanged since the last
     * scan returns that scan's record and neither re-reads, re-indexes nor
     * records: sessions flush every few seconds, and the index rebuild runs
     * synchronously on the Host thread.
     * @returns the scan record, or `undefined` when no folder is configured.
     */
    scan(): Promise<DocScanRecord | undefined>;
    /**
     * Search the indexed documentation.
     * @param query - caller text; never read as query syntax.
     * @param limit - maximum hits.
     * @param match - `phrase` for the words together in order, `all` for every word in any order, `any` for at least one word.
     * @returns best-first hits (empty when no folder is configured).
     */
    search(query: string, limit: number, match?: DocsMatch): Promise<DocsSearchHit[]>;
    /**
     * Folder + scan state for the settings surface and the state route.
     * @returns the current configuration and last scan snapshot.
     */
    state(): DocsState;
    /**
     * Attach the durable scan-history table; a scan that ran before attachment
     * is recorded now so a late-mounting storage form loses nothing.
     * @param table - the opened `scans` table.
     */
    attachScans(table: KvTable<string, DocScanRecord>): void;
    /** Detach the scan-history table ahead of its domain closing. */
    detachScans(): void;
    private record;
    private scanLogged;
    private enqueue;
}
/**
 * One `docs_search` hit as the model reads it: the path, the labels the note
 * carries, its description, and the snippet.
 * @param hit - the hit.
 * @returns one line.
 */
export declare function renderHit(hit: DocsSearchHit): string;
export declare function apply(ctx: Context, config: DocPolicyConfig): void;
//# sourceMappingURL=index.d.ts.map