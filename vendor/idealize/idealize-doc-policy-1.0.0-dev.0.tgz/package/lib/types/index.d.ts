/**
 * @idealize/doc-policy — the canonical documentation policy as product
 * behaviour (`ctx.docPolicy`).
 *
 * The service initialises from the packaged, versioned ruleset (derived from
 * JJ's canonical repository — see `src/policy/ruleset.ts` and the README pin)
 * plus the configured documentation folder (settings section `idealize-docs`,
 * field `documentationFolder`). With a folder configured the plugin:
 *
 * - scaffolds the canonical structure additively (existing files kept);
 * - scans the folder against the canonical structure on init, on settings
 *   change, on demand (`ctx.docPolicy.scan()` — vault calls it after
 *   appending commit evidence), and throttled on `session/flush`;
 * - records each scan's findings and applied `policyVersion` to the
 *   `idealize_docs` storage domain when the storage-domain form is composed;
 * - rebuilds an in-memory FTS5 index from every scan and serves it through
 *   the `docs_search` tool;
 * - injects the canonical conventions and the matching project's `_index.md`
 *   as model-facing context on `agent/session-start`;
 * - serves `GET /idealize/docs/state` (loopback only): folder + scan state
 *   for the settings surface (DOC-08).
 *
 * @module @idealize/doc-policy
 */
import { Context, Service } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import type { KvTable } from '@deepseek-ai/dsh-storage-domain';
import type { RulesetVersion } from './policy/ruleset.ts';
import type { DocsSearchHit } from './search.ts';
import type { DocScanRecord } from './spec.ts';
export { CANONICAL_DIRS, CANONICAL_ROOT_FILES, DECISION_FILE_RE, DECISION_HEADING_RE, ISO_DATE_RE, PROJECT_INDEX_REQUIRED_FIELDS, PROJECT_INDEX_OPTIONAL_FIELDS, PROJECT_INDEX_TEMPLATE, CONVENTIONS_SOURCE, RULESET_VERSION, STALE_ACTIVE_DAYS, STATUS_VOCABULARY, } from './policy/ruleset.ts';
export type { RulesetVersion } from './policy/ruleset.ts';
export { parseFrontmatter } from './frontmatter.ts';
export type { Frontmatter } from './frontmatter.ts';
export { classifyPath, validateDoc } from './classify.ts';
export type { DocKind, Finding } from './classify.ts';
export { scanFolder } from './scan.ts';
export type { IndexedDoc, ScanResult } from './scan.ts';
export { DocsIndex } from './search.ts';
export type { DocsSearchHit } from './search.ts';
export { agentsText, conventionsText, projectNoteFor, scaffoldVault } from './scaffold.ts';
export { gitToplevel, noteForRepo, parseNotePointers, projectNotes } from './notes-lookup.ts';
export type { ProjectNote } from './notes-lookup.ts';
export { SCAN_HISTORY_CAP, docPolicyDomainSpec, docScanRecordSchema } from './spec.ts';
export type { DocScanRecord } from './spec.ts';
export declare const name = "idealize-doc-policy";
/** Plugin configuration: the one user-facing choice (DOC-08). */
export interface DocPolicyConfig {
    /** Absolute path of the user's documentation folder (their vault). */
    documentationFolder?: string;
}
export declare const Config: z<DocPolicyConfig>;
declare module '@deepseek-ai/cordis' {
    interface Context {
        docPolicy: DocPolicy;
    }
}
/** Folder + scan state as the settings surface reads it (DOC-08). */
export interface DocsState {
    /** Whether a documentation folder is configured. */
    configured: boolean;
    /** The configured folder, when present. */
    folder?: string;
    /** The packaged policy version this build applies. */
    policyVersion: string;
    /** The most recent scan, when one has run. */
    lastScan?: DocScanRecord;
}
/**
 * The canonical documentation service. Scans are serialized on one chain;
 * reads (`state`, `search`) are safe at any time.
 */
export declare class DocPolicy extends Service {
    private source;
    private readonly index;
    private chain;
    private scans;
    private last;
    private lastRecorded;
    private scanCounter;
    constructor(ctx: Context, config: DocPolicyConfig);
    /**
     * The configured documentation folder, or `undefined` before setup.
     * @returns the absolute folder path, or `undefined` when unconfigured.
     */
    folder(): string | undefined;
    /**
     * The packaged ruleset version this build applies.
     * @returns the pinned ruleset version.
     */
    rulesetVersion(): RulesetVersion;
    /**
     * The canonical conventions text (the DOC-05 authority).
     * @returns the ruleset's conventions text.
     */
    conventions(): string;
    /**
     * Scaffold and scan the configured folder, rebuild the retrieval index,
     * and record the scan to the storage domain when attached (DOC-04/06/07).
     * Serialized: concurrent calls run one at a time in order.
     * @returns the scan record, or `undefined` when no folder is configured.
     */
    scan(): Promise<DocScanRecord | undefined>;
    /**
     * Phrase-search the indexed documentation.
     * @param query - caller text, matched as one literal phrase.
     * @param limit - maximum hits.
     * @returns best-first hits (empty when no folder is configured).
     */
    search(query: string, limit: number): Promise<DocsSearchHit[]>;
    /**
     * Folder + scan state for the settings surface and the state route.
     * @returns the current configuration and last scan snapshot.
     */
    state(): DocsState;
    /**
     * Attach the durable scan-history table; a scan that ran before attachment
     * is recorded now so a late-mounting storage form loses nothing.
     * @param table - the opened `scans` table.
     */
    attachScans(table: KvTable<string, DocScanRecord>): void;
    /** Detach the scan-history table ahead of its domain closing. */
    detachScans(): void;
    private record;
    private scanLogged;
    private enqueue;
}
export declare function apply(ctx: Context, config: DocPolicyConfig): void;
//# sourceMappingURL=index.d.ts.map