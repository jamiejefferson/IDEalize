/**
 * Minimal YAML-frontmatter field reader for canonical vault notes. Reads the
 * flat `key: value` fields the ruleset names (no nesting, no multi-line
 * values) and strips inline ` # comment` tails, which the canonical examples
 * carry. Not a YAML parser by design: the frontmatter schema is closed and
 * flat, and a full parser would accept documents the policy does not.
 */
/** Parsed frontmatter of one note. */
export interface Frontmatter {
    /** Whether the note opens with a `---` frontmatter block at all. */
    present: boolean;
    /** Flat fields, values trimmed with inline comments removed (may be empty strings). */
    fields: Record<string, string>;
}
/**
 * Read the frontmatter fields of one Markdown document.
 * @param markdown - complete note text.
 * @returns the parsed block, or `present: false` when the note has none.
 */
export declare function parseFrontmatter(markdown: string): Frontmatter;
//# sourceMappingURL=frontmatter.d.ts.map