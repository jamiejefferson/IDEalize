/**
 * The optional trust fields of a note (`NOTE_OPTIONAL_FIELDS` in the pinned
 * ruleset): reading them, checking them, and writing the two IDEalize itself
 * writes. Names and value formats follow the Open Knowledge Format 0.2:
 * `generated: { by, at }`, `verified` as a list of `{ by, at }` (one bare
 * mapping counts as a list of one), `stale_after` as an instant, and
 * `sources` as a list whose entries each name a `resource`.
 *
 * Reading accepts the YAML shapes those fields are written in (a flow
 * mapping on the key's line, a block mapping, a block list of either) and
 * nothing wider. Writing replaces or inserts one field's lines and leaves
 * every other byte of the file as it was.
 */
import type { Finding } from './classify.ts';
/** One `{ by, at }` record: who produced or checked a note, and when. */
export interface TrustEvent {
    /** The actor: `human:<id>`, `process:<id>` or `<producer>/<version>`. */
    by?: string;
    /** ISO 8601 date-time with a UTC offset. */
    at?: string;
}
/** The trust and listing fields read from one note's frontmatter. */
export interface NoteTrust {
    /** `type`, as the writer wrote it. */
    type?: string;
    /** `status`, as the writer wrote it. */
    status?: string;
    /** `description`: one sentence on what the note holds. */
    description?: string;
    /** `generated`, when the field is present with a value. */
    generated?: TrustEvent;
    /** `verified` events, when the field is present with a value. */
    verified?: TrustEvent[];
    /** `stale_after`, as written. */
    staleAfter?: string;
    /** `sources` entries, when the field is present with a value. */
    sources?: Array<Record<string, string>>;
}
/**
 * Read the trust and listing fields of one note.
 * @param markdown - complete note text.
 * @returns the fields the note carries; an absent or empty field is left out.
 */
export declare function readTrust(markdown: string): NoteTrust;
/**
 * Parse an ISO 8601 date-time that carries a UTC offset.
 * @param value - the text to parse.
 * @returns epoch milliseconds, or `undefined` when the text is another format or no real instant.
 */
export declare function parseInstant(value: string): number | undefined;
/**
 * Whether a string names an actor: `human:<id>`, `process:<id>` or `<producer>/<version>`.
 * @param value - the `by` value.
 * @returns true when the value follows the actor convention.
 */
export declare function isActor(value: string): boolean;
/**
 * Check the trust fields one note carries. Every finding is a warning: the
 * fields are optional, and a note that gets one wrong is still a valid note.
 * @param relPath - vault-relative path, named on each finding.
 * @param markdown - complete note text.
 * @returns one finding per field written in a form tools cannot read.
 */
export declare function validateTrust(relPath: string, markdown: string): Finding[];
/**
 * Whether a note is past its `stale_after` instant.
 * @param trust - the note's fields.
 * @param now - the instant to compare with, in epoch milliseconds.
 * @returns true when `stale_after` parses and `now` has reached it.
 */
export declare function isStale(trust: NoteTrust, now: number): boolean;
/**
 * Record who produced a note's current content, as its `generated` field.
 * @param markdown - complete note text.
 * @param by - the actor that wrote the content.
 * @param at - when it wrote it, as an ISO 8601 date-time with a UTC offset.
 * @returns the note with the field replaced or added and every other byte unchanged.
 */
export declare function stampGenerated(markdown: string, by: string, at: string): string;
/**
 * Add one check to a note's `verified` list. An earlier check by the same
 * actor is replaced, so the list holds each actor's latest check. Every other
 * entry keeps its `by` and `at`, rewritten one per line.
 * @param markdown - complete note text.
 * @param by - the actor that checked the note.
 * @param at - when it checked it, as an ISO 8601 date-time with a UTC offset.
 * @returns the note with the list rewritten and every other byte unchanged.
 */
export declare function addVerified(markdown: string, by: string, at: string): string;
//# sourceMappingURL=trust.d.ts.map