/**
 * `@idealize/services` — one list of every service the app can connect, and
 * one way to connect them.
 *
 * A person adding fal.ai or Anthropic holds two facts: the company's name and
 * an API key. They do not hold an endpoint, a wire protocol or a route id, and
 * the surface that asks for those is the reason adding a service has been hard.
 * This plugin serves the list and stores the key, reading what a service is
 * called and what it makes from the registries that already know — the LLM
 * configurable-provider directory for chat, `ctx.generation` for images, video
 * and sound — so a service the app gains appears here with no entry to write.
 * @module @idealize/services
 */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
export * from './directory.ts';
export * from './join.ts';
export * from './media-directory.ts';
export { chatKeyEnv, installServicesRoute, KEYS_FILE_FORMAT } from './routes.ts';
export type { ServicesRuntime } from './routes.ts';
export { registerMediaServices } from './registrar.ts';
export { SHIPPED_PRICE_CURRENCY, shippedTokenPrices } from './shipped-prices.ts';
export type { ShippedTokenPrice } from './shipped-prices.ts';
export type { RegistrarOptions } from './registrar.ts';
export { createQueueBackend } from './adapters/queue.ts';
export type { QueueBackend, QueueBackendOptions, ServiceAuth } from './adapters/queue.ts';
export { createImagesBackend } from './adapters/images.ts';
export type { ImagesBackend, ImagesBackendOptions } from './adapters/images.ts';
export { readCatalogCache, readInputSchemaCache, writeCatalogCache, writeInputSchemaCache } from './adapters/catalog-cache.ts';
export { coerceBody, coerceLiteral, enumRetryValues, EXCLUDED_INPUTS, humaniseLabel, inputFieldsFrom, literalsFromMessage, parseInputSchema, } from './adapters/input-schema.ts';
export type { InputProperty, InputPropertyType, InputSchema } from './adapters/input-schema.ts';
/** Where one media service is reached, replacing the directory's addresses. */
export interface MediaEndpointOverride {
    /** Catalogue API origin including its version segment, no trailing slash. */
    baseUrl?: string;
    /** Queue API origin, no trailing slash. Queue services only. */
    queueUrl?: string;
}
/** Plugin config. */
export interface Config {
    /** Whole-generation timeout in milliseconds, enqueue to last download. */
    requestTimeoutMs?: number;
    /** Milliseconds between queue status polls. */
    pollIntervalMs?: number;
    /** Minutes between catalogue refreshes; 0 refreshes once on mount only. */
    catalogueRefreshMinutes?: number;
    /**
     * Where a media service is reached, keyed by its directory id. A deployment
     * behind a proxy or on a regional endpoint answers the same wire shapes at a
     * different host, which is what the retired per-service plugins offered as
     * `baseUrl` and `queueUrl`. An id absent here is reached at the address in
     * the directory; an id absent from the directory is refused at load.
     */
    mediaEndpoints?: Record<string, MediaEndpointOverride>;
}
/** Runtime schema for {@link Config}. */
export declare const Config: z<Config>;
/** Cordis plugin name. */
export declare const name = "idealize-services";
/** Required services. */
export declare const inject: string[];
/**
 * Register every media service's generation backend, serve the services list,
 * and store the keys it collects.
 * @param ctx - the host plugin context.
 * @param config - generation timings and catalogue refresh cadence.
 */
export declare function apply(ctx: Context, config: Config): void;
//# sourceMappingURL=index.d.ts.map