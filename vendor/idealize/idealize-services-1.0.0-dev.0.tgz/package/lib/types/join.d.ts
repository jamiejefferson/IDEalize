/**
 * The join that produces the Services list, pure: chat routes from the LLM
 * directory and generation backends from the generation registry, described
 * the same way and ordered together.
 * @module @idealize/services/join
 */
import type { ServiceRow } from './directory.ts';
/** One chat route as the LLM directory reports it, plus whether its key is stored. */
export interface ChatCandidate {
    provider: string;
    displayName: string;
    /** True while a stored credential resolves, or the route is signed into. */
    connected: boolean;
    /** True while this route is reached by signing in rather than by pasting a key. */
    signIn?: boolean;
}
/** One generation backend, plus the artefacts its catalogue currently offers. */
export interface MediaCandidate {
    backend: string;
    displayName: string;
    /** The credential environment name this backend resolves its key from. */
    env: string;
    connected: boolean;
    artefacts: readonly ('image' | 'video' | 'audio')[];
}
/**
 * The key page for a service, by route id then by display-name stem. Absent
 * when neither is in {@link KEY_PAGES}: a wrong address is worse than none.
 * @param id - the route or backend id.
 * @param name - the display name.
 * @returns the key page URL, or undefined.
 */
export declare function keyPageFor(id: string, name: string): string | undefined;
/**
 * What to call a service. A registry that hands back a route id as its display
 * name gets the company's own name from {@link SERVICE_NAMES}; anything the
 * registry genuinely named keeps that name.
 * @param id - the route or backend id.
 * @param displayName - the name the registry reported.
 * @returns the name to show.
 */
export declare function serviceName(id: string, displayName: string): string;
/**
 * Join both registries into the one list the Services section renders.
 *
 * A service appearing in both — a company selling chat and images alike —
 * stays two rows, because the two keys are stored in different places and
 * either can be connected without the other. The rows carry the same name and
 * differ in what they say they make, which is the honest description of what
 * connecting each one buys.
 * @param chat - the chat routes the LLM directory declares.
 * @param media - the registered generation backends with their artefacts.
 * @returns the rows in display order.
 */
export declare function joinServices(chat: readonly ChatCandidate[], media: readonly MediaCandidate[]): ServiceRow[];
//# sourceMappingURL=join.d.ts.map