/**
 * A key gateway: one key from an organisation's gateway reaches every model
 * service the organisation pays for. The gateway holds the real provider keys,
 * enforces what each person's key allows, and records spend. The person pastes
 * the gateway's address and their key under Brains, and IDEalize reads
 * `GET <address>/v1/me` to learn which services the key reaches and where each
 * one answers. No gateway is named in this code: the address is the person's
 * own setting, so the public app knows none.
 *
 * Each service the gateway lists becomes its own route beside any direct key
 * the person holds: `gateway-anthropic` and `gateway-openrouter` for chat
 * (serving the installed catalog through llm-pi-ai's `catalog`), and
 * `gateway-fal` and `gateway-openrouter` for pictures, sound and video. The
 * router counts a gateway route as the company it fronts, so a failing
 * gateway hands a turn to the direct key without a question, and back.
 *
 * The last good answer is kept on disk (without the key), so the app starts
 * with its gateway routes in place and keeps them through a gateway outage;
 * the answer is re-read in the background on start and every 30 minutes.
 * @module @idealize/services/gateway
 */
import type { Context } from '@deepseek-ai/cordis';
import type { MediaServiceRow } from './media-directory.ts';
import type { RegistrarOptions } from './registrar.ts';
/** The credential holding the person's gateway key. */
export declare const GATEWAY_KEY_ENV = "GATEWAY_API_KEY";
/** The credential holding the gateway's address, so one keys file can carry both. */
export declare const GATEWAY_URL_ENV = "GATEWAY_URL";
/** Every route and backend the gateway adds starts with this, and nothing else does. */
export declare const GATEWAY_PREFIX = "gateway-";
/** The last good `/v1/me` answer, without the key. */
export declare const GATEWAY_STATE_FILE = "gateway-me.json";
/** How long a check of the gateway may take before the app stops waiting. */
export declare const GATEWAY_TIMEOUT_MS = 5000;
/** How often the gateway's list of services is read again. */
export declare const GATEWAY_REFRESH_MS: number;
/** One service the gateway lists. */
export interface GatewayService {
    id: string;
    label?: string;
    base_url?: string;
}
/** The gateway's answer about one key. */
export interface GatewayMe {
    key?: {
        id?: string;
        name?: string;
        kind?: string;
        last4?: string;
    };
    preset?: string;
    budget_gbp?: number | null;
    spent_this_month_gbp?: number;
    services?: GatewayService[];
}
/** What the Brains pane shows about the gateway; never the key. */
export interface GatewayStatus {
    configured: boolean;
    address?: string;
    connected: boolean;
    keyName?: string;
    last4?: string;
    preset?: string;
    budgetGbp?: number | null;
    spentGbp?: number;
    /** The services the key reaches, by the gateway's own labels. */
    services: string[];
    /** The services IDEalize uses, by id. */
    used: string[];
    checkedAt?: string;
    /** The gateway's own words when it refused, or why it could not be asked. */
    error?: string;
}
/**
 * A gateway address as the app keeps it: https, or a local address for a test
 * gateway on this computer, with no trailing slash.
 * @param raw - what the person typed.
 * @returns the address, or the reason it cannot be used.
 */
export declare function gatewayAddress(raw: string): {
    address: string;
} | {
    error: string;
};
/** What reading the gateway came back with. */
export type MeReading = {
    ok: true;
    me: GatewayMe;
} | {
    ok: false;
    status: number;
    error: string;
};
/**
 * Ask the gateway about a key. Never throws.
 * @param address - the gateway address.
 * @param key - the person's gateway key.
 * @param fetchImpl - the transport.
 * @returns the answer, or the status and the words to show.
 */
export declare function readMe(address: string, key: string, fetchImpl?: typeof fetch): Promise<MeReading>;
/** The chat routes one answer adds, as llm-pi-ai profiles keyed by route. */
export declare function chatRoutesFor(address: string, me: GatewayMe): Record<string, Record<string, unknown>>;
/** The picture, sound and video services one answer adds. */
export declare function mediaRowsFor(address: string, me: GatewayMe): MediaServiceRow[];
/**
 * Where Jev's Decisions endpoint answers through the gateway, when it fronts OpenRouter.
 * @param address - the gateway address.
 * @param me - the gateway's answer.
 * @returns the address, or undefined when the gateway does not front OpenRouter.
 */
export declare function gatewayDecisionsUrl(address: string, me: GatewayMe): string | undefined;
/**
 * The status the pane shows.
 * @param address - the gateway address, when set.
 * @param me - the last good answer.
 * @param extra - when it was read and any error since.
 * @returns the status, with no key in it.
 */
export declare function statusOf(address: string | undefined, me: GatewayMe | undefined, extra: {
    checkedAt?: string;
    error?: string;
    connected: boolean;
}): GatewayStatus;
/** What the gateway needs from the services plugin. */
export interface GatewayOptions {
    home: string;
    registrar: RegistrarOptions;
    fetchImpl?: typeof fetch;
}
/** The gateway's face for other plugins: the router asks it where Jev answers. */
export interface GatewayFace {
    /** Check, store and switch on a gateway; the refusal, or undefined once connected. */
    connect(address: string, key: string): Promise<{
        status: number;
        error: string;
    } | undefined>;
    /** Jev's address and the key to send, when the gateway fronts OpenRouter. */
    decisions(): Promise<{
        url: string;
        key: string;
    } | undefined>;
    status(): GatewayStatus;
}
/**
 * Run the gateway: restore its routes, keep its list fresh, and serve
 * `/idealize/brains/gateway` (GET status, POST connect, DELETE disconnect).
 * @param ctx - the services plugin context.
 * @param options - home, registrar timings and a test fetch.
 * @returns the face other plugins read.
 */
export declare function installGateway(ctx: Context, options: GatewayOptions): GatewayFace;
//# sourceMappingURL=gateway.d.ts.map