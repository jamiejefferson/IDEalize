/**
 * Registers one generation backend per media service in the directory.
 *
 * Before this, each service was its own plugin row in the profile, so the set
 * of services the app could offer was fixed at composition time and a new one
 * meant a new package. Registration now comes from {@link MEDIA_SERVICES}:
 * every row gets a backend, keyed or not, because an unkeyed service still
 * has to appear in the Add list and still has to tell the space launcher what
 * it makes. Whether the key resolves is what `describe()` reports, and the
 * connect route's `refreshBackend` is what re-reads it, so pasting a key makes
 * the models selectable without a restart.
 * @module @idealize/services/registrar
 */
import type { Context } from '@deepseek-ai/cordis';
import type { MediaServiceRow } from './media-directory.ts';
/** What the registrar needs from its host, so the caller owns the filesystem and the clock. */
export interface RegistrarOptions {
    /** Harness home, where each service's catalogue cache lives. */
    home: string;
    /** Whole-generation timeout in milliseconds, enqueue to last download. */
    timeoutMs: number;
    /** Milliseconds between queue status polls. */
    pollIntervalMs: number;
    /** Minutes between catalogue refreshes; 0 refreshes once on mount only. */
    refreshMinutes: number;
    /** The rows to register; defaults to the whole directory. */
    rows?: readonly MediaServiceRow[];
    /** Fetch used by every adapter; injectable for keyless tests. */
    fetchImpl?: typeof fetch;
}
/**
 * Register every media service's backend, and keep their catalogues fresh.
 * @param ctx - a context carrying `generation`, `credentials` and a logger.
 * @param options - home, timings, the rows to register, and a test fetch.
 */
export declare function registerMediaServices(ctx: Context, options: RegistrarOptions): void;
//# sourceMappingURL=registrar.d.ts.map