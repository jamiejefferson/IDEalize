/**
 * The `/idealize/brains/services` routes. GET serves one list of every service
 * the app can connect — chat routes and generation backends together, each
 * saying what it makes and whether it is connected. POST stores (or, with an
 * empty key, removes) one service's API key, choosing where the key belongs
 * from the service's kind so the caller never has to know. POST `/import`
 * takes a keys file — several keys at once, each named by the credential it
 * fills — and connects every service those credentials belong to in one call.
 *
 * The caller supplies a name and a key. It supplies no endpoint, no wire
 * protocol and no route id, because a person adding a service they hold an
 * account with knows none of those and should not be asked.
 *
 * Loopback-fenced; the mutations demand the `x-idealize-auth` header, matching
 * `/idealize/brains/media-keys`.
 * @module @idealize/services/routes
 */
import type { Context } from '@deepseek-ai/cordis';
import type { ChatCandidate, MediaCandidate } from './join.ts';
/** The one keys-file format this build reads. */
export declare const KEYS_FILE_FORMAT = 1;
/**
 * The credential reference a chat route's key is stored under. Twin of
 * `deriveKeyRef` in `dsh-client-ui-settings-models`: the same route keyed from
 * either surface must reach the same credential, or a key pasted here would be
 * invisible to the models page and the route would stay unauthenticated.
 * @param provider - the chat route id.
 * @returns the credential environment name.
 */
export declare function chatKeyEnv(provider: string): string;
/** The queries this route reads its list from, and the writes it performs. */
export interface ServicesRuntime {
    /** Every chat route the LLM directory declares, with whether its key resolves. */
    chat(): Promise<ChatCandidate[]>;
    /** Every registered generation backend that takes a key, with its artefacts. */
    media(): MediaCandidate[];
    /** Store a chat route's `apiKeyEnv` so the route activates; a no-op when already recorded. */
    recordChatKeyEnv(provider: string, env: string): Promise<void>;
    /** Drop a chat route's `apiKeyEnv` when it names `env`, so a removed key leaves no record reading the route as keyed. */
    forgetChatKeyEnv(provider: string, env: string): Promise<void>;
    /** Re-read a generation backend's catalogue after its key changed. */
    refreshBackend(id: string): Promise<boolean>;
}
/**
 * Mount the services routes while a web server, settings and credential store
 * are composed beside the registries.
 * @param ctx - the plugin context.
 * @param runtime - the registry queries and writes the route performs.
 */
export declare function installServicesRoute(ctx: Context, runtime: ServicesRuntime): void;
/** The settings namespace whose section carries the chat provider profiles. */
export declare const LLM_NS: import("@deepseek-ai/dsh-settings").SettingsNamespace;
//# sourceMappingURL=routes.d.ts.map