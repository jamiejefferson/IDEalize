import type { ShippedFacts } from './model-facts.ts';
export declare const MODEL_FACTS_DATA: ShippedFacts;
//# sourceMappingURL=model-facts.data.d.ts.map