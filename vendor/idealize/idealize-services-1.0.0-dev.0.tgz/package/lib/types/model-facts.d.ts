/**
 * What the model browser filters on beyond price and inputs: the controls a
 * model offers (read from its own settings) and what it is good at (a fixed
 * vocabulary per kind). Good-at labels come from a classification run once
 * before release by `scripts/build-model-facts.mts`, which reads each model's
 * name, description, tags and cover picture; the result ships as
 * `model-facts.data.ts`, so nobody's key pays for it and the browser works
 * offline. Controls ship the same way and, for a model newer than the
 * shipped table, are read from its input schema once that has been fetched.
 * @module @idealize/services/model-facts
 */
import type { GenModelInfo } from '@idealize/generate';
/** The four kinds of model the browser lists. */
export type FactKind = 'chat' | 'image' | 'video' | 'audio';
/** One good-at label: its id and the definition the classifier is given. */
export interface GoodAtTerm {
    id: string;
    definition: string;
}
/**
 * The good-at vocabulary per kind (JJ, 24 Oct 2026: granular enough to choose
 * between models of one kind). The definitions are what the classifier reads;
 * the browser's locale names each id.
 */
export declare const GOOD_AT_TERMS: Readonly<Record<FactKind, readonly GoodAtTerm[]>>;
/** The control ids per kind, in the order the browser shows them. */
export declare const CONTROL_IDS: Readonly<Record<FactKind, readonly string[]>>;
/** One input as far as control matching reads it. */
export interface ControlInput {
    name: string;
    enum?: readonly string[];
    type?: string;
}
/**
 * The controls a model offers, from its input properties (or a chat model's
 * supported parameters), in the kind's order.
 * @param kind - what the model makes.
 * @param inputs - the model's input properties.
 * @returns control ids.
 */
export declare function controlsFromInputs(kind: FactKind, inputs: readonly ControlInput[]): string[];
/**
 * The key a chat model's facts are filed under, so one model reached through
 * different routes (OpenRouter's `anthropic/claude-sonnet-4.5`, the
 * subscription's `claude-sonnet-4-5-20250929`) finds one entry: the last path
 * segment, lower-cased, without a variant suffix, a date or `-latest`, dots as
 * dashes.
 * @param id - the route's model id.
 * @returns the key.
 */
export declare function chatFactKey(id: string): string;
/** What the browser knows of one model beyond its catalogue row. */
export interface ModelFacts {
    controls?: readonly string[];
    goodAt?: readonly string[];
}
/** One shipped entry: `c` the controls, `g` the good-at labels. */
export interface ShippedFact {
    c?: readonly string[];
    g?: readonly string[];
}
/** The shipped table's shape. */
export interface ShippedFacts {
    generatedAt: string;
    media: Readonly<Record<string, ShippedFact>>;
    chat: Readonly<Record<string, ShippedFact>>;
}
/**
 * The shipped facts for one media model.
 * @param id - the endpoint id.
 * @param table - the table to read; defaults to the shipped one.
 * @returns its controls and good-at labels, each absent when unknown.
 */
export declare function mediaFacts(id: string, table?: ShippedFacts): ModelFacts;
/**
 * The shipped facts for one chat model, by {@link chatFactKey}.
 * @param id - the route's model id.
 * @param table - the table to read; defaults to the shipped one.
 * @returns its controls and good-at labels, each absent when unknown.
 */
export declare function chatFacts(id: string, table?: ShippedFacts): ModelFacts;
/**
 * Media models with their shipped facts attached. A model newer than the
 * shipped table gets its controls from its input schema when one has been
 * read, and no good-at labels, so the browser falls back to its tags.
 * @param models - the catalogue as the adapter holds it.
 * @param inputsOf - the input properties already known for one model, if any.
 * @param table - the table to read; defaults to the shipped one.
 * @returns new rows; the input is not changed.
 */
export declare function withModelFacts(models: readonly GenModelInfo[], inputsOf?: (id: string) => readonly ControlInput[] | undefined, table?: ShippedFacts): GenModelInfo[];
//# sourceMappingURL=model-facts.d.ts.map