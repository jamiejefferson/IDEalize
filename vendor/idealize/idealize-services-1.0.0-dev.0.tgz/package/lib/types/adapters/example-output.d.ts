/**
 * An endpoint's example output, pure: find the file a model's OpenAPI
 * document publishes as an example result, so a detail pane can play or show
 * it. fal writes examples on the response schema (`…Output`, each file an
 * object with `url` and usually `content_type`); a document without one there
 * may still name a matching file elsewhere.
 * @module @idealize/services/adapters/example-output
 */
import type { GenArtefact, GenExample } from '@idealize/generate';
/**
 * Find a model's example output in its OpenAPI document. The response schema
 * (`components.schemas` keys ending in `Output`) is read first, file objects
 * before bare URL strings; failing that,
 * any https URL with a fitting extension anywhere else, leaving out the
 * document's `info` (it carries the catalogue thumbnail, which is no example)
 * and the input schemas (their example files are inputs, such as the picture
 * an image-to-image model starts from).
 * @param document - the parsed OpenAPI JSON (wire boundary: untrusted).
 * @param artefact - what the model makes.
 * @returns the example, or undefined when the document names none.
 */
export declare function exampleOutput(document: unknown, artefact: GenArtefact): GenExample | undefined;
//# sourceMappingURL=example-output.d.ts.map