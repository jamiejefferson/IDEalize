/**
 * Images-service wire translation, pure: build the chat-completions payload for
 * audio/video generation, read media outputs back out of the response, and
 * classify provider failures into the shared GenerationError codes.
 * @module @idealize/services/adapters/images-api
 */
import type { GenArtefact, GenerationOutput, GenerationRequest } from '@idealize/generate';
import type { GenerationErrorCode } from '@idealize/generate';
/**
 * Build the chat-completions payload for a media generation: the prompt (plus
 * image/audio attachments as content parts) with `modalities` asking for the
 * artefact beside text.
 * @param request - the task request.
 * @param artefact - the artefact being generated (`audio` or `video` routes use this endpoint).
 * @returns the JSON payload to POST to `/chat/completions`.
 */
export declare function chatMediaPayload(request: GenerationRequest, artefact: GenArtefact): Record<string, unknown>;
/**
 * Parse one `data:<mediaType>;base64,<payload>` URL.
 * @param url - the candidate data URL.
 * @returns the output, or undefined when the URL is not base64 data.
 */
export declare function parseDataUrl(url: string): GenerationOutput | undefined;
/**
 * Read the media outputs out of a chat-completions response: the message's
 * `audio.data` (typed by its `format`) and any `images[].image_url.url` data
 * URLs.
 * @param body - the parsed response JSON (wire boundary: untrusted).
 * @returns the outputs, empty when the response carries no media.
 */
export declare function outputsFromChatResponse(body: unknown): GenerationOutput[];
/**
 * Classify an HTTP failure status into the shared code union.
 * @param status - the response status.
 * @returns the provider-neutral code.
 */
export declare function classifyStatus(status: number): GenerationErrorCode;
/**
 * Classify an in-band provider failure message (the pi-ai images path returns
 * failures as text) into the shared code union.
 * @param message - the provider's failure text.
 * @returns the provider-neutral code; `PROVIDER_ERROR` when nothing matches.
 */
export declare function classifyFailureMessage(message: string): GenerationErrorCode;
//# sourceMappingURL=images-api.d.ts.map