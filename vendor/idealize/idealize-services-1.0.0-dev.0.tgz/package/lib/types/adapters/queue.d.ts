/**
 * The queue adapter: a media service whose generations run through a job
 * queue. `POST <queueUrl>/<endpoint>` enqueues the request, `status_url` is
 * polled until `COMPLETED`, `response_url` yields the result, and each result
 * file is downloaded into a base64 output. `refresh()` lists one live page per
 * category the service declares and re-reads whether a key is stored.
 * `inputs()` reads one endpoint's input schema from the service's OpenAPI
 * document, cached in memory and through the caller's disk callbacks, and the
 * same schema coerces each body to the wire types the endpoint names before
 * it is enqueued. Provider failures are translated into GenerationError codes;
 * raw provider errors never escape.
 *
 * Everything service-specific — the name in its messages, its endpoints, its
 * categories, the scheme its key is sent under — arrives as data from the
 * service directory, so a second queue-shaped service is a directory row
 * rather than a package.
 * @module @idealize/services/adapters/queue
 */
import type { BackendCredential, GenerationBackend, GenInputField, GenModelInfo } from '@idealize/generate';
import type { InputSchema } from './input-schema.ts';
import type { QueueCategory } from './queue-catalog.ts';
/** How a service wants its key presented on the wire. */
export interface ServiceAuth {
    /** Header the key is sent in. */
    header: string;
    /** Text placed before the key, `''` when the key is sent bare. */
    prefix: string;
}
/** Construction options for {@link createQueueBackend}. */
export interface QueueBackendOptions {
    /** Registry id — the `provider` half of stored model choices. */
    id: string;
    /** The service's own name for itself, used in every message the person can read. */
    name: string;
    /** Catalogue API origin including its version segment, no trailing slash. */
    baseUrl: string;
    /** Queue API origin, no trailing slash. */
    queueUrl: string;
    /** The catalogue categories to list, and what each implies. */
    categories: readonly QueueCategory[];
    /** How the key is presented on the wire. */
    auth: ServiceAuth;
    /** Whole-generation timeout in milliseconds, enqueue to last download. */
    timeoutMs: number;
    /** Milliseconds between status polls. */
    pollIntervalMs: number;
    /** The key the person pastes under Brains: its display name and credential environment name. */
    credential: BackendCredential;
    /** Resolve the API key per operation (the credentials seam's re-resolve rule). */
    resolveApiKey(): Promise<string | undefined>;
    /** The catalogue this service last gave, read from disk; empty on a first run. */
    cached?: readonly GenModelInfo[];
    /** Record a freshly fetched catalogue; the adapter never decides where it goes. */
    onCatalog?(models: readonly GenModelInfo[]): void;
    /**
     * Where the service publishes one endpoint's OpenAPI document, `{id}`
     * standing for the endpoint id. Absent when it publishes none: `inputs()`
     * then resolves empty and bodies go out as the seam built them.
     */
    inputSchemaUrl?: string;
    /** The input schema this service last gave for an endpoint, read from disk; undefined on a first use. */
    cachedInputs?(modelId: string): InputSchema | undefined;
    /** Record a freshly fetched input schema; the adapter never decides where it goes. */
    onInputSchema?(modelId: string, schema: InputSchema): void;
    /** Fetch used for every request; injectable for keyless tests. */
    fetchImpl?: typeof fetch;
}
/** The backend plus its adapter-side refresh and input-schema read. */
export interface QueueBackend extends GenerationBackend {
    refresh(): Promise<void>;
    inputs(modelId: string): Promise<readonly GenInputField[]>;
}
/**
 * Create one queue-shaped media backend.
 * @param options - the service's identity, endpoints, categories, auth, timeouts, credential resolution, cached catalogue, and test fetch.
 * @returns the backend to register with `ctx.generation`.
 */
export declare function createQueueBackend(options: QueueBackendOptions): QueueBackend;
//# sourceMappingURL=queue.d.ts.map