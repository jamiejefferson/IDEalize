/**
 * A queue endpoint's input schema, pure: read it out of the OpenAPI document
 * fal publishes per endpoint, project the fields a person may choose before
 * generating, coerce a request body to the wire types it names, and parse the
 * literals a 422 offers when no schema is known.
 * @module @idealize/services/adapters/input-schema
 */
import type { GenInputField } from '@idealize/generate';
/** The wire type of one input property, as far as coercion needs it. */
export type InputPropertyType = 'string' | 'number' | 'integer' | 'boolean' | 'other';
/** One property of an endpoint's input schema. */
export interface InputProperty {
    name: string;
    type: InputPropertyType;
    /** The string literals the property accepts, when it is an enum. */
    enum?: readonly string[];
    /** The default the endpoint applies when the body omits the property. */
    default?: string | number | boolean;
    /** The smallest value a numeric property accepts, when the schema states one. */
    minimum?: number;
    /** The largest value a numeric property accepts, when the schema states one. */
    maximum?: number;
    required: boolean;
}
/** One endpoint's input schema: its properties in the order the service lists them. */
export interface InputSchema {
    properties: readonly InputProperty[];
}
/**
 * Inputs never offered to the person: the prompt and attachment the seam
 * fills itself, and the fields that belong to the provider's plumbing rather
 * than to the piece being made. `num_images` stays out because the composer's
 * Count control owns image count.
 */
export declare const EXCLUDED_INPUTS: ReadonlySet<string>;
/**
 * The label a field shows: a fixed reading for the common names, otherwise the
 * wire name with underscores as spaces and a capital first letter.
 * @param name - the wire property name.
 * @returns the label.
 */
export declare function humaniseLabel(name: string): string;
/**
 * Read an endpoint's input schema out of its OpenAPI document: the first
 * `components.schemas` entry whose key ends in `Input`, its properties in
 * `x-fal-order-properties` order (document order for the rest), and its
 * `required` list.
 * @param document - the parsed OpenAPI JSON (wire boundary: untrusted).
 * @returns the schema, or undefined when the document carries no input schema.
 */
export declare function parseInputSchema(document: unknown): InputSchema | undefined;
/**
 * The fields a person may choose before generating: every string enum,
 * numeric property and boolean the schema names outside
 * {@link EXCLUDED_INPUTS}, labelled for display, with the endpoint's default
 * when it states one of the field's own type (an enum default must be among
 * the literals). A plain string property and anything of another type is not
 * a choice and yields no field.
 * @param schema - the endpoint's input schema.
 * @returns the fields in schema order; empty when the schema offers nothing to choose.
 */
export declare function inputFieldsFrom(schema: InputSchema): GenInputField[];
/**
 * The literal an enum accepts for a value: the value itself when it is among
 * the literals, its string form when that is (`5` for `"5"`), otherwise the
 * numeric literal nearest to a numeric value (`7.5` reads as `"8"`; a tie
 * takes the larger). Undefined when nothing in the enum fits.
 * @param value - the body value.
 * @param literals - the enum's literals.
 * @returns the literal to send, or undefined.
 */
export declare function coerceLiteral(value: unknown, literals: readonly string[]): string | undefined;
/**
 * Coerce a request body to the schema's wire types, field by field: a value
 * for an enum becomes the literal {@link coerceLiteral} picks, a string for a
 * numeric field becomes a number (rounded for integers), `"true"`/`"false"`
 * for a boolean field becomes the boolean, and a number for a plain string
 * field becomes its text. Fields the schema does not name pass through.
 * @param body - the body about to be sent.
 * @param schema - the endpoint's input schema.
 * @returns the coerced body; the same values where nothing applied.
 */
export declare function coerceBody(body: Readonly<Record<string, unknown>>, schema: InputSchema): Record<string, unknown>;
/**
 * The literals a 422 message offers: every single-quoted token of
 * `Input should be '4', '5' or '6'`.
 * @param msg - one validation entry's message.
 * @returns the literals, empty when the message is not that refusal.
 */
export declare function literalsFromMessage(msg: string): string[];
/**
 * The body fields a 422 refused for being outside a literal enum, with the
 * literal each should carry instead: used when no schema is known before the
 * first enqueue. A field whose value already fits, one absent from the body,
 * and one whose literals cannot be coerced to are left out.
 * @param entries - the 422's validation entries, each a field path and message.
 * @param body - the body that was sent.
 * @returns the fields to replace, or undefined when nothing can be replaced.
 */
export declare function enumRetryValues(entries: readonly {
    field: string;
    msg: string;
}[], body: Readonly<Record<string, unknown>>): Record<string, string> | undefined;
//# sourceMappingURL=input-schema.d.ts.map