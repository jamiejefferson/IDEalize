/**
 * The model catalogue on disk, one file per service, and beside it one input
 * schema per endpoint the person has generated with.
 *
 * A service's model list belongs to the service, not to this app's release: a
 * list compiled into the build is out of date the day it ships and cannot be
 * corrected without a new one. So nothing is compiled in. The first successful
 * live fetch is written here and read on every later start, which means a
 * rate-limited or offline start shows the last list the service gave rather
 * than a stale snapshot from packaging time.
 * @module @idealize/services/adapters/catalog-cache
 */
import type { GenModelInfo } from '@idealize/generate';
import type { InputSchema } from './input-schema.ts';
/**
 * Read the last catalogue a service gave.
 * @param home - the harness home directory.
 * @param id - the service's backend id.
 * @returns the cached models, or an empty list when there is no readable cache.
 */
export declare function readCatalogCache(home: string, id: string): readonly GenModelInfo[];
/**
 * Record the catalogue a service just gave.
 * @param home - the harness home directory.
 * @param id - the service's backend id.
 * @param models - the models the live fetch returned.
 */
export declare function writeCatalogCache(home: string, id: string, models: readonly GenModelInfo[]): void;
/**
 * Read the input schema a service last gave for one endpoint.
 * @param home - the harness home directory.
 * @param id - the service's backend id.
 * @param endpoint - the endpoint (model) id.
 * @returns the cached schema, or undefined when there is no readable cache.
 */
export declare function readInputSchemaCache(home: string, id: string, endpoint: string): InputSchema | undefined;
/**
 * Record the input schema a service just gave for one endpoint.
 * @param home - the harness home directory.
 * @param id - the service's backend id.
 * @param endpoint - the endpoint (model) id.
 * @param schema - the parsed schema.
 */
export declare function writeInputSchemaCache(home: string, id: string, endpoint: string, schema: InputSchema): void;
//# sourceMappingURL=catalog-cache.d.ts.map