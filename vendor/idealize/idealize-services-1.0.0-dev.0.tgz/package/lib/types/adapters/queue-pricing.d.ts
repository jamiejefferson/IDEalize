/**
 * Queue-service prices, pure: build the batched `GET /models/pricing`
 * addresses, read one response page, and state each rate per typical output
 * so models priced in different units sort together.
 *
 * The response shape follows fal's Platform API documentation:
 * `{ prices: [{ endpoint_id, unit_price, unit, currency }], next_cursor, has_more }`.
 * @module @idealize/services/adapters/queue-pricing
 */
import type { GenArtefact, GenModelPrice } from '@idealize/generate';
/** How many endpoint ids one pricing request names. */
export declare const PRICING_BATCH = 50;
/**
 * The pricing addresses for a list of endpoints, one per batch.
 * @param pricingUrl - the service's pricing endpoint.
 * @param ids - the endpoint ids to price.
 * @param batch - ids per request.
 * @returns one URL per batch, in id order.
 */
export declare function pricingUrls(pricingUrl: string, ids: readonly string[], batch?: number): string[];
/** One endpoint's price as the service states it, before it is stated per output. */
export interface ListedPrice {
    unitPrice: number;
    unit: string;
    currency: string;
}
/**
 * Read one pricing response page. Rows without an endpoint id, a finite
 * non-negative price or a unit are dropped; a missing currency reads as USD,
 * the only currency fal bills in.
 * @param body - the parsed response JSON (wire boundary: untrusted).
 * @returns prices by endpoint id.
 */
export declare function pricesFrom(body: unknown): Map<string, ListedPrice>;
/**
 * A listed price, with its cost per typical output where the unit allows:
 * an image unit is per image, a megapixel unit is one 1-megapixel image, a
 * second of video is a fifth of a 5-second clip, and a second or minute of
 * audio is stated per minute. Any other unit (`units`, tokens, compute
 * seconds) states no per-output figure, because none can be read from it.
 * @param listed - the price as the service lists it.
 * @param artefact - what the model makes.
 * @returns the seam's price.
 */
export declare function modelPrice(listed: ListedPrice, artefact: GenArtefact): GenModelPrice;
//# sourceMappingURL=queue-pricing.d.ts.map