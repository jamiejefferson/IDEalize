/**
 * The images adapter: a media service that speaks the OpenAI images and
 * chat-completions shapes. Images run through the vendored pi-ai openrouter
 * images provider; audio (and video, when the catalogue offers it) runs
 * through the chat-completions endpoint with `modalities`. `refresh()` merges
 * the live keyless `/models` list over what is already known. Provider
 * failures are translated into GenerationError codes; raw provider errors
 * never escape.
 *
 * The service's identity, endpoint and credential arrive as data from the
 * service directory. The wire shapes do not: this adapter is written to
 * OpenRouter's, which is the only service the app has evidence for, and a
 * service that answers differently needs its own adapter rather than options
 * on this one.
 * @module @idealize/services/adapters/images
 */
import type { BackendCredential, GenerationBackend, GenModelInfo } from '@idealize/generate';
/** Construction options for {@link createImagesBackend}. */
export interface ImagesBackendOptions {
    /** Registry id — the `provider` half of stored model choices. */
    id: string;
    /** The service's own name for itself, used in every message the person can read. */
    name: string;
    /** API origin including its version segment, no trailing slash. */
    baseUrl: string;
    /** Per-request timeout in milliseconds. */
    timeoutMs: number;
    /** The key the person pastes under Brains: its display name and credential environment name. */
    credential?: BackendCredential;
    /** Resolve the API key per operation (the credentials seam's re-resolve rule). */
    resolveApiKey(): Promise<string | undefined>;
    /** The catalogue this service last gave, read from disk; empty on a first run. */
    cached?: readonly GenModelInfo[];
    /** Record a freshly fetched catalogue; the adapter never decides where it goes. */
    onCatalog?(models: readonly GenModelInfo[]): void;
    /** Fetch used for the catalogue and the chat endpoint; injectable for keyless tests. */
    fetchImpl?: typeof fetch;
}
/** The backend plus its adapter-side control: the catalogue refresh. */
export interface ImagesBackend extends GenerationBackend {
    refresh(): Promise<void>;
}
/**
 * Create one images-shaped media backend.
 * @param options - the service's identity, endpoint, timeout, credential resolution, cached catalogue, and test fetch.
 * @returns the backend to register with `ctx.generation`.
 */
export declare function createImagesBackend(options: ImagesBackendOptions): ImagesBackend;
//# sourceMappingURL=images.d.ts.map