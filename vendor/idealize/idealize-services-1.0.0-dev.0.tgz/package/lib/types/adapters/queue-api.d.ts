/**
 * Queue-service wire translation, pure: build the queue request body from a
 * generation request, find the result files in a queue response, and classify
 * provider failures into the shared GenerationError codes.
 * @module @idealize/services/adapters/queue-api
 */
import type { GenAttachment, GenerationErrorCode, GenerationRequest } from '@idealize/generate';
/**
 * The first image attachment of a request, when it carries one.
 * @param request - the task request.
 * @returns the attachment, or undefined.
 */
export declare function imageAttachment(request: GenerationRequest): GenAttachment | undefined;
/**
 * The endpoint one request is enqueued on. fal publishes each video family as
 * sibling endpoints, `…/text-to-video` and `…/image-to-video` (Seedance, Veo,
 * Kling and the rest), and only the image-conditioned one takes `image_url`.
 * A request carrying an image attachment to a model whose id ends in
 * `text-to-video` therefore goes to the `image-to-video` sibling; every other
 * request goes to the model's own endpoint.
 * @param modelId - the catalogue endpoint id the request names.
 * @param request - the task request.
 * @returns the endpoint id to POST to.
 */
export declare function endpointFor(modelId: string, request: GenerationRequest): string;
/**
 * Build the JSON body for `POST queue.fal.run/<endpoint>`: the prompt, the
 * first image attachment as a data URL (`image_url`, the field fal's
 * image-conditioned endpoints share), and the seam's neutral settings mapped
 * onto fal's vocabulary — `aspect` `a:b` becomes `aspect_ratio`, `aspect`
 * `WxH` becomes `image_size {width, height}`, `duration_s` becomes `duration`,
 * `count` becomes `num_images`. Other settings pass through under their own
 * names, and a setting already carrying fal's own name (`duration`,
 * `aspect_ratio`, `image_size`, `num_images`) wins over the neutral one; the
 * endpoint's 422 reports any it refuses. Values keep their type here; the
 * endpoint's input schema decides the wire type at enqueue.
 * @param request - the task request.
 * @returns the body to POST.
 */
export declare function queuePayload(request: GenerationRequest): Record<string, unknown>;
/** One result file a queue response names. */
export interface ResultFile {
    url: string;
    /** The `content_type` beside the URL, when the endpoint states one. */
    contentType?: string;
}
/**
 * Find every file in a queue result: any object carrying a string `url`
 * (`images[]`, `image`, `video`, `audio`, `audio_file`, and whatever an
 * endpoint names its output), in document order, at most 32 deep.
 * @param result - the parsed result JSON (wire boundary: untrusted).
 * @returns the files, empty when the result carries none.
 */
export declare function resultFilesFrom(result: unknown): ResultFile[];
/**
 * Classify an HTTP refusal from fal into the shared code union.
 * @param status - the response status.
 * @returns the code a GenerationError should carry.
 */
export declare function classifyStatus(status: number): GenerationErrorCode;
/** One validation entry of a fal 422 body, with its `loc` reduced to the field path under `body`. */
export interface ValidationEntry {
    msg: string;
    /** The dotted field path, `''` when the entry names no location. */
    field: string;
}
/**
 * The validation entries of a fal 422 body text.
 * @param text - the response body text (wire boundary: untrusted).
 * @returns the entries in document order; empty when the text is not fal's validation JSON.
 */
export declare function refusedFields(text: string): ValidationEntry[];
/**
 * The plain reason in a fal error body: `detail` as a string, or the
 * `msg` of each validation entry joined.
 * @param text - the response body text.
 * @returns the reason, or the text itself (bounded) when it is not fal's error JSON.
 */
export declare function refusalReason(text: string): string;
/**
 * Fields fal endpoints require beyond the prompt, and the value each takes
 * when the request carries nothing for it. fal's music endpoints
 * (`minimax/music-3` among them) require `lyrics` beside `prompt`, and
 * `[instrumental]` is the structure tag their lyric vocabulary uses for a
 * track with no words. These are fal wire vocabulary, not deployment choices.
 */
export declare const REQUIRED_FIELD_DEFAULTS: Readonly<Record<string, string>>;
/**
 * The defaults that would satisfy a 422 whose every `Field required` entry
 * names a field absent from the sent body and present in
 * {@link REQUIRED_FIELD_DEFAULTS}.
 * @param text - the 422 response body text (wire boundary: untrusted).
 * @param body - the body that was sent.
 * @returns the fields to add, or undefined when the 422 names no missing
 * field, names one without a default, or is not a validation body at all.
 */
export declare function requiredFieldDefaults(text: string, body: Record<string, unknown>): Record<string, string> | undefined;
//# sourceMappingURL=queue-api.d.ts.map