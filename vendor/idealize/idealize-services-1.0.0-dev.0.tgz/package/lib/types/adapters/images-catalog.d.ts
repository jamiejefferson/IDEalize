/**
 * Images-service catalogue handling, pure: map the live `/models` response to
 * seam model metadata by output modality, and merge live rows over what is
 * already known. Nothing is compiled in — the known rows come from the cache
 * the last successful fetch wrote, plus the image shapes the vendored provider
 * library carries.
 * @module @idealize/services/adapters/images-catalog
 */
import type { ImagesModel } from '@earendil-works/pi-ai';
import type { GenArtefact, GenModality, GenModelInfo } from '@idealize/generate';
/**
 * Media-type ranges per artefact: the catalogue does not state result formats.
 * @param artefact - the artefact kind a model produces.
 * @returns the wildcard media-type range for that kind.
 */
export declare function defaultMediaTypes(artefact: GenArtefact): string[];
/**
 * The artefact a model's output modalities imply: the richest non-text output
 * (video over audio over image), or undefined for text-only rows.
 * @param outputs - the row's `architecture.output_modalities`.
 * @returns the artefact, or undefined when the row generates no media.
 */
export declare function artefactOf(outputs: readonly GenModality[]): GenArtefact | undefined;
/**
 * Map the live `/api/v1/models` response body to seam model metadata,
 * keeping only rows whose output modalities name a media artefact.
 * @param body - the parsed response JSON (wire boundary: untrusted).
 * @returns one entry per media-generating row, in response order.
 */
export declare function liveModelsFrom(body: unknown): GenModelInfo[];
/**
 * Map one pi-ai images-catalogue model to seam metadata.
 * @param model - one row of the vendored provider library's own image catalogue.
 * @returns the seam metadata for that model; a row naming no name is named by its id.
 */
export declare function fromImagesModel(model: ImagesModel<string>): GenModelInfo;
/**
 * Merge live catalogue rows over what is already known: a live row replaces
 * the known row with its id, and a known row the live list omits stays
 * selectable, so a partial fetch never shrinks the picker.
 * @param known - what the cache held, or the last refresh produced.
 * @param live - the rows the last refresh produced.
 * @returns the merged catalogue, known order first, then new live rows.
 */
export declare function mergeCatalog(known: readonly GenModelInfo[], live: readonly GenModelInfo[]): GenModelInfo[];
//# sourceMappingURL=images-catalog.d.ts.map