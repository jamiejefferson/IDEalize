/**
 * The connection check: a quick, free read against the service itself, so a
 * person learns whether a key works when they connect it rather than when a
 * chat fails later. Each probe reads an address that needs the key and spends
 * nothing; a service with no such address reads as untested.
 * @module @idealize/services/connection-check
 */
/** What the check found. */
export type CheckState = 'working' | 'refused' | 'no-credit' | 'no-keys' | 'failed' | 'untested';
/**
 * Whether this service has a free probe.
 * @param id - the service id.
 * @returns true when {@link checkKey} can prove a key for it.
 */
export declare function canProbe(id: string): boolean;
/**
 * Check one key against its service.
 * @param id - the service id.
 * @param key - the key.
 * @param fetchImpl - the transport, for tests.
 * @returns what the service said; never throws.
 */
export declare function checkKey(id: string, key: string, fetchImpl?: typeof fetch): Promise<CheckState>;
//# sourceMappingURL=connection-check.d.ts.map