/**
 * The embedded sidecar's admin password, kept beside the account it unlocks.
 *
 * The account lives in the sidecar's own database under its data directory;
 * the password the host generated for it lives in the credential store. Those
 * are two different places, and the sidecar's setup endpoint runs exactly
 * once: lose the credential while the database survives and the host can
 * neither log in nor set up again, so the embedded sidecar stays down for
 * good. Writing the password into the data directory as well means the two
 * halves travel together, and a credential store that has been reset recovers
 * from the file instead of failing.
 */
/**
 * Read the password the host previously generated for this data directory.
 * @param dataDir - the sidecar's data directory.
 * @returns the password, or undefined when no readable record exists.
 */
export declare function readAdminPassword(dataDir: string): string | undefined;
/**
 * Record the password beside the account it unlocks, readable by this user only.
 * @param dataDir - the sidecar's data directory.
 * @param adminPassword - the password the host generated at setup.
 */
export declare function writeAdminPassword(dataDir: string, adminPassword: string): void;
//# sourceMappingURL=admin-password.d.ts.map