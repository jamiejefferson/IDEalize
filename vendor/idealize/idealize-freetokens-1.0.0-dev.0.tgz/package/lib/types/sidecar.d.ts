/**
 * The embedded FreeLLMAPI sidecar: spawn the forked server on a private
 * loopback port with its own data directory, provision it hands-free over
 * loopback (first-run setup skips the setup code locally), and hand back the
 * unified /v1 key. The manager owns the child's lifetime: crash → respawn
 * with backoff, dispose → SIGTERM.
 */
/** How the embedded engine process is started. */
export interface SidecarOptions {
    /**
     * Absolute path to the server's JS entry: a fork checkout's
     * `dist/index.js` in dev, or the single-file `server.mjs` bundle the
     * desktop app ships.
     */
    entry: string;
    /** Working directory for the child; defaults to the entry's directory. */
    cwd?: string;
    /** Loopback port the sidecar binds. */
    port: number;
    /** Data directory (DB + key file) owned by this deployment. */
    dataDir: string;
    /** Where the child's lifecycle lines go. */
    log: (message: string) => void;
}
/** What `provision()` hands back once the engine account exists. */
export interface ProvisionResult {
    /** The unified /v1 API key. */
    apiKey: string;
    /** Present only when this call created the account (store it). */
    adminPassword?: string;
}
/** Owns the embedded engine child process: spawn, health wait, respawn on exit, and account provisioning. */
export declare class SidecarManager {
    private readonly options;
    private child;
    private disposed;
    private fastFailures;
    constructor(options: SidecarOptions);
    /** The loopback origin the engine answers on. */
    get baseURL(): string;
    /** Spawn the server and resolve once it answers on its port. */
    start(): Promise<void>;
    private spawnChild;
    /**
     * Ensure an account and return the unified key. First run creates the
     * account (loopback skips the setup code) with a generated password the
     * caller must persist; later runs log in with the stored password.
     * @param storedPassword - the admin password persisted by an earlier run, undefined on first run.
     * @returns the unified key, plus `adminPassword` only when this call created the account.
     * @throws when setup is complete but the stored password does not log in, or the key cannot be read.
     */
    provision(storedPassword: string | undefined): Promise<ProvisionResult>;
    /**
     * Ensure the directory the child serves as its static assets, holding one
     * page that says what this port is.
     * @returns the absolute directory path.
     */
    private portPageDir;
    /** Terminate the child and stop respawning; safe to call more than once. */
    stop(): void;
    private getJson;
    private postJson;
}
//# sourceMappingURL=sidecar.d.ts.map