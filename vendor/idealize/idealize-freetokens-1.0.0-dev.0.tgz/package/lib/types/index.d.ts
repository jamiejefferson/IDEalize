/**
 * IDEalize free tokens: the `freetokens` provider over a FreeLLMAPI sidecar
 * (our fork: jamiejefferson/idealize-freellmapi). Two modes:
 *
 * - **Embedded** (config `sidecarDir` or `serverBundle` set, or the desktop
 *   pointing IDEALIZE_FREETOKENS_SERVER at its shipped single-file server
 *   bundle): the plugin spawns the forked server itself on a private
 *   loopback port with its own data directory
 *   under the harness home, provisions it hands-free (first-run setup +
 *   unified key over loopback), stores the credentials and registers the
 *   provider route — zero user setup. The user's only job is adding
 *   upstream provider keys (OpenRouter first) on the page.
 * - **Adopt** (no `sidecarDir`): detect an already-running instance (JJ's
 *   own on 3001) and register it with a pasted key, as before.
 *
 * Registration writes two places:
 * - the key goes into the credentials service under FREETOKENS_API_KEY, and
 * - the settings document's `llm-pi-ai:` section gains a hand-declared
 *   `freetokens` route (openai-completions at the sidecar's /v1) listing the
 *   models the sidecar reported.
 *
 * HTTP surface (loopback-fenced; adopt demands the header):
 * - GET  /idealize/freetokens — status page (sidecar detected, route state).
 * - POST /idealize/freetokens/adopt — {apiKey} verify + register.
 * - GET  /idealize/freetokens/status — the same facts as JSON.
 * - GET  /idealize/freetokens/routing — the engine's routing strategy, its
 *   active weight vector (null in priority mode), the saved custom vector
 *   and the per-model score breakdown (engine GET /api/fallback/routing).
 * - POST /idealize/freetokens/routing/strategy — {strategy, weights?}: switch
 *   the engine's strategy; weights {reliability, speed, intelligence} are
 *   any non-negative vector, saved as the custom vector (engine PUT
 *   /api/fallback/routing). Reliability is one weight of the engine's convex
 *   score, drawn per request from each model's success/failure posterior.
 */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
export { IdealizeAttribution, PROJECT_HEADER } from './attribution.ts';
/** Plugin config: an external engine origin, or one of the two embedded-mode entry points. */
export interface Config {
    /** The sidecar's origin; /v1 is appended for the provider route. */
    baseURL?: string;
    /** The fork checkout's `server` directory; set = embedded mode. */
    sidecarDir?: string;
    /**
     * Absolute path to a single-file server bundle (esbuild output); set =
     * embedded mode. The desktop app ships one in its resources and points
     * here through the IDEALIZE_FREETOKENS_SERVER env var, which fills this
     * in when neither it nor sidecarDir is configured.
     */
    serverBundle?: string;
    /** Loopback port the embedded sidecar binds. */
    sidecarPort?: number;
}
export declare const Config: z<Config>;
export declare function apply(ctx: Context, config: Config): void;
//# sourceMappingURL=index.d.ts.map