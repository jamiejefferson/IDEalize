/** The /idealize/freetokens page: engine status, provider keys, adoption. */
interface StatusView {
    baseURL: string;
    detected: boolean;
    keyStored: boolean;
    routeRegistered: boolean;
    modelCount?: number;
    embedded?: string;
}
/**
 * Render the /idealize/freetokens status page.
 * @param view - the engine, route, and key facts the page states.
 * @returns the complete HTML document.
 */
export declare function statusPage(view: StatusView): string;
export {};
//# sourceMappingURL=status-page.d.ts.map