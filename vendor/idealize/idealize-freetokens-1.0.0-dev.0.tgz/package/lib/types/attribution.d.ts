/**
 * Project attribution for the spend meter: `ctx.idealizeAttribution` maps a
 * requesting session to an `x-idealize-project` header. The label is the
 * session cwd's git toplevel basename (the same project rule the vault
 * uses), the cwd basename outside a repo. The llm-pi-ai fork calls
 * `headersFor` per request through its annotateRequest seam; the forked
 * FreeLLMAPI server writes the header into `requests.client_label`, which
 * /api/analytics/by-label rolls up.
 */
import { Context, Service } from '@deepseek-ai/cordis';
declare module '@deepseek-ai/cordis' {
    interface Context {
        idealizeAttribution: IdealizeAttribution;
    }
}
/** The request header carrying the project label the engine attributes spend to. */
export declare const PROJECT_HEADER = "x-idealize-project";
/** Maps a requesting session to its project attribution header. */
export declare class IdealizeAttribution extends Service {
    private readonly byCwd;
    private readonly warming;
    constructor(ctx: Context);
    /**
     * Resolve one cwd's label asynchronously into the cache `headersFor` reads.
     * A label already cached, or one the sync path caches meanwhile, is kept.
     * @param cwd - The session cwd to resolve; empty or undefined is ignored.
     * @returns a promise settled once the label is cached; it never rejects.
     */
    warm(cwd: string | undefined): Promise<void>;
    /**
     * Attribution headers for one request; undefined when nothing is known.
     * @param sessionId - The requesting session, when the request has one.
     * @returns the `x-idealize-project` header, or undefined without a session cwd.
     */
    headersFor(sessionId: string | undefined): Record<string, string> | undefined;
}
//# sourceMappingURL=attribution.d.ts.map