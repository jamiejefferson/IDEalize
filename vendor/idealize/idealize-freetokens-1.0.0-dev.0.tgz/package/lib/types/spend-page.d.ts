/**
 * The /idealize/spend page: per-project token spend from the embedded
 * engine's request ledger. "Value" prices every token at the paid rate, so
 * work done on free routes still shows what it was worth.
 */
/**
 * Render the spend page.
 * @returns the complete HTML document.
 */
export declare function spendPage(): string;
//# sourceMappingURL=spend-page.d.ts.map