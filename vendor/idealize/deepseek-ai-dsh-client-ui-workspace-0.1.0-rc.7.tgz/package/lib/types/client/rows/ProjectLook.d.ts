import type { WorkspaceBrowserProps } from '../contract/slots.ts';
/** The route `@idealize/spaces` serves the looks under. */
export declare const PROJECT_LOOK_PATH = "/idealize/project-look";
/** One project's look as the route reports it. */
export interface ProjectLook {
    accent: string | null;
    logo: 'auto' | 'custom' | 'none';
    iconUrl: string | null;
}
/**
 * The accent swatches the dialog offers. Mid-tone hues that hold their own as
 * a 16px glyph on both the light and the dark sidebar.
 */
export declare const ACCENT_SWATCHES: readonly [{
    readonly id: "red";
    readonly value: "#e5484d";
}, {
    readonly id: "orange";
    readonly value: "#f76b15";
}, {
    readonly id: "yellow";
    readonly value: "#d6a10a";
}, {
    readonly id: "green";
    readonly value: "#30a46c";
}, {
    readonly id: "teal";
    readonly value: "#12a594";
}, {
    readonly id: "blue";
    readonly value: "#3e63dd";
}, {
    readonly id: "violet";
    readonly value: "#8e4ec6";
}, {
    readonly id: "pink";
    readonly value: "#d6409f";
}];
type Translate = WorkspaceBrowserProps['t'];
/**
 * Fetch every project's look again and tell the rows. A failed fetch keeps
 * the last copy: a missing route (a build without `@idealize/spaces`) leaves
 * every row on its folder glyph.
 * @returns when the fetch settles.
 */
export declare function refreshProjectLooks(): Promise<void>;
/**
 * One project's look, kept current.
 * @param workspaceId - the project's id, or undefined for a group with none.
 * @returns the look, or undefined while unknown.
 */
export declare function useProjectLook(workspaceId: string | undefined): ProjectLook | undefined;
/**
 * The project row's leading slot content: the logo when there is one, else
 * the folder glyph, coloured with the accent when one is set.
 * @param props.workspaceId - the project's id (absent for the ungrouped and Powell groups).
 * @param props.expanded - whether the group is open (open folder glyph).
 * @param props.active - whether the open group holds the current chat.
 * @returns the slot element.
 */
export declare function ProjectSlot({ workspaceId, expanded, active }: {
    workspaceId: string | undefined;
    expanded: boolean;
    active: boolean;
}): import("react").JSX.Element;
/**
 * The Icon and colour dialog for one project. Every choice saves at once.
 * @param props.target - the project being edited, or null when closed.
 * @param props.onClose - close the dialog.
 * @param props.t - the browser root's locale seat.
 * @returns the dialog.
 */
export declare function ProjectLookDialog({ target, onClose, t }: {
    target: {
        workspaceId: string;
        title: string;
    } | null;
    onClose: () => void;
    t: Translate;
}): import("react").JSX.Element;
export {};
//# sourceMappingURL=ProjectLook.d.ts.map