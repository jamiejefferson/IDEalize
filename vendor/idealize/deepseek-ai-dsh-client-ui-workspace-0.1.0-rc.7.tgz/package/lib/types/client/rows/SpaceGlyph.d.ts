import type { WorkspaceBrowserProps } from '../contract/slots.ts';
import type { SpaceId } from '../tree.ts';
/**
 * One row's space lane.
 *
 * Rendered on every session row in every space, so the lane runs as a straight
 * vertical line down the list and no row shifts or changes height when a
 * chat's space resolves.
 * @param props - the row's space and the workspace-namespace locale seat.
 * @returns the fixed-width lane holding this space's icon.
 */
export declare function SpaceGlyph({ space, t }: {
    space: SpaceId;
    t: WorkspaceBrowserProps['t'];
}): import("react").JSX.Element;
//# sourceMappingURL=SpaceGlyph.d.ts.map