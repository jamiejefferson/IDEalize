/**
 * What a confined chat may not read: the person's stored keys, shell history
 * and the app's data folder. This module is the rule list's one home. The
 * Seatbelt profile (`@deepseek-ai/dsh-sandbox-local`) and the in-process read
 * fence (`@deepseek-ai/dsh-fs-sandbox`) both evaluate these rules, so a secret
 * the shell cannot read is a secret the read tools cannot read either.
 *
 * Rules run in order and the last match wins, which is Seatbelt's own
 * semantics. The list has four layers:
 *
 * 1. Every app data folder is closed: the running app's, its Electron folder,
 *    the default `~/.dsh`, and any other IDEalize install on the machine.
 * 2. What a chat needs from the running app's folder reopens: the commands on
 *    its PATH, plugin code, skills, presets, its own session log, and its
 *    working folder when that sits inside the data folder (Powell's does).
 * 3. Key files close again, so a reopened folder can never expose one.
 * 4. Secrets in the home folder close: login folders, credential files, shell
 *    history, and SSH private keys. `config`, `known_hosts`, `*.pub` and the
 *    agent socket stay usable, so `git push` over SSH keeps working through
 *    the agent.
 *
 * The owner can reopen a path with `readAllowed` on `dsh-sandbox-policy`.
 * Windows has no rules: its ACL runner has no read denial, and its behaviour
 * is unchanged.
 *
 * @module dsh-sandbox/read-denials
 */
import type { SandboxExecutionPolicy } from './index.ts';
/** How one rule matches a canonical path. */
export type ReadMatch = {
    kind: 'subpath';
    path: string;
} | {
    kind: 'literal';
    path: string;
}
/** An anchored regular expression; `root` names the folder it can only match under. */
 | {
    kind: 'regex';
    pattern: string;
    root: string;
};
/** One ordered rule. The last rule that matches a path decides it. */
export interface ReadRule {
    effect: 'deny' | 'allow';
    match: ReadMatch;
    /** Set on the working-folder allow: it also reopens writes, which only that folder gets. */
    workspace?: true;
}
/** Where the rules look. Everything defaults to the running process's own home and data folder. */
export interface ReadDenialEnvironment {
    /** The person's home folder. */
    home?: string;
    /** The app's data folder (the harness home). */
    dataHome?: string;
    /** The platform the rules are for. */
    platform?: NodeJS.Platform;
}
/**
 * The rules for one confined call, in order. Empty under full access and on
 * Windows.
 * @param policy - the call's resolved policy.
 * @param environment - overrides for the home folder, data folder and platform.
 * @returns the ordered rules; the last that matches a path decides it.
 */
export declare function readDenialRules(policy: SandboxExecutionPolicy, environment?: ReadDenialEnvironment): ReadRule[];
/**
 * Whether the rules refuse reading one path, by the same last-match-wins
 * evaluation the Seatbelt profile gets from the kernel.
 * @param path - a canonical absolute path.
 * @param rules - the ordered rules from {@link readDenialRules}.
 * @param platform - the platform, for case folding.
 * @returns true when the last matching rule denies.
 */
export declare function isReadDenied(path: string, rules: readonly ReadRule[], platform?: NodeJS.Platform): boolean;
/**
 * Whether a search walking down from `root` would reach a closed folder.
 * `grep` skips hidden names, so only a route with no hidden step counts.
 * @param root - the canonical folder the search starts in.
 * @param rules - the ordered rules from {@link readDenialRules}.
 * @returns true when the walk would pass through a closed location.
 */
export declare function searchReachesDenied(root: string, rules: readonly ReadRule[]): boolean;
/**
 * The folders above a closed location. Renaming one would move the secret to a
 * path the rules no longer name, so a chat working in the home folder must not
 * be able to rename them.
 * @param rules - the ordered rules from {@link readDenialRules}.
 * @returns the canonical ancestor folders, deepest and shallowest alike.
 */
export declare function protectedAncestors(rules: readonly ReadRule[]): string[];
/** Plain words for a refused read, for the model and the person behind it. */
export declare const READ_DENIED_REASON = "That file is closed to this chat: it holds keys, or sits in the app's private data. Ask the person to do this themselves, or to switch this chat to Full access if they want it to go ahead.";
//# sourceMappingURL=read-denials.d.ts.map