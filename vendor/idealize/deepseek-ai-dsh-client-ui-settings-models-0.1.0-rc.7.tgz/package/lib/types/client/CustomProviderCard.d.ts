/**
 * The card that declares a provider pi-ai does not ship — an OpenAI-compatible
 * gateway, a self-hosted server, or a provider newer than the installed
 * catalog.
 *
 * This is a create, not an edit, which is why it is its own card rather than
 * the provider editor with extra fields: the route id is being *chosen* here,
 * and the settings address does not exist until it is. One `settings.mutate`
 * sets the whole profile at `providers.<route>`; the key travels separately
 * through `credentials.set` under the reference the profile records, exactly as
 * an existing provider's key does.
 *
 * Two fields up front — the endpoint and the key (JJ, 2 Sep 2026: "can't we
 * just add the url and the api?"). Everything else derives from them: the
 * route id from the URL's host, the display name from the id, the protocol
 * from the adapter's first, and the model list from asking the endpoint the
 * moment URL and key are both typed. The derived values stay editable under
 * "More options", and a discovery that fails leaves the manual editor there.
 * The three facts a hand-declared route cannot default — endpoint, protocol,
 * and at least one model — are still required before Create enables, so the
 * failure names the field while the user is still looking at it.
 *
 * There is deliberately no reasoning-effort control, here or on the editor
 * card: effort is a per-MODEL capability, and the models under one provider
 * disagree about it, so a provider-scoped control can only be set to a value
 * some of them reject. The composer's model picker offers each model its own
 * levels instead.
 */
import type { ReactNode } from 'react';
import type { IApiClient } from '@deepseek-ai/dsh-api-remotes/client';
import type { en } from './locales.ts';
/**
 * The route id a URL suggests: its host with the `api.`/`www.` prefix and the
 * public suffix dropped (`https://api.fal.ai/v1` → `fal`, `https://openrouter.ai/api/v1`
 * → `openrouter`), lower-cased and squeezed to the route alphabet. Empty when
 * the text is not a URL yet.
 * @param url - the base URL as typed.
 * @returns a route id candidate, or ''.
 */
export declare function routeFromUrl(url: string): string;
/** Props of {@link CustomProviderCard}. */
export interface CustomProviderCardProps {
    /** Route ids already declared, so the card refuses to shadow one. */
    taken: readonly string[];
    /** Wire protocols the adapter can serve, in the order it reports them. */
    protocols: readonly string[];
    /**
     * Revision of the `llm-pi-ai` user section this card opened at, sent with
     * the create so a route another tab declared meanwhile is a refusal rather
     * than a silent overwrite of its whole profile.
     */
    revision: number;
    /** Wire faces for the write and for interrogating the endpoint. */
    api: Pick<IApiClient, 'settings' | 'credentials' | 'llm'>;
    /** Section copy. */
    t: (key: keyof typeof en) => string;
    /** Disable writes (read-only settings provider). */
    readOnly: boolean;
    /** Close the card; `changed` reports whether a provider was created. */
    onClose: (changed: boolean) => void;
}
/**
 * Render the custom-provider creation card.
 * @param props - existing routes, protocol choices, wire faces, and copy.
 * @returns the creation card.
 */
export declare function CustomProviderCard(props: CustomProviderCardProps): ReactNode;
//# sourceMappingURL=CustomProviderCard.d.ts.map