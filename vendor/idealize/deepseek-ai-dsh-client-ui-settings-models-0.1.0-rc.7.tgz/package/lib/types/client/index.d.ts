/**
 * Models settings and product-onboarding plugin, browser half. It registers
 * the ordered internal-testing and official-DeepSeek onboarding dialogs,
 * whose UI shares this package's modal wrapper; the Models page itself is
 * provided as a service for the IDEalize bar's drawer to host. The Host
 * settings and credential contracts stay behind their existing wire APIs.
 * Export discipline:
 * packages/client/AGENTS.md.
 */
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
import { ModelsSection } from './ModelsSection.tsx';
import type { ModelsSectionInjected } from './ModelsSection.tsx';
import { ModelsSettingsStore } from './store.ts';
import { type ModelsKey } from './locales.ts';
export type { ModelsSectionInjected, ModelsSectionProps } from './ModelsSection.tsx';
export type { ModelsKey } from './locales.ts';
/**
 * The Models page as a cordis service (IDEalize fork seam): the settings
 * modal no longer hosts it, and the client bundle purity gate forbids
 * cross-plugin value imports, so the bar's Models & usage drawer consumes
 * the component + wired face through the Context instead.
 */
export interface ModelsSettingsSectionHost {
    /** The page component, rendered by the consuming surface. */
    Component: typeof ModelsSection;
    /** The wired business face (the same store the onboarding dialogs share). */
    face: () => ModelsSectionInjected;
}
declare module '@deepseek-ai/cordis' {
    interface Context {
        modelsSettingsSection: ModelsSettingsSectionHost;
    }
}
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** The Models page + product-onboarding copy. */
        'settings.models': ModelsKey;
    }
}
export type { ModelsSettingsState, ProviderRow } from './store.ts';
/**
 * Refetch the page snapshot only after its first load: an unopened Models
 * page must not fetch on background invalidations.
 * @param controller - the page store.
 */
export declare function refreshIfLoaded(controller: ModelsSettingsStore): void;
/**
 * Required services (cordis fiber inject). The target slot is declared by
 * ui-settings' apply, whose activation order relative to this one is NOT
 * constrained; registration depends on each slot through `slots.inject()`.
 */
export declare const inject: string[];
/**
 * Register the onboarding dialogs, wire the shared store to the connection,
 * and keep it fresh on every pushed invalidation (settings, credentials, or
 * provider topology).
 * @param ctx - client root context.
 */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map