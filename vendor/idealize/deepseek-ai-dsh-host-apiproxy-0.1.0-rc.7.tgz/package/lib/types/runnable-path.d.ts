/**
 * Whether opening a path with its default application would run it. macOS
 * LaunchServices runs a script bundle, an app or an installer, and an
 * extension-less executable opens in Terminal and runs; Windows runs its
 * script and installer types. `host.openPath` refuses these, matching the
 * Files pane's own open route (security audit, 9 Oct 2026).
 */
/**
 * @param path - the absolute path about to be opened.
 * @returns true when opening it would run code.
 */
export declare function runsWhenOpened(path: string): Promise<boolean>;
//# sourceMappingURL=runnable-path.d.ts.map