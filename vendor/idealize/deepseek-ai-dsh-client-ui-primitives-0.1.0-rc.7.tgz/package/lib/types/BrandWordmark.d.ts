import type { IconProps } from './icons/props.ts';
/**
 * Render the full brand wordmark.
 * @param props.size - height in px (default 24; the row scales from it).
 * @param props.className - extra class for layout placement.
 * @returns the wordmark row (aria-hidden decorative brand art).
 */
export declare function BrandWordmark({ size, className }: IconProps): import("react").JSX.Element;
//# sourceMappingURL=BrandWordmark.d.ts.map