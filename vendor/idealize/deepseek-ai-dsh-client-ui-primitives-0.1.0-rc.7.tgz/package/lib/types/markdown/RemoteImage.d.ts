/**
 * An image in markdown that lives on someone else's server. Fetching it tells
 * that server the address, and an agent that has read hostile text can put
 * anything in that address, chat contents included. So it loads when the person
 * clicks, and the button says which server it would ask.
 */
/**
 * @param props.src - the absolute http(s) address.
 * @param props.alt - the image's description.
 * @param props.label - the button's words, with `{host}` for the server.
 * @returns the button, or the image once it has been asked for.
 */
export declare function RemoteImage({ src, alt, label }: {
    src: string;
    alt: string;
    label?: string | undefined;
}): import("react").JSX.Element;
//# sourceMappingURL=RemoteImage.d.ts.map