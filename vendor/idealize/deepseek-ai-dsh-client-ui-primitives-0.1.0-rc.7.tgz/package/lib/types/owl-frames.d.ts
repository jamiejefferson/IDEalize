/**
 * All 42 frames of V0's owl run-cycle (downscaled to 190x210, WebP q90), for
 * the OwlMark welcome animation. Copied from the skin package's splash frames
 * (host-side; the client cannot import it). Regenerated from Resources/Owl in
 * the V0 repo with PIL.
 */
export declare const OWL_FRAMES: readonly string[];
//# sourceMappingURL=owl-frames.d.ts.map