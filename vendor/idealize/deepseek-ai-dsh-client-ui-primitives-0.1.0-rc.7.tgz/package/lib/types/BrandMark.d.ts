/**
 * The square IDEalize logo card (V0's app mark), inlined from JJ's approved
 * asset (Paper "Welcome Option B" brand row, 2026-08-20): rounded white
 * card, stacked "IDE / alize", generous inner padding. Shipped at 2x for a
 * crisp 58px render.
 */
/** {@link BrandMark} props. */
export interface BrandMarkProps {
    /** Card edge length in CSS pixels (the card is square). */
    size?: number;
    /** Optional class for placement. */
    className?: string | undefined;
}
/**
 * Render the square logo card.
 * @param props - see {@link BrandMarkProps}.
 * @returns the card img element.
 */
export declare function BrandMark({ size, className }: BrandMarkProps): import("react").JSX.Element;
//# sourceMappingURL=BrandMark.d.ts.map