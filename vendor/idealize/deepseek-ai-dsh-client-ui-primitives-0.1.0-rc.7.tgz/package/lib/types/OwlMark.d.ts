/** {@link OwlMark} props. */
export interface OwlMarkProps {
    /** Rendered height in CSS pixels; width follows the 190:210 intrinsic ratio. */
    size?: number;
    /** Optional class for placement and motion. */
    className?: string | undefined;
    /**
     * V0's welcome behaviour: play the run-cycle once on appear, then settle;
     * roll over for another go. A run in flight is never restarted, and
     * prefers-reduced-motion keeps the owl still.
     */
    animate?: boolean;
}
/**
 * The IDEalize owl mascot (V0's welcome mark), rendered from the inlined
 * boot-splash flipbook so it needs no network request. Hover detection lives
 * on a stationary wrapper, not the frames: an animated image moving under
 * the pointer would end its own hover and cancel the run.
 * @param props - see {@link OwlMarkProps}.
 * @returns a wrapper span carrying the owl `img`.
 */
export declare function OwlMark({ size, className, animate }: OwlMarkProps): import("react").JSX.Element;
//# sourceMappingURL=OwlMark.d.ts.map