/** Data URI of the owl's resting frame. */
export declare const OWL_DATA_URI: string;
//# sourceMappingURL=owl-frame.d.ts.map