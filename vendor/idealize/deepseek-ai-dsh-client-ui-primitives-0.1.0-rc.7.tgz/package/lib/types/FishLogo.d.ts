import type { IconProps } from './icons/props.ts';
/**
 * Render the brand mark.
 * @param props.size - width in px (default 24; height keeps the 25.4:19.4 ratio).
 * @param props.className - extra class for layout placement.
 * @returns the logo svg (aria-hidden; pair with the wordmark for accessibility).
 */
export declare function FishLogo({ size, className }: IconProps): import("react").JSX.Element;
//# sourceMappingURL=FishLogo.d.ts.map