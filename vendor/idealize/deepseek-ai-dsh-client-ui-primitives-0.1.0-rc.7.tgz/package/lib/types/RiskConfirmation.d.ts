export interface RiskConfirmationProps {
    open: boolean;
    title: string;
    description: string;
    acknowledgeLabel: string;
    cancelLabel: string;
    confirmLabel: string;
    acknowledged: boolean;
    disabled?: boolean;
    onAcknowledgedChange: (acknowledged: boolean) => void;
    onCancel: () => void;
    onConfirm: () => void;
    /**
     * An optional second checkbox under the acknowledgement, for a caller that
     * can keep the choice beyond this one action. It never gates the primary
     * action; the caller reads `checked` when the confirm lands.
     */
    remember?: {
        label: string;
        checked: boolean;
        onChange: (checked: boolean) => void;
    };
}
/**
 * Render one in-page confirmation whose primary action is unavailable until
 * the caller-controlled acknowledgement is checked.
 */
export declare function RiskConfirmation({ open, title, description, acknowledgeLabel, cancelLabel, confirmLabel, acknowledged, disabled, onAcknowledgedChange, onCancel, onConfirm, remember, }: RiskConfirmationProps): import("react").JSX.Element;
//# sourceMappingURL=RiskConfirmation.d.ts.map