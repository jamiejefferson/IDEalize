/**
 * The rail's Notes scratchpad, host half: which Markdown file is the current
 * note, and a fresh one when there is none or a new one is asked for.
 *
 * Notes live in one folder outside every project (JJ, 6 Oct 2026: "saved by
 * default in a general documentation notes space as it would be separate from
 * projects"): `Notes/` inside the documentation vault, or `IDEalize Notes/` in
 * the Documents folder while no vault is set. The current note is remembered
 * in a dotfile beside the notes (hidden from the Files pane, which skips
 * dotfiles), so the same note opens on every tap and across restarts, and a
 * note moved with its folder stays current.
 * @module @idealize/ui-bar/notes
 */
/** The notes folder's name inside the documentation vault. */
export declare const NOTES_FOLDER = "Notes";
/** The notes folder's name in Documents while no vault is set. */
export declare const FALLBACK_NOTES_FOLDER = "IDEalize Notes";
/** The pointer to the current note, kept in the notes folder. */
export declare const CURRENT_POINTER = ".current-note";
/**
 * A fresh note's file name and heading for one moment, in local time.
 * @param now - the moment the note is started.
 * @returns the file stem (sortable, `Notes 2026-10-06 1430`) and the heading (`Notes, 6 Oct 2026`).
 */
export declare function noteName(now: Date): {
    stem: string;
    heading: string;
};
/**
 * The current note in `folder`, creating the folder, and a fresh note when
 * the pointer names nothing on disk or `fresh` asks for one.
 * @param folder - the notes folder (created when missing).
 * @param fresh - start a new note and make it current.
 * @param now - the clock, for the new note's name.
 * @returns the absolute path of the current note.
 */
export declare function currentNote(folder: string, fresh: boolean, now?: Date): Promise<string>;
//# sourceMappingURL=notes.d.ts.map