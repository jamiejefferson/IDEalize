import { type SpaceId } from '@idealize/spaces/client';
/**
 * Render a space's served icon at the given square size, in the current text colour.
 * @param props - the space and the rendered edge length in CSS pixels.
 * @returns a decorative square masked by the icon; the surrounding control carries the label.
 */
export declare function SpaceIcon({ space, size }: {
    space: SpaceId;
    size: number;
}): import("react").JSX.Element;
//# sourceMappingURL=SpaceIcon.d.ts.map