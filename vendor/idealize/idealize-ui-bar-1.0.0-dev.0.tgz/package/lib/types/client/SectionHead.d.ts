/**
 * Section heading shared by the drawer panes: title, an optional one-line
 * detail, an optional trailing action. Styled from the Brains pane's sheet so
 * every pane's sections read the same.
 */
import type { ReactNode } from 'react';
export declare function SectionHead({ title, detail, action }: {
    title: string;
    detail?: string;
    action?: ReactNode;
}): import("react").JSX.Element;
//# sourceMappingURL=SectionHead.d.ts.map