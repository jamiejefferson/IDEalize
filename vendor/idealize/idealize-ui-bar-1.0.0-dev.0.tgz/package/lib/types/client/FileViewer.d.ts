import type { PropsLocale } from '@deepseek-ai/dsh-client-ui-slots';
type BarTranslate = PropsLocale<'idealize-bar'>['t'];
/** How long typing in a note pauses before it is written to disk. */
export declare const NOTE_SAVE_DELAY_MS = 600;
/**
 * Hold a width inside the outline's range.
 * @param width - the width asked for.
 * @returns the width the column will actually take.
 */
export declare function clampOutlineWidth(width: number): number;
export declare function FileViewer({ path, canReveal, onClose, onAddToChat, onNewNote, t }: {
    path: string;
    canReveal: boolean;
    onClose: () => void;
    /** Hand the file's path to the active chat's composer; false = no active chat. */
    onAddToChat: (path: string) => boolean;
    /** Set while the file is the Notes scratchpad: start a fresh note in its place. */
    onNewNote?: () => void;
    t: BarTranslate;
}): import("react").JSX.Element;
export {};
//# sourceMappingURL=FileViewer.d.ts.map