import type { PropsLocale } from '@deepseek-ai/dsh-client-ui-slots';
type BarTranslate = PropsLocale<'idealize-bar'>['t'];
/**
 * Hold a width inside the outline's range.
 * @param width - the width asked for.
 * @returns the width the column will actually take.
 */
export declare function clampOutlineWidth(width: number): number;
export declare function FileViewer({ path, canReveal, onClose, onAddToChat, t }: {
    path: string;
    canReveal: boolean;
    onClose: () => void;
    /** Hand the file's path to the active chat's composer; false = no active chat. */
    onAddToChat: (path: string) => boolean;
    t: BarTranslate;
}): import("react").JSX.Element;
export {};
//# sourceMappingURL=FileViewer.d.ts.map