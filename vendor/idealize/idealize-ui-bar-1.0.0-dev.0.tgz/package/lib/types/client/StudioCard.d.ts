import type { InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { StudioViewState } from '@idealize/ui-studio/client';
/** Registration-side face. */
export interface StudioCardInjected {
    /** Selector hook over the shared Studio store. */
    useStudio: <T>(selector: (state: StudioViewState) => T) => T;
    /** Selector hook over the Telegram remote's standing: connected once a token is stored, a chat paired and nothing is wrong. */
    useTelegram: <T>(selector: (state: {
        connected: boolean;
    }) => T) => T;
    /** Selector hook over whether the Studio chat is the current chat and whether any project exists to hold it. */
    useTarget: <T>(selector: (state: {
        current: boolean;
        available: boolean;
    }) => T) => T;
    /** Read the overview (see the Studio store) and the Telegram remote's status. */
    sync: () => Promise<void>;
    /** Open the Studio chat, minting it the first time. */
    open: () => Promise<void>;
}
export type StudioCardProps = PropsRuntime<'sidebar.workspaces.pinned'> & PropsLocale<'idealize-bar'> & InjectFace<StudioCardInjected>;
/**
 * Render the card.
 * @param props - the pinned seat's props, the bar's locale seat and the wired face.
 * @returns the card, or null while no project is listed.
 */
export declare function StudioCard({ useStudio, useTelegram, useTarget, sync, open, t }: StudioCardProps): import("react").JSX.Element | null;
//# sourceMappingURL=StudioCard.d.ts.map