/**
 * Host paths as the browser meets them. The host names every path in its own
 * platform's form: a Mac writes `/Users/jj/proj`, a Windows PC writes
 * `C:\Users\jj\proj`. The Files pane joins and compares these strings, so
 * each join uses the host's separator and each comparison accepts either
 * separator, and a Windows path compares without case, as NTFS does.
 */
/** The separator a host path is written with. */
export declare function separatorOf(path: string): string;
/**
 * One child path under a host folder, written with the folder's own separator.
 * @param parent - the host folder.
 * @param relative - a name, or a `/`-separated relative path.
 * @returns the joined path.
 */
export declare function joinHostPath(parent: string, relative: string): string;
/**
 * Whether `path` sits strictly beneath the folder `root`.
 * @param root - the host folder.
 * @param path - the candidate path.
 */
export declare function isBeneath(root: string, path: string): boolean;
/**
 * Whether `path` is the folder `root` itself or sits beneath it.
 * @param root - the host folder.
 * @param path - the candidate path.
 */
export declare function isAtOrBeneath(root: string, path: string): boolean;
/** Labels that name Finder or the Trash, each with the wording a Windows PC uses. */
type FileManagerKey = 'files.reveal' | 'files.revealFailed' | 'files.trash' | 'files.trashConfirm' | 'files.trashed' | 'files.trashFailed';
/**
 * The label key for this computer's file manager: Explorer and the Recycle Bin
 * on Windows, Finder and the Trash everywhere else.
 * @param key - the macOS key.
 * @param userAgent - the browser's user agent, which names Windows on a PC.
 */
export declare function fileManagerKey<K extends FileManagerKey>(key: K, userAgent?: string): K | `${K}.windows`;
export {};
//# sourceMappingURL=host-path.d.ts.map