/**
 * Pure helpers behind the Schedule pane: the cron task wire fields, the copy
 * derived from a schedule (repeat badges, sentences), the day-lane geometry
 * the calendar and the reschedule drag share, and the task-draft parser the
 * Create-with-chat state reads from an assistant reply.
 */
import type { BarKey } from './locales.ts';
/** Translate seat the schedule copy helpers read (the bar namespace's bound `t`). */
export type ScheduleTranslate = (key: BarKey, params?: Record<string, unknown>) => string;
/** Schedule union, restated from @idealize/cron's wire fields. */
export type Schedule = {
    kind: 'every';
    seconds: number;
} | {
    kind: 'daily';
    at: string;
    timeZone: string;
} | {
    kind: 'weekly';
    at: string;
    timeZone: string;
    days: number[];
};
/** A task as `GET /idealize/cron/tasks` reports it. */
export interface TaskView {
    id: string;
    name: string;
    schedule: Schedule;
    prompt: string;
    cwd: string;
    provider?: string;
    model?: string;
    enabled: boolean;
    createdAt: string;
    nextFireAt?: string;
    running: boolean;
}
/** The editable fields of a task: an existing one (id set) or a draft. */
export interface TaskDraft {
    id?: string;
    name: string;
    schedule: Schedule;
    prompt: string;
    cwd: string;
    provider?: string;
    model?: string;
    enabled: boolean;
}
/** Monday to Friday (0 = Sunday). */
export declare const WEEKDAYS: readonly number[];
/**
 * The short day label for a `Date.getDay()` index.
 * @param day - day index, 0 = Sunday.
 * @param t - bar translate.
 * @returns the localised short label (en "SUN" … "SAT").
 */
export declare function dayShort(day: number, t: ScheduleTranslate): string;
/**
 * The full day name for a `Date.getDay()` index.
 * @param day - day index, 0 = Sunday.
 * @param t - bar translate.
 * @returns the localised day name (en "Sunday" … "Saturday").
 */
export declare function dayName(day: number, t: ScheduleTranslate): string;
/** Pixels per hour in the day lane. */
export declare const HOUR_PX = 72;
/** Height of a timed task block. */
export declare const BLOCK_PX = 58;
/** The browser's zone, the default for new tasks. */
export declare function localTimeZone(): string;
/**
 * The uppercase badge on a task block: WEEKDAYS, TUE + THU, THURSDAY, DAILY, EVERY 30 MIN.
 * @param schedule - the task's schedule.
 * @param t - bar translate.
 * @returns the localised badge.
 */
export declare function repeatBadge(schedule: Schedule, t: ScheduleTranslate): string;
/**
 * The REPEAT row sentence: Every weekday, Every day, Tuesdays and Thursdays, Every 30 minutes.
 * @param schedule - the task's schedule.
 * @param t - bar translate.
 * @returns the localised sentence.
 */
export declare function repeatSentence(schedule: Schedule, t: ScheduleTranslate): string;
/** "09:00" → minutes since midnight. */
export declare function minutesOf(at: string): number;
/** Minutes since midnight → "HH:mm". */
export declare function timeOf(minutes: number): string;
/** Whether a schedule has a fire on the given local calendar day. */
export declare function occursOn(schedule: Schedule, date: Date): boolean;
/** Lane geometry for a timed block: top offset in px from 00:00. */
export declare function blockTop(schedule: Schedule): number;
/** The lane offset in px → the snapped HH:mm (5-minute grid) the drag would set. */
export declare function timeAtOffset(topPx: number): string;
/**
 * The schedule a calendar tap drafts: a weekly task on the tapped day at the
 * tapped time, so the editor opens showing exactly the slot that was clicked.
 * @param day - the calendar day the tap landed on.
 * @param at - the tapped "HH:mm" (the lane offset, or a view's default).
 * @param timeZone - the zone stamped on the draft.
 */
export declare function tappedSchedule(day: Date, at: string, timeZone: string): Schedule;
/**
 * Assign each timed block a stagger column so overlapping blocks step right
 * like the wireframe's 11:05 / 13:00 pair. Blocks sorted by start; a block
 * overlapping the previous one takes the next column.
 * @returns column index per task id.
 */
export declare function staggerColumns(tasks: readonly TaskView[]): Map<string, number>;
/** The Monday-first week containing `date`, as seven local dates. */
export declare function weekOf(date: Date): Date[];
/** Whether two dates fall on the same local calendar day. */
export declare function sameDay(a: Date, b: Date): boolean;
/**
 * "20 August 2026" in the pane's date navigator.
 * @param date - the shown day.
 * @param locale - BCP 47 tag (the dictionary's `sched.dateLocale`).
 * @returns the localised long date.
 */
export declare function longDate(date: Date, locale?: string): string;
/**
 * "August 2026" for the month view.
 * @param date - a day in the shown month.
 * @param locale - BCP 47 tag (the dictionary's `sched.dateLocale`).
 * @returns the localised month title.
 */
export declare function monthTitle(date: Date, locale?: string): string;
/**
 * The footer's "Next run: tomorrow at 09:00" line, from the host-computed
 * next fire for saved tasks; drafts get an approximation in the browser's
 * own clock (time-of-day rules in the browser zone).
 * @param draft - the edited task.
 * @param nextFireAt - the host-computed next fire, when the saved schedule is untouched.
 * @param now - the current time.
 * @param t - bar translate.
 * @returns the localised next-run line.
 */
export declare function nextRunLine(draft: TaskDraft, nextFireAt: string | undefined, now: Date, t: ScheduleTranslate): string;
/** The last path segment, for "Save to" summaries. */
export declare function folderName(path: string): string;
/**
 * "Default" or the task's pinned model label.
 * @param draft - the provider/model half of a draft.
 * @param t - bar translate.
 * @returns the localised model label.
 */
export declare function modelLabel(draft: Pick<TaskDraft, 'provider' | 'model'>, t: ScheduleTranslate): string;
/**
 * One Create-with-chat message: the user's words first (so the session title
 * derives from them), then the seed that asks for prose plus one fenced JSON
 * task block the pane parses.
 * @param words - what the user typed.
 * @param timeZone - the zone times are read in.
 * @param cwd - the folder the task runs in.
 * @param slot - the tapped calendar slot, when the state opened from a tap; the model defaults the schedule to it.
 */
export declare function seededMessage(words: string, timeZone: string, cwd: string, slot?: Schedule): string;
/** Split one seeded user message back into the words the user typed. */
export declare function stripSeed(text: string): string;
/** A draft parsed from an assistant reply, or undefined when no valid block is present. */
export interface ParsedDraft {
    name: string;
    schedule: Schedule;
    prompt: string;
}
/**
 * Read the last fenced JSON block of an assistant reply as a task draft.
 * @param text - assistant reply text.
 * @param timeZone - zone stamped on time-of-day schedules.
 * @returns the draft, or undefined when the block is missing or invalid.
 */
export declare function parseDraft(text: string, timeZone: string): ParsedDraft | undefined;
/** The reply with its JSON block removed, for the transcript row. */
export declare function replyProse(text: string): string;
//# sourceMappingURL=schedule-model.d.ts.map