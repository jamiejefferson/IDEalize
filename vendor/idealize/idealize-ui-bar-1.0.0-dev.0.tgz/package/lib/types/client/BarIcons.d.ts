/**
 * The bar's own icon set: one 16x16 grid, 1.5px strokes, round caps, so the
 * row reads as a single family instead of borrowed upstream glyphs.
 */
import type React from 'react';
interface IconProps {
    size?: number;
}
/** Folder: the files drawer. */
export declare function BarIconFiles({ size }: IconProps): React.JSX.Element;
/** Terminal: a prompt chevron and an underscore in a rounded frame, the Terminal pane. */
export declare function BarIconTerminal({ size }: IconProps): React.JSX.Element;
/**
 * Brain: the Brains pane (JJ, 11 Sep 2026, reversing the 3 Sep sparkle). A
 * two-lobed outline with the central fissure and one fold per lobe, drawn at
 * the same 1.3px stroke as the rail's other glyphs.
 */
export declare function BarIconModels({ size }: IconProps): React.JSX.Element;
/** Clock face with a coin's rim: the Time & cost pane (24 Sep 2026). */
export declare function BarIconWork({ size }: IconProps): React.JSX.Element;
/** Cog: the Settings pane (JJ, 11 Sep 2026). */
export declare function BarIconSettings({ size }: IconProps): React.JSX.Element;
/** Door: the service hatch (JJ, 2026-08-28). */
export declare function BarIconHatch({ size }: IconProps): React.JSX.Element;
/** Circular arrow: the files toolbar's refresh. */
export declare function BarIconRefresh({ size }: IconProps): React.JSX.Element;
/** Tray with an inbound arrow (V0's browse glyph): the browse-pane toggle. */
export declare function BarIconBrowse({ size }: IconProps): React.JSX.Element;
/** Speech bubble with a heart: feedback. */
export declare function BarIconFeedback({ size }: IconProps): React.JSX.Element;
/** Big window shrinking to a pip: minimode. */
export declare function BarIconMinimode({ size }: IconProps): React.JSX.Element;
/** Puzzle piece: plugins (JJ, 2026-08-28). */
export declare function BarIconPlugins({ size }: IconProps): React.JSX.Element;
/** Artist palette: the Appearance pane (JJ, 2026-08-28). */
export declare function BarIconAppearance({ size }: IconProps): React.JSX.Element;
/** Chevron closing the drawer. */
export declare function BarIconClose({ size }: IconProps): React.JSX.Element;
/** Document with a plus: create a file. */
export declare function BarIconFilePlus({ size }: IconProps): React.JSX.Element;
/** Folder with a plus: create a folder. */
export declare function BarIconFolderPlus({ size }: IconProps): React.JSX.Element;
/** Indented list: the file viewer's section-title outline. */
export declare function BarIconOutline({ size }: IconProps): React.JSX.Element;
/** Arrow right: what a tile or a brain row does when it is pressed. */
export declare function BarIconArrowRight({ size }: IconProps): React.JSX.Element;
/** Chevron left: the way back to the previous step. */
export declare function BarIconChevronLeft({ size }: IconProps): React.JSX.Element;
/** Plus: add a brain. */
export declare function BarIconPlus({ size }: IconProps): React.JSX.Element;
/** Key: the provider key a refused space is waiting on. */
export declare function BarIconKey({ size }: IconProps): React.JSX.Element;
/** Offset bars: the trajectory ledger's timing overview. */
export declare function BarIconTrajectory({ size }: IconProps): React.JSX.Element;
/** Calendar: the schedule pane's week. */
export declare function BarIconSchedule({ size }: IconProps): React.JSX.Element;
export {};
//# sourceMappingURL=BarIcons.d.ts.map