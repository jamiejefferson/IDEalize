import type { BarKey } from './locales.ts';
type Translate = (key: BarKey, params?: Record<string, string | number>) => string;
/** GET /idealize/brains/gateway, as far as this row reads it. */
export interface GatewayState {
    configured: boolean;
    address?: string;
    connected: boolean;
    preset?: string;
    budgetGbp?: number | null;
    spentGbp?: number;
    services: string[];
    error?: string;
}
/** Read the gateway's state; null when the host serves no gateway. */
export declare function readGateway(fetchImpl?: typeof fetch): Promise<GatewayState | null>;
/** The line under the row's name. */
export declare function gatewayLine(state: GatewayState, t: Translate): string;
/**
 * The row. The Models pane shows it whether or not a gateway is set. A caller
 * that splits its services into two lists passes `configuredOnly`: true shows
 * the row only once a gateway is set, false only until then.
 * @param props - copy, the optional list filter, and a test fetch.
 * @returns the row, or nothing when it has no place in this list.
 */
export declare function GatewayRow({ t, configuredOnly, onState, fetchImpl }: {
    t: Translate;
    configuredOnly?: boolean;
    /** Told whether a gateway is set, so the list can drop its empty-state line. */
    onState?: (configured: boolean) => void;
    fetchImpl?: typeof fetch;
}): import("react").JSX.Element | null;
export {};
//# sourceMappingURL=GatewayRow.d.ts.map