import type { BarKey } from './locales.ts';
/**
 * The folder a project sits in, which tells two same-named projects apart in
 * a column too narrow for the whole path; the row's title holds the path.
 * @param path - the project's folder, with either separator.
 * @returns the parent folder's name, or the path itself at a root.
 */
export declare function parentFolder(path: string): string;
/**
 * Render the Time & cost pane.
 * @param props.t - bar copy.
 * @returns the pane element tree.
 */
export declare function WorkPanel({ t }: {
    t: (key: BarKey, params?: Record<string, string | number>) => string;
}): import("react").JSX.Element;
//# sourceMappingURL=WorkPanel.d.ts.map