import type { BarKey } from './locales.ts';
/**
 * Render the Time & cost pane.
 * @param props.t - bar copy.
 * @returns the pane element tree.
 */
export declare function WorkPanel({ t }: {
    t: (key: BarKey, params?: Record<string, string | number>) => string;
}): import("react").JSX.Element;
//# sourceMappingURL=WorkPanel.d.ts.map