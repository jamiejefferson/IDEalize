import type React from 'react';
import type { InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { AppearancePanelComponentProps } from '@idealize/appearance/client';
import type { BarViewStore, HatchTab } from './bar-store.ts';
import { type BrainsPanelHost } from './BrainsPanel.tsx';
import { type ServiceSectionInjected } from './ServiceSection.tsx';
import { type TrajectoryHost } from './TrajectoryPane.tsx';
import { type ScheduleHost } from './SchedulePane.tsx';
/**
 * The terminal plugin's pane component as the drawer consumes it (restated;
 * `@idealize/ui-terminal` owns `ctx.terminalMode.Pane`). One plain shell for
 * the app, in the directory it is first opened in.
 */
export interface TerminalHost {
    Pane: (props: {
        cwd: string | undefined;
    }) => React.JSX.Element;
}
/** The appearance plugin's panel plus the props the drawer hands it (index.ts binds them once). */
export interface AppearanceHost {
    Component: (props: AppearancePanelComponentProps) => React.JSX.Element | null;
    props: AppearancePanelComponentProps;
}
/** Registration-side face: the view store, the pane transitions, and the re-hosted sections. */
export interface DrawerPanelInjected {
    hooks: {
        /** The bar's view state (arrives as the `useBarView` selector hook). */
        barView: BarViewStore;
    };
    /** Close the drawer (clears the open pane). */
    closePanel: () => void;
    /** Switch the Service hatch pane's tab. */
    setHatchTab: (tab: HatchTab) => void;
    /** Show a file in the deck column. */
    openFile: (path: string) => void;
    /** The active chat's working directory; the Files pane's project tab reads it. */
    currentCwd: () => string | undefined;
    /** Raise the host's folder picker (the Files pane's Reconnect flow). */
    pickDirectory: () => Promise<string | null>;
    /** Register a folder as a project and open a chat in it (the Files pane's "Idealize this"). */
    idealize: (path: string) => void;
    /** The Brains pane's re-hosted provider editor (index.ts). */
    modelsHost: BrainsPanelHost;
    /** Mark the pending Brains request handled, so reopening the pane does not replay it. */
    clearBrainsRequest: () => void;
    /** The Trajectory pane's re-hosted event ledger (index.ts). */
    trajectoryHost: TrajectoryHost;
    /** Mark the pending inspect handoff applied, so reopening the pane does not replay it. */
    clearInspect: () => void;
    /** Mark the pending Files reveal shown, so reopening the pane does not replay it. */
    clearReveal: () => void;
    /** The Schedule pane's re-hosted calendar (index.ts). */
    scheduleHost: ScheduleHost;
    /**
     * The Terminal pane's grid, resolved at render because the terminal plugin
     * provides its service after this drawer registers; undefined where no
     * terminal plugin is composed (the entry that opens the pane is hidden then).
     */
    terminalHost: () => TerminalHost | undefined;
    /** The Service chat's session plumbing (index.ts). */
    service: ServiceSectionInjected;
    /** The appearance inspector, seated from `ctx.appearance`. */
    appearanceHost: AppearanceHost;
    /**
     * Append a file's path to the active chat's composer draft.
     * @returns false when no chat is active to receive it.
     */
    addToChat: (path: string) => boolean;
    /** Raise the done chime + a notification (the @idealize/notify seam) after a feedback submit lands. */
    notifyDone: (title: string, body: string) => void;
}
export type DrawerPanelProps = PropsRuntime<'shell.drawer'> & PropsLocale<'idealize-bar'> & InjectFace<DrawerPanelInjected>;
export declare function DrawerPanel(props: DrawerPanelProps): React.JSX.Element | null;
//# sourceMappingURL=DrawerPanel.d.ts.map