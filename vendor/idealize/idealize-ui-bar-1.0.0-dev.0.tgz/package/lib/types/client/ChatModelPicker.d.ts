/**
 * The model browser for a chat, opened from the composer's brain chip (Paper
 * "Brains rethink", board 09). The browser itself is unchanged: this reads the
 * catalogue the Brains sheet reads and hands it over. It lists only routes the
 * person has connected, because a choice here takes effect on the next reply
 * and a model with no account behind it would fail that reply.
 * @module @idealize/ui-bar/client/ChatModelPicker
 */
import type { ReactNode } from 'react';
import type { Translate } from './model-browser.ts';
/** What the chip asks for (restated; `@idealize/activity-pills` owns the type). */
export interface ChatModelRequest {
    brainName: string;
    current: {
        provider: string;
        model: string;
    } | null;
    onApply: (model: {
        provider: string;
        model: string;
    }) => void;
    onClose: () => void;
}
/**
 * The chip's model browser.
 * @param props.request - the chip's request.
 * @param props.t - the bar's translator.
 * @returns the browser, portalled over the window.
 */
export declare function ChatModelPicker({ request, t }: {
    request: ChatModelRequest;
    t: Translate;
}): ReactNode;
//# sourceMappingURL=ChatModelPicker.d.ts.map