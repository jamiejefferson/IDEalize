import type { SessionBinding } from '@deepseek-ai/dsh-client-runtime/client';
import type { ParsedDraft, Schedule, ScheduleTranslate } from './schedule-model.ts';
/**
 * Render the Create-with-chat state.
 * @param props.cwd - the folder the task will run in (and the chat's workspace).
 * @param props.timeZone - zone for the draft's times.
 * @param props.seed - the tapped calendar slot, when the state opened from a calendar tap; seeds the model's default schedule.
 * @param props.ensureSession - session factory (index.ts).
 * @param props.onBack - return to the calendar.
 * @param props.onEditFields - open the parsed draft in the editor.
 * @param props.onCreate - save the parsed draft; resolves an error or undefined.
 * @param props.t - the bar namespace's bound translate.
 * @returns the state's element tree.
 */
export declare function ScheduleCreateChat({ cwd, timeZone, seed, ensureSession, onBack, onEditFields, onCreate, t }: {
    cwd: string;
    timeZone: string;
    seed?: Schedule;
    ensureSession: (path: string) => Promise<SessionBinding | null>;
    onBack: () => void;
    onEditFields: (draft: ParsedDraft) => void;
    onCreate: (draft: ParsedDraft) => Promise<string | undefined>;
    t: ScheduleTranslate;
}): import("react").JSX.Element;
//# sourceMappingURL=ScheduleCreateChat.d.ts.map