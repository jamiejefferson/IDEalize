import type { InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { SpaceBrain, SpaceId, SpaceRosterEntry } from '@idealize/spaces/client';
import { type HeroLauncherInjected } from './HeroLauncher.tsx';
/** Full slot props for the band under the card. */
export type HeroBrainsProps = PropsRuntime<'conversation.hero.below'> & PropsLocale<'idealize-bar'> & InjectFace<HeroLauncherInjected>;
/** The preset every new Chat and Coding chat runs on (restated from `@idealize/activity-pills`, whose host half seeds it). */
export declare const CORE_PRESET = "core";
/** The media space a Studio chat opens on; the chat box's toggle moves it to the other two. */
export declare const STUDIO_ENTRY: SpaceId;
/**
 * The preset a view starts on: the core preset where the space offers it,
 * else the space's default, else its first.
 * @param entry - the space's roster entry.
 * @returns the preset, or undefined when the space offers none.
 */
export declare function viewPreset(entry: SpaceRosterEntry | undefined): SpaceBrain | undefined;
/**
 * Render the three views under the composer.
 * @param props - composed slot props.
 * @returns the band, or null where the chat has already gone elsewhere.
 */
export declare function HeroBrains(props: HeroBrainsProps): import("react").JSX.Element | null;
//# sourceMappingURL=HeroBrains.d.ts.map