import type { InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import { type HeroLauncherInjected } from './HeroLauncher.tsx';
/** Full slot props for the band under the card. */
export type HeroBrainsProps = PropsRuntime<'conversation.hero.below'> & PropsLocale<'idealize-bar'> & InjectFace<HeroLauncherInjected>;
/**
 * Render the starting points under the composer.
 * @param props - composed slot props.
 * @returns the band, or null where the chat has already gone elsewhere.
 */
export declare function HeroBrains(props: HeroBrainsProps): import("react").JSX.Element | null;
//# sourceMappingURL=HeroBrains.d.ts.map