import type React from 'react';
import type { PropsLocale } from '@deepseek-ai/dsh-client-ui-slots';
import type { RevealRequest } from './bar-store.ts';
/** The bar namespace's bound translate seat, passed down as a plain prop. */
type BarTranslate = PropsLocale<'idealize-bar'>['t'];
/**
 * The drag payload type a Files row sets: its absolute path. The trees accept
 * it as a move and the composer card as Add to chat; `text/plain` rides along
 * so a drop anywhere else pastes the path.
 */
export declare const FILE_DRAG_TYPE = "application/x-idealize-path";
interface RootEntry {
    name: string;
    path: string;
}
/**
 * The folders a reveal has to open between a tree root and a file: every
 * directory strictly below the root on the way to the file's own folder,
 * outermost first. A file directly under the root needs none.
 * @param root - the tree root holding the file.
 * @param path - the file's absolute path, under `root`.
 * @returns the ancestor directories, outermost first.
 */
export declare function revealAncestors(root: string, path: string): string[];
/**
 * Client half of the host route's single-component name rule: creation
 * refuses empty names and anything that could climb out of the parent.
 * @param raw - candidate name as typed.
 * @returns whether the trimmed name is a safe single path component.
 */
export declare function isValidEntryName(raw: string): boolean;
/**
 * Narrow the workspace roots to the one holding the active chat, so the
 * project tab shows the current project rather than every registered one.
 * With no chat open, or a cwd under none of them, every root stands.
 * @param roots - the registered workspace roots.
 * @param cwd - the active chat's working directory, when there is one.
 * @returns the roots the project tab shows.
 */
export declare function currentProjectRoots(roots: RootEntry[], cwd: string | undefined): RootEntry[];
export declare function FilesPanel({ canReveal, canTrash, currentCwd, pickDirectory, onOpenFile, onAddToChat, onIdealize, reveal, onRevealDone, externalReload, t, }: {
    canReveal: boolean;
    /** Offer Move to Trash on rows (macOS only: the Finder does the moving). */
    canTrash: boolean;
    /** The active chat's working directory; picks the current project out of the roots. */
    currentCwd: string | undefined;
    /** Raise the host's folder picker for Reconnect; rejects where the shell has none. */
    pickDirectory: () => Promise<string | null>;
    /** Open a file in the deck's viewer panel. */
    onOpenFile: (path: string) => void;
    /** Hand a file's path to the active chat's composer; false = no active chat. */
    onAddToChat: (path: string) => boolean;
    /** Register a folder as a project and open a chat in it (the row menu's "Idealize this"). */
    onIdealize: (path: string) => void;
    /** The bar's pending reveal (`ctx.idealizeBar.revealFile`); null while none is outstanding. */
    reveal: RevealRequest | null;
    /** The reveal has been shown, or refused for a path under no tab: the bar clears it. */
    onRevealDone: () => void;
    /** Bumped by the bar when an artefact lands; every loaded folder is listed again. */
    externalReload: number;
    t: BarTranslate;
}): React.JSX.Element;
export {};
//# sourceMappingURL=FilesPanel.d.ts.map