import type React from 'react';
import type { PropsLocale } from '@deepseek-ai/dsh-client-ui-slots';
import type { RevealRequest } from './bar-store.ts';
/** The bar namespace's bound translate seat, passed down as a plain prop. */
type BarTranslate = PropsLocale<'idealize-bar'>['t'];
/**
 * The drag payload type a Files row sets: its absolute path. The trees accept
 * it as a move and the composer card as Add to chat; `text/plain` rides along
 * so a drop anywhere else pastes the path.
 */
export declare const FILE_DRAG_TYPE = "application/x-idealize-path";
interface RootEntry {
    name: string;
    path: string;
}
/** One folder set the host reports under `tabs`. */
type TabId = 'project' | 'projectsRoot' | 'documentation' | 'skills';
/** One view of the pane: a host tab, or the current project's documentation folder. */
type ViewId = TabId | 'projectDocs';
/** Whose files show: the first row of tabs. */
type Scope = 'project' | 'all' | 'skills';
/** Which of a scope's two folders shows: the second row of tabs. */
type Kind = 'files' | 'docs';
/**
 * The view a scope and kind select.
 * @param scope - whose files show.
 * @param kind - which of the scope's two folders shows.
 * @returns the view's id.
 */
export declare function viewOf(scope: Scope, kind: Kind): ViewId;
/**
 * Whether a clicked file opens in IDEalize's own viewer. Markdown and images
 * do; every other type belongs to its default application (JJ, 18 Sep 2026).
 * @param path - the file's path or name.
 * @returns true for a Markdown or image extension, compared without case.
 */
export declare function opensInApp(path: string): boolean;
/**
 * One tab as `GET /idealize/bar/aliases` reports it: its tree roots plus the
 * live access verdict of the alias behind it. `roots` is empty exactly when
 * there is nothing to browse — an uncaptured alias (`state: 'unset'`) or one
 * whose folder failed its probe, both of which render Reconnect instead.
 */
interface AliasTab {
    id: TabId;
    /** The alias to rewrite on Reconnect; absent on the project tab. */
    alias?: 'projectsRoot' | 'documentation' | 'skills';
    roots: RootEntry[];
    state: 'ok' | 'unset' | 'missing' | 'not-a-directory' | 'unreadable' | 'unwritable';
    /** The host's plain-language failure sentence, shown verbatim. */
    reason?: string;
}
/** One project's documentation folder as `GET /idealize/bar/aliases` reports it under `projectDocs`. */
interface ProjectDocsEntry {
    project: RootEntry;
    /** Absent while `state` is `'unset'`. */
    folder?: string;
    /** `chosen` by the user, or found in the vault by its `note` or its `name`. */
    source?: 'chosen' | 'note' | 'name';
    state: AliasTab['state'];
    /** The host's plain-language failure sentence, shown verbatim. */
    reason?: string;
}
/**
 * Narrow the documentation folders to the current project's, as the project
 * files view narrows the workspace roots.
 * @param entries - every project's documentation folder.
 * @param projects - the roots the project files view shows.
 * @returns the entries whose project is one of `projects`.
 */
export declare function currentProjectDocs(entries: ProjectDocsEntry[], projects: RootEntry[]): ProjectDocsEntry[];
/**
 * The tree roots of the documentation view: one project's folder under its
 * own name, several under their projects' names so the rows tell them apart.
 * @param entries - the current project's documentation folders.
 * @returns a root per folder that answers.
 */
export declare function projectDocsRoots(entries: ProjectDocsEntry[]): RootEntry[];
/**
 * The folders a reveal has to open between a tree root and a file: every
 * directory strictly below the root on the way to the file's own folder,
 * outermost first. A file directly under the root needs none.
 * @param root - the tree root holding the file.
 * @param path - the file's absolute path, under `root`.
 * @returns the ancestor directories, outermost first.
 */
export declare function revealAncestors(root: string, path: string): string[];
/**
 * Client half of the host route's single-component name rule: creation
 * refuses empty names and anything that could climb out of the parent.
 * @param raw - candidate name as typed.
 * @returns whether the trimmed name is a safe single path component.
 */
export declare function isValidEntryName(raw: string): boolean;
/**
 * Narrow the workspace roots to the one holding the active chat, so the
 * project tab shows the current project rather than every registered one.
 * With no chat open, or a cwd under none of them, every root stands.
 * @param roots - the registered workspace roots.
 * @param cwd - the active chat's working directory, when there is one.
 * @returns the roots the project tab shows.
 */
export declare function currentProjectRoots(roots: RootEntry[], cwd: string | undefined): RootEntry[];
export declare function FilesPanel({ canReveal, canTrash, canOpenExternal, currentCwd, pickDirectory, onOpenFile, onAddToChat, onIdealize, reveal, onRevealDone, externalReload, t, }: {
    canReveal: boolean;
    /** Offer Move to Trash on rows (macOS only: the Finder does the moving). */
    canTrash: boolean;
    /** Hand files the viewer does not render to their default application (macOS only). */
    canOpenExternal: boolean;
    /** The active chat's working directory; picks the current project out of the roots. */
    currentCwd: string | undefined;
    /** Raise the host's folder picker for Reconnect; rejects where the shell has none. */
    pickDirectory: () => Promise<string | null>;
    /** Open a file in the deck's viewer panel. */
    onOpenFile: (path: string) => void;
    /** Hand a file's path to the active chat's composer; false = no active chat. */
    onAddToChat: (path: string) => boolean;
    /** Register a folder as a project and open a chat in it (the row menu's "Idealize this"). */
    onIdealize: (path: string) => void;
    /** The bar's pending reveal (`ctx.idealizeBar.revealFile`); null while none is outstanding. */
    reveal: RevealRequest | null;
    /** The reveal has been shown, or refused for a path under no tab: the bar clears it. */
    onRevealDone: () => void;
    /** Bumped by the bar when an artefact lands; every loaded folder is listed again. */
    externalReload: number;
    t: BarTranslate;
}): React.JSX.Element;
export {};
//# sourceMappingURL=FilesPanel.d.ts.map