import type { PropsLocale } from '@deepseek-ai/dsh-client-ui-slots';
/** The bar namespace's bound translate seat, passed down as a plain prop. */
type BarTranslate = PropsLocale<'idealize-bar'>['t'];
/**
 * Render the Feedback pane.
 * @param props.t - the bar namespace's bound translate.
 * @param props.notifyDone - chime + notification after a submit lands (JJ round 3: the in-pane line alone went unnoticed).
 * @returns the pane element tree.
 */
export declare function FeedbackPanel({ t, notifyDone }: {
    t: BarTranslate;
    notifyDone: (title: string, body: string) => void;
}): import("react").JSX.Element;
export {};
//# sourceMappingURL=FeedbackPanel.d.ts.map