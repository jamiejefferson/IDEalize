/**
 * The model browser's data, pure: every kind of model (chat, image, video,
 * sound) folded into one row shape, the curated "Good at" vocabulary per
 * kind, who makes each model, its headline price per output, and the
 * search, filters and sort the browser applies. The component
 * (ModelBrowser.tsx) only renders what these functions return.
 * @module @idealize/ui-bar/client/model-browser
 */
import type { BarKey } from './locales.ts';
/** The pane's translate function, which every label passes through. */
export type Translate = (key: BarKey, params?: Record<string, string | number>) => string;
/** What a browser chooses: a chat model, or one generating space's model. */
export type BrowserKind = 'chat' | 'image' | 'video' | 'audio';
/** What a model reads. */
export type Takes = 'text' | 'image' | 'file' | 'audio' | 'video';
/** The display order of {@link Takes}. */
export declare const TAKES_ORDER: readonly Takes[];
/** How the browser orders the list. */
export type BrowserSort = 'cheapest' | 'newest' | 'name' | 'rated';
/** One fact line of the detail pane: a label and its value, the value in the code font when it is a figure. */
export interface FactLine {
    label: string;
    value: string;
    figure?: boolean;
}
/** A model's price as the list and the detail pane state it. */
export interface BrowserPrice {
    /** The headline figure, formatted with its currency; absent when no price is known. */
    headline?: string;
    /** The line under the headline. */
    sub?: string;
    /** True when the headline is the per-output figure the column names; false prices sort last. */
    comparable: boolean;
    /** The comparable figure, for sorting. */
    sortValue?: number;
    /** The raw price lines for the facts table. */
    lines: FactLine[];
    /** Who published the price. */
    from?: string;
}
/** One model as the browser lists it. */
export interface BrowserModel {
    /** The value the sheet stores: `provider model`. */
    value: string;
    /** The backend (media) or route (chat) id. */
    provider: string;
    id: string;
    name: string;
    maker?: string;
    /** The route a chat model is served through, when it is not the maker's own name. */
    route?: string;
    takes: Takes[];
    makes: BrowserKind;
    /** `YYYY-MM-DD`, when known. */
    released?: string;
    description?: string;
    thumbnailUrl?: string;
    licence?: string;
    /** Curated "Good at" labels this model carries, as locale keys in the kind's order. */
    goodAt: BarKey[];
    /** The controls this model offers, as locale keys in the kind's order. */
    controls: BarKey[];
    contextWindow?: number;
    price: BrowserPrice;
    /** A media model whose example output the browser may fetch on selection. */
    hasExample: boolean;
}
/** The media price as `GET /idealize/brains/media` states it on a candidate. */
export interface MediaPrice {
    unitPrice: number;
    unit: string;
    currency: string;
    perOutput?: {
        amount: number;
        output: string;
    };
}
/** One media candidate as `GET /idealize/brains/media` lists it. */
export interface MediaCandidateModel {
    id: string;
    name: string;
    artefact?: string;
    inputModalities?: string[];
    requiredInputs?: string[];
    description?: string;
    thumbnailUrl?: string;
    thumbnailAnimatedUrl?: string;
    tags?: string[];
    licence?: string;
    released?: string;
    maker?: string;
    price?: MediaPrice;
    /** The controls it offers, as model-facts ids. */
    controls?: string[];
    /** What it is good at, as model-facts ids; absent when it was never labelled. */
    goodAt?: string[];
}
/** One chat model as `GET /idealize/models/details` lists it. */
export interface ChatModelDetail {
    id: string;
    name: string;
    description?: string;
    released?: string;
    contextWindow?: number;
    inputModalities?: string[];
    tools?: boolean;
    reasoning?: boolean;
    price?: {
        input: number;
        output: number;
        source: 'user' | 'market' | 'catalogue';
    };
    /** The controls it offers, as model-facts ids. */
    controls?: string[];
    /** What it is good at, as model-facts ids; absent when it was never labelled. */
    goodAt?: string[];
}
/** One "Good at" label and the provider tags (or chat abilities) that earn it when no label was shipped. */
interface GoodAtRule {
    label: BarKey;
    tags: readonly string[];
}
/**
 * The "Good at" vocabulary per kind, in the order the chips show (JJ, 24 Oct
 * 2026: granular enough to choose between models of one kind). It matches
 * `GOOD_AT_TERMS` in `@idealize/services`, whose shipped labels a row
 * normally carries; the tags here only label a model newer than that table.
 * Chat abilities are named as pseudo-tags (`tools`, `reasoning`, `long-context`).
 */
export declare const GOOD_AT: Readonly<Record<BrowserKind, readonly GoodAtRule[]>>;
/**
 * The controls vocabulary per kind, in the order the chips show. It matches
 * `CONTROL_IDS` in `@idealize/services`, which reads each model's own settings.
 */
export declare const CONTROLS: Readonly<Record<BrowserKind, readonly BarKey[]>>;
/** The context window from which a chat model counts as good at long documents. */
export declare const LONG_CONTEXT = 1000000;
/**
 * The display name of who makes a model.
 * @param hint - the maker segment the catalogue states, or a chat id's first segment.
 * @param id - the model id, consulted when the hint matches nothing.
 * @returns the company's name, or the hint tidied, or undefined with neither.
 */
export declare function makerName(hint: string | undefined, id: string): string | undefined;
/**
 * A model's name without the category phrase fal appends to it.
 * @param name - the catalogue's display name.
 * @returns the name as the list shows it.
 */
export declare function cleanName(name: string): string;
/**
 * A price in its currency: cents from a unit up, three significant figures
 * below it, so $0.0125 never reads as $0.01.
 */
export declare function money(amount: number, currency?: string): string;
/** The unit the price column names, per kind. */
export declare const PRICE_UNIT: Readonly<Record<BrowserKind, BarKey>>;
/**
 * A media model's price as the list and facts table state it.
 * @param price - the candidate's price, when one is known.
 * @param kind - what the model makes.
 * @param from - who published the price.
 * @param t - the pane's translate function.
 * @returns the browser price.
 */
export declare function mediaPrice(price: MediaPrice | undefined, kind: Exclude<BrowserKind, 'chat'>, from: string, t: Translate): BrowserPrice;
/**
 * A chat model's price: writing per 1M tokens as the headline, reading under it.
 * @param price - the effective token price, when one is known.
 * @param providerName - the route's display name, for a price from the shipped catalogue.
 * @param t - the pane's translate function.
 * @returns the browser price.
 */
export declare function chatPrice(price: ChatModelDetail['price'], providerName: string, t: Translate): BrowserPrice;
/** The "Good at" labels a set of provider tags earns, in the kind's order. */
export declare function goodAtFor(kind: BrowserKind, tags: readonly string[]): BarKey[];
/**
 * A row's "Good at" labels: the shipped ones when the model was labelled
 * (even when none fit), else the ones its tags earn.
 * @param kind - what the model makes.
 * @param shipped - the model-facts ids the route sent, if any.
 * @param tags - the provider's tags or chat abilities.
 */
export declare function goodAtOf(kind: BrowserKind, shipped: readonly string[] | undefined, tags: readonly string[]): BarKey[];
/** A row's controls as locale keys, in the kind's order. */
export declare function controlsOf(kind: BrowserKind, ids: readonly string[] | undefined): BarKey[];
/**
 * Fold one media candidate into a browser row.
 * @param backend - the backend id serving it.
 * @param model - the candidate's model.
 * @param kind - what the space makes.
 * @param from - the backend's display name.
 * @param t - the pane's translate function.
 * @returns the row.
 */
export declare function mediaModel(backend: string, model: MediaCandidateModel, kind: Exclude<BrowserKind, 'chat'>, from: string, t: Translate): BrowserModel;
/**
 * Fold one chat model into a browser row. OpenRouter names its models
 * `Maker: Name`; the maker moves to its own line.
 * @param provider - the route id.
 * @param providerName - the route's display name.
 * @param model - the model as the details route lists it.
 * @param t - the pane's translate function.
 * @param route - the route as the row names it, with any terminal-CLI mark; defaults to its display name.
 * @returns the row.
 */
export declare function chatModel(provider: string, providerName: string, model: ChatModelDetail, t: Translate, route?: string): BrowserModel;
/**
 * The person's ratings as `GET /idealize/router/ratings` lists them: by
 * rating key, each tag's stars. Quiet marks travel too and are never shown
 * (JJ, 28 Oct 2026).
 */
export type RatingMap = Readonly<Record<string, {
    tags: Readonly<Record<string, {
        stars?: number;
    }>>;
}>>;
/**
 * A chat model's facts key, as `chatFactKey` in `@idealize/services` makes
 * it: the last path segment, lower case, without a variant, a date or
 * `latest`, dots as dashes. Copied because the browser bundle cannot import
 * the host's services.
 * @param id - the model id as its route lists it.
 */
export declare function chatKeyOf(id: string): string;
/** The key the router files a model's ratings under. */
export declare function ratingKeyOf(kind: BrowserKind, id: string): string;
/** A model's stars by tag, unstarred tags left out. */
export declare function starsOf(ratings: RatingMap | undefined, model: Pick<BrowserModel, 'makes' | 'id'>): Record<string, number>;
/** The tags a kind of model can be rated for: its Good at vocabulary, in order. */
export declare function ratingTags(kind: BrowserKind): string[];
/** The locale key naming a rating tag: the Good at label of the same id. */
export declare const tagKey: (tag: string) => BarKey;
/**
 * A list row's rating line, the two best-rated tags first: `★ 5 coding · 3 writing`.
 * @param stars - the row's stars by tag.
 * @param t - the pane's translate function.
 * @returns the line, or undefined for an unrated model.
 */
export declare function ratingSummary(stars: Readonly<Record<string, number>>, t: Translate): string | undefined;
/** The browser's filters, as its controls stand. */
export interface BrowserFilters {
    query: string;
    takes: readonly Takes[];
    goodAt: readonly BarKey[];
    controls: readonly BarKey[];
    clientOnly: boolean;
}
/**
 * The models the filters leave: the query matches name, maker, id or
 * description; every chosen Takes chip must be among what a model reads;
 * every chosen Good at label must be earned; every chosen control must be
 * offered; and with Client work only on, a
 * model must state a commercial licence.
 * @param models - the full catalogue.
 * @param filters - the controls.
 * @returns the matching models, in the given order.
 */
export declare function filterModels(models: readonly BrowserModel[], filters: BrowserFilters): BrowserModel[];
/**
 * Order models for the list. Cheapest puts comparable prices first, low to
 * high, then prices in other units, then models without one; newest puts
 * dated models first; your ratings puts starred models first, best first;
 * ties fall back to the name.
 * @param models - the models to order.
 * @param sort - the chosen order.
 * @param ratings - the person's ratings, for the rated order.
 * @returns a new array.
 */
export declare function sortModels(models: readonly BrowserModel[], sort: BrowserSort, ratings?: RatingMap): BrowserModel[];
/** The Takes chips a catalogue offers: every kind of input some model reads, in display order. */
export declare function takesOffered(models: readonly BrowserModel[]): Takes[];
/** The Good at chips a catalogue offers: every label some model carries, in the kind's order. */
export declare function goodAtOffered(kind: BrowserKind, models: readonly BrowserModel[]): BarKey[];
/** The Controls chips a catalogue offers: every control some model has, in the kind's order. */
export declare function controlsOffered(kind: BrowserKind, models: readonly BrowserModel[]): BarKey[];
/** Whether the catalogue carries licence data, so the Client work only switch means something. */
export declare function hasLicences(models: readonly BrowserModel[]): boolean;
/** Who makes a model and where it is served, as the list's second line states them. */
export declare function byline(model: BrowserModel): string;
/** `YYYY-MM-DD` as `Mon YYYY`, or undefined for anything else. */
export declare function monthYear(date: string | undefined): string | undefined;
export {};
//# sourceMappingURL=model-browser.d.ts.map