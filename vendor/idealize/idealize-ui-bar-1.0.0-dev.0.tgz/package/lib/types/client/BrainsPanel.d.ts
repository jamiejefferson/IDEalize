import type { ModelsSettingsSectionHost, ModelsSectionInjected } from '@deepseek-ai/dsh-client-ui-settings-models/client';
import type { BrainsRequest } from './bar-store.ts';
import type { BarKey } from './locales.ts';
export { providerDisplayName } from './format.ts';
/** The upstream provider editor, delivered through the Context (index.ts). */
export interface BrainsPanelHost {
    models: {
        Component: ModelsSettingsSectionHost['Component'];
        props: ModelsSectionInjected;
    };
    /**
     * Move the open chat onto a brain's model, when that chat is running the
     * brain. The pane knows what changed; only the plugin knows which chat is
     * open and how to write its model, so the sheet hands the id over and the
     * plugin decides whether anything follows.
     * @param brainId - the brain the sheet just saved.
     * @returns once the write settled, or at once when nothing follows.
     */
    followBrain: (brainId: string) => Promise<void>;
}
/**
 * "What matters most" (Paper "Brains rethink", board 11): three plain choices
 * that write the same three weights the fine-tune sliders do, so a stored brain
 * stays valid. The values are this pane's, chosen on 4 Nov 2026.
 */
declare const MATTERS: {
    readonly cost: {
        readonly cost: 90;
        readonly speed: 50;
        readonly intelligence: 20;
    };
    readonly balanced: {
        readonly cost: 50;
        readonly speed: 50;
        readonly intelligence: 50;
    };
    readonly best: {
        readonly cost: 10;
        readonly speed: 50;
        readonly intelligence: 90;
    };
};
type Matter = keyof typeof MATTERS;
/**
 * Which plain choice a brain's weights read as. A brain's shipped row and a
 * fine-tuned one rarely match a choice exactly, so this reads the lean.
 * @param criteria - the brain's weights.
 * @param criteria.cost - how much low cost counts.
 * @param criteria.intelligence - how much intelligence counts.
 * @returns the choice to mark.
 */
export declare function matterOf(criteria: {
    cost: number;
    intelligence: number;
}): Matter;
/**
 * A model's readable name from its route id, for when no catalogue has been read
 * yet: `deepseek/deepseek-v4-flash` reads DeepSeek V4 Flash.
 * @param id - the model id.
 * @returns the name to show.
 */
export declare function readableModelId(id: string): string;
/**
 * Render the Brains pane.
 * @param props.host - the provider editor face (index.ts).
 * @param props.t - bar copy.
 * @returns the pane element tree.
 */
export declare function BrainsPanel({ host, request, onRequestHandled, t }: {
    host: BrainsPanelHost;
    /** What another surface asked this pane to do; null when nothing is outstanding. */
    request?: BrainsRequest | null;
    /** Mark {@link request} handled, so reopening the pane does not replay it. */
    onRequestHandled?: () => void;
    t: (key: BarKey, params?: Record<string, string | number>) => string;
}): import("react").JSX.Element;
//# sourceMappingURL=BrainsPanel.d.ts.map