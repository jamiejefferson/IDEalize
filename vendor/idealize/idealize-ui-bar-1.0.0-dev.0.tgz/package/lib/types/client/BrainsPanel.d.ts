import type { ModelsSettingsSectionHost, ModelsSectionInjected } from '@deepseek-ai/dsh-client-ui-settings-models/client';
import type { BrainsRequest } from './bar-store.ts';
import type { BarKey } from './locales.ts';
export { providerDisplayName } from './format.ts';
/** The upstream provider editor, delivered through the Context (index.ts). */
export interface BrainsPanelHost {
    models: {
        Component: ModelsSettingsSectionHost['Component'];
        props: ModelsSectionInjected;
    };
    /**
     * Move the open chat onto a preset's model. The pane no longer edits
     * presets, so it never calls this; the member stays because the drawer's
     * host object supplies it.
     * @param brainId - the preset that was saved.
     * @returns once the write settled.
     */
    followBrain: (brainId: string) => Promise<void>;
}
/**
 * A model's readable name from its route id, for when no catalogue has been read
 * yet: `deepseek/deepseek-v4-flash` reads DeepSeek V4 Flash.
 * @param id - the model id.
 * @returns the name to show.
 */
export declare function readableModelId(id: string): string;
/**
 * Render the Models pane.
 * @param props.host - the provider editor face (index.ts).
 * @param props.request - what another surface asked this pane to open.
 * @param props.onRequestHandled - marks the request handled.
 * @param props.t - bar copy.
 * @returns the pane element tree.
 */
export declare function BrainsPanel({ host, request, onRequestHandled, t }: {
    host: BrainsPanelHost;
    /** What another surface asked this pane to do; null when nothing is outstanding. */
    request?: BrainsRequest | null;
    /** Mark {@link request} handled, so reopening the pane does not replay it. */
    onRequestHandled?: () => void;
    t: (key: BarKey, params?: Record<string, string | number>) => string;
}): import("react").JSX.Element;
//# sourceMappingURL=BrainsPanel.d.ts.map