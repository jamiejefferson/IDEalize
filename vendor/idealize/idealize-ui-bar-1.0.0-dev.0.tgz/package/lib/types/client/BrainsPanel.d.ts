import type { ModelsSettingsSectionHost, ModelsSectionInjected } from '@deepseek-ai/dsh-client-ui-settings-models/client';
import type { BrainsRequest } from './bar-store.ts';
import type { BarKey } from './locales.ts';
/** The upstream provider editor, delivered through the Context (index.ts). */
export interface BrainsPanelHost {
    models: {
        Component: ModelsSettingsSectionHost['Component'];
        props: ModelsSectionInjected;
    };
    /**
     * Move the open chat onto a brain's model, when that chat is running the
     * brain. The pane knows what changed; only the plugin knows which chat is
     * open and how to write its model, so the sheet hands the id over and the
     * plugin decides whether anything follows.
     * @param brainId - the brain the sheet just saved.
     * @returns once the write settled, or at once when nothing follows.
     */
    followBrain: (brainId: string) => Promise<void>;
}
/**
 * What a provider route is called, everywhere in this pane: the name its
 * directory gave it when that is a name, else its id with a capital. The
 * host already resolves catalogue routes through the services directory
 * (openai → OpenAI); this is the last resort for a route no table knows.
 * @param provider - the route id.
 * @param displayName - the name the state payload carries, when it does.
 * @returns the name to show.
 */
export declare function providerDisplayName(provider: string, displayName?: string): string;
/**
 * Render the Brains pane.
 * @param props.host - the provider editor face (index.ts).
 * @param props.t - bar copy.
 * @returns the pane element tree.
 */
export declare function BrainsPanel({ host, request, onRequestHandled, t }: {
    host: BrainsPanelHost;
    /** What another surface asked this pane to do; null when nothing is outstanding. */
    request?: BrainsRequest | null;
    /** Mark {@link request} handled, so reopening the pane does not replay it. */
    onRequestHandled?: () => void;
    t: (key: BarKey, params?: Record<string, string | number>) => string;
}): import("react").JSX.Element;
//# sourceMappingURL=BrainsPanel.d.ts.map