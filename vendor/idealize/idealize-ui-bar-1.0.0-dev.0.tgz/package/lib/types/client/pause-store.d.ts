/**
 * The window's read of the pause on every agent (feedback 495cec0a), behind
 * the sidebar's Pause control. The host owns the pause (`@idealize/comm`'s
 * `/idealize/pause`); this store reads it, re-reads it whenever the host
 * announces a change on the bridge feed (a press from the quit dialog lands
 * here too), and presses its three buttons.
 *
 * Resume names the Terminal chats it could not reach because their shell was
 * closed (the app restarted). The store opens each one's shell through the
 * terminal route, which launches its CLI on its conversation; the host types
 * the carry-on line once that CLI is at its prompt.
 * @module @idealize/ui-bar/client/pause-store
 */
import { type SnapshotStore } from '@deepseek-ai/dsh-client-runtime/client';
/** The route the host serves the pause on. */
export declare const PAUSE_PATH = "/idealize/pause";
/** Where every agent stands (restated from `@idealize/comm`'s wire body). */
export type PausePhase = 'running' | 'saving' | 'paused';
/** The pause as the host serves it. */
export interface PauseView {
    phase: PausePhase;
    since?: string;
    chats: {
        id: string;
        label: string;
        kind: 'chat' | 'terminal';
        state: 'saving' | 'stopped';
    }[];
    /** Agents still writing their notes. */
    saving: number;
    /** Agents working right now, counted while running. */
    working: number;
}
/** A Terminal chat whose shell Resume asks the window to open. */
export interface ShellToOpen {
    sessionId: string;
    cwd?: string;
    activity?: string;
}
/** The three presses. */
export type PauseAction = 'pause' | 'stop' | 'resume';
/** What the control renders from. */
export interface PauseState {
    /** The host's pause; null until the first read lands, or where no host serves it. */
    pause: PauseView | null;
    /** A press is on its way. */
    busy: boolean;
    /** The last press's failure, in the host's words. */
    error: string | null;
}
/** How the store reaches the host; a test swaps it. */
export interface PauseTransport {
    read(): Promise<PauseView | null>;
    press(action: PauseAction): Promise<PauseView & {
        open?: ShellToOpen[];
    }>;
    openShell(shell: ShellToOpen): Promise<void>;
}
/** The host's routes over fetch. */
export declare const httpPauseTransport: PauseTransport;
/** The pause store: one per window. */
export declare class PauseStore {
    private readonly transport;
    readonly store: SnapshotStore<PauseState>;
    /** @param transport - how the store reaches the host. */
    constructor(transport?: PauseTransport);
    /** Read the pause from the host; a failed read keeps what the store holds. */
    load(): Promise<void>;
    /**
     * Press one of the control's buttons, then open the shells Resume names.
     * @param action - pause, stop or resume.
     */
    press(action: PauseAction): Promise<void>;
    /**
     * Read the pause now and again on every change the host announces.
     * @returns a function that stops following.
     */
    start(): () => void;
}
//# sourceMappingURL=pause-store.d.ts.map