import type { ModelsSettingsSectionHost, ModelsSectionInjected } from '@deepseek-ai/dsh-client-ui-settings-models/client';
import type { AgentPresetSectionHost, AgentPresetSectionProps } from '@deepseek-ai/dsh-client-ui-agent-preset/client';
import type { BarKey } from './locales.ts';
/** The global standard hooks every slot component receives (threaded through). */
export type PanelGlobals = Pick<AgentPresetSectionProps, 'useSessions' | 'useWorkspaces'>;
/**
 * Everything the panel needs beyond bar copy, assembled in index.ts from the
 * two upstream section services (the client bundle purity gate forbids
 * cross-plugin value imports, so the components arrive through the Context).
 */
export interface ModelsPanelHost {
    /** The provider page: upstream component + its wired face. */
    models: {
        Component: ModelsSettingsSectionHost['Component'];
        props: ModelsSectionInjected;
    };
    /** The preset roster: upstream component + pre-bound props (minus shell shares). */
    presets: {
        Component: AgentPresetSectionHost['Component'];
        props: Omit<AgentPresetSectionProps, 'close' | keyof PanelGlobals>;
    };
}
/**
 * Render the Models & usage panel body.
 * @param props.host - the section faces (index.ts).
 * @param props.t - bar copy.
 * @param props.close - close the drawer (handed to the preset section).
 * @returns the panel element tree.
 */
export declare function ModelsPanel({ host, globals, t, close }: {
    host: ModelsPanelHost;
    globals: PanelGlobals;
    t: (key: BarKey) => string;
    close: () => void;
}): import("react").JSX.Element;
//# sourceMappingURL=ModelsPanel.d.ts.map