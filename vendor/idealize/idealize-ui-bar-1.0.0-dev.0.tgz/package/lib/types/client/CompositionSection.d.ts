/**
 * The Composition tab of the Service hatch drawer pane: the @idealize/hatch
 * host page (what the app is made of, edits with snapshots and rollback)
 * hosted in an iframe beside the Service chat.
 */
import type { PropsLocale } from '@deepseek-ai/dsh-client-ui-slots';
export type CompositionSectionProps = PropsLocale<'idealize-bar'>;
/**
 * Render the hatch page in a pane-filling frame.
 * @param props - composed slot props.
 * @returns the iframe wrapper.
 */
export declare function CompositionSection({ t }: CompositionSectionProps): import("react").JSX.Element;
//# sourceMappingURL=CompositionSection.d.ts.map