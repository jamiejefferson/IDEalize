/**
 * The line under the composer that the heart and the dislike bring up (Paper
 * "Ratings and dislike" boards 01 and 02). One line per chat at a time: the
 * heart's "Rate X for [tag] ☆☆☆☆☆", or the dislike's offer to try two other
 * models. The router's loopback routes answer both; this module holds which
 * line each chat shows and the calls behind it.
 * @module @idealize/ui-bar/client/rating-line
 */
/** The kinds of model a line can be about. */
export type LineKind = 'chat' | 'image' | 'video' | 'audio';
/** One model as the router names it. */
export interface LineModel {
    provider: string;
    model: string;
    label: string;
}
/** What the heart's line rates: the model behind the chat's last answer. */
export interface RateTarget extends LineModel {
    kind: LineKind;
    /** The kind of work the router read for that answer; the line opens on it. */
    tag: string;
    /** Every tag the kind can be rated for. */
    tags: string[];
    /** The person's stars for this model, by tag. */
    stars: Record<string, number>;
}
/** What both runs of an offer should cost. */
export type LinePrice = {
    amount: number;
} | {
    unknown: true;
};
/** The dislike's offer. */
export interface Offer {
    kind: LineKind;
    tag: string;
    first: LineModel;
    alternatives: LineModel[];
    price: LinePrice;
}
export type LineState = {
    kind: 'loading';
    from: 'heart' | 'dislike';
} | {
    kind: 'rate';
    target: RateTarget;
    tag: string;
    saved?: {
        stars: number | null;
        before: number | null;
    } | undefined;
} | {
    kind: 'offer';
    offer: Offer;
    starting?: boolean | undefined;
} | {
    kind: 'note';
    from: 'heart' | 'dislike';
    message: string;
};
/**
 * Show or clear one chat's line.
 * @param sessionId - the chat.
 * @param state - the line, or undefined to clear it.
 */
export declare function setLine(sessionId: string, state: LineState | undefined): void;
/**
 * The line one chat shows.
 * @param sessionId - the chat.
 */
export declare function lineOf(sessionId: string): LineState | undefined;
/**
 * Subscribe a component to one chat's line.
 * @param sessionId - the chat.
 * @returns its line.
 */
export declare function useLine(sessionId: string): LineState | undefined;
/**
 * The heart: open the rating line, or close it when it is already open.
 * @param sessionId - the chat.
 * @param nothingYet - the note shown when the chat has no answer to rate.
 */
export declare function openRating(sessionId: string, nothingYet: string): Promise<void>;
/**
 * Set or clear the stars on the line's model for the line's tag.
 * @param sessionId - the chat.
 * @param stars - 1 to 5, or null to clear.
 */
export declare function rateOnLine(sessionId: string, stars: number | null): Promise<void>;
/**
 * The dislike: ask the router for two models to try, or close the offer.
 * @param sessionId - the chat.
 * @param cannot - the note shown when nothing can be offered, given the router's reason.
 */
export declare function openOffer(sessionId: string, cannot: (reason: string) => string): Promise<void>;
/**
 * Accept the offer: the router runs the alternatives and the comparison card takes over.
 * @param sessionId - the chat.
 * @param failed - the note shown when the router refuses, given its reason.
 */
export declare function acceptOffer(sessionId: string, failed: (reason: string) => string): Promise<void>;
/**
 * Keep one alternative, or the first answer.
 * @param sessionId - the chat.
 * @param id - the comparison.
 * @param index - the alternative, or -1 for the first answer.
 * @returns the router's error sentence, or undefined.
 */
export declare function pickAnswer(sessionId: string, id: string, index: number): Promise<string | undefined>;
/**
 * The offer's price as the button says it.
 * @param price - the router's estimate.
 * @returns the locale key and its amount.
 */
export declare function priceKey(price: LinePrice): {
    key: 'line.offer.price.about' | 'line.offer.price.under' | 'line.offer.price.free' | 'line.offer.price.unknown';
    amount?: string;
};
//# sourceMappingURL=rating-line.d.ts.map