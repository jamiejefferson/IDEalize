import type { InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { PauseAction, PauseState } from './pause-store.ts';
/** Registration-side face. */
export interface PauseControlInjected {
    /** Selector hook over the window's pause store. */
    usePause: <T>(selector: (state: PauseState) => T) => T;
    /** Press one of the control's buttons. */
    press: (action: PauseAction) => Promise<void>;
    /** Follow the host's pause while the control is mounted. */
    follow: () => () => void;
}
export type PauseControlProps = PropsRuntime<'sidebar.footer.action'> & PropsLocale<'idealize-bar'> & InjectFace<PauseControlInjected>;
/**
 * Render the control.
 * @param props - the foot seat's column state, the bar's locale seat and the wired face.
 * @returns the control, or null until the host has answered.
 */
export declare function PauseControl({ wide, usePause, press, follow, t }: PauseControlProps): import("react").JSX.Element | null;
//# sourceMappingURL=PauseControl.d.ts.map