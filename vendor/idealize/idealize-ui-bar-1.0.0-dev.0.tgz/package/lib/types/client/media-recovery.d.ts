/** Shared localised recovery copy for generating-space availability verdicts. */
import type { BarKey } from './locales.ts';
/** The route fields needed to explain an unavailable generating space. */
interface MediaRecoveryVerdict {
    /** The host's structured reason, or another space-level refusal. */
    reason?: string;
    /** The host sentence retained for unknown ids and non-generation refusals. */
    recovery?: string;
}
/**
 * Render the same localised sentence in the launcher and Brains pane.
 * @param id - a space id or its persisted media-preset id.
 * @param verdict - the host's structured reason and fallback sentence.
 * @param t - the ui-bar namespace translator.
 * @returns localised generation recovery, or the host fallback for another refusal.
 */
export declare function mediaRecoveryText(id: string, verdict: MediaRecoveryVerdict, t: (key: BarKey) => string): string;
export {};
//# sourceMappingURL=media-recovery.d.ts.map