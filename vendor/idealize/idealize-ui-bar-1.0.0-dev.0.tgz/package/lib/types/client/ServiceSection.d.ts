import type { SessionBinding } from '@deepseek-ai/dsh-client-runtime/client';
import type { PropsLocale } from '@deepseek-ai/dsh-client-ui-slots';
/** Registration-side face, built over ctx.workspaces/ctx.sessions (index.ts). */
export interface ServiceSectionInjected {
    /** A binding for the newest existing hatch session, without creating anything. */
    adoptSession: (path: string) => SessionBinding | null;
    /**
     * Create/find the source workspace and a session in it, stage it open so
     * the transcript streams, and bind it. Rejects on any create failure —
     * the section renders the message; it never fails silently.
     */
    ensureSession: (path: string) => Promise<SessionBinding>;
    /** Open the Brains pane (model connections), from the connect-a-model notice. */
    openModels: () => void;
}
/** The pane hands the section its copy and the session plumbing. */
export type ServiceSectionProps = PropsLocale<'idealize-bar'> & ServiceSectionInjected;
/**
 * Render the Service section: source status with its in-place edit (persisted
 * through POST /idealize/hatch/service), the full hatch transcript opened by
 * the animated quote row, and the composer (attachments, stop) that starts
 * the session on first send. Probe, create, edit, and send failures each
 * render a visible strip.
 * @param props - composed slot props.
 * @returns the section element tree.
 */
export declare function ServiceSection(props: ServiceSectionProps): import("react").JSX.Element;
//# sourceMappingURL=ServiceSection.d.ts.map