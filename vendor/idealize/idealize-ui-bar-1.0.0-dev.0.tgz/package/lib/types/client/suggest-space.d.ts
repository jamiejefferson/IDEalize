/**
 * The welcome card's guess that a message belongs in a media space (Paper
 * "Brains rethink", board 06). It only offers: the person chooses with one
 * click, or carries on where they are. So it reads for an ask to make the
 * thing, because "fix the logo on my site" is not a request for a picture.
 * @module @idealize/ui-bar/client/suggest-space
 */
import type { SpaceId } from '@idealize/spaces/client';
/** The spaces the guess can point at. */
export type SuggestedSpace = Extract<SpaceId, 'gallery' | 'soundstage' | 'motion'>;
/**
 * Read a draft for an ask to make media.
 * @param draft - the composer's text.
 * @returns the space it suits, or undefined when it reads as anything else.
 */
export declare function suggestSpace(draft: string): SuggestedSpace | undefined;
//# sourceMappingURL=suggest-space.d.ts.map