import type { PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
export type MinimodeButtonProps = PropsRuntime<'sidebar.header.action'> & PropsLocale<'idealize-bar'>;
/**
 * The collapse button.
 * @param props - the sidebar column state and the bar's locale seat.
 * @returns the button, or null outside the desktop shell.
 */
export declare function MinimodeButton({ t }: MinimodeButtonProps): import("react").JSX.Element | null;
//# sourceMappingURL=MinimodeButton.d.ts.map