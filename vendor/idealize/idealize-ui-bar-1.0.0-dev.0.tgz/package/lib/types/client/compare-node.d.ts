/**
 * The comparison after a dislike, as one chat node: every
 * `idealize/router-compare` step of one comparison folds into one card that
 * sits under the reply the person disliked (Paper "Ratings and dislike"
 * board 03). The first reply stays where it is in the chat.
 * @module @idealize/ui-bar/client/compare-node
 */
import type { ConversationNodeDefinition } from '@deepseek-ai/dsh-client-runtime/client';
import type { RouterCompareEventData } from '@idealize/router/client';
/** One comparison as the card reads it. */
export interface CompareNodeData {
    started: RouterCompareEventData;
    answers: Array<RouterCompareEventData | undefined>;
    /** The alternative kept, -1 for the first answer, undefined while the person decides. */
    picked?: number | undefined;
}
declare module '@deepseek-ai/dsh-client-ui-conversation/client' {
    interface ChatNodeDataMap {
        /** Two other models' answers to the ask the person disliked a reply to. */
        'router-compare': CompareNodeData;
    }
}
export declare const COMPARE_KIND = "router-compare";
/**
 * Fold one step into the card.
 * @param state - the card so far.
 * @param step - the step.
 * @returns the card after it.
 */
export declare function foldStep(state: CompareNodeData, step: RouterCompareEventData): CompareNodeData;
/** One Context per comparison, keyed by its id. */
export declare const compareDefinition: ConversationNodeDefinition<CompareNodeData>;
//# sourceMappingURL=compare-node.d.ts.map