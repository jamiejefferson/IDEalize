import type { BarKey } from './locales.ts';
/**
 * Render the Budget section.
 * @param props.providerName - a route's display name, by the pane's one rule.
 * @param props.t - bar copy.
 * @returns the section's element tree.
 */
export declare function BudgetSection({ providerName, t }: {
    providerName: (provider: string) => string;
    t: (key: BarKey, params?: Record<string, string | number>) => string;
}): import("react").JSX.Element;
//# sourceMappingURL=BudgetSection.d.ts.map