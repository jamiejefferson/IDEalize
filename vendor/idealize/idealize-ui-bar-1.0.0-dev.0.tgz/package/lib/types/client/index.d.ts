import { type ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
import type { ObservableSnapshot } from '@deepseek-ai/dsh-client-runtime/client';
import type { SpaceId } from '@idealize/spaces/client';
import { type BarPanel, type BarViewState } from './bar-store.ts';
import { type BarKey } from './locales.ts';
export { IdealizeBar } from './IdealizeBar.tsx';
export { DrawerPanel } from './DrawerPanel.tsx';
export { DeckPanel } from './DeckPanel.tsx';
export { HeartButton } from './HeartButton.tsx';
export { BrainsPanel } from './BrainsPanel.tsx';
export { FeedbackPanel } from './FeedbackPanel.tsx';
export { ServiceSection } from './ServiceSection.tsx';
export { CompositionSection } from './CompositionSection.tsx';
export { SchedulePane } from './SchedulePane.tsx';
export type { ScheduleHost, SchedulePaneProps } from './SchedulePane.tsx';
export { StudioCard } from './StudioCard.tsx';
export type { StudioCardInjected, StudioCardProps } from './StudioCard.tsx';
export { HeroLauncher, NoPresetChip, SPACE_LABELS } from './HeroLauncher.tsx';
export type { BrainAccess, HeroLauncherInjected, HeroLauncherProps, LauncherSession, LauncherSpaces } from './HeroLauncher.tsx';
export { CHAT_VIEW, createSpaceSeed, openChatView, ringHasView, subscribeRing } from './view-switch.ts';
export type { ErasedSlots, SpaceSeed } from './view-switch.ts';
export { PlanToggle } from './PlanToggle.tsx';
export type { PlanToggleInjected, PlanToggleProps } from './PlanToggle.tsx';
export { HatchTrigger } from './HatchChrome.tsx';
export { createBarViewStore } from './bar-store.ts';
export type { BarPanel, BarViewState, BarViewStore, BrainsRequest, HatchTab, RevealRequest } from './bar-store.ts';
export type { BarKey } from './locales.ts';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** The tool rail's copy. */
        'idealize-bar': BarKey;
    }
}
/**
 * The pane face other plugins reach (`ctx.idealizeBar`): drive the rail's
 * drawer panes and the deck's file viewer without importing the components.
 * Calls go through the same closures the rail's own entries use, so the
 * drawer/deck columns (`ctx.layout`) and the appearance service's open flag
 * stay in step however a pane is opened.
 */
export interface IdealizeBarService {
    /** The bar's view state (open pane, hatch tab, deck file); read-only. */
    readonly state: ObservableSnapshot<BarViewState>;
    /**
     * Open a drawer pane and the drawer column; the appearance pane also
     * raises the appearance service's open flag. No-op when already showing.
     * @param panel - the pane to show.
     */
    show(panel: BarPanel): void;
    /** Close the open drawer pane and the drawer column; no-op when closed. */
    close(): void;
    /**
     * Show a file in the deck's viewer and open the deck column.
     * @param path - file path as the files pane reports it.
     */
    openFile(path: string): void;
    /** Clear the deck's file and close the deck column; no-op when empty. */
    closeFile(): void;
    /**
     * Open the Files pane on one file: the tab whose root holds it (the project
     * tab first), every ancestor folder expanded, its folder selected as the
     * creation target, and its row scrolled into view and highlighted until the
     * next click. A path under no tab's root leaves the pane open with a
     * status line saying so.
     * @param path - absolute path of the file.
     */
    revealFile(path: string): void;
    /**
     * Open the Brains pane on its add-a-brain flow with a space already set —
     * what the welcome card's brain step offers when a space has no brains yet.
     * @param space - the space the new brain will work in.
     */
    addBrain(space: SpaceId): void;
}
declare module '@deepseek-ai/cordis' {
    interface Context {
        /** The rail's pane service (this plugin owns the concrete value). */
        idealizeBar: IdealizeBarService;
    }
}
/** Required services for the rail, its panes, and the composer seats. */
export declare const inject: string[];
/**
 * Client plugin body: the rail, the drawer/deck panes, the composer heart,
 * and the welcome launcher.
 * @param ctx - client root context.
 */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map