import type { InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
/** Registration-side face: the command verb. */
export interface PlanToggleInjected {
    /**
     * Enter or leave plan mode by command.
     * @param on - the target mode.
     * @returns null on admitted execution; a failure line otherwise.
     */
    setPlanMode: (on: boolean) => Promise<string | null>;
}
export type PlanToggleProps = PropsRuntime<'conversation.input.plan'> & PropsLocale<'idealize-bar'> & InjectFace<PlanToggleInjected> & {
    /** Selector hook over ui-conversation's chat store, whose `view` is the ring's active view id. */
    useStore: <T>(selector: (state: {
        view: string | null;
    }) => T) => T;
};
/** The ring views the plan icon serves; a chat with no view chosen yet counts as Chat. */
export declare const PLAN_VIEWS: readonly string[];
/**
 * Render the plan-mode icon button.
 * @param props - composed slot props.
 * @returns the button, or null while the session has no plan capability or the ring sits on a generating space.
 */
export declare function PlanToggle({ useProjection, useStore, locked, setPlanMode, t }: PlanToggleProps): import("react").JSX.Element | null;
//# sourceMappingURL=PlanToggle.d.ts.map