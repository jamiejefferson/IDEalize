import type { InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { PillSessionSummary } from '@idealize/activity-pills/client';
import type { SpaceId, SpaceRosterEntry } from '@idealize/spaces/client';
import type { BarKey } from './locales.ts';
/**
 * Whether a chat on a brain can open its first request now, as the agents
 * route's `access` field reports it. `unavailable` with `no-access` means the
 * brain's route has no stored key; with `no-sign-in`, that the route is a
 * subscription nobody has signed in to.
 */
export interface BrainAccess {
    state: 'ready' | 'confirm' | 'unavailable';
    reason?: string;
    model: {
        provider: string;
        model: string;
    } | null;
    /** The route's display name, when the sign-in surface offers the route. */
    providerName?: string;
}
/** The launcher's view of the space vocabulary: the roster read, the launch, and the two recoveries. */
export interface LauncherSpaces {
    /**
     * The roster both steps read, in chooser order.
     * @returns one entry per declared space; an empty list when the route is unreachable.
     */
    load: () => Promise<readonly SpaceRosterEntry[]>;
    /**
     * Each brain's access, keyed by preset id. A brain marked unavailable is
     * listed with the reason and starts no chat; its row opens the key editor,
     * or the sign-in surface when a sign-in is what the route waits on.
     * @returns the map; empty when the route is unreachable.
     */
    access: () => Promise<Readonly<Record<string, BrainAccess>>>;
    /**
     * Enter a space on a brain: record the space and the brain, recompose the
     * chat's preset, and flip its view ring.
     * @param space - the chosen space.
     * @param brain - the chosen brain's agent preset id.
     * @param sessionId - the chat being launched, or undefined for the current one.
     * @returns false when the host refused, which leaves the chooser up.
     */
    enter: (space: SpaceId, brain: string, sessionId: string | undefined) => Promise<boolean>;
    /**
     * Open the Brains pane's add flow with the space already set.
     * @param space - the space the new brain will work in.
     */
    addBrain: (space: SpaceId) => void;
    /** Open the Brains pane's provider editor, where a provider key is added. */
    addKey: () => void;
    /** Open the sign-in surface, where a subscription route is signed in to. */
    signIn: () => void;
    /**
     * The Terminal space's launch table (`GET /idealize/terminal/launches`):
     * the default CLI command, the per-brain overrides and the catalogue that
     * names them. In Terminal a brain runs a CLI on its own login, so the
     * brain step shows the CLI, never the chat model or its key (JJ, 2 Sep
     * 2026: "I selected gpt but got claude").
     * @returns the table, or undefined outside the desktop app.
     */
    terminalLaunches: () => Promise<TerminalLaunches | undefined>;
}
/** One CLI the terminal can launch, as the launches route's catalogue lists it. */
export interface TerminalCliOption {
    id: string;
    label: string;
    command: string;
    installed: boolean | null;
}
/** The `GET /idealize/terminal/launches` payload the Terminal brain step reads. */
export interface TerminalLaunches {
    default: string;
    byActivity: Record<string, string>;
    catalog?: TerminalCliOption[];
}
/**
 * The CLI one brain launches in Terminal, by label: the per-brain override
 * or the default, named through the catalogue; a command outside the
 * catalogue is shown verbatim, and `''` is a plain shell.
 * @param brain - the brain's preset id.
 * @param launches - the launch table.
 * @param t - the bar's copy.
 * @returns the label and whether the login shell finds the executable.
 */
export declare function terminalCliOf(brain: string, launches: TerminalLaunches, t: HeroLauncherProps['t']): {
    label: string;
    installed: boolean | null;
};
/**
 * The chat the card launches: the pills summary plus the brain the durable
 * record already names, when one does. A brain is recorded only by a launch
 * or a brain switch, so its presence means this chat has already answered the
 * card's questions — on a reload, where the in-memory launch key is gone, it
 * is what keeps the chooser from asking again inside a Gallery chat.
 */
export type LauncherSession = PillSessionSummary & {
    brain?: string | undefined;
    /** The recorded space; the Studio chat (`studio`) is launched by construction and never asks. */
    space?: string | undefined;
};
/** Registration-side face: the space vocabulary and the chat the card launches. */
export interface HeroLauncherInjected {
    /** The five spaces, their brains, and the launch. */
    spaces: LauncherSpaces;
    /** The session the welcome card launches (the current blank one), if any. */
    currentSession: () => LauncherSession | undefined;
}
export type HeroLauncherProps = PropsRuntime<'conversation.hero.launcher'> & PropsLocale<'idealize-bar'> & InjectFace<HeroLauncherInjected>;
/** The name of each space, wherever one is shown (the tiles, the chip, the Brains pane's add sheet). */
export declare const SPACE_LABELS: Record<SpaceId, BarKey>;
/**
 * The empty occupant of the hero's agent-preset seat: the brain step is the
 * preset choice, so the "Standard mode" chip renders nothing.
 * @returns null.
 */
export declare function NoPresetChip(): null;
/**
 * Render the welcome card body.
 * @param props - composed slot props.
 * @returns the card rows.
 */
export declare function HeroLauncher(props: HeroLauncherProps): import("react").JSX.Element | null;
//# sourceMappingURL=HeroLauncher.d.ts.map