/**
 * The Studio drawer pane: `@idealize/ui-studio`'s coordination view, seated
 * beside the conversation. The view's plugin publishes the component and its
 * wired face as the `studioSection` service (FORK.md), because the client
 * bundle purity gate forbids importing another plugin's value exports.
 *
 * One Studio view serves every chat — it follows the active chat's project on
 * its own poll — so the pane takes no session and remounts nothing on a chat
 * switch; the plugin's own store carries the view across the drawer's
 * unmounts.
 * @module @idealize/ui-bar/client/StudioPane
 */
import type { StudioSectionHost } from '@idealize/ui-studio/client';
/** The Studio plugin's section service as the drawer consumes it (index.ts binds it once). */
export interface StudioHost {
    /** The Studio view component. */
    Component: StudioSectionHost['Component'];
    /**
     * Wire the view.
     * @returns the wired face.
     */
    face: () => ReturnType<StudioSectionHost['face']>;
}
export interface StudioPaneProps {
    /** The re-hosted Studio view. */
    host: StudioHost;
}
/**
 * Render the Studio view in the drawer.
 * @param props - the host.
 * @returns the view's element tree.
 */
export declare function StudioPane({ host }: StudioPaneProps): import("react").JSX.Element;
//# sourceMappingURL=StudioPane.d.ts.map