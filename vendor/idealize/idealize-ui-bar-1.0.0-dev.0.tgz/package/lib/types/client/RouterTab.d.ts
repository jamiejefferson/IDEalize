import type { BarKey } from './locales.ts';
/**
 * Render the Router tab.
 * @param props.t - bar copy.
 * @returns the tab's element tree.
 */
export declare function RouterTab({ t, onConnect }: {
    t: (key: BarKey, params?: Record<string, string | number>) => string;
    onConnect?: () => void;
}): import("react").JSX.Element;
//# sourceMappingURL=RouterTab.d.ts.map