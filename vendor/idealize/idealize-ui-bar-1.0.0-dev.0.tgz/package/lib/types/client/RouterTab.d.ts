import type { BarKey } from './locales.ts';
/**
 * Render the router's recent decisions behind a disclosure.
 * @param props.t - bar copy.
 * @returns the disclosure's element tree.
 */
export declare function RecentModelChanges({ t }: {
    t: (key: BarKey, params?: Record<string, string | number>) => string;
}): import("react").JSX.Element;
//# sourceMappingURL=RouterTab.d.ts.map