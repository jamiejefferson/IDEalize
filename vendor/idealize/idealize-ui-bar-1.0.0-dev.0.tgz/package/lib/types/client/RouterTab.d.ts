import type { BarKey } from './locales.ts';
/**
 * Render the Router tab.
 * @param props.t - bar copy.
 * @returns the tab's element tree.
 */
export declare function RouterTab({ t }: {
    t: (key: BarKey, params?: Record<string, string | number>) => string;
}): import("react").JSX.Element;
//# sourceMappingURL=RouterTab.d.ts.map