import type { ScheduleTranslate, TaskDraft } from './schedule-model.ts';
/**
 * Render the task editor.
 * @param props.draft - the task (id set) or a new draft.
 * @param props.nextFireAt - the host-computed next fire for a saved task.
 * @param props.workspaces - registered folders for SAVE TO.
 * @param props.onBack - return to the calendar without saving.
 * @param props.onSave - persist; resolves an error message or undefined.
 * @param props.onDelete - delete the saved task (absent for drafts).
 * @param props.t - the bar namespace's bound translate.
 * @returns the editor element tree.
 */
export declare function ScheduleEditor({ draft: initial, nextFireAt, workspaces, onBack, onSave, onDelete, t }: {
    draft: TaskDraft;
    nextFireAt?: string | undefined;
    workspaces: {
        name: string;
        path: string;
    }[];
    onBack: () => void;
    onSave: (draft: TaskDraft) => Promise<string | undefined>;
    onDelete?: (() => Promise<void>) | undefined;
    t: ScheduleTranslate;
}): import("react").JSX.Element;
//# sourceMappingURL=ScheduleEditor.d.ts.map