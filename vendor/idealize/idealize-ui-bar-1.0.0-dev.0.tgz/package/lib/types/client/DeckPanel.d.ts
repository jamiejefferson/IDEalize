import type { InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { BarViewStore } from './bar-store.ts';
/** Registration-side face: the view store plus the close transition (index.ts owns the write). */
export interface DeckPanelInjected {
    hooks: {
        /** The bar's view state (arrives as the `useBarView` selector hook). */
        barView: BarViewStore;
    };
    /** Close the deck column and clear the open file. */
    closeFile: () => void;
    /** Hand a file's path to the active chat's composer; false = no active chat. */
    addToChat: (path: string) => boolean;
}
export type DeckPanelProps = PropsRuntime<'shell.deck'> & PropsLocale<'idealize-bar'> & InjectFace<DeckPanelInjected>;
export declare function DeckPanel({ useBarView, closeFile, addToChat, t }: DeckPanelProps): import("react").JSX.Element | null;
//# sourceMappingURL=DeckPanel.d.ts.map