import type { InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { BarViewStore } from './bar-store.ts';
/** Registration-side face: the view store plus the close transition (index.ts owns the write). */
export interface DeckPanelInjected {
    hooks: {
        /** The bar's view state (arrives as the `useBarView` selector hook). */
        barView: BarViewStore;
    };
    /** Close the deck column and clear the open file. */
    closeFile: () => void;
    /** Hand a file's path to the active chat's composer; false = no active chat. */
    addToChat: (path: string) => boolean;
    /** Start a fresh Notes scratchpad and show it in place of the current one. */
    newNote: () => void;
}
export type DeckPanelProps = PropsRuntime<'shell.deck'> & PropsLocale<'idealize-bar'> & InjectFace<DeckPanelInjected>;
export declare function DeckPanel({ useBarView, closeFile, addToChat, newNote, t }: DeckPanelProps): import("react").JSX.Element | null;
//# sourceMappingURL=DeckPanel.d.ts.map