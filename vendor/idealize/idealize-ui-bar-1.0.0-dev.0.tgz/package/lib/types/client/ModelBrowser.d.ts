/**
 * The model browser: one modal that chooses every kind of model the Brains
 * sheet asks for (chat, image, video, sound), over the whole catalogue a
 * select could not show. Search, Takes, Good at and Controls chips, a Client work only
 * switch and a sort narrow and order a windowed list on the left; the
 * selected model's sample, description and facts read on the right; the
 * footer applies the choice (Paper "Model picker" boards 02 to 04, approved
 * by JJ on 23 Oct 2026). The rows come from model-browser.ts; this file only
 * renders them and fetches a media model's example output when it is
 * selected, so 400 rows never cost 400 schema reads.
 * @module @idealize/ui-bar/client/ModelBrowser
 */
import type { ReactNode } from 'react';
import type { BrowserKind, BrowserModel, RatingMap, Translate } from './model-browser.ts';
/** An example output the backend publishes for a media model. */
export interface BrowserExample {
    url: string;
    mediaType: string;
}
export interface ModelBrowserProps {
    kind: BrowserKind;
    /** The space or role the model is chosen for, as the eyebrow names it. */
    spaceLabel: string;
    /** The catalogue; null while it is still being read. */
    models: readonly BrowserModel[] | null;
    /** The value in use (`provider model`), empty for none or the default. */
    current: string;
    /** Who publishes media samples, for the sample caption. */
    sampleSource?: string | undefined;
    /** Offered for a chat model, whose empty choice follows the default model. */
    allowDefault?: boolean;
    t: Translate;
    onApply: (value: string) => void;
    onClose: () => void;
    /** Fetch one media model's example output; resolves null when it has none. */
    fetchExample?: (provider: string, model: string) => Promise<BrowserExample | null>;
    /** The person's ratings; with {@link onRate}, the detail pane carries Your ratings. */
    ratings?: RatingMap | undefined;
    /** Set (1 to 5) or clear (null) one tag's stars on a model. */
    onRate?: ((model: BrowserModel, tag: string, stars: number | null) => void) | undefined;
}
/** Every list row is this tall, which is what lets the list render only the rows in view. */
export declare const ROW_HEIGHT = 62;
/**
 * The browser itself, rendered into the document body so it sits over the
 * whole window rather than inside the Brains pane.
 * @param props - the kind, catalogue, current choice and callbacks.
 * @returns the portal.
 */
export declare function ModelBrowser(props: ModelBrowserProps): ReactNode;
//# sourceMappingURL=ModelBrowser.d.ts.map