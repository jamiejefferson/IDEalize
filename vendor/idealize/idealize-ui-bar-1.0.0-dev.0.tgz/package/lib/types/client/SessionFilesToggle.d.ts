import type { BarKey } from './locales.ts';
/**
 * Render the switch.
 * @param props.t - bar copy.
 * @returns the labelled checkbox, or null until the host has answered.
 */
export declare function SessionFilesToggle({ t }: {
    t: (key: BarKey) => string;
}): import("react").JSX.Element | null;
//# sourceMappingURL=SessionFilesToggle.d.ts.map