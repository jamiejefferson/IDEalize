import type { InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { BarPanel, BarViewStore } from './bar-store.ts';
/** Registration-side face: the view store plus the pane transitions (index.ts owns the writes). */
export interface IdealizeBarInjected {
    hooks: {
        /** The bar's view state (arrives as the `useBarView` selector hook). */
        barView: BarViewStore;
    };
    /** Open the pane, or close the drawer when it is already the open pane. */
    togglePanel: (panel: BarPanel) => void;
    /**
     * Open the upstream settings dialog, or undefined in a composition without
     * `settingsOpen` — the rail then carries no Settings button.
     */
    openSettings: (() => void) | undefined;
}
export type IdealizeBarProps = PropsRuntime<'shell.rail'> & PropsLocale<'idealize-bar'> & InjectFace<IdealizeBarInjected>;
/** Sidebar launcher the Plugins button proxies (hidden by this bar's CSS). */
export declare const MARKET_LAUNCHER_SELECTOR = ".dshMarketLauncher";
export declare function IdealizeBar(props: IdealizeBarProps): import("react").JSX.Element;
//# sourceMappingURL=IdealizeBar.d.ts.map