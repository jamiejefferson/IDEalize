/**
 * The project half of the chat title: "in Casa Madrigal" after the chat's
 * name (JJ, 7 Oct 2026, after typing prompts into the wrong chat). Seated on
 * `conversation.session.header.context`; the title's own typography reaches
 * both runs through `data-session-title-part`, and the project is drawn a
 * step smaller than the chat's name, with "in" quieter still. A chat that
 * belongs to no project (Powell's, run from the home folder) says nothing.
 */
import type { PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
export type ProjectContextProps = PropsRuntime<'conversation.session.header.context'> & PropsLocale<'idealize-bar'>;
export declare function ProjectContext({ sessionId, useWorkspaces, t }: ProjectContextProps): import("react").JSX.Element | null;
//# sourceMappingURL=ProjectContext.d.ts.map