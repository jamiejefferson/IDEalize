import type { ChatNodeViewProps } from '@deepseek-ai/dsh-client-ui-conversation/client';
import type { BarKey } from './locales.ts';
import type { CompareNodeData } from './compare-node.ts';
type Translate = (key: BarKey, params?: Record<string, string | number>) => string;
/**
 * The card for one comparison.
 * @param props.sessionId - the chat.
 * @param props.data - the comparison so far.
 * @param props.t - the rail's copy.
 */
export declare function CompareCard({ sessionId, data, t, onClose }: {
    sessionId: string;
    data: CompareNodeData;
    t: Translate;
    /** Shown on a decided card outside the transcript, so the line can be put away. */
    onClose?: (() => void) | undefined;
}): import("react").JSX.Element;
/**
 * The keyed `conversation.chat.node` renderer for `kind: 'router-compare'`, bound to the rail's copy.
 * @param t - the rail's copy.
 * @returns the renderer.
 */
export declare function compareNodeView(t: Translate): ({ node, sessionId }: ChatNodeViewProps<"router-compare">) => import("react").JSX.Element | null;
export {};
//# sourceMappingURL=CompareCard.d.ts.map