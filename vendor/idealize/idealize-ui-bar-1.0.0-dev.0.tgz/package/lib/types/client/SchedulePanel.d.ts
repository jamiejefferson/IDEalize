import type { SessionBinding } from '@deepseek-ai/dsh-client-runtime/client';
import type { ScheduleTranslate, TaskDraft, TaskView } from './schedule-model.ts';
/** Registration-side face (index.ts): workspaces and the chat session the create state seeds. */
export interface SchedulePanelInjected {
    /** Registered project folders, for the SAVE TO row and the default run folder. */
    workspaces: () => {
        name: string;
        path: string;
    }[];
    /** The folder of the current chat (the default for a new task), or undefined without one. */
    currentCwd: () => string | undefined;
    /** Create/find the workspace for a path and bind a session in it (the Create-with-chat session). */
    ensureSession: (path: string) => Promise<SessionBinding | null>;
    /** Close the drawer column. */
    closeDrawer: () => void;
}
/**
 * Save (create or update) one task through the cron service.
 * @returns the saved task, or an error message.
 */
export declare function saveTask(draft: TaskDraft): Promise<{
    ok: true;
    task: TaskView;
} | {
    ok: false;
    error: string;
}>;
/**
 * Render the Schedule pane.
 * @param props.workspaces - registered folders.
 * @param props.currentCwd - the current chat's folder.
 * @param props.ensureSession - session factory for Create-with-chat.
 * @param props.closeDrawer - close the column.
 * @param props.t - the bar namespace's bound translate.
 * @returns the pane element tree.
 */
export declare function SchedulePanel({ workspaces, currentCwd, ensureSession, closeDrawer, t }: SchedulePanelInjected & {
    t: ScheduleTranslate;
}): import("react").JSX.Element;
//# sourceMappingURL=SchedulePanel.d.ts.map