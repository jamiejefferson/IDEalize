import type { PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
export type RatingLineProps = PropsRuntime<'conversation.input.dock'> & PropsLocale<'idealize-bar'>;
export declare function RatingLine(props: RatingLineProps): import("react").JSX.Element;
//# sourceMappingURL=RatingLine.d.ts.map