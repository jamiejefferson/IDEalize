import type { PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
export type HeartButtonProps = PropsRuntime<'conversation.input.right'> & PropsLocale<'idealize-bar'>;
/**
 * The heart drawn at the composer's icon size, or the dislike's broken heart:
 * the same heart cut along a zigzag, each half leaning out from the point.
 */
export declare function HeartIcon({ broken }: {
    broken?: boolean;
}): import("react").JSX.Element;
export declare function HeartButton({ input, sessionId, useSessions, t }: HeartButtonProps): import("react").JSX.Element | null;
export declare function DislikeButton({ input, sessionId, useSessions, t }: HeartButtonProps): import("react").JSX.Element | null;
//# sourceMappingURL=HeartButton.d.ts.map