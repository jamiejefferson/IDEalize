import type { PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
export type HeartButtonProps = PropsRuntime<'conversation.input.right'> & PropsLocale<'idealize-bar'>;
export declare function HeartButton({ input, inputActions, t }: HeartButtonProps): import("react").JSX.Element;
//# sourceMappingURL=HeartButton.d.ts.map