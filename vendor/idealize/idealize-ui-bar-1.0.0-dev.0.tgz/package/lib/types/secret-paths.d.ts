/**
 * Files the app never reads, writes, lists or serves through its own routes,
 * whichever window asks: keys, credentials and shell history. The Files pane
 * browses the whole home folder, so before 1.0.15 its routes returned
 * `~/.ssh/config` and the app's own key store to any caller (security audit,
 * 9 Oct 2026).
 * @module @idealize/ui-bar/secret-paths
 */
/**
 * Whether a resolved path is, or sits inside, a secret location.
 * @param resolved - an absolute, realpath-resolved path.
 * @param home - the home folder.
 * @param dshHome - the app's data folder (the harness home).
 * @returns true when the routes must refuse it.
 */
export declare function isSecretPath(resolved: string, home: string, dshHome: string): boolean;
//# sourceMappingURL=secret-paths.d.ts.map