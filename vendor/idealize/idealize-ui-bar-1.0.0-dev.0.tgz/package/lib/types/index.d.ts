/**
 * @idealize/ui-bar — Host half of the IDEalize toggle bar.
 *
 * Serves the loopback JSON the browser half consumes:
 * - `GET  /idealize/bar/capabilities` — which optional destinations exist here
 *   (the desktop shell's terminal, macOS reveal-in-Finder).
 * - `GET  /idealize/bar/files[?path=]` — workspace file listing; without a
 *   path the workspace roots, with one the entries of a directory FENCED to
 *   the registered workspace roots PLUS the captured workspace-alias folders
 *   (realpath prefix check).
 * - `GET  /idealize/bar/aliases` — the Files pane's three tabs: the current
 *   project (workspace roots), the projects root, and the documentation
 *   vault, each with its live access state so a dead alias keeps its tab and
 *   offers Reconnect.
 * - `GET  /idealize/bar/browse[?path=]` — the second file window's listing:
 *   the home root without a path, a directory's entries with one, FENCED to
 *   home plus the workspace roots plus the alias folders.
 * - `GET  /idealize/bar/file?path=` — file content for the viewer (text as a
 *   JSON envelope, size-capped), same home-plus-roots fence.
 * - `GET  /idealize/bar/raw?path=` — raw image bytes for the viewer's img
 *   tags, image extensions only, same fence.
 * - `POST /idealize/bar/terminal` — open the desktop shell's terminal when
 *   its action service is composed (desktop app only).
 * - `POST /idealize/bar/reveal` — reveal a fenced path in the macOS Finder.
 * - `POST /idealize/bar/write` — overwrite a fenced text file (409 when its size moved).
 * - `POST /idealize/bar/rename`, `/duplicate`, `/move`, `/trash` — the Files
 *   pane's entry operations, every path checked against the viewer fence.
 * - `POST /idealize/bar/create` — create one file or folder inside a fenced
 *   parent directory (home-plus-roots fence; the name is a single validated
 *   path component).
 *
 * Same loopback + `x-idealize-auth` fence as the other /idealize routes.
 * @module @idealize/ui-bar
 */
import type { Context } from '@deepseek-ai/cordis';
export declare function apply(ctx: Context): void;
//# sourceMappingURL=index.d.ts.map