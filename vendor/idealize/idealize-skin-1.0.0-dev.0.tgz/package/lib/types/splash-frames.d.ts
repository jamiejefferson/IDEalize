/**
 * All 42 frames of V0's owl run-cycle (Resources/Owl, downscaled to 190x210,
 * WebP q90), inlined for the boot splash. Regenerated from the V0 repo with PIL.
 */
export declare const OWL_FRAMES: readonly string[];
//# sourceMappingURL=splash-frames.d.ts.map