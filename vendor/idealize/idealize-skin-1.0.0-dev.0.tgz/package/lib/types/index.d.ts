/**
 * @idealize/skin — Host registration for the IDEalize brand token sheet.
 * Transforms the served index like ui-theme's boot script does; the sheet
 * itself lives in ./skin-css.ts.
 * @module @idealize/skin
 */
import type { Context } from '@deepseek-ai/cordis';
export { injectSkin, SKIN_CSS, SKIN_STYLE_ID } from './skin-css.ts';
/** The 42 owl run-cycle frames (190×210 WebP data URIs) the boot splash plays. */
export { OWL_FRAMES as SPLASH_FRAMES } from './splash-frames.ts';
/** The owl at rest: the run cycle's first frame, for still marks such as the Askbar's Studio tile. */
export declare const OWL_FRAME_STILL: string;
/**
 * Register the index transform when the webserver is composed, and stand
 * down upstream's first-run notice (IDEalize owns the first-run moment).
 * @param ctx - Host context that may acquire the HTTP service.
 */
export declare function apply(ctx: Context): void;
//# sourceMappingURL=index.d.ts.map