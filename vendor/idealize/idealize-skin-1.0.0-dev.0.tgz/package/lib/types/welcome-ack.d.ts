/**
 * Pre-acknowledge upstream's "Internal Testing Notice" so IDEalize users
 * never see DeepSeek's developer-testing dialog — the boot splash and the
 * IDEalize identity own the first-run moment. Constants mirror
 * `packages/client/ui-settings-models/src/onboarding-copy.ts` (that module is
 * bundled into the client artifact, so the values are restated here); if
 * upstream bumps the notice version the dialog reappears once and this file
 * follows.
 */
import type { Context } from '@deepseek-ai/cordis';
/**
 * Write the acknowledgement once, only when the user has none stored — a
 * user who later acknowledges a newer notice is never overwritten.
 * @param ctx - Host context that may acquire the settings service.
 */
export declare function suppressUpstreamWelcomeNotice(ctx: Context): void;
//# sourceMappingURL=welcome-ack.d.ts.map