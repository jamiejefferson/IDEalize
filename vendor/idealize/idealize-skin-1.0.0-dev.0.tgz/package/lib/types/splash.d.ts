/**
 * The IDEalize boot splash: V0's owl over the brand ground with the
 * "What shall we make?" wordmark, shown from the first byte of HTML until
 * the client mounts (or a 10-second hard timeout). Pure inline markup —
 * no requests, so it paints before the client bundle even starts loading.
 * The in-app welcome slate (replacing the client's own empty state) is
 * queued client-slot work; this covers the boot moment.
 */
/** The id of the splash root element, which the client removes once it renders. */
export declare const SPLASH_ID = "idealize-splash";
/**
 * Render the boot splash: inline styles, the owl frames, and the script that plays them.
 * @returns the self-contained HTML fragment.
 */
export declare function splashMarkup(): string;
//# sourceMappingURL=splash.d.ts.map