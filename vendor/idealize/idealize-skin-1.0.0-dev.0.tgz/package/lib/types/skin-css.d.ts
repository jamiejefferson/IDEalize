/**
 * The IDEalize brand token sheet. The two palettes are the IDEalize preset's:
 * IDEalize Light (#FFFFFF ground / #1B1F24 ink / #0969DA blue, crisp
 * dividers) and V0's IDEalize Dark (#2A2F35 ground / #D5DDE3 ink / #85C1B4
 * sage). Every
 * derived surface comes from `@idealize/appearance`'s `deriveTokens`, the same
 * derivation the appearance panel lays for the IDEalize preset and for every
 * other preset, so the sheet and the panel's layer carry one token list
 * (`PRESET_TOKEN_KEYS`) with equal values: choosing IDEalize in the panel
 * repaints exactly what this sheet paints, and no other preset leaves a
 * token this sheet set.
 *
 * The sheet redefines those tokens, the code font token, and the
 * `--idealize-type-*` pane type scale, on the same `body` /
 * `body[data-ds-dark-theme]` scopes design-platform.css uses. Injected into
 * the served index after the opening body tag, it follows the head-linked
 * token sheets in document order, so equal-specificity redefinitions here
 * win. The error, warning and success text colours are design-platform's
 * seeds deepened along their hue until they read on each ground.
 */
/** The id of the injected `<style>` element. */
export declare const SKIN_STYLE_ID = "idealize-skin";
/** The brand token sheet's CSS text. */
export declare const SKIN_CSS: string;
/**
 * Insert the skin style block immediately after the opening body tag, after
 * any earlier body-start injections (the ui-theme boot script), so the sheet
 * follows every head-linked token stylesheet in document order.
 * @param html - Raw application index HTML.
 * @returns HTML containing the skin stylesheet.
 */
export declare function injectSkin(html: string): string;
//# sourceMappingURL=skin-css.d.ts.map