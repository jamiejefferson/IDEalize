/**
 * @idealize/askbar — host half of the Askbar (A1 prototype): the roster
 * route the bar renders from, and the transform route that asks the desktop
 * shell to collapse to or expand from the bar.
 *
 * HTTP: `GET /idealize/askbar/roster?project=<folder>&sessions=<id,id>` joins
 * comm's chat listing, the project board's blockers and the Studio fold into
 * chip rows plus the bar's interaction timings; `sessions` names the sidebar's
 * rows in order, and without it every comm chat of the folder is covered.
 * `GET /idealize/askbar/owl.webp` serves the skin's still owl frame for the
 * Studio tile. `POST /idealize/askbar/transform` `{to: 'mini'|'maxi'}` drives
 * the desktop shell's window transform (loopback + `x-idealize-auth: 1`);
 * without a desktop shell it answers 501. Reads are loopback-only.
 *
 * comm and studio are probed, never injected: the roster degrades to an
 * empty listing without comm and to comm-only states without studio, so the
 * bar renders honestly in any composition.
 * @module @idealize/askbar
 */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
export { chipStateOf } from './chip-state.ts';
export type { ChipAttention, ChipBlocker, ChipExecution, ChipStateInput } from './chip-state.ts';
export { portraitOf } from './portrait.ts';
export type { Portrait } from './portrait.ts';
export { assembleChips, assembleGroups, assembleGroupsOf } from './roster.ts';
export type { CommBoardRow, CommListRow } from './roster.ts';
export type { AskbarChip, AskbarConfigWire, AskbarEdge, AskbarRoster, ChipState } from './types.ts';
/** Roster path. */
export declare const ROSTER_PATH = "/idealize/askbar/roster";
/** Transform path. */
export declare const TRANSFORM_PATH = "/idealize/askbar/transform";
/** The still owl (the Studio tile's mark), served as WebP. */
export declare const OWL_PATH = "/idealize/askbar/owl.webp";
/**
 * Hold the bar's window at a width so a panel beside its column is not cut
 * off at the window edge. `POST { width }`; a width at or below the column's
 * own gives the room back.
 */
export declare const WIDTH_PATH = "/idealize/askbar/width";
/**
 * Give the bar's window the keyboard, or hand it back. `POST { focus }`. A
 * revealed panel asks for it so the person can type into the ask field from a
 * rollover (JJ, 14 Sep 2026); a closed panel gives it back so their typing
 * returns to the app they were in. The bar's window is a non-activating
 * panel, so taking the keyboard never brings the app forward.
 */
export declare const FOCUS_PATH = "/idealize/askbar/focus";
export declare const name = "idealize-askbar";
/** Validated Askbar configuration: the bar's docked edge and its interaction timings. */
export interface Config {
    /** Screen edge the Askbar docks to (JJ, 1 Sep 2026: left, configurable). */
    edge: 'left' | 'right';
    /** Hover delay before a chip reveals its destination card, in milliseconds. */
    hoverRevealMs: number;
    /** Pending-send countdown between releasing a hold and dispatch, in milliseconds (JJ, 1 Sep 2026: one second). */
    pendingSendMs: number;
    /** Maxi/mini window transform animation duration, in milliseconds. */
    transformMs: number;
    /** Roster poll interval for the bar renderer, in milliseconds. */
    pollMs: number;
}
export declare const Config: z<Config>;
export declare function apply(ctx: Context, config: Config): void;
//# sourceMappingURL=index.d.ts.map