/**
 * The one way the bar reaches an agent: comm's `send` command, the same path
 * the panel's ask field posts through. Voice and typing share it so a
 * transcript is delivered exactly as a typed message is.
 * @module @idealize/askbar/src/client/send
 */
/**
 * Send one message to a named agent.
 * @param target - the agent's chat id.
 * @param body - what to say.
 * @returns whether comm accepted it.
 */
export declare function sendToAgent(target: string, body: string): Promise<boolean>;
//# sourceMappingURL=send.d.ts.map