/**
 * The Askbar's voice capture: the microphone half of the hold gesture, and the
 * call to the transcription seam.
 *
 * Decoding and resampling happen here because this is a browser: the recorder
 * produces a container the host would need a codec for, and `AudioContext`
 * already holds one. What crosses to the host is mono float samples at
 * whisper's rate, and nothing else.
 *
 * The samples live in this page's memory for the length of one capture. They
 * are never written to disk, so a cancelled or failed capture leaves nothing
 * behind once the page drops it.
 * @module @idealize/askbar/src/client/capture
 */
/** The rate the seam's provider requires; the capture is resampled to it before it is sent. */
export declare const CAPTURE_SAMPLE_RATE = 16000;
/** A capture in progress. */
export interface Capture {
    /**
     * Stop recording and hand back what was captured.
     * @returns the mono samples, resampled to {@link CAPTURE_SAMPLE_RATE}.
     */
    stop(): Promise<Float32Array>;
    /** Stop recording and discard it. Releases the microphone either way. */
    cancel(): void;
}
/** Why a capture could not start. */
export type CaptureRefusal = 'no-microphone' | 'denied' | 'unsupported';
/** A capture that could not start. */
export declare class CaptureError extends Error {
    /** What stopped it. */
    readonly refusal: CaptureRefusal;
    /**
     * @param refusal - what stopped it.
     * @param message - what a person reads.
     */
    constructor(refusal: CaptureRefusal, message: string);
}
/** What the seam answered for one capture. */
export type TranscriptOutcome = {
    kind: 'text';
    text: string;
    confident: boolean;
} | {
    kind: 'refused';
    refusal: string;
    message: string;
};
/** How ready the speech provider is, as the state route reports it. */
export type SpeechReadiness = {
    state: 'ready';
} | {
    state: 'preparing';
    percent: number;
} | {
    state: 'unavailable';
    detail: string;
};
/** What the state route publishes. */
export interface SpeechState {
    /** The registered providers; empty when no speech provider is composed. */
    providers: {
        id: string;
        label: string;
        location: 'on-device' | 'remote';
        model: string;
        sampleRate: number;
    }[];
    /** Readiness of the provider a capture would reach. */
    readiness: SpeechReadiness;
}
/**
 * Open the microphone and start recording.
 * @returns the capture in progress.
 * @throws CaptureError when the browser has no recorder, no device, or the
 *   person declined the microphone.
 */
export declare function startCapture(): Promise<Capture>;
/**
 * Read what the speech provider is and whether it can run.
 * @returns the state, or undefined when the route cannot be reached.
 */
export declare function speechState(): Promise<SpeechState | undefined>;
/**
 * Fetch the model files if they are not here yet.
 * @returns readiness once the attempt settles, or undefined when the route cannot be reached.
 */
export declare function prepareSpeech(): Promise<SpeechReadiness | undefined>;
/**
 * Send one capture to the seam.
 * @param samples - the mono samples at {@link CAPTURE_SAMPLE_RATE}.
 * @returns the transcript, or what the seam refused.
 */
export declare function transcribeCapture(samples: Float32Array): Promise<TranscriptOutcome>;
//# sourceMappingURL=capture.d.ts.map