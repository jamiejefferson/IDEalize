/**
 * The first-use speech notice: whether this person has been told what a hold
 * captures and where it is processed.
 *
 * Kept in this window's storage rather than in settings because it records a
 * notice being read, not a preference the agent or another surface acts on.
 * Cleared storage shows the notice again, which is the safe direction.
 * @module @idealize/askbar/src/client/speech-notice
 */
/** Storage key holding the acknowledgement. */
export declare const SPEECH_NOTICE_KEY = "idealize.askbar.speechNotice";
/**
 * Whether the notice has been read.
 * @returns true once it has been acknowledged in this window's storage.
 */
export declare function speechNoticeSeen(): boolean;
/** Record that the notice has been read. */
export declare function rememberSpeechNotice(): void;
//# sourceMappingURL=speech-notice.d.ts.map