/**
 * The sidebar's persisted row order, read from the browser storage
 * ui-workspace's view store persists to. The floating bar is a second page
 * on the same origin, so it reads the order the expanded sidebar last wrote
 * and shows the rows the way the sidebar does.
 * @module @idealize/askbar/src/client/sidebar-order
 */
import type { SidebarOrder } from './selection.ts';
/** The localStorage key of ui-workspace's view store (`createWorkspaceViewStore`, `persist`). */
export declare const SIDEBAR_VIEW_KEY = "dsh.workspace.view.v5";
/** The subset of `Storage` the read needs, so tests pass a plain object. */
export interface OrderStorage {
    /** `Storage.getItem`. */
    getItem(key: string): string | null;
}
/**
 * The sidebar's persisted view, or an empty one when the store has not
 * persisted yet, the value does not parse, or the page has no storage (a
 * node run of the client tree). A malformed entry is skipped rather than
 * trusted: the value crosses a durable boundary.
 * @param storage - where the view store persists; defaults to the page's localStorage.
 * @returns the order and last-seen activity per account, empty when nothing usable is stored.
 */
export declare function readSidebarOrder(storage?: OrderStorage | undefined): SidebarOrder;
/** The localStorage key of the client runtime's session selection store (`dsh-client-runtime` sessions service). */
export declare const CURRENT_SESSION_KEY = "dsh.sessions.current";
/**
 * The chat the main window has open, as its selection store persisted it.
 * The floating bar's page keeps its own selection from load, so it reads the
 * main window's to show the same New Session row the sidebar shows.
 * @param storage - where the selection store persists; defaults to the page's localStorage.
 * @returns the current session id, or none when nothing usable is stored.
 */
export declare function readCurrentSession(storage?: OrderStorage | undefined): string | undefined;
//# sourceMappingURL=sidebar-order.d.ts.map