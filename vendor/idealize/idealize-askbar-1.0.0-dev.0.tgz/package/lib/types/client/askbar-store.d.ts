/**
 * The bar's read model: one snapshot store fed by polling the roster route
 * for the current selection (project plus the sidebar's session rows), with
 * the host-bridge SSE stream as a hurry-up (any bridge event triggers an
 * immediate refresh, so `agent-finished` and mail land without waiting for
 * the next poll). A new selection refreshes at once; a new project also drops
 * the old roster so the bar never shows another project's agents. The store
 * is the single writer; components read it through `useSyncExternalStore`.
 * @module @idealize/askbar/src/client/askbar-store
 */
import { type SnapshotStore } from '@deepseek-ai/dsh-client-runtime/client';
import type { AskbarRoster } from '../types.ts';
import { type RosterSelection } from './selection.ts';
/** What the bar renders: the selection it follows, the latest roster, or why there is none yet. */
export interface AskbarView {
    /** The project folder the bar follows; '' while no project exists. */
    project: string;
    /** The latest roster for that project; null before the first successful read. */
    roster: AskbarRoster | null;
    /** The latest read failure, cleared by the next success; null while healthy. */
    error: string | null;
}
/** The observable bar view. */
export type AskbarStore = SnapshotStore<AskbarView>;
/** The running store: its view, the selection setter, and the disposer. */
export interface AskbarStoreHandle {
    /** The observable bar view. */
    store: AskbarStore;
    /**
     * Follow another selection; an unchanged one is a no-op.
     * @param next - the project and its sidebar rows.
     */
    select: (next: RosterSelection) => void;
    /** Stop polling and close the stream. */
    stop: () => void;
}
/** What a store's reads ask for beyond the selection itself. */
export interface AskbarStoreOptions {
    /**
     * Ask each read for every project's agents grouped. Both homes ask for it,
     * with the sidebar's rows riding along so the groups cover those rows and
     * no other (JJ, 13 Sep 2026: one set of agents in all three states).
     */
    allProjects?: boolean;
}
/**
 * The roster URL for one selection. An empty project asks for the timings
 * alone (the route serves no chips for it); otherwise the sidebar's rows ride
 * along so the host covers exactly those.
 * @param selection - the project and its sessions.
 * @param allProjects - true to ask for every project's agents grouped as well (the sidebar rail).
 * @returns the roster route with its query.
 */
export declare function rosterUrl(selection: RosterSelection, allProjects?: boolean): string;
/**
 * Create the store and start its poll plus SSE hurry-up.
 * @param initial - the selection the bar starts on.
 * @param options - what the reads ask for beyond the selection.
 * @returns the store, the selection setter, and the disposer.
 */
export declare function startAskbarStore(initial: RosterSelection, options?: AskbarStoreOptions): AskbarStoreHandle;
//# sourceMappingURL=askbar-store.d.ts.map