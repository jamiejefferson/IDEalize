/**
 * @idealize/askbar — browser half: one rail, two homes. In the desktop
 * shell's Askbar window (the `dsh-desktop-mode=askbar` marker) the floating
 * home takes the root slot at priority -1 (single slots render their
 * lowest-priority registrant, the same shadowing the fork uses elsewhere), so
 * the bar replaces the whole app frame. In every other window the in-window
 * home registers into the main sidebar's `sidebar.rail` seat, which the shell
 * renders while the column is collapsed, so the collapsed sidebar and the
 * floating bar show the same rail. Both homes read one store: it polls the
 * roster route for every row the expanded sidebar lists, grouped by project
 * in the sidebar's order, hurries on host-bridge SSE events, and follows the
 * session and workspace stores live. One set of agents in all three states
 * (JJ, 13 Sep 2026): the expanded sidebar is the reference, and a rail in
 * either home shows exactly its rows.
 * @module @idealize/askbar/client
 */
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
export { STATE_LABEL_KEYS } from './Chip.tsx';
export { AskbarRoot } from './AskbarRoot.tsx';
export type { AskbarRootInjected, AskbarRootProps } from './AskbarRoot.tsx';
export { OWL_SRC, Rail } from './Rail.tsx';
export type { RailHome, RailProps } from './Rail.tsx';
export { SidebarRail } from './SidebarRail.tsx';
export type { SidebarRailInjected, SidebarRailProps } from './SidebarRail.tsx';
export { LOOSE_ROWS_KEY, NO_SELECTION, sameSelection, selectEverything, selectRoster } from './selection.ts';
export { CURRENT_SESSION_KEY, readCurrentSession, readSidebarOrder, SIDEBAR_VIEW_KEY } from './sidebar-order.ts';
export type { RosterSelection, SelectionSessionRow, SelectionSessions, SelectionWorkspaces } from './selection.ts';
export { OPEN_STUDIO_EVENT, onStudioRequest, requestStudio } from './studio-request.ts';
export type { AskbarKey } from './locales.ts';
/** Services the bar reads. */
export declare const inject: string[];
/**
 * Register the rail: the floating home when this renderer is the Askbar
 * window, the sidebar home otherwise.
 * @param ctx - browser Cordis context.
 */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map