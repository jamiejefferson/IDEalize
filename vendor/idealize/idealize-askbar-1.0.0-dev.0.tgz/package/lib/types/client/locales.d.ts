/** `idealize-askbar` namespace dictionaries: the rail in both homes, its chips and states, the hold flow, and the compact panel. */
/** Simplified Chinese dictionary (the key-set source of truth). */
export declare const zh: {
    'project.expand': string;
    'project.expandSidebar': string;
    'studio.title': string;
    'newChat.label': string;
    'studio.open': string;
    'studio.openHere': string;
    'agents.label': string;
    'keys.nextAgent': string;
    'keys.previousAgent': string;
    'empty.noProject': string;
    'empty.noAgents': string;
    'error.unreachable': string;
    'state.listening': string;
    'state.working': string;
    'state.needsInput': string;
    'state.wrong': string;
    'state.finished': string;
    'state.finishedDetail': string;
    'state.ready': string;
    'state.idle': string;
    'chip.label': string;
    'hold.listening': string;
    'hold.hint': string;
    'hold.cancel': string;
    'hold.noticeTitle': string;
    'hold.noticeBody': string;
    'hold.noticeAccept': string;
    'hold.transcribing': string;
    'hold.preparing': string;
    'hold.preparingBody': string;
    'hold.sendingTo': string;
    'hold.onItsWay': string;
    'hold.refused': string;
    'hold.dismiss': string;
    'hold.noAudio': string;
    'hold.hostGone': string;
    'panel.label': string;
    'panel.identity': string;
    'panel.latestTask': string;
    'panel.noTask': string;
    'panel.noStatus': string;
    'panel.checkTranscript': string;
    'panel.nothingHeard': string;
    'panel.ask': string;
    'panel.send': string;
    'panel.sending': string;
    'panel.sent': string;
    'panel.retry': string;
    'panel.openStudio': string;
    'panel.recent': string;
    'panel.noRecent': string;
    'panel.you': string;
    'panel.working': string;
    'panel.noAnswer': string;
};
/** Dictionary keys of the `idealize-askbar` namespace. */
export type AskbarKey = keyof typeof zh;
/** English dictionary. */
export declare const en: {
    'project.expand': string;
    'project.expandSidebar': string;
    'studio.title': string;
    'newChat.label': string;
    'studio.open': string;
    'studio.openHere': string;
    'agents.label': string;
    'keys.nextAgent': string;
    'keys.previousAgent': string;
    'empty.noProject': string;
    'empty.noAgents': string;
    'error.unreachable': string;
    'state.listening': string;
    'state.working': string;
    'state.needsInput': string;
    'state.wrong': string;
    'state.finished': string;
    'state.finishedDetail': string;
    'state.ready': string;
    'state.idle': string;
    'chip.label': string;
    'hold.listening': string;
    'hold.hint': string;
    'hold.cancel': string;
    'hold.noticeTitle': string;
    'hold.noticeBody': string;
    'hold.noticeAccept': string;
    'hold.transcribing': string;
    'hold.preparing': string;
    'hold.preparingBody': string;
    'hold.sendingTo': string;
    'hold.onItsWay': string;
    'hold.refused': string;
    'hold.dismiss': string;
    'hold.noAudio': string;
    'hold.hostGone': string;
    'panel.label': string;
    'panel.identity': string;
    'panel.latestTask': string;
    'panel.noTask': string;
    'panel.noStatus': string;
    'panel.checkTranscript': string;
    'panel.nothingHeard': string;
    'panel.ask': string;
    'panel.send': string;
    'panel.sending': string;
    'panel.sent': string;
    'panel.retry': string;
    'panel.openStudio': string;
    'panel.recent': string;
    'panel.noRecent': string;
    'panel.you': string;
    'panel.working': string;
    'panel.noAnswer': string;
};
/** The dictionary namespace this package registers. */
export declare const NS = "idealize-askbar";
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** The Askbar's copy. */
        'idealize-askbar': AskbarKey;
    }
}
//# sourceMappingURL=locales.d.ts.map