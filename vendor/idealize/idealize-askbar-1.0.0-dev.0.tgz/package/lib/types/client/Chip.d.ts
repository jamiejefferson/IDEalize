/**
 * One agent chip: the generated portrait with the state's badge, ring and
 * motion, plus the press-and-hold gesture. The chip owns only the gesture
 * mechanics; what a hold means (pending send, panel) is the root's decision
 * through the callbacks.
 *
 * A chip captions its portrait with the agent's name and its state in words.
 * The faces are generated, so a chip captioned with its state alone named
 * nobody and the bar's agents read as unrelated to the chats in the sidebar
 * (JJ, 11 Sep 2026: "the agents in it bear no relation to the live ones").
 * Both homes are 108px wide and render this identically (JJ, 13 Sep 2026:
 * "the two bars should both be the same").
 * @module @idealize/askbar/src/client/Chip
 */
import React from 'react';
import type { PropsLocale } from '@deepseek-ai/dsh-client-ui-slots';
import type { AskbarChip, ChipState } from '../types.ts';
import type { AskbarKey } from './locales.ts';
/** The dictionary key naming each visual state. */
export declare const STATE_LABEL_KEYS: Record<ChipState, AskbarKey>;
/**
 * A state's words where there is room for a sentence (the panel's head, the
 * chip's accessible name): `finished` adds that the chat is safe to close,
 * which the chip's one-word caption cannot hold.
 * @param state - the visual state.
 * @returns the dictionary key of the state's longer wording.
 */
export declare function stateDetailKey(state: ChipState): AskbarKey;
/** Chip props: the roster row, the bar's locale seat, and the root's gesture callbacks. */
export type ChipProps = PropsLocale<'idealize-askbar'> & {
    /** The roster row this chip renders. */
    chip: AskbarChip;
    /** The project folder, part of the portrait seed. */
    project: string;
    /** The pointer entered this chip (its id) or left every chip (null); the root arms the reveal. */
    onHover?: ((chipId: string | null) => void) | undefined;
    /** True while this chip's hold is capturing (renders the listening state). */
    listening: boolean;
    /** Open the compact panel (click or Enter). */
    onOpen: (chip: AskbarChip) => void;
    /** A hold began on this chip. */
    onHoldStart: (chip: AskbarChip) => void;
    /** The hold ended; `held` is how long the pointer stayed down, in milliseconds. */
    onHoldEnd: (chip: AskbarChip, held: number) => void;
};
/**
 * Render one chip.
 * @param props - the roster row, locale seat and gesture callbacks.
 * @returns the chip button.
 */
export declare function Chip(props: ChipProps): React.JSX.Element;
//# sourceMappingURL=Chip.d.ts.map