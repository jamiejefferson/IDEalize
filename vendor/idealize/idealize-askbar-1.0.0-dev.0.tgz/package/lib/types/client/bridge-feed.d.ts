/**
 * One connection to the host bridge feed per window, shared by every plugin
 * that follows it.
 *
 * The rail, the notifier, the bar and the Schedule pane each opened their own
 * `EventSource` on `/idealize/events/stream`, and three of them read
 * `/idealize/events/recent` first. The host speaks HTTP/1.1 and a browser
 * allows six connections per origin, so three feed streams plus three open
 * Terminal chats filled the pool and every later request queued behind them,
 * a keystroke's POST included.
 *
 * Plugin bundles may not value-import each other's runtime state, so each
 * bundle inlines this module and the copies meet on one `globalThis` slot
 * (the same reason `studio-request` raises a document event).
 * @module @idealize/askbar/src/client/bridge-feed
 */
/** One frame of the feed, as far as this module reads it; followers narrow it further. */
export interface BridgeFeedFrame {
    /** The host's order of events, counting from one. */
    seq: number;
    /** The event kind. */
    kind?: string;
    [field: string]: unknown;
}
/** What a follower holds while attached. */
export interface BridgeFeedAttachment {
    /** The feed's retained tail as it stood when this follower attached, oldest first. */
    tail: readonly BridgeFeedFrame[];
    /** Stop following. The connection closes with its last follower. */
    close(): void;
}
/**
 * Follow the host bridge feed. Events recorded before the call arrive as
 * `tail`; `onEvent` runs for each event after it.
 * @param onEvent - what to run on each new event.
 * @returns the attachment, or undefined when the bridge is absent.
 */
export declare function followBridgeFeed(onEvent: (event: BridgeFeedFrame) => void): Promise<BridgeFeedAttachment | undefined>;
/**
 * Close the window's connection and forget its followers: a window tearing
 * down, or a test isolating itself from the last one.
 */
export declare function closeBridgeFeed(): void;
//# sourceMappingURL=bridge-feed.d.ts.map