/**
 * Which chats the bar shows: the main sidebar's rows for the current project,
 * read from the same two client stores the sidebar reads. Pure, so the rule
 * is testable without a composed runtime.
 * @module @idealize/askbar/src/client/selection
 */
/** The session list fields the selection reads (the client runtime's `SessionListState`, structurally). */
export interface SelectionSessions {
    /** The current session, when one is selected. */
    current: string | undefined;
    /** Host-list order. */
    ids: readonly string[];
    /** One row per session. */
    byId: Readonly<Record<string, SelectionSessionRow | undefined>>;
}
/** The per-session fields the selection reads (`SessionSummary`, structurally). */
export interface SelectionSessionRow {
    /** The session's project folder, when it has one. */
    cwd?: string | undefined;
    /** Subagent children never list. */
    origin?: 'subagent' | undefined;
    /** An empty log. A blank chat is the sidebar's provisional New Session row; a blank terminal is a shell the sidebar lists. */
    blank: boolean;
    /** The host projections the sidebar reads (a merge-extensible map; this package reads the `space` key alone). */
    projectionValues?: Readonly<Record<string, unknown>> | undefined;
    /** Last activity, for the most-recent fallback. */
    updatedAt: number;
}
/** The workspace list fields the selection reads (`WorkspaceListState`, structurally). */
export interface SelectionWorkspaces {
    /** Every workspace in display order. */
    items: readonly {
        workspaceId: string;
        path: string;
        sessionIds: readonly string[];
    }[];
    /** The registry-global archive set. */
    archivedSessionIds: readonly string[];
}
/**
 * The sidebar's persisted view (ui-workspace's view store): the order per
 * account and the activity it last saw, a workspace's rows under its id and
 * the rows outside every workspace under {@link LOOSE_ROWS_KEY}. Read by
 * {@link readSidebarOrder}; an account without an entry keeps its stored order
 * (a workspace) or newest-first order (the loose rows), as the sidebar does.
 */
export interface SidebarOrder {
    /** `manual` keeps the persisted order; `updated` (the default) promotes rows touched since the last sync. */
    orderBy?: 'manual' | 'updated' | undefined;
    /** The persisted row order per account. */
    sessionOrderByAccount?: Readonly<Record<string, readonly string[] | undefined>> | undefined;
    /** Per account, each row's `updatedAt` when the sidebar last synced the order. */
    sessionUpdatedAtByAccount?: Readonly<Record<string, Readonly<Record<string, number | undefined>> | undefined>> | undefined;
}
/** The {@link SidebarOrder} account of the rows outside every workspace (ui-workspace's `UNGROUPED_KEY`). */
export declare const LOOSE_ROWS_KEY = "";
/** The rows a group shows before its "Show n more" control (ui-workspace's `COLLAPSED_SESSION_LIMIT`). */
export declare const GROUP_ROW_LIMIT = 5;
/** The bar's read key: the project folder and the sessions it shows, in sidebar order. */
export interface RosterSelection {
    /** The project folder, or '' when no project exists yet. */
    project: string;
    /** The visible sessions of that project, in the sidebar's order. */
    sessionIds: readonly string[];
}
/** The bar's explicit empty state. */
export declare const NO_SELECTION: RosterSelection;
/**
 * Pick the project the bar follows and its visible sessions.
 *
 * The project is the current session's workspace; without a current session,
 * the workspace of the most recently touched session; without any, the first
 * workspace. A current session outside every workspace (the sidebar's
 * Ungrouped bucket) shows the ungrouped sessions sharing its folder.
 * @param sessions - the client runtime's session list snapshot.
 * @param workspaces - the client runtime's workspace list snapshot.
 * @returns the project and its sessions, or {@link NO_SELECTION} when no project exists yet.
 */
export declare function selectRoster(sessions: SelectionSessions, workspaces: SelectionWorkspaces): RosterSelection;
/**
 * Every row the expanded sidebar shows, in its order: each project's first
 * {@link GROUP_ROW_LIMIT} rows in the order the sidebar renders for that
 * project, then the first {@link GROUP_ROW_LIMIT} rows outside every project.
 * The rendered order is the persisted one with the sidebar's own promotion
 * applied: under `updated` ordering a row touched since the sidebar last
 * synced moves to the front, newest first, which is what the sidebar does the
 * moment it mounts. The project is the one {@link selectRoster} would follow,
 * which the panel and the Studio request still name as context.
 *
 * Both rails read this, so the collapsed sidebar, the floating bar and the
 * expanded sidebar show one set of agents (JJ, 13 Sep 2026: "the agents that
 * show in the three sidebar states are all still different").
 * @param sessions - the client runtime's session list snapshot.
 * @param workspaces - the client runtime's workspace list snapshot.
 * @param view - the sidebar's persisted view.
 * @returns the current project with the rows the sidebar shows, or {@link NO_SELECTION} when no project exists yet.
 */
export declare function selectEverything(sessions: SelectionSessions, workspaces: SelectionWorkspaces, view?: SidebarOrder): RosterSelection;
/**
 * Whether two selections read the same roster.
 * @param a - one selection.
 * @param b - the other.
 * @returns true when the project and the session list match.
 */
export declare function sameSelection(a: RosterSelection, b: RosterSelection): boolean;
//# sourceMappingURL=selection.d.ts.map