/**
 * The rail: the bar body both homes render — the Studio entry, then one chip
 * per agent in a scrolling column (overflow scrolls; nothing pops out), plus
 * the hold / pending-send flow, the compact panel and the keyboard path
 * (arrows move between chips, Enter opens the panel, Escape closes or
 * discards). The home decides what the project cell and the Studio entry do
 * (`onOpenMain`) and, in the sidebar, what a chip click does (`onOpenChip`);
 * a hold reaches the panel in both homes, since its ask field posts to the
 * agent from anywhere.
 *
 * The two homes differ above the chips. The floating bar presides with its own
 * brand mark and New chat, which the sidebar column carries above the seat,
 * so the rail there starts at the Studio. Below that both homes are the same
 * column: every project's agents in the sidebar's order, one group per
 * project under a rule that carries no title (JJ, 10 Sep 2026). Hovering a
 * chip reveals its panel after `hoverRevealMs`.
 * @module @idealize/askbar/src/client/Rail
 */
import React from 'react';
import type { PropsLocale } from '@deepseek-ai/dsh-client-ui-slots';
import type { AskbarChip } from '../types.ts';
import type { AskbarView } from './askbar-store.ts';
/** Where the rail renders: the floating Askbar window, or the main window's collapsed sidebar. */
export type RailHome = 'floating' | 'sidebar';
/** Rail props: the bar view, its home, the home's callbacks and the locale seat. */
export type RailProps = PropsLocale<'idealize-askbar'> & {
    /** The bar view to render (project, roster, error). */
    view: AskbarView;
    /** The home; the sidebar home lays the rail out for a 36px column. */
    home: RailHome;
    /**
     * What the project cell (no argument), the Studio entry plus the panel foot
     * (`'studio'`) and the bar's New chat (`'new'`) do: the floating home grows
     * back to the main window, the sidebar home expands the column or opens the
     * Studio chat in place. Only the floating home ever sends `'new'`: the
     * sidebar carries its own New-chat control above this seat.
     */
    onOpenMain: (open?: 'studio' | 'new') => void;
    /** When set, a chip click (or Enter) runs this in place of opening the panel; a hold still reaches the panel. */
    onOpenChip?: ((chip: AskbarChip) => void) | undefined;
    /**
     * Called whenever a panel appears or goes. The floating home makes room for
     * it in its window; the sidebar home has room already. Must be referentially
     * stable, since the rail reports through an effect.
     */
    onPanelChange?: ((showing: boolean) => void) | undefined;
};
/** The still owl the Studio tile shows (served by the host half from the skin). */
export declare const OWL_SRC = "/idealize/askbar/owl.webp";
/** How long the pointer may be off both chip and panel before an unlocked panel closes. */
export declare const PANEL_LEAVE_GRACE_MS = 250;
/**
 * Render the rail.
 * @param props - the view, home, callbacks and locale seat.
 * @returns the rail column.
 */
export declare function Rail(props: RailProps): React.JSX.Element;
//# sourceMappingURL=Rail.d.ts.map