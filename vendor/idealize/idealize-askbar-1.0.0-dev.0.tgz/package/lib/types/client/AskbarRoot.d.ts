/**
 * The floating home: the Askbar window's whole surface. The root owns what
 * only a separate window needs — the drag region (the bar's background is the
 * window's handle; every control opts out, so a drag never starts on a chip)
 * and the transform back to the main window — and renders the shared `Rail`
 * inside it.
 * @module @idealize/askbar/src/client/AskbarRoot
 */
import React from 'react';
import type { PropsLocale } from '@deepseek-ai/dsh-client-ui-slots';
import type { AskbarStore } from './askbar-store.ts';
export { OWL_SRC } from './Rail.tsx';
/**
 * The bar's own window width (`ASKBAR_WIDTH` in dsh-plugin-desktop, and
 * `.bar` in this package's sheet; restated because neither is importable
 * here).
 */
export declare const BAR_WINDOW_WIDTH = 108;
/** The window width while a panel shows: the column, an 8px gap, the 300px panel, and 4px clear of the far edge. */
export declare const PANEL_WINDOW_WIDTH: number;
/** What the slot registration hands the root. */
export interface AskbarRootInjected {
    /** The observable bar view (the project it follows rides in the view). */
    store: AskbarStore;
}
/** Root props: the injected store plus the bar's locale seat. */
export type AskbarRootProps = AskbarRootInjected & PropsLocale<'idealize-askbar'>;
/**
 * Render the floating bar.
 * @param props - the injected store and locale seat.
 * @returns the dock column.
 */
export declare function AskbarRoot(props: AskbarRootProps): React.JSX.Element;
//# sourceMappingURL=AskbarRoot.d.ts.map