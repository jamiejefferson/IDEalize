/**
 * The compact panel: the design spec's six elements — agent and project,
 * latest task, response summary, the chat's recent exchanges (JJ, 14 Sep
 * 2026: "do something useful with the large blank space"), one ask field,
 * and the way into the Studio — plus the pending-send progress strip a
 * completed hold shows. The exchanges come
 * from comm's `transcript` command and refresh while the panel is open, so an
 * ask sent from the bar shows its answer where it was asked.
 * @module @idealize/askbar/src/client/Panel
 */
import React from 'react';
import type { PropsLocale } from '@deepseek-ai/dsh-client-ui-slots';
import type { AskbarChip, AskbarEdge } from '../types.ts';
/** Panel props: the chip it details, the bar's locale seat, and the root's callbacks. */
export type PanelProps = PropsLocale<'idealize-askbar'> & {
    /** The chip the panel details. */
    chip: AskbarChip;
    /** The project folder (identity header and portrait seed). */
    project: string;
    /** The bar's docked edge; the panel opens on its inner side. */
    edge: AskbarEdge;
    /** True when a hold opened the panel, so the note explains why the words are here rather than sent. */
    fromHold: boolean;
    /** Text the panel opens holding: a transcript nobody has read, or one whose delivery was refused. */
    initialDraft: string;
    /** Close the panel. */
    onClose: () => void;
    /** Expand to the main window and open the Studio there. */
    onExpand: () => void;
    /** The pointer entered (true) or left (false) the panel; a rollover's panel stays while it is over it. */
    onHover?: ((over: boolean) => void) | undefined;
};
/** One question-and-answer pair as comm's `transcript` command folds it. */
export interface PanelExchange {
    /** 1-based position in the chat. */
    index: number;
    /** What the person asked. */
    question: string;
    /** The agent's reply so far; absent while the agent has not answered. */
    answer?: string | undefined;
}
/** How many exchanges the panel shows, newest last. */
export declare const RECENT_EXCHANGES = 4;
/** How often the open panel re-reads the transcript, so an answer lands where it was asked. */
export declare const RECENT_REFRESH_MS = 3000;
/**
 * Render the compact panel for one chip.
 * @param props - the chip, locale seat and callbacks.
 * @returns the panel card.
 */
export declare function Panel(props: PanelProps): React.JSX.Element;
//# sourceMappingURL=Panel.d.ts.map