/**
 * Generated kaomoji agent portraits (design spec, decided 1 Sep 2026:
 * Option A). A portrait is rendered from a deterministic seed of project plus
 * agent name, so the same agent shows the same face everywhere and no image
 * asset is ever stored. The seed picks eyes, mouth and bracket shape, each
 * from a small fixed set, plus a pastel fill for the chip behind the face.
 * @module @idealize/askbar/src/portrait
 */
/** One rendered portrait: the face text and its chip colours. */
export interface Portrait {
    /** The kaomoji face, e.g. `[o_o]`, rendered in a mono font. */
    face: string;
    /** Chip background fill. */
    fill: string;
    /** Chip border colour. */
    border: string;
    /** Face ink colour. */
    ink: string;
}
/**
 * Render the portrait for one agent.
 * @param project - the resolved project folder (part of the seed, so pools that reuse a name across projects still differ).
 * @param name - the agent's name.
 * @returns the deterministic face and chip colours for this agent.
 */
export declare function portraitOf(project: string, name: string): Portrait;
//# sourceMappingURL=portrait.d.ts.map