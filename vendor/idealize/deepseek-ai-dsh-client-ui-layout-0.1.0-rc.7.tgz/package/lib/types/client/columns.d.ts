/**
 * Pure concession-chain column solver for the three-column AppFrame.
 * Chain order is fixed by contract: keep center >= CENTER_MIN by shrinking
 * details, then auto-closing it, then dropping the sidebar to its compact
 * rail while an open deck/drawer presses (both derived — preferred width
 * preferences are never rewritten, so widening the window or closing the
 * panel restores them). Without an open deck/drawer the sidebar never
 * concedes, and center absorbs any remaining deficit as the last resort.
 * Inputs are the layout store's plain width preferences (0 = closed); a
 * closed sidebar resolves to the fixed SIDEBAR_COLLAPSED control rail while
 * closed details resolve to zero width. The SIDEBAR_AUTO_COLLAPSE breakpoint
 * is consumed by AppFrame, which decides the effective sidebar preference
 * before solving; the solver itself stays breakpoint-free.
 */
/** Resolved widths for one frame; center may drop below CENTER_MIN only at the final fallback. */
export interface Columns {
    sidebar: number;
    center: number;
    details: number;
    deck: number;
    drawer: number;
}
/**
 * Center column floor; only the final fallback may go below it. 480 keeps
 * the composer usable; at the desktop app's default 1280-wide window the
 * drawer drags between its 320 floor and 696 (the sidebar concedes to its
 * rail once 280 + drawer + 480 no longer fit beside the 48px tool rail).
 */
export declare const CENTER_MIN = 480;
/** Sidebar drag clamp floor. */
export declare const SIDEBAR_MIN = 264;
/** Sidebar drag clamp ceiling. */
export declare const SIDEBAR_MAX = 420;
/** Sidebar width before any user drag. */
export declare const SIDEBAR_DEFAULT = 280;
/**
 * Closed-sidebar rail. IDEalize fork (JJ, 13 Sep 2026): 108px, not the 56px
 * an icon column needs, because the rail carries `@idealize/askbar`'s agent
 * chips and must read the same as the floating bar ("the two bars should both
 * be the same"). `ASKBAR_WIDTH` in dsh-plugin-desktop holds the same number.
 */
export declare const SIDEBAR_COLLAPSED = 108;
/** Viewport width below which the sidebar auto-collapses to the rail (deepsuite
 * LG breakpoint); a manual toggle below it re-expands over the squeezed center
 * (stores.ts narrowExpanded). */
export declare const SIDEBAR_AUTO_COLLAPSE = 1024;
/** Details drag clamp floor. */
export declare const DETAILS_MIN = 300;
/** Details drag clamp ceiling. */
export declare const DETAILS_MAX = 520;
/** Details width before any user drag. */
export declare const DETAILS_DEFAULT = 360;
/** Drawer concession floor. */
export declare const DRAWER_MIN = 320;
/** Drawer drag clamp ceiling. */
export declare const DRAWER_MAX = 720;
/** Drawer width when opened. */
export declare const DRAWER_DEFAULT = 420;
/** Deck (document panel) concession floor. */
export declare const DECK_MIN = 360;
/** Deck drag clamp ceiling. */
export declare const DECK_MAX = 960;
/** Deck width when opened. */
export declare const DECK_DEFAULT = 560;
/**
 * Clamp a panel width into its contract range.
 * @param px - requested width.
 * @param min - range lower bound.
 * @param max - range upper bound.
 * @returns the clamped width.
 */
export declare function clampWidth(px: number, min: number, max: number): number;
/**
 * Solve the three column widths for one viewport frame. Pure: no hysteresis —
 * the output is a function of (viewport, preferences) only, so recovery on
 * re-widening is automatic. Preferences re-clamp here because they cross the
 * store boundary and callers may still supply stale ranges.
 * @param viewport - available frame width in px.
 * @param sidebar - sidebar width preference in px (0 = closed).
 * @param details - details width preference in px (0 = closed).
 * @param drawer - drawer width preference in px (0 = closed).
 * @param deck - deck (document panel) width preference in px (0 = closed).
 * @returns resolved widths; details 0 means visually closed (never unmounted), while a closed sidebar keeps its compact rail.
 */
export declare function computeColumns(viewport: number, sidebar: number, details: number, drawer?: number, deck?: number): Columns;
//# sourceMappingURL=columns.d.ts.map