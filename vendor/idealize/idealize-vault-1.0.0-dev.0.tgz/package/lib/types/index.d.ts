/**
 * @idealize/vault — commit-evidence documentation over the canonical
 * structure `@idealize/doc-policy` owns.
 *
 * The documentation folder, scaffold, conventions, and session-start context
 * injection live in `ctx.docPolicy`; this plugin keeps the write side:
 *
 * - on `session/flush` (throttled), finds the project note whose `repo:`
 *   matches the session's git toplevel and appends commit evidence since the
 *   note's own `last_touched`, advancing the date — no commits, no write, and
 *   failures are logged, never thrown into session teardown; a successful
 *   append triggers a docPolicy rescan so the index stays fresh (DOC-06);
 * - serves `GET /idealize/vault/reconcile` (loopback only): notes whose repos
 *   moved ahead of them.
 *
 * Settings section `idealize-vault` keeps the projects root (`projectsRoot`);
 * the documentation folder is docPolicy's `idealize-docs` section.
 *
 * @module @idealize/vault
 */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
export { appendSessionLog, commitsSince, reconcile } from './notes.ts';
export type { CommitLine, StaleNote } from './notes.ts';
export declare const name = "idealize-vault";
export declare const inject: string[];
/** Plugin config, mirrored by the `idealize-vault` settings section. */
export interface VaultConfig {
    /** Absolute directory the vault's per-project folders live under. */
    projectsRoot?: string;
}
export declare const Config: z<VaultConfig>;
export declare function apply(ctx: Context, config: VaultConfig): void;
//# sourceMappingURL=index.d.ts.map