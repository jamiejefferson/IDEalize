/**
 * @idealize/vault — commit-evidence documentation over the canonical
 * structure `@idealize/doc-policy` owns.
 *
 * The documentation folder, scaffold, conventions, and session-start context
 * injection live in `ctx.docPolicy`; this plugin keeps the write side:
 *
 * - on `session/flush` (throttled), finds the project note whose `repo:`
 *   matches the session's git toplevel and appends commit evidence since the
 *   note's own `last_touched` to the project's `log.md`, advancing the note's
 *   date — no commits, no write, and
 *   failures are logged, never thrown into session teardown; a successful
 *   append triggers a docPolicy rescan so the index stays fresh (DOC-06);
 * - on the same flush, compares the repository's uncommitted files with the
 *   reading taken when the chat was first seen, and keeps one line in `log.md`
 *   for a chat that changed files and committed nothing (`./uncommitted.ts`);
 * - on the same flush, rewrites the chat's Markdown copy under the project
 *   note's folder (`sessions/`), so the conversation outlives the app's own log
 *   and any model can be handed it (`sessionFiles`, on unless switched off);
 * - serves `GET` and `POST /idealize/vault/settings` (loopback only): the
 *   `sessionFiles` switch the Files panel's documentation views show;
 * - serves `GET /idealize/vault/reconcile` (loopback only): notes whose repos
 *   moved ahead of them;
 * - serves `POST /idealize/vault/migrate-log` (loopback only): moves one
 *   note's legacy `## Session log` section into its `log.md`, when a person asks.
 *
 * Settings section `idealize-vault` keeps the projects root (`projectsRoot`);
 * the documentation folder is docPolicy's `idealize-docs` section.
 *
 * @module @idealize/vault
 */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
export { appendSessionLog, commitsSince, migrateSessionLog, quotedSubject, reconcile } from './notes.ts';
export type { CommitLine, LogMigration, StaleNote } from './notes.ts';
export { LEGACY_LOG_HEADING, LEGACY_LOG_POINTER, addToLog, legacyLog, logPathFor, newLog, readLog } from './log.ts';
export type { LegacyLog } from './log.ts';
export { UNCOMMITTED_MARK, changedSince, recordUncommitted, uncommittedLine, workingState } from './uncommitted.ts';
export type { UncommittedEntry, WorkingState } from './uncommitted.ts';
export { SESSIONS_DIR, transcriptOf, transcriptTail, writeTranscript } from './transcript.ts';
export type { TranscriptInput, TranscriptMessage } from './transcript.ts';
export declare const name = "idealize-vault";
export declare const inject: string[];
/** Plugin config, mirrored by the `idealize-vault` settings section. */
export interface VaultConfig {
    /** Absolute directory the vault's per-project folders live under. */
    projectsRoot?: string;
    /** Keep a Markdown copy of each chat in its project's documentation folder. */
    sessionFiles?: boolean;
}
export declare const Config: z<VaultConfig>;
export declare function apply(ctx: Context, config: VaultConfig): void;
//# sourceMappingURL=index.d.ts.map