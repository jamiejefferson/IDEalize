/**
 * A chat as a Markdown file in the project's documentation folder: what the
 * person said and what each model answered, in order, in a form any model or
 * any person can read. It is the conversation's copy outside the app. The
 * app's own log stays the source the app reads; this file is rewritten whole
 * from it on each save, so it is never more than one save behind and never
 * merged by hand.
 *
 * Tool output and file contents are left out: they are the bulk of a working
 * chat and would bury the conversation. A tool call keeps one line.
 */
export declare const SESSIONS_DIR = "sessions";
/** One content block, as far as the transcript reads it. */
interface Block {
    type: string;
    text?: string;
    name?: string;
}
/** One message of the chat's derived history, as far as the transcript reads it. */
export interface TranscriptMessage {
    role: 'user' | 'assistant';
    content: readonly Block[];
    source: {
        kind: string;
        provider?: string;
        model?: string;
    };
}
export interface TranscriptInput {
    sessionId: string;
    title?: string | undefined;
    /** ISO time the chat began. */
    started: string;
    project: string;
    brain?: string | undefined;
    messages: readonly TranscriptMessage[];
}
/**
 * The chat as Markdown.
 * @param input - the chat's identity and its derived messages.
 * @returns the file's text, or undefined while the person has said nothing.
 */
export declare function transcriptOf(input: TranscriptInput): string | undefined;
/**
 * Write one chat's file. The name carries the date, the title and the end of
 * the chat's id. The id finds the file again, so the name follows the title:
 * the app titles a chat from its first words and again once a model names it,
 * and the file a person looks for is the one named as the sidebar names it.
 * @param projectFolder - the project's folder in the documentation.
 * @param input - the chat.
 * @returns the path written, or undefined when there was nothing to write.
 */
export declare function writeTranscript(projectFolder: string, input: TranscriptInput): Promise<string | undefined>;
export {};
//# sourceMappingURL=transcript.d.ts.map