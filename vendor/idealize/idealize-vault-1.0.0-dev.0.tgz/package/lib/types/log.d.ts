/**
 * A project's session log as its own file: `log.md` beside the project's
 * `_index.md`, with one `## YYYY-MM-DD` heading per day and one line per
 * entry. The index stays short enough to hand to a chat whole, and the log
 * can grow without limit.
 *
 * Every function here edits text by inserting lines. Nothing already in a log
 * is rewritten or reordered, so a line a person added by hand stays where they
 * put it.
 */
/** The heading a project index once kept its log under. */
export declare const LEGACY_LOG_HEADING = "## Session log";
/** What a migrated index keeps under that heading. */
export declare const LEGACY_LOG_POINTER = "The session log is in [log.md](log.md).";
/**
 * The log file that belongs to a project index.
 * @param notePath - the project's `_index.md`.
 * @returns the path of `log.md` in the same folder.
 */
export declare function logPathFor(notePath: string): string;
/**
 * A log file's text, when the file exists.
 * @param path - the log file.
 * @returns its text, or `undefined` when there is no such file.
 */
export declare function readLog(path: string): Promise<string | undefined>;
/**
 * The text a new log file opens with.
 * @param notePath - the project's `_index.md`, which names the project.
 * @param index - the index's text.
 * @param created - the ISO date the log is created on.
 * @returns frontmatter (`type: log`, `project`, `created`), a title and one line saying who writes the file.
 */
export declare function newLog(notePath: string, index: string, created: string): string;
/**
 * Add lines under a heading of a log, creating the heading when the log has
 * none of that name. A new `## YYYY-MM-DD` heading goes before the first later
 * day, so days stay in order; any other new heading goes at the end.
 * @param log - the log's text.
 * @param heading - the heading's text without `## `: a day, or a name such as `Undated`.
 * @param lines - the lines to add, in order.
 * @returns the log with the lines added at the end of that heading's section.
 */
export declare function addToLog(log: string, heading: string, lines: readonly string[]): string;
/** A project index's legacy log section, located in the index's lines. */
export interface LegacyLog {
    /** The index's lines. */
    rows: string[];
    /** The line the `## Session log` heading is on. */
    start: number;
    /** The line after the section's last. */
    end: number;
    /** The section's list items: the log's lines. */
    entries: string[];
    /** The section's other lines that a person wrote, which stay in the index. */
    prose: string[];
}
/**
 * Find the `## Session log` section of a project index.
 * @param index - the index's text.
 * @returns the section, or `undefined` when the index has none.
 */
export declare function legacyLog(index: string): LegacyLog | undefined;
//# sourceMappingURL=log.d.ts.map