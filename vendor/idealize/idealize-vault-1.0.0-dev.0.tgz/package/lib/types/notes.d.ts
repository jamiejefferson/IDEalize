/**
 * Vault commit-evidence mechanics: the session log append (into the project's
 * `log.md`, see `./log.ts`), the opt-in move of a legacy log section, and the
 * staleness reconcile, built on the project-note lookups `@idealize/doc-policy` owns.
 * Pure filesystem + git functions so the plugin body stays a thin listener.
 *
 * Contract carried over from V0's session-close hook: writes happen only on
 * commit evidence, the backfill window starts at the note's own
 * `last_touched`, commits already present in the note or its log are never re-appended,
 * and failures are reported to the caller's logger — never thrown into
 * session teardown.
 */
import type { ProjectNote } from '@idealize/doc-policy';
/** One appended commit line. */
export interface CommitLine {
    hash: string;
    date: string;
    subject: string;
}
/**
 * Commits in one repo since a date (exclusive of merges), oldest first.
 * @param repo - repository toplevel.
 * @param sinceDate - inclusive ISO start date, or `undefined` for all history.
 * @returns parsed commit lines.
 */
export declare function commitsSince(repo: string, sinceDate: string | undefined): Promise<CommitLine[]>;
/**
 * A commit subject as quoted text. Anyone who can commit to a repository writes
 * these, and the note they land in reaches every chat in that project, so a
 * subject has to read as a record of what someone wrote and cannot open a new
 * line or a heading of its own.
 * @param subject - the subject as git reports it.
 * @returns the subject in double quotes, on one line.
 */
export declare function quotedSubject(subject: string): string;
/**
 * Append commit evidence to a project's `log.md`, beside the note, and advance
 * the note's `last_touched`. Each commit is one line under the heading of its
 * day, with the short hash first. A commit whose hash already appears in the
 * log or anywhere in the note (a legacy `## Session log` section included) is
 * skipped, and with nothing new both files are left byte-identical (the
 * no-evidence-no-write rule). The log is created on the first entry. The note
 * changes only in its `last_touched` line.
 * @param note - the target project note.
 * @param commits - candidate commits, oldest first.
 * @param today - ISO date stamped into `last_touched`, and into a new log's `created`.
 * @returns the commits actually appended.
 */
export declare function appendSessionLog(note: ProjectNote, commits: CommitLine[], today: string): Promise<CommitLine[]>;
/** What {@link migrateSessionLog} did. */
export interface LogMigration {
    /** How many lines moved out of the note. */
    moved: number;
    /** The log file the lines are in. */
    log: string;
}
/**
 * Move a note's legacy `## Session log` section into the project's `log.md`,
 * leaving the heading with a link to the log. The section's list items are
 * the log: a dated one (`- YYYY-MM-DD …`) goes under its day, any other under
 * `## Undated`, word for word. An item whose commit hash the log already holds
 * is dropped from the note and not added twice. Other lines a person wrote in
 * the section stay in the note, above the link; the two lines the template
 * shipped there are removed. A note with no such section, or with no list
 * items in it, is left byte-identical. This runs only when a person asks for it.
 * @param notePath - the project's `_index.md`.
 * @param today - ISO date stamped into a new log's `created`.
 * @returns how many lines moved, and where to.
 */
export declare function migrateSessionLog(notePath: string, today: string): Promise<LogMigration>;
/** One reconcile row: a note whose repo moved ahead of it. */
export interface StaleNote {
    note: string;
    repo: string;
    lastTouched: string | undefined;
    commitsBehind: number;
}
/**
 * Notes-vs-repos staleness: notes whose repos hold commits after `last_touched`.
 * @param folder - absolute path of the documentation folder.
 * @returns stale notes; `commitsBehind: -1` marks an unreadable repo pointer.
 */
export declare function reconcile(folder: string): Promise<StaleNote[]>;
//# sourceMappingURL=notes.d.ts.map