/**
 * Vault commit-evidence mechanics: the session log append and the staleness
 * reconcile, built on the project-note lookups `@idealize/doc-policy` owns.
 * Pure filesystem + git functions so the plugin body stays a thin listener.
 *
 * Contract carried over from V0's session-close hook: writes happen only on
 * commit evidence, the backfill window starts at the note's own
 * `last_touched`, commits already present in the note are never re-appended,
 * and failures are reported to the caller's logger — never thrown into
 * session teardown.
 */
import type { ProjectNote } from '@idealize/doc-policy';
/** One appended commit line. */
export interface CommitLine {
    hash: string;
    date: string;
    subject: string;
}
/**
 * Commits in one repo since a date (exclusive of merges), oldest first.
 * @param repo - repository toplevel.
 * @param sinceDate - inclusive ISO start date, or `undefined` for all history.
 * @returns parsed commit lines.
 */
export declare function commitsSince(repo: string, sinceDate: string | undefined): Promise<CommitLine[]>;
/**
 * Append commit evidence to one note's session log and advance
 * `last_touched`. Returns the commits actually appended: commits whose hash
 * already appears anywhere in the note are skipped, and with nothing new the
 * note is left byte-identical (the no-evidence-no-write rule).
 * @param note - the target project note.
 * @param commits - candidate commits, oldest first.
 * @param today - ISO date stamped into `last_touched` on a write.
 * @returns the commits actually appended.
 */
export declare function appendSessionLog(note: ProjectNote, commits: CommitLine[], today: string): Promise<CommitLine[]>;
/** One reconcile row: a note whose repo moved ahead of it. */
export interface StaleNote {
    note: string;
    repo: string;
    lastTouched: string | undefined;
    commitsBehind: number;
}
/**
 * Notes-vs-repos staleness: notes whose repos hold commits after `last_touched`.
 * @param folder - absolute path of the documentation folder.
 * @returns stale notes; `commitsBehind: -1` marks an unreadable repo pointer.
 */
export declare function reconcile(folder: string): Promise<StaleNote[]>;
//# sourceMappingURL=notes.d.ts.map