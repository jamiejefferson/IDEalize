/**
 * Vault scaffolding after the ajjent-vault blueprint: Projects/ People/
 * Decisions/ Reference/ templates/ plus CONVENTIONS.md and AGENTS.md.
 * Scaffolding is additive and idempotent — an existing file is never
 * overwritten, so adopting a live vault is safe.
 */
/** Directories every vault carries. */
export declare const VAULT_DIRS: readonly ["Projects", "People", "Decisions", "Reference", "templates"];
/** Create the vault structure; existing files and directories are kept. */
export declare function scaffoldVault(vaultPath: string): Promise<string[]>;
/** Instantiate the project template for one repo. */
export declare function projectNoteFor(name: string, repo: string, date: string): string;
//# sourceMappingURL=scaffold.d.ts.map