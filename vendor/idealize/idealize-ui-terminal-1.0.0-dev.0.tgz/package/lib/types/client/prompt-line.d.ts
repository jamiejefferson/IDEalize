/**
 * Reads typed lines back out of a terminal's keystrokes, so a terminal chat
 * can be named from the first prompt typed into it (JJ, 7 Oct 2026). The
 * keystrokes are xterm's `onData` stream: printable text, Backspace (DEL or
 * BS), Ctrl-U, escape sequences (arrows, bracketed-paste markers) and Enter
 * (CR). Cursor movement inside the line is not followed, so an edited line
 * reads as typed in order; good enough for a name, never shown as the prompt.
 */
/** Keystroke-to-line reader for one terminal. */
export declare class PromptLines {
    private line;
    /** The line typed so far and not yet sent with Enter; empty when there is none. */
    get draft(): string;
    /**
     * Feed one `onData` chunk.
     * @param data - the keystrokes.
     * @returns each line completed by Enter in this chunk, trimmed, in order.
     */
    push(data: string): string[];
}
/**
 * Whether a typed line reads like a prompt worth naming a chat after: three
 * words or more, so `ls`, `y` and a slash command pass by.
 * @param line - one typed line.
 * @returns whether to name the chat from it.
 */
export declare function namesAChat(line: string): boolean;
//# sourceMappingURL=prompt-line.d.ts.map