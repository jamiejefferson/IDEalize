/** `idealize-terminal` namespace dictionaries: the terminal view. */
/** Simplified Chinese dictionary (the key-set source of truth). */
export declare const zh: {
    readonly 'view.terminal': "终端";
    readonly 'terminal.connecting': "正在打开终端…";
    readonly 'terminal.exited': "终端已退出。";
    readonly 'terminal.restart': "再开一个";
    readonly 'terminal.error': "无法打开终端";
};
/** English dictionary. */
export declare const en: Record<TerminalKey, string>;
/** Keys of this plugin's dictionary. */
export type TerminalKey = keyof typeof zh;
/** Dictionary namespace owned by this plugin. */
export declare const NS = "idealize-terminal";
//# sourceMappingURL=locales.d.ts.map