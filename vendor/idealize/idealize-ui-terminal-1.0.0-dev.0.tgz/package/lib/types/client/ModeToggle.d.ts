/** The view ids the capsule moves between. */
export declare const CHAT_VIEW = "chat";
export declare const TERMINAL_VIEW = "terminal";
/** Next view for a toggle from the given one (anything other than the terminal reads as chat). */
export declare function toggledView(current: string | null | undefined): string;
/** True for V0's shortcut: ⌘J on macOS, Ctrl+J elsewhere; never with Shift/Alt. */
export declare function isToggleShortcut(event: Pick<KeyboardEvent, 'key' | 'metaKey' | 'ctrlKey' | 'altKey' | 'shiftKey'>): boolean;
/** Props the capsule reads: the chat store's view plus its writer. */
export interface ModeToggleProps {
    useStore: <T>(selector: (state: {
        view: string | null;
    }) => T) => T;
    actions: {
        setView: (view: string) => void;
    };
    t: (key: 'toggle.chat' | 'toggle.terminal' | 'toggle.label') => string;
}
/**
 * The capsule.
 * @param props - store hooks and copy.
 * @returns the toggle.
 */
export declare function ModeToggle({ useStore, actions, t }: ModeToggleProps): import("react").JSX.Element;
//# sourceMappingURL=ModeToggle.d.ts.map