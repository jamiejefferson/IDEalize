/** The view ids the shortcut moves between. */
export declare const CHAT_VIEW = "chat";
export declare const TERMINAL_VIEW = "terminal";
/** Next view for a toggle from the given one (anything other than the terminal reads as chat). */
export declare function toggledView(current: string | null | undefined): string;
/** True for V0's shortcut: ⌘J on macOS, Ctrl+J elsewhere; never with Shift/Alt. */
export declare function isToggleShortcut(event: Pick<KeyboardEvent, 'key' | 'metaKey' | 'ctrlKey' | 'altKey' | 'shiftKey'>): boolean;
/** Props the shortcut reads: the chat store's view plus its writer. */
export interface ModeShortcutProps {
    useStore: <T>(selector: (state: {
        view: string | null;
    }) => T) => T;
    actions: {
        setView: (view: string) => void;
    };
}
/**
 * The invisible shortcut listener.
 * @param props - store hooks.
 * @returns nothing renders.
 */
export declare function ModeShortcut({ useStore, actions }: ModeShortcutProps): null;
//# sourceMappingURL=ModeShortcut.d.ts.map