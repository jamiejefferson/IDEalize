/**
 * Markdown paths in a terminal chat's output become links that open in the
 * app's file viewer (JJ, 30 Sep 2026: "md file links in the chat should open
 * in the file viewer inside idealize"). An agent in the terminal prints the
 * files it writes (`Write(docs/plan.md)`, `Wrote 40 lines to notes.md`); a
 * click on one shows it beside the chat instead of leaving the app.
 *
 * Only paths the viewer says it shows are linked, and a relative one resolves
 * against the chat's folder, which is where the agent runs. A row that wraps
 * is read as one line with its neighbours, so a long path broken across rows
 * still links whole. A click that ends a drag-selection opens nothing.
 */
import type { IBuffer, ILinkProvider } from '@xterm/xterm';
/** The viewer a terminal link opens into (structurally the chat's file viewer). */
export interface TerminalFileViewer {
    /** Whether the viewer shows this file. */
    shows(path: string): boolean;
    /** Show the file. */
    open(path: string): void;
}
/** The grid face the provider reads (a slice of xterm's `Terminal`). */
export interface LinkGrid {
    readonly buffer: {
        readonly active: IBuffer;
    };
    readonly cols: number;
    hasSelection(): boolean;
}
/**
 * A printed path, made openable: absolute and `~/` paths as printed, others
 * under the chat's folder.
 * @param printed - the path as the output spells it.
 * @param cwd - the chat's folder, when known.
 * @returns the path to open, or undefined for a relative path with no folder.
 */
export declare function terminalFilePath(printed: string, cwd: string | undefined): string | undefined;
/**
 * The link provider over one grid.
 * @param grid - the terminal whose output is read.
 * @param cwd - reads the chat's folder at the time of the hover.
 * @param viewer - reads the viewer at the time of the hover; undefined links nothing.
 * @returns the provider to hand `terminal.registerLinkProvider`.
 */
export declare function markdownPathLinks(grid: LinkGrid, cwd: () => string | undefined, viewer: () => TerminalFileViewer | undefined): ILinkProvider;
//# sourceMappingURL=file-links.d.ts.map