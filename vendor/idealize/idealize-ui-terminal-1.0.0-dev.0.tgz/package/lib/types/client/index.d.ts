/**
 * Chat⇄Terminal toggle, browser half. When the host reports an embedded
 * terminal (the desktop shell), this plugin adds a `terminal` entry to the
 * conversation view ring (the ring's tabs are the visible switch) and an
 * invisible occupant of the session header's action group that binds ⌘J to
 * the chat store's active view. Browsers without the desktop shell register
 * nothing. Wherever the appearance service is composed, the grid follows its
 * Terminal section (`ctx.appearance.terminalPaint()`, re-read on store
 * changes); without it the grid sits on the page's alias tokens. A
 * `terminalMode` service exposes the same probe answer plus `open(sessionId)`
 * and `restart(sessionId, brainId)`, so other plugins (the welcome card's
 * Terminal launch, the composer's brain menu) flip a chat onto the terminal, or
 * replace its shell with one running another brain, without owning the ring.
 * The service also carries `Pane`, the same grid over one plain shell (no
 * launch command, no chat) for the tool rail's Terminal pane; the rail plugin
 * cannot import the component (bundle purity), so the service is the channel.
 *
 * This view owns its whole column and carries its own input, so on a still
 * blank chat it retires the conversation composer from its own stylesheet,
 * matching the active view id ui-conversation publishes on `data-blank-view`.
 * Views whose prompts go through the composer (Gallery, Sound Stage) keep it.
 */
import type React from 'react';
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
import { type TerminalKey } from './locales.ts';
import { type TerminalPaneProps } from './TerminalPane.tsx';
export { ModeShortcut, isToggleShortcut, toggledView } from './ModeShortcut.tsx';
export { applyTerminalPaint, currentTerminalPaint, httpTransport, reservedGutter, restartTerminal, TerminalView, withAlpha, xtermTheme, } from './TerminalView.tsx';
export type { TerminalTransport, StreamEvent } from './TerminalView.tsx';
export type { TerminalKey } from './locales.ts';
export { createTerminalPane, PANE_KEY } from './TerminalPane.tsx';
export type { TerminalPaneProps } from './TerminalPane.tsx';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** The toggle's copy. */
        'idealize-terminal': TerminalKey;
    }
}
/**
 * Required services: the slot registry, copy, session rows (for the chat's
 * directory), and the workspaces list (archiving a Terminal chat ends its shell).
 */
export declare const inject: string[];
/** The capability probe's answer shape. */
export interface TerminalCapabilities {
    embedded: boolean;
}
/**
 * Ask the host whether an embedded terminal exists here.
 * @param fetchImpl - the fetch to use; injected for tests.
 * @returns the capabilities; a failed or non-OK request reads as `embedded: false`.
 */
export declare function probeCapabilities(fetchImpl?: typeof fetch): Promise<TerminalCapabilities>;
/** Chat-store write used by the view switch (restated from ui-conversation's action set). */
interface ChatViewActions {
    setView(view: string): void;
}
/** The renderer host face's store resolver (the framework's per-session instance cache). */
interface ErasedStoreHost {
    storeOf(entry: {
        options: {
            id?: string;
        };
        store?: unknown;
    }, scopeKey?: string): {
        actions: ChatViewActions;
    } | undefined;
}
/** Type-erased slot registry face used where the typed overloads cannot see a foreign store. */
export interface ErasedSlots {
    entries(key: string): readonly {
        options: {
            id?: string;
        };
        store?: unknown;
    }[];
    subscribe(key: string, fn: () => void): () => void;
    register(options: Record<string, unknown>, component: unknown): () => void;
    inject(key: string, fn: () => () => void): void;
    /** SlotRegistry's renderer host face (TS-private; no public seam resolves a per-session store instance). */
    hostFace(): ErasedStoreHost;
}
/**
 * Switch one chat's conversation ring to the Terminal view by writing the
 * chat store's `view` through the framework's per-session instance cache
 * (`hostFace().storeOf` — the instance the rendered ring reads; a fresh
 * `handle.create()` would make a parallel instance the ring never sees).
 * @param slots - the erased slot registry.
 * @param sessionId - the chat whose ring flips.
 * @returns whether the chat entry existed and the switch was written.
 */
export declare function openTerminalView(slots: ErasedSlots, sessionId: string): boolean;
/** The Chat⇄Terminal service other plugins launch the terminal through. */
export interface TerminalModeHost {
    /**
     * Whether this host serves an embedded terminal (the memoized capability
     * probe — the same answer that gated the ring entry).
     * @returns the probe's answer.
     */
    embedded(): Promise<boolean>;
    /**
     * Switch the session's conversation ring to the Terminal view.
     * @param sessionId - the chat whose ring flips.
     * @returns whether the switch was written (false until the ring exists).
     */
    open(sessionId: string): boolean;
    /**
     * Restart the chat's shell on another brain: close the running shell and
     * reopen it on that brain's launch command.
     *
     * The scrollback and whatever the running agent held in context are lost, so
     * the caller must have confirmed with the user before calling this. Callers
     * that only want to know whether a switch would cost anything compare the
     * commands from `GET /idealize/terminal/launches` themselves.
     * @param sessionId - the chat whose shell restarts.
     * @param brainId - the agent preset id whose launch command the fresh shell gets.
     * @returns once the old shell is gone and the reopen has been asked for.
     */
    restart(sessionId: string, brainId: string): Promise<void>;
    /**
     * The grid over one plain shell, for a pane outside the conversation
     * column (the tool rail's Terminal pane). One shell for the whole app,
     * keyed `idealize-terminal-pane`; it survives the pane's unmounts, so closing and
     * reopening the pane reattaches to the same scrollback. Render it only
     * where `embedded()` answered true.
     * @param props - the directory the shell starts in.
     * @returns the grid.
     */
    Pane: (props: TerminalPaneProps) => React.JSX.Element;
}
declare module '@deepseek-ai/cordis' {
    interface Context {
        terminalMode: TerminalModeHost;
    }
}
/**
 * Client plugin body.
 * @param ctx - client root context.
 */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map