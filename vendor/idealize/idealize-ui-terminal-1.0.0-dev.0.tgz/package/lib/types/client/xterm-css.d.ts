/** xterm.js base stylesheet (MIT, @xterm/xterm 6.0.0), injected once at runtime. */
export declare const XTERM_CSS: string;
//# sourceMappingURL=xterm-css.d.ts.map