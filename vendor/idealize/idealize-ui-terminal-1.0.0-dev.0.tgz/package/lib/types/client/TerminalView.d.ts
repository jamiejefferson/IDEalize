import type { ITheme } from '@xterm/xterm';
import type { TerminalPaint } from '@idealize/appearance/client';
/** The transport the view talks to (the host routes; swapped in tests). */
export interface TerminalTransport {
    open(input: {
        key: string;
        cwd: string | undefined;
        cols: number;
        rows: number;
        /** The chat's activity preset id; the host types that activity's launch command into a fresh shell. */
        activity: string | undefined;
        /** A bare shell (the tool rail's Terminal pane): no launch command, and no chat recorded for the key. */
        plain?: boolean;
    }): Promise<{
        id: string;
    }>;
    stream(id: string, onEvent: (event: StreamEvent) => void, onError: () => void): () => void;
    input(id: string, data: string): void;
    resize(id: string, cols: number, rows: number): void;
    /**
     * End the shell so the next open starts a fresh one. Awaited, because the
     * host reattaches an open shell by key: reopening before the close lands
     * would hand back the very process the caller asked to replace.
     * @param id - the terminal id the open reported.
     * @returns once the host has ended the shell.
     */
    close(id: string): Promise<void>;
}
/** Events the stream carries. */
export type StreamEvent = {
    kind: 'replay';
    data: string;
} | {
    kind: 'data';
    data: string;
} | {
    kind: 'exit';
    exitCode: number;
};
/** The production transport over `/idealize/terminal/*`. */
export declare const httpTransport: TerminalTransport;
/**
 * What a drop types into the shell: each path backslash-escaped, joined by
 * spaces, with a trailing space so the next word starts clear of it. This is
 * what Terminal.app types for a dragged file, and what a terminal agent reads
 * as an attached image.
 * @param paths - absolute paths, in drop order.
 */
export declare function dropText(paths: readonly string[]): string;
/**
 * The disk paths one drop carries: files from Finder, the desktop or a
 * screenshot thumbnail (through the desktop shell's bridge), or a Files pane row.
 * @param transfer - the drop's payload.
 */
export declare function droppedPaths(transfer: DataTransfer): string[];
/** Forget every cached grid (plugin unload). */
export declare function disposeTerminals(): void;
/**
 * Restart one chat's shell on another brain: end the running shell, drop its
 * cached grid, and let the mounted view reopen on the new brain's launch
 * command. The scrollback and whatever the running agent held in context do
 * not survive, which is why every caller confirms with the user first.
 *
 * The close is awaited before the view is told: the host reattaches an open
 * shell by session key, so reopening any sooner would hand back the same
 * process.
 * @param sessionId - the chat whose shell restarts.
 * @param brainId - the agent preset id whose launch command the fresh shell gets.
 * @returns once the old shell is gone and the reopen has been asked for.
 */
export declare function restartTerminal(sessionId: string, brainId: string): Promise<void>;
/**
 * End one chat's shell for good: the chat was archived, so its process has no
 * row to come back to (JJ, 2 Sep 2026: archiving a Terminal chat is how it
 * closes). Nothing to do when the chat never opened a shell here.
 * @param sessionId - the archived chat.
 * @returns once the host has been asked to close the shell.
 */
export declare function closeTerminal(sessionId: string): Promise<void>;
/**
 * The grid host's padding for one paint margin. The right side gives back the
 * scrollbar width the fit addon takes, so the columns reach the same distance
 * from both edges and xterm's overlay scrollbar rides inside the margin.
 * @param margin - the paint's margin in CSS px.
 * @returns the CSS padding shorthand.
 */
export declare function gridPadding(margin: number): string;
/**
 * The scrollbar gutter the nearest scrolling ancestor holds back, so the
 * terminal's ground can carry across it (`.root::after`).
 * @param from - the terminal root, the element whose ancestors are searched.
 * @returns the reserved width in CSS px; 0 when no ancestor scrolls.
 */
export declare function reservedGutter(from: HTMLElement): number;
/**
 * The zoom that returns the terminal to 1 under whatever its ancestors apply.
 *
 * The appearance panel sizes a surface with CSS `zoom` (the chat surface at 20pt
 * is `zoom: 1.25`, the interface size zooms `#root`). xterm maps a pointer to a
 * cell by dividing a zoomed distance by an unzoomed cell height, so under 1.25
 * a press 800px down the grid selects the row 200px below it, and the fit
 * addon's row count overruns the host, which shows as a black strip along the
 * bottom (JJ, 17 Sep 2026). Nested zoom multiplies, so the reciprocal undoes it.
 *
 * An ancestor with no box (`display: contents`) reports a zoom of 1 whatever it
 * inherits. The chat view wraps the root in one, which left the packaged app
 * uncorrected, so the nearest ancestor that renders a box is the one measured.
 * @param start - the terminal root's parent, whose effective zoom is undone.
 * @returns the CSS zoom for the terminal root, '' when no ancestor zooms.
 */
export declare function counterZoom(start: Element | null): string;
/**
 * The appearance package's `SURFACE_EXEMPT_ATTRIBUTE`, spelled here because the
 * client bundle imports that package for types only. A surface's font rule
 * (`[surface] :not(…) { font-family: inherit }`) ties xterm's own rule on
 * `.xterm-rows` and comes later, so the chat surface's face, weight and tracking
 * reached the rows while xterm kept mapping the pointer on the monospace grid
 * it measured: the glyphs drifted left of their cells, about 100px by the end
 * of a long line (JJ, 17 Sep 2026). The attribute takes the subtree out of
 * those rules.
 */
export declare const SURFACE_EXEMPT = "data-idealize-surface-exempt";
/**
 * The paint currently applied, or undefined while the grid sits on the
 * page's alias tokens.
 * @returns the active paint.
 */
export declare function currentTerminalPaint(): TerminalPaint | undefined;
/**
 * xterm's theme object for one paint: the four surface colours plus the 16
 * ANSI slots by name.
 * @param next - the resolved paint.
 * @returns the xterm theme.
 */
export declare function xtermTheme(next: TerminalPaint): ITheme;
/**
 * Apply the appearance panel's terminal paint to every cached grid and every
 * grid created after. A mounted grid is refitted on the next frame, after the
 * view has rendered the paint's margin, and the PTY hears the new cols/rows
 * through the grid's `onResize`. Undefined returns to the page-token fallback.
 * @param next - the resolved paint, or undefined to clear.
 */
export declare function applyTerminalPaint(next: TerminalPaint | undefined): void;
/**
 * A colour at an opacity, in the forms xterm's theme parser accepts:
 * `#RRGGBB` gains an alpha byte, `rgb(...)` becomes `rgba(...)`; any other
 * form (a `var()` the page has not resolved, an empty token) is returned as
 * given.
 * @param colour - a computed `#RRGGBB` or `rgb(r, g, b)` string.
 * @param alpha - opacity 0–1.
 * @returns the translucent colour.
 */
export declare function withAlpha(colour: string, alpha: number): string;
/** Props the view ring gives the terminal entry. */
export interface TerminalViewProps {
    sessionId: string;
    /** The chat's working directory (undefined falls back to home on the host). */
    cwd: string | undefined;
    /** The chat's activity preset id (selects the fresh shell's launch command; undefined = the default). */
    activity?: string | undefined;
    /**
     * A bare shell: the host types no launch command and records no chat for
     * the key. The tool rail's Terminal pane opens this way, so its key names
     * no chat and its output is nobody's run.
     */
    plain?: boolean;
    transport?: TerminalTransport;
    t: (key: 'terminal.connecting' | 'terminal.exited' | 'terminal.restart' | 'terminal.error') => string;
}
/**
 * The terminal view.
 * @param props - session identity, directory, and copy.
 * @returns the grid.
 */
export declare function TerminalView({ sessionId, cwd, activity, plain, transport, t }: TerminalViewProps): import("react").JSX.Element;
//# sourceMappingURL=TerminalView.d.ts.map