/**
 * Whether a terminal's CLI is working, read from the only signal a shell
 * gives: its output. A harness agent announces itself through `agent/status`,
 * so the bridge knows when it starts and stops. A terminal agent is somebody
 * else's program — Claude Code, Pi — running inside a pty, and it announces
 * nothing. The person reads the shell the same way this does: output means it
 * is doing something, and a stretch of quiet means it has stopped.
 *
 * Three rules keep ordinary use out of it. {@link QUIET_MS} of silence ends
 * a run, so a CLI thinking between lines stays one run rather than several.
 * A run shorter than {@link MIN_RUN_MS} is never reported. And output within
 * {@link ECHO_MS} of the person's keystroke is their typing echoing back, so
 * it never counts towards that floor: typing a long prompt, or moving through
 * a CLI's menu, had raised a done chime at every pause (feedback 1047a635).
 *
 * A CLI that reports its own turns (`turns.ts`) is still watched here for its
 * working state; its done chime comes from its report.
 * @module @idealize/ui-terminal/activity
 */
/** Silence that ends a run. Fixed protocol timing, not a deployment tunable. */
export declare const QUIET_MS = 1500;
/**
 * The shortest run worth reporting. Echoed keystrokes and a prompt redraw are
 * output too; only a run outlasting this is the CLI working.
 */
export declare const MIN_RUN_MS = 4000;
/**
 * How long after a keystroke the terminal's output is still the person's: the
 * echo, and the redraw a CLI's prompt or menu makes round the key.
 */
export declare const ECHO_MS = 500;
/** What a watcher reports, and what it reads the clock and the timer from. */
export interface ActivityOptions {
    /**
     * A terminal started working: its run has outlasted {@link MIN_RUN_MS} and
     * output is still arriving.
     * @param id - the terminal's id.
     */
    onWorking(id: string): void;
    /**
     * A terminal stopped working: an announced run has fallen quiet.
     * @param id - the terminal's id.
     * @param ranForMs - how long the run lasted.
     * @param cut - true when the host interrupted the run ({@link TerminalActivity.interrupted}).
     */
    onDone(id: string, ranForMs: number, cut: boolean): void;
    /**
     * A terminal fell quiet after any run, announced or not, so a nudge held
     * back while it was printing can be tried again.
     * @param id - the terminal's id.
     */
    onQuiet?(id: string): void;
    /** The clock, injectable so a test can drive it. */
    now?: () => number;
}
/**
 * Watch terminals for the runs their output describes.
 *
 * The watcher owns no subscription: the caller feeds it what the shell says
 * ({@link TerminalActivity.sawOutput}, {@link TerminalActivity.closed}), which
 * keeps the rule testable without a pty and lets one watcher serve every
 * terminal the shell opens.
 */
export declare class TerminalActivity {
    #private;
    /**
     * @param options - what the watcher reports and the clock it reads.
     */
    constructor(options: ActivityOptions);
    /**
     * The terminals working right now, in no particular order.
     * @returns the ids of the terminals whose runs have been announced.
     */
    working(): string[];
    /**
     * Whether a terminal has printed within the last {@link QUIET_MS}, announced
     * or not: a nudge typed then could land in the middle of a redraw.
     * @param id - the terminal's id.
     * @returns true while a run stands.
     */
    busy(id: string): boolean;
    /**
     * Record that the person typed into a terminal (a key, a paste, a click the
     * CLI asked to hear), so the output it brings back is known for theirs.
     * @param id - the terminal's id.
     */
    sawInput(id: string): void;
    /**
     * Record that the host interrupted a terminal's run, so its end is reported
     * as cut. The mark lives on the run and ends with it; the next run starts
     * unmarked.
     * @param id - the terminal's id.
     */
    interrupted(id: string): void;
    /**
     * Record that a terminal wrote output.
     * @param id - the terminal's id.
     */
    sawOutput(id: string): void;
    /**
     * Forget a terminal that has gone: an exit ends its run without reporting
     * one, because the shell closing is not the CLI finishing a piece of work.
     * @param id - the terminal's id.
     */
    closed(id: string): void;
    /** End every run without reporting; the watcher is being disposed. */
    stop(): void;
}
//# sourceMappingURL=activity.d.ts.map