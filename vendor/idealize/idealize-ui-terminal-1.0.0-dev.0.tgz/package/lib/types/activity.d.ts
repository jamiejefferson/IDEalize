/**
 * Whether a terminal's CLI is working, read from the only signal a shell
 * gives: its output. A harness agent announces itself through `agent/status`,
 * so the bridge knows when it starts and stops. A terminal agent is somebody
 * else's program — Claude Code, Pi — running inside a pty, and it announces
 * nothing. The person reads the shell the same way this does: output means it
 * is doing something, and a stretch of quiet means it has stopped.
 *
 * Two thresholds keep ordinary use out of it. {@link QUIET_MS} of silence ends
 * a run, so a CLI thinking between lines stays one run rather than several.
 * A run shorter than {@link MIN_RUN_MS} is never reported, so typing at a
 * prompt — which echoes, and so is output — raises nothing.
 * @module @idealize/ui-terminal/activity
 */
/** Silence that ends a run. Fixed protocol timing, not a deployment tunable. */
export declare const QUIET_MS = 1500;
/**
 * The shortest run worth reporting. Echoed keystrokes and a prompt redraw are
 * output too; only a run outlasting this is the CLI working.
 */
export declare const MIN_RUN_MS = 4000;
/** What a watcher reports, and what it reads the clock and the timer from. */
export interface ActivityOptions {
    /**
     * A terminal started working: its run has outlasted {@link MIN_RUN_MS} and
     * output is still arriving.
     * @param id - the terminal's id.
     */
    onWorking(id: string): void;
    /**
     * A terminal stopped working: an announced run has fallen quiet.
     * @param id - the terminal's id.
     * @param ranForMs - how long the run lasted.
     */
    onDone(id: string, ranForMs: number): void;
    /** The clock, injectable so a test can drive it. */
    now?: () => number;
}
/**
 * Watch terminals for the runs their output describes.
 *
 * The watcher owns no subscription: the caller feeds it what the shell says
 * ({@link TerminalActivity.sawOutput}, {@link TerminalActivity.closed}), which
 * keeps the rule testable without a pty and lets one watcher serve every
 * terminal the shell opens.
 */
export declare class TerminalActivity {
    #private;
    /**
     * @param options - what the watcher reports and the clock it reads.
     */
    constructor(options: ActivityOptions);
    /**
     * The terminals working right now, in no particular order.
     * @returns the ids of the terminals whose runs have been announced.
     */
    working(): string[];
    /**
     * Record that a terminal wrote output.
     * @param id - the terminal's id.
     */
    sawOutput(id: string): void;
    /**
     * Forget a terminal that has gone: an exit ends its run without reporting
     * one, because the shell closing is not the CLI finishing a piece of work.
     * @param id - the terminal's id.
     */
    closed(id: string): void;
    /** End every run without reporting; the watcher is being disposed. */
    stop(): void;
}
//# sourceMappingURL=activity.d.ts.map