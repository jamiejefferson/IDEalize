/**
 * Typing a note's wake line into a Terminal chat's CLI. A note from another
 * chat used to wake the chat's own agent, which sits unused behind the
 * terminal (8 Oct 2026); the agent the person talks to is the program in the
 * shell, and the only way into it is the keyboard. JJ asked for the note to
 * reach it, so the host types one line and presses Enter, the way the person
 * would.
 *
 * Typing into somebody else's program is only safe at its prompt, so a nudge
 * waits while any of these hold, and is tried again when the terminal next
 * falls quiet:
 * - the shell has printed within the activity watcher's quiet window;
 * - the person has typed a line and not sent it (Enter would send theirs too);
 * - the program in front is not a command-line agent (a bare shell would run
 *   the line as a command, an editor would take it as text);
 * - the screen shows a choice (a permission prompt or a question), where
 *   Enter picks the highlighted answer.
 * One nudge is held per terminal; a later one replaces it.
 * @module @idealize/ui-terminal/nudge
 */
import type { DesktopTerminalLike } from './index.ts';
/** Programs that run a command-line agent: npm-installed CLIs show as `node`. */
export declare const AGENT_PROGRAMS: readonly string[];
/**
 * Whether the program in front of a shell is a command-line agent.
 * @param front - the pty's name for it, a path or a bare name.
 * @param launched - the program this host's launch ran, when known.
 * @returns true for a known agent, the launched program, or a version-named binary.
 */
export declare function isAgentProgram(front: string, launched: string | undefined): boolean;
/** Gap between the line and its Enter, so a TUI reads them as typing and a submit. */
export declare const ENTER_AFTER_MS = 150;
/**
 * Whether the bottom of a terminal's output shows a choice waiting for Enter.
 * @param replay - the terminal's recent output.
 * @returns true when a menu or yes/no question is on screen.
 */
export declare function showsChoice(replay: string): boolean;
/**
 * The program a launch command runs, as the process table names it.
 * @param command - the launch command, e.g. `claude --dangerously-skip-permissions`.
 * @returns the program's base name, or undefined for an empty command.
 */
export declare function programOf(command: string): string | undefined;
/** What the nudger reads about a terminal; the plugin answers from its watcher and input readers. */
export interface NudgeReads {
    /** The terminal printed within the quiet window. */
    busy(id: string): boolean;
    /** The line the person has typed and not sent. */
    draft(id: string): string;
    /** The program the terminal launched, when this host launched it. */
    program(id: string): string | undefined;
}
/** Types wake lines into terminals when they are at their prompt. */
export declare class TerminalNudges {
    #private;
    /** @param reads - what the plugin knows about each terminal. */
    constructor(reads: NudgeReads);
    /**
     * Type a line into a terminal now if it is at its agent's prompt, or hold
     * it until the terminal next falls quiet.
     * @param terminal - the chat's shell.
     * @param text - the line to type; one line, no Enter.
     * @param wanted - asked again before a held line is typed; false drops it
     *   (the agent read its inbox in the meantime).
     * @returns `typed` or `held`.
     */
    nudge(terminal: DesktopTerminalLike, text: string, wanted?: () => boolean): 'typed' | 'held';
    /**
     * A terminal fell quiet: type its held line if it is now at its prompt.
     * @param id - the terminal's id.
     */
    quiet(id: string): void;
    /**
     * Forget a terminal that has gone.
     * @param id - the terminal's id.
     */
    closed(id: string): void;
}
//# sourceMappingURL=nudge.d.ts.map