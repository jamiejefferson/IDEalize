/**
 * @idealize/ui-terminal — Host half of the Chat⇄Terminal toggle.
 *
 * Serves the loopback routes the browser half drives its xterm.js grid with:
 * - `GET  /idealize/terminal/capabilities` — `{ embedded }`: whether the
 *   desktop shell's `desktopTerminals` service is composed here. Browsers
 *   without it get `false` and never see the toggle.
 * - `GET  /idealize/terminal/launches` — `{ default, byActivity }`: the launch
 *   commands this deployment is configured with. The composer's brain menu
 *   reads them to say, BEFORE the click, which brains restart the shell.
 * - `POST /idealize/terminal/open` — `{ key, cwd, cols, rows, activity, plain? }`
 *   → `{ id, launch? }`. One shell per key (the chat's session id); reopening
 *   reattaches. The directory is FENCED to home plus the workspace roots
 *   (symlinks resolved). A FRESH shell gets the launch command for the named
 *   activity typed at its first prompt (V0's TerminalSession.start()); a
 *   reattach — the replay buffer already holds output — never does. `launch`
 *   reports the command a fresh open scheduled. `plain: true` opens a bare
 *   shell for the tool rail's Terminal pane: no launch command, and no chat
 *   recorded for the activity watcher, because the key is not a chat.
 * - `GET  /idealize/terminal/stream?id=` — SSE: a `replay` event carrying
 *   the recent output, then live `data` events and one `exit`.
 * - `POST /idealize/terminal/input` — `{ id, data }` keystrokes.
 * - `POST /idealize/terminal/resize` — `{ id, cols, rows }`.
 * - `POST /idealize/terminal/close` — `{ id }` ends the shell.
 *
 * Same loopback + `x-idealize-auth` fence as the other /idealize routes.
 * @module @idealize/ui-terminal
 */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
export { LAUNCHES_PATH, launchCommandFor } from './launches.ts';
export type { TerminalCliOption, TerminalLaunches } from './launches.ts';
/** Stable Cordis plugin name. */
export declare const name = "idealize-ui-terminal";
/** Plugin config. */
export interface Config {
    /**
     * The command typed into a fresh embedded shell once its first prompt
     * output arrives (V0's default launch command). Empty disables the
     * auto-launch.
     */
    launchCommand?: string;
    /**
     * Per-activity launch command, keyed by the activity preset id the open
     * request names (the pill the chat launched on); an absent id falls back
     * to `launchCommand`.
     */
    launchByActivity?: Record<string, string>;
    /**
     * The command-line agents the Brains pane offers as launch choices, in
     * order. `command` `''` is a plain shell. The route probes each command's
     * executable through the login shell and serves the verdict alongside.
     */
    clis?: {
        /** Stable choice id the launch settings store. */
        id: string;
        /** The row label the pickers show. */
        label: string;
        /** What a fresh shell types; `''` is a plain shell. */
        command: string;
    }[];
}
/** Runtime schema for {@link Config}. */
export declare const Config: z<Config>;
/** Events one embedded terminal emits (restated from the desktop plugin). */
export type EmbeddedTerminalEvent = {
    kind: 'data';
    data: string;
} | {
    kind: 'exit';
    exitCode: number;
};
/** The desktop shell's embedded-terminal face (restated; dsh-plugin-desktop owns it). */
export interface DesktopTerminalLike {
    readonly id: string;
    readonly cols: number;
    readonly rows: number;
    readonly exit: {
        exitCode: number;
    } | undefined;
    replay(): string;
    write(data: string): void;
    resize(cols: number, rows: number): void;
    subscribe(listener: (event: EmbeddedTerminalEvent) => void): () => void;
    close(): void;
}
/** Which terminal agents are working right now, for the surfaces that show it. */
export interface IdealizeTerminals {
    /**
     * Which terminal chats are working.
     * @returns the session ids of every terminal chat whose CLI is working.
     */
    working(): string[];
}
declare module '@deepseek-ai/cordis' {
    interface Context {
        idealizeTerminals: IdealizeTerminals;
    }
    interface Events {
        /**
         * A terminal agent started or stopped working, from its shell's output.
         * @mode emit
         * @param change - the terminal's id and whether it is working now.
         */
        'idealize/terminal-activity': (change: {
            id: string;
            working: boolean;
        }) => void;
    }
}
/**
 * How long a run lasted, in the words the group chat carries.
 * @param ms - the run's duration.
 * @returns `2m 30s`, or `45s` under a minute.
 */
export declare function describeRun(ms: number): string;
/** The service the routes probe for. */
export interface DesktopTerminalsLike {
    open(options: {
        key?: string;
        cwd: string;
        cols?: number;
        rows?: number;
    }): DesktopTerminalLike;
    get(id: string): DesktopTerminalLike | undefined;
}
/** Where the probe looks for the desktop service. */
export declare const DESKTOP_TERMINALS_SERVICE = "desktopTerminals";
/**
 * A grid dimension from a request body.
 * @param value - the raw body field.
 * @param max - the inclusive cap.
 * @returns the integer when it lies in `[1, max]`, otherwise undefined.
 */
export declare function gridDimension(value: unknown, max: number): number | undefined;
/**
 * Resolve a requested directory and require it inside home or a workspace
 * root (symlinks resolved first, so a link that escapes both is refused).
 * @param raw - the requested directory.
 * @param roots - the workspace roots.
 * @returns the real path, or undefined when refused or missing.
 */
export declare function fencedDirectory(raw: string, roots: readonly string[]): Promise<string | undefined>;
/**
 * Type `command` into a fresh shell once its prompt shows — V0's
 * TerminalSession.start() analogue. Output means the shell is drawing, and
 * the launch waits for {@link LAUNCH_AFTER_PROMPT_MS} of quiet after the last
 * chunk, so a prompt written in several pieces is finished before the command
 * is typed into it. {@link LAUNCH_FALLBACK_MS} is the deadline for a shell
 * that reports nothing or never falls quiet. Ctrl-U leads so a stray
 * half-typed prefix cannot join the command. The caller schedules this only
 * for a fresh shell (empty replay), so a reattach never types a second
 * launch.
 * @param terminal - the freshly opened shell.
 * @param command - the resolved non-empty launch command.
 */
export declare function scheduleLaunch(terminal: DesktopTerminalLike, command: string): void;
/**
 * Register the terminal routes under the web server.
 * @param ctx - Host context.
 * @param config - launch-command configuration.
 */
export declare function apply(ctx: Context, config?: Config): void;
//# sourceMappingURL=index.d.ts.map