/**
 * The conversation a Terminal chat's command-line agent reopens.
 *
 * A Terminal chat's CLI dies with the app, and the fresh shell a relaunch
 * opens typed the brain's command bare, so Claude Code came back with no
 * history (JJ, 30 Oct 2026: every terminal chat reopens its own conversation
 * after every restart, paused or not). A CLI that lets the caller name its
 * conversation gets one id per chat and program, derived from the two
 * (UUIDv5), so the binding is never written anywhere: the chat's id is in its
 * log, and the program is the one its brain launches. The first launch starts
 * the conversation under that id; every later one reopens it, and nothing is
 * typed into it, so the agent waits for the person. Each program keeps its own
 * conversation: a brain switch onto another CLI starts that CLI's own, and
 * switching back reopens the first.
 *
 * {@link CONVERSATION_CHANNELS} lists the CLIs that take a caller-chosen id,
 * each checked against its own `--help` on 30 Oct 2026 (Claude Code 2.1.314,
 * Pi 0.85.1). Codex 0.162.1 and Kimi Code 0.41.0 only reopen ids they choose
 * themselves (`codex resume <id>`, `kimi --session <id>`), so they launch
 * fresh, as every CLI did before.
 * @module @idealize/ui-terminal/conversation
 */
/** How one CLI starts and reopens a conversation under an id the caller picks. */
export interface ConversationChannel {
    /** The option that starts the conversation under the id. */
    start: string;
    /** The option that reopens a started conversation; absent where `start` reopens it too. */
    resume?: string;
    /** Matches a command that already picks its own conversation; such a command is the user's and is typed as written. */
    own: RegExp;
}
/** The CLIs that take a caller-chosen conversation id, keyed by executable name. */
export declare const CONVERSATION_CHANNELS: Readonly<Record<string, ConversationChannel>>;
/**
 * The conversation id one chat's program runs under: a UUIDv5 of the chat's
 * session id and the program's name, so the same chat and program always
 * name the same conversation and two chats in one folder never share one.
 * @param chat - the chat's session id (the terminal's key).
 * @param program - the CLI's executable name.
 * @returns a lower-case UUID.
 */
export declare function conversationId(chat: string, program: string): string;
/**
 * Whether Claude Code has a conversation under `id`. It writes one file per
 * conversation, `<id>.jsonl`, in a folder per project under its config
 * directory, and only once the first message is sent. Every project folder is
 * looked in, so the folder-naming rule (which shortens long paths) never
 * decides the answer.
 * @param id - the conversation id.
 * @returns true once the conversation's file exists.
 */
export declare function claudeConversationExists(id: string): Promise<boolean>;
/**
 * The launch command with the chat's conversation named on it, at the end
 * where both CLIs read options. A CLI outside the table, or a command that
 * picks its own conversation, is returned as configured.
 * @param command - the configured launch command.
 * @param chat - the chat's session id.
 * @param exists - whether a conversation id has been started (Claude Code's file check by default).
 * @returns the command with the start or reopen option appended.
 */
export declare function withConversation(command: string, chat: string, exists?: (id: string) => Promise<boolean>): Promise<string>;
//# sourceMappingURL=conversation.d.ts.map