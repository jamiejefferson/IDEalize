# @idealize/ui-terminal

The embedded terminal, both halves: the Terminal space's view inside the conversation column, the tool rail's Terminal pane over one plain shell, the loopback routes that drive their xterm.js grids, and the `terminalMode` service other plugins open or restart a chat's shell through. Mounted by the `idealize` profile as the `idealize-ui-terminal` row. The shell itself belongs to the desktop shell's `desktopTerminals` service (`dsh-plugin-desktop`); this package probes for it and registers nothing when it is absent, so a plain browser never sees a Terminal view.

## Configuration

| Field | Default | Meaning |
|---|---|---|
| `launchCommand` | `claude --dangerously-skip-permissions` | The command typed into a fresh shell once its prompt has finished drawing; empty disables the auto-launch. |
| `launchByActivity` | `{}` | Per-brain launch command keyed by the agent preset id the open request names; an absent id falls back to `launchCommand`. |
| `appendKnowledge` | `true` | Whether a Claude Code, Pi or Codex launch is typed with IDEalize's standing rules passed on its command line, and a Claude Code launch with the hooks that report its turns; `false` types the command as written. |
| `clis` | Claude Code, Codex CLI, Gemini CLI, Kimi CLI, Pi, Herdr, OpenCode, Aider, Plain shell | The command-line agents probed as launch choices; `''` is a plain shell. The Brains pane offers the installed ones. |

`launchCommandFor` (`src/launches.ts`) is the one pure read over both, shared by the host's open route and the `GET /idealize/terminal/launches` payload, so a surface deciding whether a brain switch restarts the shell compares the commands the shell will actually run. The config is also a settings section (`idealize-ui-terminal`), so the Brains pane's launch choices persist in the settings document over the composition values.

## Routes (loopback only; mutations need `x-idealize-auth: 1`)

- `GET /idealize/terminal/capabilities` returns `{embedded}`: whether `desktopTerminals` is composed here.
- `GET /idealize/terminal/launches` returns `{default, byActivity, catalog}`: the configured launch commands plus the CLI catalogue, each entry probed for its executable through the login zsh (`installed`; null where the probe cannot run, true for a plain shell; cached a minute).
- `POST /idealize/terminal/launch` `{activity?, command}` persists a launch choice: the named brain's override, or the default without `activity`. The command must be one line of at most 200 characters; running shells keep their command until restarted.
- `POST /idealize/terminal/open` `{key, cwd, cols, rows, activity, plain?}` returns `{id, launch?}`. One shell per key (the chat's session id); reopening reattaches. The directory is fenced to home plus the workspace roots with symlinks resolved. A fresh shell gets the named activity's launch command typed once it has been quiet for 300 ms, or at a 2 s deadline for a shell that reports nothing or never falls quiet; a reattach whose replay buffer already holds output never does. `plain: true` opens a bare shell (the rail's Terminal pane, key `idealize-terminal-pane`): no launch command, and no chat recorded for the activity watcher, so its output never counts as an agent's run. Grids past 500 by 300 are refused.
- `GET /idealize/terminal/stream?id=` is SSE: one `replay` event with the recent output, then live `data` events and one `exit`.
- `POST /idealize/terminal/input` `{id, data}`, `POST /idealize/terminal/resize` `{id, cols, rows}`, `POST /idealize/terminal/close` `{id}`.

## Browser half

After one capability probe, and only when it answers `embedded: true`, the plugin registers the `terminal` entry of the conversation view ring (order 5) and an invisible occupant of `conversation.session.header.actions` (`ModeShortcut`, order 100) that binds ⌘J (Ctrl+J elsewhere) to flipping the chat between the Chat and Terminal views. The view owns its whole column and carries its own input, so on a still-blank chat it retires the composer seat from its own stylesheet by matching the active view id `ui-conversation` publishes on `data-blank-view`. The grid follows `@idealize/appearance`'s Terminal section through `ctx.appearance.terminalPaint()` while that service is composed, and sits on the page's alias tokens otherwise.

`ctx.terminalMode` is provided in every composition, probed or not: `embedded()` returns the memoised probe answer, `open(sessionId)` flips the chat's ring onto the Terminal view through the same per-session chat store the rendered ring reads, `restart(sessionId, brainId)` closes the running shell and reopens it on that brain's launch command, and `Pane` is the same grid over one plain shell for the tool rail's Terminal pane (`@idealize/ui-bar` seats it; JJ, 15 Sep 2026: "a plain terminal - no cli etc. just for running commands"). The pane's shell starts in the directory the pane is first opened in (the current chat's project, else home), is cached like every chat grid so closing the pane keeps the shell and its scrollback, and takes the appearance panel's Terminal paint like the main view. Restarting loses the scrollback and the running agent's context, so callers confirm with the user first; `@idealize/activity-pills`' brain switcher does, with the line "The terminal restarts. You may lose some context.". Archiving a Terminal chat is how it closes (JJ, 2 Sep 2026): the client watches `workspaces.list`'s archived ids and ends the archived chat's shell, so no process runs on behind a row that has left the sidebar. A Terminal chat never sends a prompt, so the sidebar (`@deepseek-ai/dsh-client-ui-workspace`) counts it as started from its launch — its recorded `terminal` space — and lists it with the row verbs like any chat.

## Grid size

An agent's full-screen UI draws its input box on the grid's last rows, so a grid taller than its column hides the one place to type (JJ, 18 Sep 2026). Three rules in `src/client/TerminalView.tsx` and its stylesheet keep the last row inside the column and the shell informed:

- **The host is sized by its column.** `.grid` carries `contain: size`, because xterm gives its screen an explicit pixel height and the conversation's view area (`flex: 1 0 auto`) grows to its content and never shrinks under it. Uncontained, the drawn rows held the host open through a shorter window or a larger font, and the fit addon measured the height the old grid had made.
- **One fit per frame, from every cause.** A `ResizeObserver` on the host covers the window, a column drag, the paint's margin, a surface zoom and a view returning from `display: none`; `applyTerminalPaint` covers font size, family and line height; `document.fonts`' `loadingdone` covers a web font that arrives after the grid opened, and measures the cell again. A host with no box is never fitted, so a hidden view does not shrink the shell to one row.
- **The PTY hears from the grid.** The connection subscribes to xterm's `onResize`, so every change of cols/rows reaches `POST /idealize/terminal/resize`, whichever cause refitted the grid, and an unchanged size sends nothing.

### Rendered proof

```sh
OUT=.idealize/proof/terminal-resize pnpm exec tsx packages/idealize/ui-terminal/proof/resize-proof.mts
```

Headless Chromium mounts the shipped view inside the shipped conversation column styles, and the shipped pane inside a drawer-like column, over a PTY stand-in that redraws an ask bar on the last row of whatever size it was last told. It walks the window shrinking and growing, the column narrowing, font size, line height, margin, hide-resize-show, a 1.25 surface zoom, a 420x320 window and a late web font (macOS: it borrows a system face), and fails unless after each step the last row ends inside the visible frame, the frame has nothing to scroll, the ask bar is on the last row, and the last size the PTY was told equals the grid's. It writes one screenshot per step and `result.json`.

## Standing rules for a terminal agent

A harness agent reads IDEalize's standing rules from its system prompt. The CLIs a Terminal chat runs read none of it, so a Claude Code chat was never told where documentation goes (JJ, 17 Sep 2026). On a fresh launch the open route asks each service in `KNOWLEDGE_SERVICES` (`docPolicy` for where documentation goes, then `idealizeComm` for how notes between chats work, the same text harness agents carry in their prompt) for `terminalKnowledge(cwd)`, writes the answers to `<DSH_HOME>/idealize/terminal-knowledge/<terminal id>.md`, and types the launch with that file passed on the command line. The file is removed when the shell exits. A service joins by offering the method; this package probes and never imports it.

`PROMPT_CHANNELS` (`src/knowledge.ts`) lists the CLIs with an option for it, keyed by executable name:

| CLI | Typed as |
|---|---|
| `claude` | `<command> --append-system-prompt "$(cat '<file>')"` |
| `pi` | `<command> --append-system-prompt "$(cat '<file>')"` |
| `codex` | `codex -c developer_instructions="$(cat '<file>')" <rest of command>` (Codex reads options before its subcommand or prompt) |

Each was proved on 17 Sep 2026 against the real program (Claude Code, Pi 0.85.1, Codex 0.153.4): with the option the agent named the project's note and folder, and a control run without it answered that it had not been told. A command that already sets its own instructions (`--system-prompt`, `--append-system-prompt`, `developer_instructions`) is the user's and is typed as written. Another CLI, `appendKnowledge: false`, a deployment whose services have nothing to say, or a failed write all type the command as configured. The open route's `launch` and the launches route still report the configured command, because that is what a brain switch compares.

## When a terminal agent has finished

A Terminal chat's done chime, its system notification and its "Finished a run in the terminal" line in the group chat all come from one place, and two sources feed it.

**The agent's own report (Claude Code).** A Claude Code launch on macOS or Linux is typed with `--settings '<DSH_HOME>/idealize/terminal-turns/claude-turns.json'`. The file holds four hooks (`TURN_HOOKS`, `src/turns.ts`): SessionStart, UserPromptSubmit, Stop and SessionEnd run `idealize turn open|start|stop|close`, quiet and always exiting 0. `@idealize/comm` hands the report to `ctx.idealizeTerminals.turn(sessionId, turn)`. A stop is the finish, timed from the last start. From the first report until the session closes, the watcher below stays silent about that terminal's finishes. Claude Code merges these hooks with the person's own and refuses to start when a `--settings` file is missing, so the file is rewritten (one rename) on every launch, and a failed write types the launch without it. A command that loads its own `--settings`, `appendKnowledge: false` and Windows all go without the hooks. Proved on 30 Oct 2026 against Claude Code 2.1.314: the four hooks fired from the file in order, the stop as the reply ended.

**The activity watcher (every other CLI).** `TerminalActivity` (`src/activity.ts`) reads the shell's output: a run that outlasts 4 s is the CLI working, and 1.5 s of quiet ends it. Output within 500 ms of the person's keystroke (`/idealize/terminal/input`) is their typing echoing back and never counts towards the 4 s. Before that rule, typing a prompt or moving through a menu raised a chime at every pause: in the AMI chat from 26 to 30 Oct 2026 there were 215 chimes against 49 Claude Code turns, and 43 of them came at a turn's end (feedback 1047a635). A CLI working quietly, such as a long tool run with no output, still ends a run early here.

## Model Experience

None for the chat's own model: the embedded shell runs its own process and its output never enters the chat's session log or any model request; the chat's brain and model are chosen by `@idealize/activity-pills` and `@idealize/spaces`.

The Claude Code, Pi or Codex process the shell launches does receive text from this package: the knowledge file above, added to its system prompt (Codex: its developer instructions) once at launch. With `@idealize/doc-policy` composed and a folder set, that is the preamble line plus the documentation rule and the project's note path, about 960 characters plus three copies of the folder path. The turn hooks add nothing: Claude Code puts a SessionStart or UserPromptSubmit hook's output into the model's context, and these send theirs to `/dev/null`.

#### KV Cache effect

Independent for the chat's request: opening, restarting or closing a shell changes nothing in it. For the launched process the added text is fixed for the life of the process, so its prefix stays stable.

## A chat's own conversation

A Terminal chat's CLI dies with the app, and a relaunch used to type the brain's command bare, so Claude Code came back with no history. JJ ruled on 30 Oct 2026 that every terminal chat reopens its own conversation after every restart, paused or not. `withConversation` (`src/conversation.ts`) names the conversation on the launch line of a CLI that takes a caller-chosen id. The id is a UUIDv5 of the chat's session id and the CLI's executable name (`conversationId`), so nothing is stored: the same chat and CLI always name the same conversation, two chats in one folder get one each, and a brain switch onto another CLI starts that CLI's own while switching back reopens the first. Nothing is typed into a reopened conversation, so the agent waits for the person.

| CLI | First launch | Later launches |
|---|---|---|
| `claude` | `<command> --session-id <id>` | `<command> --resume <id>`, once `<id>.jsonl` exists in any folder under `$CLAUDE_CONFIG_DIR/projects` (default `~/.claude/projects`); Claude Code writes it on the first message and refuses `--session-id` for an id already in use |
| `pi` | `<command> --session-id <id>` | the same line: Pi creates the session when it is missing and reopens it when it is not |

Each was proved on 30 Oct 2026 with the exact line the route builds (Claude Code 2.1.314, Pi 0.85.1): the first run was told a word, the second run named it. The standing-rules option follows the conversation option on the line. A command that already picks its own conversation (`--resume`, `--continue`, `--session-id`, and Pi's `--session`, `--fork`, `--no-session`) is typed as written, as is any CLI outside `CONVERSATION_CHANNELS` and any launch whose look for the conversation fails.

## Known Limitations and Deferred Work

- **⌘J still flips a started desktop chat between Chat and Terminal.** The space is fixed for the life of a chat and the tab row is gone, so this shortcut is the one control left that moves a chat between two spaces; it stays because the packaged-window proof needs a way to start a Terminal chat and the shortcut lives in this package, whose proof cannot run headless.
- **A brain switch replaces the shell.** `restart` closes the PTY and reopens it on the new launch command. A switch onto another CLI starts that CLI's own conversation, so the previous agent's context stays behind, which is why the confirm dialog exists; a switch between two brains on the same Claude Code or Pi reopens the chat's conversation under the new command.
- **Codex and Kimi start a fresh conversation after a restart.** Codex 0.162.1 (`codex resume <id>`) and Kimi Code 0.41.0 (`kimi --session <id>`) only reopen ids they choose themselves; binding them means reading each CLI's own session store after launch.
- **A conversation Claude Code starts on its own is not followed.** Where `/clear` starts a new conversation under an id Claude Code picks (not checked against 2.1.314, which needs an interactive run), the next restart reopens the chat's bound conversation from before it.
- **The launch command is typed on a timer, not on a prompt protocol.** It goes in after the shell has been quiet for 300 ms, or at a 2 s deadline whichever comes first, so a shell that prints nothing until after 2 s, or one that never falls quiet, still receives the command while it is drawing. There is no prompt-detection protocol to do better.
- **Kimi, Gemini, OpenCode, Aider and Herdr receive no standing rules.** Kimi 0.41.0 offers only `--agent-file`, which replaces the whole agent profile; Herdr is a workspace manager with no agent of its own; the other three were not installed to prove an option against. A reattached shell keeps the rules it launched with, so a changed documentation folder reaches a terminal agent at its next fresh launch.
- **Desktop only.** Without the desktop shell's `desktopTerminals` service the routes answer 409 and the view is never registered; there is no browser-side fallback shell.

## Nudges from other chats

Pausing every agent (feedback 495cec0a) uses three more members of `ctx.idealizeTerminals`. `deliver(sessionId, text, wanted)` types a line as `nudge` does and settles with what became of it (`src/delivery.ts`): `answered` once the line was typed and the run it set off was reported working and then finished, or once 30 s pass after typing with no run starting; `dropped` when the line was replaced, no longer wanted or interrupted; `gone` when the shell closed. With `options.interruptWith`, `deliver` first stops a CLI in the middle of a run (a turn its hooks report, or a run the watcher has announced) with Escape, the interrupt key of Claude Code 2.1.314, Codex 0.162.1 (`/keymap`: Interrupt Turn `esc`), Pi 0.85.1 (footer: "escape interrupt") and Kimi 0.41.0 (its editor cancels the stream on Escape). Once the prompt is back (the next quiet spell, or 1.75 s with no output) it empties the input box with 32 presses of Ctrl-U and types `interruptWith` in place of `text`: Claude Code puts the interrupted prompt back in the box, and a line typed onto it sent the old task again (30 Oct 2026). Ctrl-U deletes to the start of a line in all four CLIs and does nothing in an empty box; Ctrl-C would clear the box in one press, but Codex quits on a single Ctrl-C when the box is already empty. Claude Code runs no Stop hook for an interrupted turn, so the turn is closed here, and the interrupted run neither chimes nor posts. `interrupt(sessionId)` drops the line held for a chat and presses Escape when the CLI is working; an idle CLI gets no key, because a second Escape at the prompt opens Claude Code's rewind and Codex's backtrack. `onOpened(listener)` hears each chat whose shell opens or reattaches, so Resume can type the line it owes a chat whose shell was closed.

A note from another chat used to wake the chat's own agent behind the terminal, which ran turns on a model the person never chose and brought the composer back under the grid (JJ, 8 Oct 2026). `ctx.idealizeTerminals.nudge(sessionId, text, wanted)` now types the wake line into the chat's CLI and presses Enter 150 ms later, the way the person would. It types only when every check passes, and otherwise holds one line per terminal and tries again each time the terminal falls quiet (`TerminalActivity`'s `onQuiet`). The checks: the shell has been quiet for the watcher's window; the person has no line typed and unsent (read from `/idealize/terminal/input` through `PromptLines`); the desktop shell names its foreground program and that program is a command-line agent (`claude`, `codex`, `pi`, `node`, the launch's own program, or a version-named binary such as `2.1.294`, which is how a pty names Claude Code's native install); and the last 4,000 characters of output show no numbered menu or yes/no question, where Enter would pick an answer. A desktop shell without `foreground()` gets no typing at all. `wanted` is asked before a held line is typed, so a note the agent has already read drops its nudge.
