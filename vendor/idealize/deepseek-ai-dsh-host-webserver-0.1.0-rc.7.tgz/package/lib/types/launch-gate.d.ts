/**
 * The launch gate: who may call the app's own routes.
 *
 * The server listens on loopback, and its browser fence (Host, Origin,
 * Sec-Fetch-Site and a custom header) keeps web pages out. It never told one
 * local caller from another, so any process on the Mac, an agent's shell
 * included, could drive every route with `curl` (security audit, 9 Oct 2026).
 *
 * When the embedding shell places a launch token on `globalThis` under
 * {@link LAUNCH_TOKEN_KEY} before boot, every `/api` and `/idealize` request
 * must prove it holds that token or a session key derived from it:
 * - the app's own windows carry the token as the {@link LAUNCH_COOKIE} cookie,
 *   which the shell sets in its browser session and no other program holds;
 * - a chat's shell carries its session id and that session's key
 *   ({@link sessionKey}) and may reach only the routes in
 *   {@link SESSION_ROUTES}.
 * With no token placed (tests, a bare web run), the gate stays open and only
 * the loopback Host check applies.
 */
import type { IncomingMessage } from 'node:http';
/** Where the embedding shell places the launch token before boot. */
export declare const LAUNCH_TOKEN_KEY: unique symbol;
/** The cookie the app's windows carry the launch token in. */
export declare const LAUNCH_COOKIE = "idealize_launch";
/** Header carrying a chat shell's session id. */
export declare const SESSION_HEADER = "x-idealize-session";
/** Header carrying a chat shell's session key (or the launch token itself). */
export declare const KEY_HEADER = "x-idealize-key";
/** The routes a chat's shell may call with its session key. */
export declare const SESSION_ROUTES: readonly string[];
/** Who made a request, as the gate proved it. */
export type LaunchCaller = {
    kind: 'app';
} | {
    kind: 'session';
    sessionId: string;
} | {
    kind: 'open';
};
/**
 * The launch token the shell placed, when it placed one.
 * @returns the token, or undefined when the gate is open.
 */
export declare function launchToken(): string | undefined;
/**
 * The key one chat's shell carries: derived from the launch token, so the host
 * checks it without storing anything, and useless after the app restarts.
 * @param token - the launch token.
 * @param sessionId - the chat's session id.
 * @returns the hex key.
 */
export declare function sessionKey(token: string, sessionId: string): string;
/**
 * The key for one chat's shell under the current launch token.
 * @param sessionId - the chat's session id.
 * @returns the key, or undefined when the gate is open.
 */
export declare function currentSessionKey(sessionId: string): string | undefined;
/**
 * Whether a Host header names this machine's loopback.
 * @param host - the request's Host header.
 * @returns true for 127.0.0.1, localhost and [::1], any port.
 */
export declare function loopbackHost(host: string | undefined): boolean;
/**
 * Whether the gate guards a path.
 * @param path - the request pathname.
 * @returns true for the RPC bridge and the app's own routes.
 */
export declare function gatedPath(path: string): boolean;
/**
 * Prove who sent a request.
 * @param req - the incoming request.
 * @returns the caller, or undefined when the request proves nothing.
 */
export declare function identify(req: IncomingMessage): LaunchCaller | undefined;
/**
 * Decide one request: whether it may proceed, recording the caller on it.
 * @param req - the incoming request.
 * @param path - its pathname.
 * @returns undefined to proceed, or the status to refuse with.
 */
export declare function admit(req: IncomingMessage, path: string): 403 | 401 | undefined;
/**
 * Who the gate proved a request came from.
 * @param req - a request the gate admitted.
 * @returns the caller; `open` when the gate is open or never saw the request.
 */
export declare function requestCaller(req: IncomingMessage): LaunchCaller;
//# sourceMappingURL=launch-gate.d.ts.map