/**
 * The Content-Security-Policy on the app's own pages. A chat renders text from
 * anywhere (web pages, repositories, other agents), so this is the second line
 * behind the renderer's own escaping: markup that slips through cannot run an
 * inline script, load a script from elsewhere, send data to another server, or
 * frame the app.
 *
 * Each allowance below is here because a page needs it. Removing one means
 * re-proving the surface named beside it with a real page load.
 */
/**
 * The policy for the app's main page.
 * @param html - the final index.html body, after every index tap.
 * @returns the header value: inline scripts run only when their exact text is hashed here.
 */
export declare function appPagePolicy(html: string): string;
/**
 * The policy for a page a route renders itself (service hatch, sign-in, spend,
 * status, model list). Those pages are fixed text with inline scripts and hold
 * no agent output, so inline script stays allowed; everything else stays shut,
 * so nothing they run can reach another server. A route that serves someone's
 * file sends its own sandboxed policy, which replaces this one.
 */
export declare const ROUTE_PAGE_POLICY: string;
//# sourceMappingURL=page-policy.d.ts.map