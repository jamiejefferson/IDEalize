/**
 * @idealize/provider-pack — the login-first auth substrate.
 *
 * Provides `ctx.idealizeOAuth`: a persistent pi-ai credential store under the
 * Harness home plus provider-owned OAuth login/logout orchestration. The
 * llm-pi-ai adapter (this fork) builds its Models collections over the same
 * store, so a credential stored here authenticates ordinary session requests
 * for OAuth routes such as `openai-codex`.
 *
 * When the webserver is composed the pack also registers the sign-in surface:
 *
 * - `GET  /idealize/signin`          — minimal branded page listing OAuth providers
 * - `GET  /idealize/auth/providers`  — provider ids, labels, stored/pending state
 * - `POST /idealize/auth/login`      — `?provider=` starts the flow, returns `{ authUrl }`
 * - `GET  /idealize/auth/status`     — `?provider=` reports pending/stored/error
 * - `POST /idealize/auth/logout`     — `?provider=` deletes the stored credential
 *
 * Mutating endpoints demand the `x-idealize-auth: 1` header (a cross-origin
 * page cannot attach custom headers without a CORS preflight the server never
 * grants) and every endpoint refuses a non-loopback Host, which closes DNS
 * rebinding. Full integration with the web app's token fence is queued work.
 *
 * @module @idealize/provider-pack
 */
import { Context, Service } from '@deepseek-ai/cordis';
import { FileCredentialStore } from './store.ts';
export { noteAuthEvent } from './pending.ts';
export type { PendingLogin } from './pending.ts';
export { FileCredentialStore, OAUTH_STORE_FILENAME, oauthStorePath } from './store.ts';
declare module '@deepseek-ai/cordis' {
    interface Context {
        idealizeOAuth: IdealizeOAuth;
    }
}
/** What the providers endpoint reports per OAuth-capable catalog provider. */
export interface OAuthProviderStatus {
    id: string;
    name: string;
    loginLabel?: string;
    /**
     * True when sign-in is the only way this route authenticates: its catalog
     * provider declares no API-key method, so a pasted key can never serve it
     * (`openai-codex` sends a ChatGPT token, not a key). A route offering both,
     * such as kimi-coding, is false and keeps taking keys.
     */
    keyless: boolean;
    stored: boolean;
    pending: boolean;
    /** While a device-code login is pending: the code the provider's page may ask the person to type. */
    userCode?: string;
    error?: string;
}
/** Subscription sign-in behind `ctx.idealizeOAuth`: stored OAuth credentials and in-flight logins. */
export declare class IdealizeOAuth extends Service {
    /** The stored OAuth credentials, shared with the pi-ai adapter. */
    readonly store: FileCredentialStore;
    private readonly pending;
    constructor(ctx: Context);
    /**
     * Every installed catalog provider whose auth offers OAuth — minus the
     * withheld ones. Anthropic's flow ships in pi-ai but subscription use in
     * third-party agents is barred by its terms today (scope decision 3: key
     * only, standing investigation); offering the button would invite a
     * violation, so it is withheld here rather than hidden downstream.
     * @returns each offered provider's id, display name, whether sign-in is its only auth, and optional login label.
     */
    oauthProviders(): {
        id: string;
        name: string;
        keyless: boolean;
        loginLabel?: string;
    }[];
    /**
     * Current status for the sign-in surface.
     * @returns one row per offered provider: stored, pending, and last error.
     */
    status(): Promise<OAuthProviderStatus[]>;
    /**
     * Start (or join) one provider's login flow. Resolves with the authorize
     * URL as soon as the flow surfaces it; the flow itself continues until the
     * local callback settles it, after which pi-ai has persisted the credential
     * into the store.
     * @param providerId - a catalog provider with OAuth auth.
     * @returns the URL the user's browser must open.
     */
    login(providerId: string): Promise<string>;
    /**
     * Delete one provider's stored credential and clear its attempt record.
     * @param providerId - The provider to sign out of.
     */
    logout(providerId: string): Promise<void>;
}
/** Provide the service, and the sign-in surface when the webserver is composed. */
export declare function apply(ctx: Context): void;
//# sourceMappingURL=index.d.ts.map