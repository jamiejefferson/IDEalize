/**
 * The /idealize/signin page: a self-contained branded page listing OAuth
 * providers with sign-in/sign-out actions against the pack's endpoints.
 * Deliberately dependency-free (inline CSS in the IDEalize palette, plain
 * fetch) so it works before any client bundle loads.
 */
/**
 * Render the sign-in page.
 * @returns the complete HTML document.
 */
export declare function signinPage(): string;
//# sourceMappingURL=signin-page.d.ts.map