/**
 * File-backed pi-ai credential store: one JSON document under the Harness
 * home, mode 0600, one credential per provider id. Changes serialize per
 * provider through a promise chain (pi-ai's InMemoryCredentialStore contract),
 * so a slow token refresh holds up only its own provider. Every provider shares
 * the one document, so each read-then-write of it also takes a turn on a chain
 * of its own. The whole-file write is atomic (temp file + rename) so a crash
 * never leaves a torn document holding refresh tokens.
 */
import type { Credential, CredentialInfo, CredentialStore } from '@earendil-works/pi-ai';
/** The store document filename inside the Harness home. */
export declare const OAUTH_STORE_FILENAME = ".idealize-oauth.json";
/**
 * Resolve the store path for one Harness home.
 * @param dshHome - the harness home directory.
 * @returns the absolute path of the OAuth document under it.
 */
export declare function oauthStorePath(dshHome: string): string;
/** pi-ai's `CredentialStore` over one JSON document, with per-provider serialised writes. */
export declare class FileCredentialStore implements CredentialStore {
    private readonly path;
    private readonly chains;
    private edits;
    constructor(path: string);
    private readAll;
    private writeAll;
    /** Read the document, change it and write it back, one change at a time across every provider. */
    private edit;
    /** Serialize tasks per provider id. */
    private enqueue;
    read(providerId: string): Promise<Credential | undefined>;
    list(): Promise<readonly CredentialInfo[]>;
    modify(providerId: string, fn: (current: Credential | undefined) => Promise<Credential | undefined>): Promise<Credential | undefined>;
    delete(providerId: string): Promise<void>;
}
//# sourceMappingURL=store.d.ts.map