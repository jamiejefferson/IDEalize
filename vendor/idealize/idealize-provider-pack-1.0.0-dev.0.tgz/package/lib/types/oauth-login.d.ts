/**
 * The pi-ai OAuth login driver: start (or join) one provider's flow and wait
 * for the page the person must open. Every path here runs a live provider
 * handshake — a PKCE authorize URL served to a localhost callback, or a
 * device-code poll — so the module is driven by the sign-in walk against the
 * packaged app rather than by an offline harness.
 * @module @idealize/provider-pack/src/oauth-login
 */
import type { PendingLogin } from './pending.ts';
import type { FileCredentialStore } from './store.ts';
/**
 * Start (or join) one provider's login flow. Resolves with the authorize URL
 * as soon as the flow surfaces it; the flow itself continues until the local
 * callback settles it, after which pi-ai has persisted the credential.
 * @param store - the credential store pi-ai writes the result into.
 * @param pending - the live attempts, keyed by provider id.
 * @param providerId - a catalog provider with OAuth auth.
 * @returns the URL the user's browser must open.
 */
export declare function startOAuthLogin(store: FileCredentialStore, pending: Map<string, PendingLogin>, providerId: string): Promise<string>;
//# sourceMappingURL=oauth-login.d.ts.map