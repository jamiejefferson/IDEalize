/**
 * The launch layer's centred mark: the square IDEalize logo card (V0's app
 * mark, Paper "Welcome Option B" brand row, 2026-08-20), copied from
 * ui-primitives' BrandMark — the client bundle purity gate forbids a value
 * import from @deepseek-ai/*, so the card ships as this package's own asset.
 */
/** The 116x116 card PNG as a data URI. */
export declare const LAUNCH_MARK_URI: string;
//# sourceMappingURL=launch-mark.d.ts.map