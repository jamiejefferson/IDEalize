/**
 * The launch park/play state machine. Parked while any OTHER shell.overlay
 * occupant is actively rendering (first-run onboarding, the tour, the
 * shortcuts sheet), it plays exactly once when the last one clears: the body
 * arming attribute goes on (the injected sheet's and ui-bar's keyframes are
 * gated on it), and after the sequence budget the attribute comes off and the
 * phase settles to 'done', so the animations can never replay on a later
 * re-render. Under prefers-reduced-motion the machine starts settled: no logo
 * layer, no beats, panels render in their final state.
 *
 * "Actively rendering" is read from the DOM, not the slot registry: the tour
 * occupant stays registered from boot and renders null while idle, so entry
 * presence says nothing about visibility. The machine watches the
 * `div[data-slot="shell.overlay"]` container's element children — every child
 * other than this package's own layer root or a crash face is an active
 * occupant — which decouples the machine from any specific overlay package.
 */
import { type SnapshotStore } from '@deepseek-ai/dsh-client-runtime/client';
/** Park/play/settled states of one app launch. */
export type LaunchPhase = 'parked' | 'playing' | 'done';
/** The body attribute that arms the panel keyframes while it reads "playing". */
export declare const LAUNCH_BODY_ATTRIBUTE = "data-idealize-launch";
/**
 * Attribute on this package's own layer root, excluded from the foreign-occupant
 * count. LaunchOverlay.tsx renders it; the overlay spec pins the pairing.
 */
export declare const LAUNCH_LAYER_ATTRIBUTE = "data-idealize-launch-layer";
/** Beat the parked logo holds after the overlay clears, so the mark reads as a beat, not a flash. */
export declare const LAUNCH_DWELL_MS = 250;
/**
 * From arming to the last panel beat's end (logo fade 350ms + staggered
 * slides; launch-sheet.ts and ui-bar's rail keyframe carry the matching values).
 */
export declare const LAUNCH_SEQUENCE_MS = 850;
/** The machine's observable phase plus its lifecycle. */
export interface LaunchMachine {
    /** Phase store the overlay occupant reads through its injected hook. */
    readonly phases: SnapshotStore<LaunchPhase>;
    /** Begin: park until the overlay container clears, or settle instantly under reduced motion. */
    start(): void;
    /** Tear down observers, timers, and the body attribute. */
    dispose(): void;
}
/**
 * Create the machine. Observers and timers install on {@link LaunchMachine.start}.
 * @returns the machine behind the overlay occupant and the body arming attribute.
 */
export declare function createLaunchMachine(): LaunchMachine;
//# sourceMappingURL=launch-machine.d.ts.map