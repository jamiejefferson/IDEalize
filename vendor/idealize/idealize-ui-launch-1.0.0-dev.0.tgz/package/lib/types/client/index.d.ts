/**
 * IDEalize opening sequence, browser half. Two parts share one park/play
 * machine (launch-machine.ts): the shell.overlay occupant `idealize-launch`
 * (order 10 — below the tour's 90 and first-run onboarding's 95, so those
 * paint above the logo layer) renders the centred brand card bridging the
 * boot splash, and one injected global stylesheet keyframes the existing
 * `data-idealize-surface` hooks (sessions slides from the left, chat from the
 * right; the rail animates itself in ui-bar). The machine arms the beats by
 * setting `data-idealize-launch="playing"` on the body exactly once per
 * launch: it stays parked while any other shell.overlay occupant is actively
 * rendering and plays when the last one clears. prefers-reduced-motion skips
 * every beat.
 */
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
/** Required services. */
export declare const inject: string[];
/**
 * Client plugin body: the panel-beat sheet, the park/play machine, and the
 * logo-layer occupant.
 * @param ctx - client root context.
 */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map