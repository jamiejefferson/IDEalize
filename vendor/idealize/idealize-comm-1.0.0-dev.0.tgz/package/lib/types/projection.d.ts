/**
 * The agent-name session event and its projection. The name reaches the
 * model (the chat is told who it is), so it is logged; the projection lets
 * clients show it beside the title without reading the log.
 */
import type { SessionEvent } from '@deepseek-ai/dsh-session';
import type { ProjectionDefinition } from '@deepseek-ai/dsh-session-projection';
import type { AgentNameProjection } from './projection-types.ts';
export type { AgentNameEventData, AgentNameProjection } from './projection-types.ts';
/** The `agentName` session projection: the latest `idealize/agent-name` event's name. */
export declare const agentNameProjectionDefinition: ProjectionDefinition<'agentName', AgentNameProjection>;
/**
 * The latest name in a session log.
 * @param events - the session's events, oldest first.
 * @returns the last assigned name, or undefined before any assignment.
 */
export declare function foldAgentName(events: readonly SessionEvent[]): string | undefined;
//# sourceMappingURL=projection.d.ts.map