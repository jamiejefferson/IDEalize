/**
 * `ctx.idealizeComm` — the command surface's host half. Builds the session
 * roster (live agents plus persisted sessions), answers every wire command,
 * and raises the shell-facing events (mail, notify, focus, reveal) through
 * typed Cordis events and, when composed, the host bridge feed.
 */
import { Context, Service } from '@deepseek-ai/cordis';
import type { Agent } from '@deepseek-ai/dsh-agent';
import { createUserMessage } from '@deepseek-ai/dsh-llm';
import type { SessionEvent } from '@deepseek-ai/dsh-session';
import type { Session } from '@deepseek-ai/dsh-session';
import type { SpaceId } from '@idealize/spaces';
import type { StudioEvent } from '@idealize/studio';
import type { SessionRecord } from './resolve.ts';
import { NoteLog } from './note-log.ts';
import type { NoteLogEntry } from './note-log.ts';
import type { CommStore } from './store.ts';
import type { CommConfig } from './config.ts';
import type { CommRole } from './store.ts';
import type { CommExchange, CommMessage, CommRequest, CommResponse } from './wire.ts';
declare module '@deepseek-ai/dsh-llm' {
    interface MessageSourceMap {
        /**
         * A brief another chat wrote to start this one. The chat's own composer
         * never produces it, so nothing that reads `user` as the person's word
         * (skill gestures, goal authority, the Studio post) takes it as theirs.
         */
        'chat-brief': ChatBriefSource;
    }
}
/** Where a brief came from, as the durable log records it. */
export interface ChatBriefSource {
    kind: 'chat-brief';
    form: 'notice';
    /** The collapsed row's line in the chat, naming the sender. */
    summary: string;
    /** The session the sender's key proved, when the roster knows it. */
    senderSessionId?: string;
    /** The sender's name as the person knows it. */
    senderLabel: string;
    /** The brief alone, without the line saying who wrote it, for views that show what was asked. */
    brief: string;
}
declare module '@deepseek-ai/cordis' {
    interface Context {
        idealizeComm: IdealizeComm;
    }
    interface Events {
        /**
         * A message landed in a session's mailbox; the unread count is the badge.
         * @mode emit
         * @param sessionId - the recipient.
         * @param message - what arrived.
         * @param unread - the recipient's mailbox size after delivery.
         */
        'idealize/comm-mail'(sessionId: string, message: CommMessage, unread: number): void;
        /**
         * A chat asked for a system notification (`idealize notify`).
         * @mode emit
         * @param title - the notification title, already carrying the sender's label.
         * @param body - the notification text.
         * @param sound - whether the sender asked for a sound.
         */
        'idealize/comm-notify'(title: string, body: string, sound: boolean): void;
        /**
         * A chat asked the shell to bring a session to the front (`idealize focus`).
         * @mode emit
         * @param sessionId - the session to show.
         */
        'idealize/comm-focus'(sessionId: string): void;
        /**
         * A chat pointed the person at a file (`idealize reveal`).
         * @mode emit
         * @param path - the absolute, symlink-resolved file path.
         * @param open - whether to open it in the viewer as well as select it.
         * @param sessionId - the session whose project holds the file.
         */
        'idealize/comm-reveal'(path: string, open: boolean, sessionId: string): void;
    }
}
/**
 * What an idle coordinator is told when Studio changes while its mailbox was
 * empty; everything later piles up quietly until the inbox drains.
 */
export declare const WAKE_NOTICE = "Studio changed while you were idle. Run `idealize inbox` for what happened, `idealize chat` for the group chat, and `idealize studio` for the board.";
/**
 * What an idle agent is told when a note reaches its empty mailbox; later
 * notes pile up quietly until the inbox drains (the coordinator's rule).
 *
 * A note can release a waiting chat: one told to pause until another had
 * finished read that chat's "I've finished" as information and kept waiting
 * for the person to say so (JJ, 22 Sep 2026). A note carries no more than that.
 * Anything destructive, outward-facing or outside the project needs the person
 * in the receiving chat, because a note can be written by an agent that read
 * hostile text (JJ, 9 Oct 2026, reversing part of the 22 Sep rule).
 */
export declare const MAIL_NOTICE: string;
/**
 * What an idle agent is told when the person's note, typed in the Studio,
 * reaches its empty mailbox: the answer belongs in the Studio, where the
 * person is reading, so the notice names `idealize post` as the reply.
 */
export declare const STUDIO_MAIL_NOTICE = "A note from the person, sent from the Studio, arrived while you were idle. Run `idealize inbox` (or call `idealize_inbox`) to read it, then answer in the Studio with `idealize post <text>` (or `idealize_post`), not only here.";
/** The label a Studio-origin note carries in the inbox and on the bridge feed. */
export declare const STUDIO_SENDER_LABEL = "Studio";
/**
 * The artefacts a turn stored, as one clause per media kind in first-seen
 * order: "2 images and a video".
 *
 * The clause used to carry each record's uuid, which is the artefact store's
 * key and means nothing to a reader — a line in the project's group chat read
 * as "generated 3 images (ea340464-9de1-4426-…, …)" and the count vanished
 * behind the ids (JJ, 11 Sep 2026). The ids stay in the artefact records an
 * agent lists; the chat line says what happened.
 * @param records - the stored artefacts, in log order.
 * @returns the clause, never empty for a non-empty list.
 */
export declare function describeArtefacts(records: readonly {
    id: string;
    mediaType: string;
}[]): string;
/** One roster entry with what `list` and the handlers need beyond addressing. */
export interface RosterEntry extends SessionRecord {
    running: boolean;
    live: Agent | undefined;
}
/**
 * The space a spawn asks for, by its id or the word a person uses for it.
 * @param said - `images`, `sounds`, `video`, `chat`, or a space id.
 * @returns the launchable space, or undefined when the word names none.
 */
export declare function spaceOfRequest(said: string): SpaceId | undefined;
/**
 * The opening message of a chat another chat started: marked with its true
 * source, naming the sender for the person in the chat row and for the model
 * in the text, since a model reads every message as user-role text and sees
 * no source field. It stops being the person's own message because a brief can
 * be written by an agent that read hostile text (security pass, 4 Nov 2026).
 * @param brief - the brief as the sender wrote it.
 * @param sender - the sending chat, undefined when the roster does not hold it (a subagent's shell).
 * @param senderId - the session the sender's key proved.
 * @returns the message to follow up with.
 */
export declare function chatBriefMessage(brief: string, sender: {
    name?: string;
    label: string;
} | undefined, senderId: string | undefined): ReturnType<typeof createUserMessage>;
/**
 * Fold a session log into Q/A exchanges: each person-authored user message or
 * another chat's opening brief opens one, the assistant text that follows
 * (until the next question) answers it.
 * @param events - the session log.
 * @returns exchanges in order, indexed from 1.
 */
export declare function foldExchanges(events: readonly SessionEvent[]): CommExchange[];
/** The `idealize` command service: agent naming, roles, the roster, and mailbox delivery behind `POST /idealize/comm`. */
/** Who sent a wire request, as the host's launch gate proved it. */
export interface CommCaller {
    /** True when a chat's shell sent it (the `idealize` command), false for the app itself. */
    shell: boolean;
    /** The sender the request's body named, before the host stamped the proven one. */
    claimedFrom?: string;
}
export declare class IdealizeComm extends Service {
    /** The current settings section (preset→role mapping, background post window); the plugin swaps this for the settings source. */
    config: () => CommConfig;
    private readonly store;
    /** Every note, kept after its inbox is read. */
    private readonly noteLog;
    private readonly noteLimiter;
    private readonly attentionLimiter;
    /** Image, sound and video chats started by chats in this launch. */
    private mediaSpawns;
    /** Background generations awaiting their one Studio line, keyed by session id. */
    private readonly pendingBackground;
    /**
     * The messaging rules for a command-line agent in a Terminal chat. Claude
     * Code and Codex read no system prompt of IDEalize's, so until 8 Oct 2026
     * they were never told how notes work or that a note is cut at the wire's
     * limit. `@idealize/ui-terminal` passes this on the CLI's launch line.
     * @returns the same text every harness agent carries in its prompt.
     */
    terminalKnowledge(): string;
    /**
     * Type a wake line into a chat's terminal, when the chat has one open.
     * Held lines are dropped once the agent has read its inbox.
     * @param sessionId - the recipient chat.
     * @param text - the notice.
     * @returns true when the chat has a terminal, so its own agent is not woken.
     */
    private nudgeTerminal;
    /** The terminal plugin, when composed; probed by name because comm takes no dependency on it. */
    private terminals;
    /**
     * Whether every agent is paused (feedback 495cec0a): while it holds, notes
     * still land in their inboxes and wake nobody, and Resume wakes the chats
     * whose inbox filled meanwhile ({@link releaseHeldMail}).
     * @returns true from Pause until Resume.
     */
    private held;
    /**
     * Resume's half of the wake hold: every chat outside `skip` with notes
     * waiting is woken the way its first note would have woken it. A stored chat
     * stays asleep, as it would have without the pause.
     * @param skip - the chats Resume is already telling to carry on.
     */
    releaseHeldMail(skip: ReadonlySet<string>): Promise<void>;
    constructor(ctx: Context, options: {
        store: CommStore;
        config: () => CommConfig;
        noteLog?: NoteLog;
    });
    /** The durable state, for listeners the plugin wires around this service. */
    get state(): CommStore;
    /** Name draws in flight, so `session/created` and session start cannot both draw for one session. */
    private readonly naming;
    /**
     * Give a session its agent name if it has none: the project's pool is
     * recorded on first use and the draw is logged to the session so the model
     * and the sidebar both learn it.
     * @param session - the session to name.
     * @returns the name, new or existing.
     */
    ensureName(session: Session): Promise<string>;
    private drawName;
    /**
     * Record a role for a session whose preset carries one and give it the
     * role's task title. No-op for presets outside the mapping.
     * @param session - the session to take the role.
     * @param presetId - the session's preset id, matched against the role mapping.
     * @returns the adopted role, or `undefined` when the preset carries none.
     */
    adoptRole(session: Session, presetId: string | undefined): Promise<CommRole | undefined>;
    /**
     * Every addressable session: live agents first, then persisted sessions not currently live.
     * @returns the roster entries in address order.
     */
    /**
     * Every addressable chat. The Studio chat (the `studio` space) is the
     * person's own seat and never lists: it is neither named nor a delivery
     * target.
     * @returns the roster, live chats first.
     */
    roster(): Promise<RosterEntry[]>;
    /**
     * The notice naming the other chats open in a new chat's project.
     * @param session - the new chat.
     * @returns the notice, or undefined when it is alone there.
     */
    peers(session: Session): Promise<string | undefined>;
    private info;
    /**
     * Add one line to the note log. A full or unwritable disk must not stop chats
     * talking to each other, so a failed write is logged and dropped.
     * @param entry - the act to record.
     */
    private logNote;
    /** Record a chat's refused attempt. */
    private logRefusal;
    private deliver;
    /**
     * The board's rows, newest first.
     * @param scope - the project folder to keep, or undefined for every project.
     * @returns the board response.
     */
    private board;
    /**
     * Answer one wire request. Never throws for a caller mistake; those come back as `ok: false`.
     * A chat's shell also answers to the note limits, and what it tries past
     * its bounds goes in the note log.
     * @param request - the command envelope from the wire.
     * @param caller - who the host's launch gate proved sent it.
     * @returns the command's response payload.
     */
    handle(request: CommRequest, caller?: CommCaller): Promise<CommResponse>;
    /**
     * The app's lines of the note log, newest last, for the Studio to show.
     * @param limit - how many to return, at most 1000.
     * @returns the entries.
     */
    noteHistory(limit: number): Promise<NoteLogEntry[]>;
    private answer;
    /**
     * The Studio task commands: assignments and reports write the project's
     * timeline through `ctx.idealizeStudio`; `studio` reads its folded state.
     * Reports record structured events and invoke nobody — routine status stays
     * off every other model's context until that chat reads the board itself.
     */
    private studioCommand;
    private eventsOf;
    /**
     * Whether a chat's shell may read another chat's transcript: its own, any in
     * its project, and any for the Studio manager, which spans every project.
     * @param me - the reading chat, undefined when the roster does not hold it.
     * @param other - the chat to read.
     * @returns true when the read stays in bounds.
     */
    private mayRead;
    /**
     * Put a line from a chat in front of the person, the only way a chat's shell
     * reaches their attention: a request naming them on the project's Studio
     * timeline, under the chat's own name, which `@idealize/notify` raises as an
     * alert (the `needs-input` row of its table). Nothing on screen moves until
     * they open it.
     * @param me - the asking chat.
     * @param text - what it asks.
     * @returns true when the line reached a timeline.
     */
    private askPerson;
    private reveal;
    /**
     * The one-line mailbox note a Studio event earns, or undefined for the
     * events that must not invoke anyone (FR-P0-15: routine status changes the
     * fold and wakes nobody).
     * @param event - the committed Studio event.
     * @returns the note, or undefined when the event is not a wake trigger.
     */
    private wakeLine;
    /**
     * Wake the project's coordinator for a qualifying Studio event: a mailbox
     * note always, plus one model invocation when the coordinator is live,
     * idle, and had an empty mailbox — so a burst invokes it once and the rest
     * waits in the inbox. The event's own author is never woken.
     * @param event - the committed Studio event.
     */
    wakeCoordinator(event: StudioEvent): Promise<void>;
    /**
     * The safety net under the prompt's posting rule: when a turn that called a
     * generation tool ends and the agent posted nothing to the Studio during it,
     * one `idealize`-authored `message` on the project's timeline says who
     * generated what, with the artefact ids, and links the agent's chat through
     * `source.thread`. Nothing is recorded for a turn with no generation call,
     * a generation that stored no artefact (its failure is in the agent's own
     * chat), a chat outside a project, the Studio chat, or a turn in which the
     * agent posted itself (any `message` it authored, a `rung` line included).
     * The system author keeps the coordinator asleep: the line reports an act
     * and asks nobody to do anything. An artefact stored after the turn ended
     * (a `run_in_background` generation) takes the {@link noteBackgroundArtefact} path.
     * @param session - the session whose turn ended; its log is read up to that turn's end.
     * @param turn - the ended turn's number.
     * @returns the recorded line, or undefined when nothing was recorded.
     */
    reportFinishedTurn(session: Session, turn: number): Promise<string | undefined>;
    /**
     * The safety net's second path: a generation tool run with
     * `run_in_background` stores its artefacts after the turn that started it
     * has ended, where {@link reportFinishedTurn} never sees them. An
     * `artefact/created` event whose record names a generation tool as its
     * source, and whose own turn (`sourceTask.turnSeq`) has already ended,
     * joins the session's pending batch; the batch's window
     * (`backgroundPostDelayMs`) restarts on every arrival, and when it closes
     * one `idealize`-authored `message` reports the batch. An artefact whose
     * own turn is still running (every foreground generation), a chat outside a
     * project, and the Studio chat are ignored.
     * Disposing the plugin, or the session ({@link forgetSession}), drops a
     * pending batch unposted.
     * @param session - the session whose log gained the event; its log decides whether a turn is open.
     * @param event - the `artefact/created` event as appended.
     */
    noteBackgroundArtefact(session: Session, event: SessionEvent<'artefact/created'>): void;
    /**
     * Drop a session's pending background batch: the session is gone, so its
     * line would name a chat the Studio row cannot open.
     * @param session - the disposed session.
     */
    forgetSession(session: Session): void;
    /**
     * Post the closed batch. The project is re-read at post time in case the
     * session's log changed while the window was open.
     * @returns the recorded line, or undefined when the Studio is not composed or the session no longer posts.
     */
    private postBackgroundBatch;
    /**
     * Record one system-authored line on the project's timeline, naming the
     * agent from the store, else the log, else the session id, and linking the
     * chat through `source.thread`.
     * @returns the recorded body, or undefined when no Studio service is composed.
     */
    private postSystemLine;
    /**
     * Start a new chat in a project with an opening brief. The child opens in
     * the background (no focus event), so the caller keeps the person's
     * attention; its task title is the caller's `--name`, else one read off the
     * brief. `--coordinator` starts the role chat on its Activity Agent
     * instead, or answers the existing one's id (one coordinator per project).
     */
    /**
     * What a role's chat is composed from: the agent registry, the role's
     * Activity Agent preset (when presets are composed) and the model, the
     * default selection unless the request names one. Shared by a fresh spawn
     * and a resume so the two never drift.
     */
    private composition;
    /**
     * Resume a stored role chat on its own persisted history, composed as a
     * fresh one would be, and wake it once when its mailbox already holds
     * mail: `send` invokes only a live recipient with exactly one unread note,
     * so a backlog left from an earlier run would otherwise wait for the
     * person's next note and then still not be read.
     * @param existing - the stored roster entry (not live).
     * @param role - the role it carries.
     * @param model - the model the request names, if any.
     * @returns the resumed session's id, or why it could not be resumed.
     */
    private revive;
    private spawn;
}
//# sourceMappingURL=service.d.ts.map