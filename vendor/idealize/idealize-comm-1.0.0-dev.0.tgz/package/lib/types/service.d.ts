/**
 * `ctx.idealizeComm` — the command surface's host half. Builds the session
 * roster (live agents plus persisted sessions), answers every wire command,
 * and raises the shell-facing events (mail, notify, focus, reveal) through
 * typed Cordis events and, when composed, the host bridge feed.
 */
import { Context, Service } from '@deepseek-ai/cordis';
import type { Agent } from '@deepseek-ai/dsh-agent';
import type { SessionEvent } from '@deepseek-ai/dsh-session';
import type { Session } from '@deepseek-ai/dsh-session';
import type { StudioEvent } from '@idealize/studio';
import type { SessionRecord } from './resolve.ts';
import type { CommStore } from './store.ts';
import type { CommConfig } from './config.ts';
import type { CommRole } from './store.ts';
import type { CommExchange, CommMessage, CommRequest, CommResponse } from './wire.ts';
declare module '@deepseek-ai/cordis' {
    interface Context {
        idealizeComm: IdealizeComm;
    }
    interface Events {
        /**
         * A message landed in a session's mailbox; the unread count is the badge.
         * @mode emit
         * @param sessionId - the recipient.
         * @param message - what arrived.
         * @param unread - the recipient's mailbox size after delivery.
         */
        'idealize/comm-mail'(sessionId: string, message: CommMessage, unread: number): void;
        /**
         * A chat asked for a system notification (`idealize notify`).
         * @mode emit
         * @param title - the notification title, already carrying the sender's label.
         * @param body - the notification text.
         * @param sound - whether the sender asked for a sound.
         */
        'idealize/comm-notify'(title: string, body: string, sound: boolean): void;
        /**
         * A chat asked the shell to bring a session to the front (`idealize focus`).
         * @mode emit
         * @param sessionId - the session to show.
         */
        'idealize/comm-focus'(sessionId: string): void;
        /**
         * A chat pointed the person at a file (`idealize reveal`).
         * @mode emit
         * @param path - the absolute, symlink-resolved file path.
         * @param open - whether to open it in the viewer as well as select it.
         * @param sessionId - the session whose project holds the file.
         */
        'idealize/comm-reveal'(path: string, open: boolean, sessionId: string): void;
    }
}
/**
 * What an idle coordinator is told when Studio changes while its mailbox was
 * empty; everything later piles up quietly until the inbox drains.
 */
export declare const WAKE_NOTICE = "Studio changed while you were idle. Run `idealize inbox` for what happened, `idealize chat` for the group chat, and `idealize studio` for the board.";
/**
 * What an idle agent is told when a note reaches its empty mailbox; later
 * notes pile up quietly until the inbox drains (the coordinator's rule).
 */
export declare const MAIL_NOTICE = "A note from another agent arrived while you were idle. Run `idealize inbox` to read it and `idealize send <agent> <text>` to answer.";
/**
 * What an idle agent is told when the person's note, typed in the Studio,
 * reaches its empty mailbox: the answer belongs in the Studio, where the
 * person is reading, so the notice names `idealize post` as the reply.
 */
export declare const STUDIO_MAIL_NOTICE = "A note from the person, sent from the Studio, arrived while you were idle. Run `idealize inbox` to read it, then answer in the Studio with `idealize post <text>`, not only here.";
/** The label a Studio-origin note carries in the inbox and on the bridge feed. */
export declare const STUDIO_SENDER_LABEL = "Studio";
/**
 * The artefacts a turn stored, as one clause per media kind in first-seen
 * order: "2 images and a video".
 *
 * The clause used to carry each record's uuid, which is the artefact store's
 * key and means nothing to a reader — a line in the project's group chat read
 * as "generated 3 images (ea340464-9de1-4426-…, …)" and the count vanished
 * behind the ids (JJ, 11 Sep 2026). The ids stay in the artefact records an
 * agent lists; the chat line says what happened.
 * @param records - the stored artefacts, in log order.
 * @returns the clause, never empty for a non-empty list.
 */
export declare function describeArtefacts(records: readonly {
    id: string;
    mediaType: string;
}[]): string;
/** One roster entry with what `list` and the handlers need beyond addressing. */
interface RosterEntry extends SessionRecord {
    running: boolean;
    live: Agent | undefined;
}
/**
 * Fold a session log into Q/A exchanges: each person-authored user message
 * opens one, the assistant text that follows (until the next question)
 * answers it.
 * @param events - the session log.
 * @returns exchanges in order, indexed from 1.
 */
export declare function foldExchanges(events: readonly SessionEvent[]): CommExchange[];
/** The `idealize` command service: agent naming, roles, the roster, and mailbox delivery behind `POST /idealize/comm`. */
export declare class IdealizeComm extends Service {
    /** The current settings section (preset→role mapping, background post window); the plugin swaps this for the settings source. */
    config: () => CommConfig;
    private readonly store;
    /** Background generations awaiting their one Studio line, keyed by session id. */
    private readonly pendingBackground;
    constructor(ctx: Context, options: {
        store: CommStore;
        config: () => CommConfig;
    });
    /** The durable state, for listeners the plugin wires around this service. */
    get state(): CommStore;
    /** Name draws in flight, so `session/created` and session start cannot both draw for one session. */
    private readonly naming;
    /**
     * Give a session its agent name if it has none: the project's pool is
     * recorded on first use and the draw is logged to the session so the model
     * and the sidebar both learn it.
     * @param session - the session to name.
     * @returns the name, new or existing.
     */
    ensureName(session: Session): Promise<string>;
    private drawName;
    /**
     * Record a role for a session whose preset carries one and give it the
     * role's task title. No-op for presets outside the mapping.
     * @param session - the session to take the role.
     * @param presetId - the session's preset id, matched against the role mapping.
     * @returns the adopted role, or `undefined` when the preset carries none.
     */
    adoptRole(session: Session, presetId: string | undefined): Promise<CommRole | undefined>;
    /**
     * Every addressable session: live agents first, then persisted sessions not currently live.
     * @returns the roster entries in address order.
     */
    /**
     * Every addressable chat. The Studio chat (the `studio` space) is the
     * person's own seat and never lists: it is neither named nor a delivery
     * target.
     * @returns the roster, live chats first.
     */
    roster(): Promise<RosterEntry[]>;
    private info;
    private deliver;
    /**
     * The board's rows, newest first.
     * @param scope - the project folder to keep, or undefined for every project.
     * @returns the board response.
     */
    private board;
    /**
     * Answer one wire request. Never throws for a caller mistake; those come back as `ok: false`.
     * @param request - the command envelope from the wire.
     * @returns the command's response payload.
     */
    handle(request: CommRequest): Promise<CommResponse>;
    /**
     * The Studio task commands: assignments and reports write the project's
     * timeline through `ctx.idealizeStudio`; `studio` reads its folded state.
     * Reports record structured events and invoke nobody — routine status stays
     * off every other model's context until that chat reads the board itself.
     */
    private studioCommand;
    private eventsOf;
    private reveal;
    /**
     * The one-line mailbox note a Studio event earns, or undefined for the
     * events that must not invoke anyone (FR-P0-15: routine status changes the
     * fold and wakes nobody).
     * @param event - the committed Studio event.
     * @returns the note, or undefined when the event is not a wake trigger.
     */
    private wakeLine;
    /**
     * Wake the project's coordinator for a qualifying Studio event: a mailbox
     * note always, plus one model invocation when the coordinator is live,
     * idle, and had an empty mailbox — so a burst invokes it once and the rest
     * waits in the inbox. The event's own author is never woken.
     * @param event - the committed Studio event.
     */
    wakeCoordinator(event: StudioEvent): Promise<void>;
    /**
     * The safety net under the prompt's posting rule: when a turn that called a
     * generation tool ends and the agent posted nothing to the Studio during it,
     * one `idealize`-authored `message` on the project's timeline says who
     * generated what, with the artefact ids, and links the agent's chat through
     * `source.thread`. Nothing is recorded for a turn with no generation call,
     * a generation that stored no artefact (its failure is in the agent's own
     * chat), a chat outside a project, the Studio chat, or a turn in which the
     * agent posted itself (any `message` it authored, a `rung` line included).
     * The system author keeps the coordinator asleep: the line reports an act
     * and asks nobody to do anything. An artefact stored after the turn ended
     * (a `run_in_background` generation) takes the {@link noteBackgroundArtefact} path.
     * @param session - the session whose turn ended; its log is read up to that turn's end.
     * @param turn - the ended turn's number.
     * @returns the recorded line, or undefined when nothing was recorded.
     */
    reportFinishedTurn(session: Session, turn: number): Promise<string | undefined>;
    /**
     * The safety net's second path: a generation tool run with
     * `run_in_background` stores its artefacts after the turn that started it
     * has ended, where {@link reportFinishedTurn} never sees them. An
     * `artefact/created` event whose record names a generation tool as its
     * source, and whose own turn (`sourceTask.turnSeq`) has already ended,
     * joins the session's pending batch; the batch's window
     * (`backgroundPostDelayMs`) restarts on every arrival, and when it closes
     * one `idealize`-authored `message` reports the batch. An artefact whose
     * own turn is still running (every foreground generation), a chat outside a
     * project, and the Studio chat are ignored.
     * Disposing the plugin, or the session ({@link forgetSession}), drops a
     * pending batch unposted.
     * @param session - the session whose log gained the event; its log decides whether a turn is open.
     * @param event - the `artefact/created` event as appended.
     */
    noteBackgroundArtefact(session: Session, event: SessionEvent<'artefact/created'>): void;
    /**
     * Drop a session's pending background batch: the session is gone, so its
     * line would name a chat the Studio row cannot open.
     * @param session - the disposed session.
     */
    forgetSession(session: Session): void;
    /**
     * Post the closed batch. The project is re-read at post time in case the
     * session's log changed while the window was open.
     * @returns the recorded line, or undefined when the Studio is not composed or the session no longer posts.
     */
    private postBackgroundBatch;
    /**
     * Record one system-authored line on the project's timeline, naming the
     * agent from the store, else the log, else the session id, and linking the
     * chat through `source.thread`.
     * @returns the recorded body, or undefined when no Studio service is composed.
     */
    private postSystemLine;
    /**
     * Start a new chat in a project with an opening brief. The child opens in
     * the background (no focus event), so the caller keeps the person's
     * attention; its task title is the caller's `--name`, else one read off the
     * brief. `--coordinator` starts the role chat on its Activity Agent
     * instead, or answers the existing one's id (one coordinator per project).
     */
    /**
     * What a role's chat is composed from: the agent registry, the role's
     * Activity Agent preset (when presets are composed) and the model, the
     * default selection unless the request names one. Shared by a fresh spawn
     * and a resume so the two never drift.
     */
    private composition;
    /**
     * Resume a stored role chat on its own persisted history, composed as a
     * fresh one would be, and wake it once when its mailbox already holds
     * mail: `send` invokes only a live recipient with exactly one unread note,
     * so a backlog left from an earlier run would otherwise wait for the
     * person's next note and then still not be read.
     * @param existing - the stored roster entry (not live).
     * @param role - the role it carries.
     * @param model - the model the request names, if any.
     * @returns the resumed session's id, or why it could not be resumed.
     */
    private revive;
    private spawn;
}
export {};
//# sourceMappingURL=service.d.ts.map