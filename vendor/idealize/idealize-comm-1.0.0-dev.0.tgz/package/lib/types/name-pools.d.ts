/**
 * The twelve agent-name pools (496 unique names). A project draws its chat
 * names from one pool, so names never repeat inside a project and two
 * projects on different pools never clash. Source: JJ's project-name-pools.md.
 */
/** Twelve pools of 41 or 42 names each. */
export declare const NAME_POOLS: readonly (readonly string[])[];
//# sourceMappingURL=name-pools.d.ts.map