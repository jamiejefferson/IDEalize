/**
 * `ctx.idealizePause` — pausing every agent (feedback 495cec0a) on a live
 * host: {@link PauseController}'s rules over the agents, the Terminal chats'
 * shells, the documentation folder, the schedule and the mailboxes. Every
 * service outside this package is probed by name, so comm takes no new
 * dependency: a composition without terminals, notes or a schedule pauses the
 * chat agents it has.
 * @module @idealize/comm/pause-service
 */
import { Context, Service } from '@deepseek-ai/cordis';
import type { PauseSnapshot, PauseStore, PauseWorld, ShellToOpen, TerminalLineOutcome, TerminalPauseLines, WorkingChat } from './pause.ts';
declare module '@deepseek-ai/cordis' {
    interface Context {
        idealizePause: IdealizePause;
    }
}
/** {@link PauseWorld} over a live host. */
export declare class HostPauseWorld implements PauseWorld {
    private readonly ctx;
    /** @param ctx - the host context the pause acts through. */
    constructor(ctx: Context);
    private terminals;
    private live;
    /**
     * The brain a Terminal chat's shell launches: the latest it records, else
     * the preset it was created on; a stored chat answers from the projection
     * checkpoint, the way the sidebar does.
     */
    private brainOf;
    working(): Promise<WorkingChat[]>;
    saveChat(id: string, text: string): Promise<void>;
    saveTerminal(id: string, lines: TerminalPauseLines, wanted: () => boolean): Promise<TerminalLineOutcome> | undefined;
    stopChat(id: string): void;
    stopTerminal(id: string): void;
    carryOnChat(id: string, text: string): Promise<void>;
    carryOnTerminal(id: string, text: string): boolean;
    notesFolder(cwd: string): Promise<string | undefined>;
    unread(id: string): number;
    releaseSchedule(): Promise<void>;
    releaseMail(skip: ReadonlySet<string>): Promise<void>;
    announce(): void;
    warn(message: string): void;
    now(): Date;
}
/** Options a test passes to swap the host for fakes. */
export interface IdealizePauseOptions {
    world?: PauseWorld;
    store?: PauseStore;
}
/** The pause as a host service: the sidebar's routes and the desktop's quit dialog both use it. */
export declare class IdealizePause extends Service {
    private readonly controller;
    constructor(ctx: Context, options?: IdealizePauseOptions);
    /** @returns true from Pause until Resume: schedule runs and note wakes wait. */
    held(): boolean;
    /** @returns the pause as the windows show it. */
    snapshot(): Promise<PauseSnapshot>;
    /** @returns the pause after every working agent was told to save its notes. */
    pause(): Promise<PauseSnapshot>;
    /** @returns the pause after every agent still saving was interrupted. */
    stopNow(): Promise<PauseSnapshot>;
    /** @returns the pause after every paused agent was told to carry on, and the shells to open. */
    resume(): Promise<PauseSnapshot & {
        open: ShellToOpen[];
    }>;
    /**
     * @param listener - called after each change of the pause.
     * @returns a function that stops the listening.
     */
    onChange(listener: () => void): () => void;
}
//# sourceMappingURL=pause-service.d.ts.map