/**
 * Per-sender limits on what a chat's shell can send, so one chat that reads
 * hostile text or loops cannot flood other chats' inboxes, the Studio timeline
 * or the person's alerts. In memory: a limit is per launch, and restarting the
 * app clears it.
 * @module @idealize/comm/rate-limit
 */
/** One sliding window: at most `limit` sends in `windowMs`. */
export interface RateWindow {
    limit: number;
    windowMs: number;
}
/**
 * The limit on notes per sending chat, shared by everything that lands in
 * another chat's inbox or on the timeline. A coordinator telling 20 workers one
 * thing each is 20 in a burst and fits inside a minute's 30; 300 an hour is
 * that coordinator exchanging 15 notes an hour with each of the 20 for a whole
 * hour. A sequential agent spends a model call per note, so only a script in a
 * loop gets near either number.
 */
export declare const NOTE_RATE: readonly RateWindow[];
/**
 * The limit per sending chat on lines that interrupt the person (`notify`,
 * `focus`, `reveal --open`). The coordinator's guide asks for one notification
 * per decision, so 10 an hour leaves room for a busy hour and keeps a loop from
 * turning into a stream of alerts.
 */
export declare const ATTENTION_RATE: readonly RateWindow[];
/**
 * The image, sound and video chats one launch's chats may start between them.
 * A started chat can generate at the person's expense, so this bounds what a
 * chat reading hostile text can order. A project that needs more than 20 such
 * chats from its agents in one launch can start them from the space itself,
 * where the person is the one starting them.
 */
export declare const MEDIA_SPAWNS_PER_LAUNCH = 20;
/** What a check answers. */
export type RateVerdict = {
    ok: true;
}
/** `first` is true once per spell of refusals, so the note log gets one line for a flood. */
 | {
    ok: false;
    retryAfterSeconds: number;
    first: boolean;
};
/** A set of sliding windows per sender. */
export declare class SenderLimiter {
    private readonly windows;
    private readonly sent;
    private readonly refusing;
    constructor(windows: readonly RateWindow[]);
    /**
     * Count one send when it is within every window.
     * @param sender - the sending session.
     * @param now - the clock.
     * @returns whether the send may go.
     */
    take(sender: string, now?: number): RateVerdict;
}
//# sourceMappingURL=rate-limit.d.ts.map