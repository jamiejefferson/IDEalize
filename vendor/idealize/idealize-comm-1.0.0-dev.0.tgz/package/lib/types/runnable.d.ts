/**
 * Whether opening a path with its default application would run it. macOS
 * LaunchServices runs a script bundle, an app or an installer, and an
 * extension-less executable opens in Terminal and runs; Windows runs its
 * script and installer types. The table matches `host.openPath`'s
 * (`@deepseek-ai/dsh-host-apiproxy`'s `runnable-path.ts`), which comm does not
 * depend on.
 * @module @idealize/comm/runnable
 */
/**
 * @param path - the absolute path about to be opened.
 * @returns true when opening it would run code.
 */
export declare function runsWhenOpened(path: string): Promise<boolean>;
//# sourceMappingURL=runnable.d.ts.map