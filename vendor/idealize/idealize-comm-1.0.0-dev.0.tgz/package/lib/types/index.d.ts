/**
 * @idealize/comm — the `idealize` command surface as host routes plus a thin
 * CLI shim. Chats (and the agents running inside them) list each other, post
 * to persistent mailboxes and to the project's group chat on the Studio
 * timeline, report where a piece stands on the rung ladder, spawn worker
 * chats with a brief, read each other's transcripts, and point the person at
 * files.
 *
 * HTTP: `POST /idealize/comm` takes one {@link CommRequest} and answers one
 * {@link CommResponse}. `GET/POST /idealize/comm/roles` reads and sets which
 * Activity Agent carries the Project Coordinator role (the Brains pane's
 * role row). Loopback-fenced; every command except `ping` demands
 * the `x-idealize-auth: 1` header. The shell environment of every tool run
 * carries `DSH_IDEALIZE_HOST` (the server origin) so the `idealize` binary
 * finds its host, and the same origin is written to
 * `<DSH_HOME>/idealize/comm-host.json` for shells started outside a session.
 *
 * @module @idealize/comm
 */
import type { IncomingMessage, ServerResponse } from 'node:http';
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import type { CommConfig } from './config.ts';
import type { CommCommand, CommRequest } from './wire.ts';
export { IdealizeComm, foldExchanges, MAIL_NOTICE, STUDIO_MAIL_NOTICE, WAKE_NOTICE } from './service.ts';
export { CommStore, commStorePath, parseCommState } from './store.ts';
export type { CommRole, CommState } from './store.ts';
export { resolveTarget } from './resolve.ts';
export { pickName, poolFor } from './names.ts';
export { NAME_POOLS } from './name-pools.ts';
export { agentNameProjectionDefinition, foldAgentName } from './projection.ts';
export type { AgentNameEventData, AgentNameProjection } from './projection.ts';
export { DEFAULT_ROLE_CONFIG, presetOfRole, ROLE_OPENING, ROLE_TITLES, roleGuide, roleOfPreset, seedRolePreset, withRolePersona } from './roles.ts';
export type { RoleConfig } from './roles.ts';
export { DEFAULT_COMM_CONFIG } from './config.ts';
export type { CommConfig } from './config.ts';
export type { Resolution, SessionRecord } from './resolve.ts';
export { chatNameFromTask, clockTime, COMM_COMMANDS, TRUNCATION_WARNING, Wire } from './wire.ts';
export type { CommCommand, CommExchange, CommMessage, CommRequest, CommResponse, CommRung, CommSessionInfo, StudioTaskRow } from './wire.ts';
export declare const name = "idealize-comm";
/**
 * Settings: which Activity Agent carries each coordinator role, and how long
 * the safety net batches a background generation's artefacts.
 */
export declare const Config: z<CommConfig>;
/**
 * The standing guidance every agent's prompt carries about the other chats
 * and the `idealize` command (order 120, the tool-guidance band). The
 * session-start notice names the chat; this section survives compaction and
 * says how to reach a peer, since without it an agent asked to post to the
 * Studio guessed at an unrelated CLI on the person's machine, and one asked
 * about "@Name" searched transcripts instead of asking (JJ, 8 Sep 2026). The
 * last two sentences are the posting rules: a finished piece of work earns
 * one Studio line, and a note from the Studio is answered in the Studio
 * (JJ, 8 Sep 2026: "when an agent completes an action I want them to post a
 * note into the studio").
 */
export declare const COMMANDS_SECTION: {
    readonly name: "idealize:commands";
    readonly order: 120;
    readonly text: string;
};
/** The environment key the CLI reads its host origin from inside a tool shell. */
export declare const HOST_ENV_KEY = "DSH_IDEALIZE_HOST";
/**
 * Where the host origin is written for shells started outside a session.
 * @param dshHome - the harness home directory.
 * @returns the absolute path of `idealize/comm-host.json` under it.
 */
export declare function commHostPath(dshHome: string): string;
/**
 * Validate one JSON body into a request; the wire boundary is where shapes
 * are checked, so the service trusts what it receives.
 * @param text - the raw request body.
 * @returns the request, or an error line.
 */
export declare function parseRequest(text: string): CommRequest | {
    error: string;
};
/**
 * Loopback + header fence; `ping` alone passes without the header.
 * @param req - the incoming request, read for its Host and auth headers.
 * @param res - the response a refusal is written to (403, plain text).
 * @param command - the parsed command, undefined when the body carried none.
 * @returns true when the response has been ended and the caller must stop.
 */
export declare function refuse(req: IncomingMessage, res: ServerResponse, command: CommCommand | undefined): boolean;
export declare function apply(ctx: Context, config?: CommConfig): void;
//# sourceMappingURL=index.d.ts.map