/**
 * Addressing: a `<session>` argument resolves by id, then by alias
 * (`coordinator`/`project-agent`, `studio-agent`), then by agent name, then by
 * label, then by project folder name. Several matches are an error naming the
 * candidates; the first match is never picked silently.
 */
import type { CommRole } from './store.ts';
/** What resolution needs to know about one session. */
export interface SessionRecord {
    id: string;
    /** The chat's agent name, once assigned. */
    name?: string;
    /** The task label: the spawn title, the live title, or the folder. */
    label: string;
    cwd?: string;
    role: CommRole | 'chat';
}
/** The outcome of resolving a target: the session, or the error line the CLI prints. */
export type Resolution = {
    ok: true;
    session: SessionRecord;
} | {
    ok: false;
    error: string;
};
/**
 * Resolve one target against a roster.
 * @param target - the id, alias, label, or folder name.
 * @param roster - every addressable session.
 * @param from - the caller's id; the `coordinator` alias means the caller's own project's.
 * @returns the matched session, or `ok: false` with the reason (unknown target, ambiguous match, no such role running).
 */
export declare function resolveTarget(target: string, roster: readonly SessionRecord[], from?: string): Resolution;
//# sourceMappingURL=resolve.d.ts.map