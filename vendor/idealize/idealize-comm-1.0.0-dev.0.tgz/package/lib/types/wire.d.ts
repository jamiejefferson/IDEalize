/**
 * The command-surface wire: request and response fields, the rung ladder,
 * the body caps, and the generated status line. Mirrors V0's IPCProtocol so
 * the agent guides written against `idealize <command>` keep working.
 */
/** Every command the surface accepts; deferred V0 commands are absent on purpose. */
export type CommCommand = 'ping' | 'list' | 'notify' | 'send' | 'inbox' | 'peek' | 'rung' | 'board' | 'spawn' | 'post' | 'chat' | 'transcript' | 'setStatus' | 'focus' | 'reveal' | 'task' | 'progress' | 'blocked' | 'need' | 'done' | 'studio' | 'handoff' | 'accept' | 'reject' | 'decide' | 'synthesis';
/** Every command the wire accepts; `parseRequest` refuses anything else. */
export declare const COMM_COMMANDS: readonly CommCommand[];
/** One request, JSON over `POST /idealize/comm`. Field names match V0's IPCRequest. */
export interface CommRequest {
    command: CommCommand;
    /** The calling session's id, from the shell's `DSH_SESSION_ID` (else `IDEALIZE_SESSION_ID`). */
    from?: string;
    target?: string;
    body?: string;
    title?: string;
    sound?: boolean;
    open?: boolean;
    limit?: number;
    name?: string;
    path?: string;
    model?: string;
    piece?: string;
    rung?: string;
    blocker?: string;
    /** spawn: start (or surface) the project's coordinator instead of a worker. */
    coordinator?: boolean;
    /**
     * spawn: start (or surface) the one Studio coordinator instead of a worker.
     * It belongs to no project, so `path` is ignored and none is required.
     */
    studio?: boolean;
    /** progress/blocked/need/done: the Studio task the report belongs to. */
    task?: string;
    /** blocked/need: who owes the response; absent leaves a blocker unassigned, and `need` defaults to the user. */
    owner?: string;
    /** need: ask for an approval or external operation rather than information. */
    action?: boolean;
}
/** One mailbox message. */
export interface CommMessage {
    from: string;
    fromLabel?: string;
    body: string;
    /** ISO-8601 instant. */
    timestamp: string;
    piece?: string;
    rung?: string;
    blocker?: string;
}
/** Where one piece of work stands, as last reported by its chat. */
export interface CommRung {
    piece: string;
    rung: string;
    blocker: string;
    note?: string;
    session: string;
    sessionLabel?: string;
    projectPath?: string;
    /** ISO-8601 instant. */
    updated: string;
}
/** One Q/A pair of a chat's transcript. */
export interface CommExchange {
    index: number;
    question: string;
    answer?: string;
}
/** One session as `list` reports it. */
export interface CommSessionInfo {
    id: string;
    /** The chat's agent name, once assigned. */
    name?: string;
    /** The task: the brief-derived or user-given title, or the role label. */
    title: string;
    projectPath?: string;
    status?: string;
    unread: number;
    /** The chat's comm role; `chat` for an ordinary chat with none. */
    role: 'project-agent' | 'studio-agent' | 'chat';
    /** True while an agent runs a turn; an idle live chat and a stored one both read false. */
    running: boolean;
    /** True while an agent holds the session in this app run; false for a stored session only persistence knows. */
    live: boolean;
}
/** One Studio task as `studio` reports it: the fold's row plus roster labels. */
export interface StudioTaskRow {
    id: string;
    goal: string;
    owner: string;
    /** The owner's agent name (or title), when the roster knows the session. */
    ownerLabel?: string;
    state: string;
    attention: string;
    attentionOwner?: string;
    attentionOwnerLabel?: string;
    /** ISO-8601 instant of the last event that touched the task. */
    updated: string;
}
/** The response envelope; `ok: false` carries `error`. */
export interface CommResponse {
    ok: boolean;
    error?: string;
    info?: string;
    warning?: string;
    sessions?: CommSessionInfo[];
    messages?: CommMessage[];
    exchanges?: CommExchange[];
    rungs?: CommRung[];
    tasks?: StudioTaskRow[];
    /** studio: the latest published synthesis, when one exists. */
    synthesis?: {
        body: string;
        stale: boolean;
        at: string;
    };
}
/** Body and note caps plus the rung grammar (V0's `Wire`). */
export declare const Wire: {
    readonly maxBodyCharacters: 800;
    readonly maxNoteCharacters: 160;
    readonly truncationNote: "…[truncated — the wire carries rungs, not stories]";
    readonly rungs: readonly string[];
    readonly blockers: readonly string[];
    /** Flatten a note to one line and cut it at the note cap on a word boundary. */
    readonly clampNote: (note: string) => string;
    /** Cut a message body at the body cap, appending the truncation note. */
    readonly clamp: (body: string) => {
        text: string;
        truncated: boolean;
    };
    /** Lower-case, trimmed, spaces to hyphens: the rung and blocker spelling. */
    readonly normalise: (word: string) => string;
    /** The one status line every chat reports with, generated so the grammar cannot drift. */
    readonly statusLine: (input: {
        project?: string;
        piece: string;
        rung: string;
        blocker: string;
        session?: string;
        note?: string;
    }) => string;
};
/** Told to the sender: the next message only gets shorter if its author hears this. */
export declare const TRUNCATION_WARNING: string;
/**
 * A chat name read off a task brief: the first non-empty line, stripped of
 * heading or list decoration, cut at the first sentence end when what is left
 * still says something, capped at 32 characters on a word boundary, and
 * sentence-cased unless the word is deliberately styled ("iOS").
 * @param task - the brief.
 * @returns the name, or undefined for a blank brief.
 */
export declare function chatNameFromTask(task: string): string | undefined;
/**
 * Format a mailbox timestamp as the CLI prints it.
 * @param iso - the message's ISO timestamp.
 * @returns `HH:mm:ss` in local time.
 */
export declare function clockTime(iso: string): string;
/**
 * The standing guidance every agent's prompt carries about the other chats
 * and the `idealize` command (order 120, the tool-guidance band). The
 * session-start notice names the chat; this section survives compaction and
 * says how to reach a peer, since without it an agent asked to post to the
 * Studio guessed at an unrelated CLI on the person's machine, and one asked
 * about "@Name" searched transcripts instead of asking (JJ, 8 Sep 2026). The
 * last two sentences are the posting rules: a finished piece of work earns
 * one Studio line, and a note from the Studio is answered in the Studio
 * (JJ, 8 Sep 2026: "when an agent completes an action I want them to post a
 * note into the studio"). It also says that another chat's note carries the
 * person's authority and what a handoff note contains, because a chat paused
 * "until Bossk finishes" read Bossk's "I've finished" as information and kept
 * waiting for the person (JJ, 22 Sep 2026). The last sentence says where
 * detail goes, because a note is cut at the wire's limit and agents sent
 * long notes that arrived trimmed (JJ, 8 Oct 2026).
 */
export declare const COMMANDS_SECTION: {
    readonly name: "idealize:commands";
    readonly order: 120;
    readonly text: string;
};
//# sourceMappingURL=wire.d.ts.map