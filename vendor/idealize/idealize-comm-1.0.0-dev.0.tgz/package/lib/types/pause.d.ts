/**
 * Pausing every agent (feedback 495cec0a, JJ 30 Oct 2026): "a 'pause' button
 * so that all live agent work can get paused safely… when its time to shut the
 * mac down, you can press pause and all active agents save their workings etc
 * ready to be picked up as soon as work is 'un-paused'."
 *
 * JJ's rulings the same day: an agent that is mid-task saves notes, then stops,
 * and Pause waits for each one with Stop now to cut the wait; the control sits
 * at the bottom of the sidebar; quitting while agents work asks whether to
 * pause them first. Later the same day, for terminal agents: "if a terminal
 * agent is in the middle of a run, the pause button needs to interrupt and get
 * the agent to wrap up safely ready to restart when prompted". A chat agent
 * already reads the save line mid-turn (it is spliced into the running turn);
 * a terminal agent mid-run is now stopped first and given {@link wrapUpLine}.
 *
 * The phases: `running` → Pause → `saving` while working agents write their
 * notes → `paused` once every one has stopped (or Stop now) → Resume →
 * `running`. Pressing Pause with nobody working goes straight to `paused`.
 * Anything but `running` holds the schedule and stops notes between chats
 * from waking anyone. The document survives a restart; a restart during
 * `saving` reads as `paused`, because quitting ended every agent's run.
 *
 * This module is the state machine and its words, over a {@link PauseWorld}
 * the host service supplies, so the rules test without a live host.
 * @module @idealize/comm/pause
 */
/** Where every agent stands. */
export type PausePhase = 'running' | 'saving' | 'paused';
/** One paused chat's progress through the pause. */
export type PausedChatState = 'saving' | 'stopped';
/** What a working agent runs in: the chat's own agent, or the CLI in its terminal. */
export type PausedChatKind = 'chat' | 'terminal';
/** One chat whose agent was working when Pause was pressed. */
export interface PausedChat {
    id: string;
    kind: PausedChatKind;
    /** The chat's agent name or title, as the sidebar names it. */
    label: string;
    cwd?: string;
    /** The note the agent was asked to write; absent when the project keeps no notes folder. */
    note?: string;
    /** A terminal chat's brain, so Resume can reopen its shell on the right CLI. */
    activity?: string;
    state: PausedChatState;
    /** True once the agent finished its notes; false when Stop now cut it short. */
    saved: boolean;
}
/** A carry-on line Resume could not type yet: its terminal chat had no shell open. */
export interface OwedLine {
    id: string;
    text: string;
}
/** The persisted document. */
export interface PauseDocument {
    phase: PausePhase;
    /** When Pause was pressed, ISO-8601. */
    since?: string;
    chats: PausedChat[];
    owed: OwedLine[];
}
/** One chat whose agent is working now, as the host finds it. */
export interface WorkingChat {
    id: string;
    kind: PausedChatKind;
    label: string;
    /** The agent's name, for its note's file name. */
    name?: string;
    cwd?: string;
    activity?: string;
}
/** A terminal chat's two pause lines: for an agent at its prompt, and for one the pause interrupts. */
export interface TerminalPauseLines {
    /** The agent was at its prompt. */
    save: string;
    /** The agent was in the middle of a run and has just been stopped. */
    wrapUp: string;
}
/** What became of a line typed into a terminal (restated from `@idealize/ui-terminal`). */
export type TerminalLineOutcome = 'answered' | 'dropped' | 'gone';
/** A terminal chat Resume could not reach, for the window to open its shell. */
export interface ShellToOpen {
    sessionId: string;
    cwd?: string;
    activity?: string;
}
/** The pause as the sidebar and the quit dialog read it. */
export interface PauseSnapshot {
    phase: PausePhase;
    since?: string;
    chats: {
        id: string;
        label: string;
        kind: PausedChatKind;
        state: PausedChatState;
    }[];
    /** Agents still writing their notes. */
    saving: number;
    /** Agents working right now; counted only while running, for the quit dialog. */
    working: number;
}
/** The host the pause acts on. */
export interface PauseWorld {
    /** Every chat whose agent is working now. */
    working(): Promise<WorkingChat[]>;
    /** Tell a working chat's agent to save its notes; settles once it has stopped. */
    saveChat(id: string, text: string): Promise<void>;
    /**
     * Type the save line into a terminal chat; settles once answered, or
     * undefined with no shell. An agent in the middle of a run is interrupted
     * first and gets the wrap-up line instead.
     */
    saveTerminal(id: string, lines: TerminalPauseLines, wanted: () => boolean): Promise<TerminalLineOutcome> | undefined;
    /** Cancel a chat agent's turn. */
    stopChat(id: string): void;
    /** Interrupt a terminal chat's CLI. */
    stopTerminal(id: string): void;
    /** Tell a paused chat's agent to carry on, waking a stored chat if need be. */
    carryOnChat(id: string, text: string): Promise<void>;
    /** Type the carry-on line into a terminal chat; false when it has no shell open. */
    carryOnTerminal(id: string, text: string): boolean;
    /** The project's notes folder, when the documentation folder holds one. */
    notesFolder(cwd: string): Promise<string | undefined>;
    /** How many notes wait in a chat's inbox. */
    unread(id: string): number;
    /** Run the schedule tasks the pause held. */
    releaseSchedule(): Promise<void>;
    /** Wake the chats, other than `skip`, whose inbox filled while paused. */
    releaseMail(skip: ReadonlySet<string>): Promise<void>;
    /** Tell the windows the pause changed. */
    announce(): void;
    /** Report a failure that must not stop the pause. */
    warn(message: string): void;
    now(): Date;
}
/**
 * Read a stored document, dropping what is malformed. A document stored
 * mid-save reads as paused with every chat stopped unsaved: the app quit, and
 * quitting ended every agent's run.
 * @param text - the document's JSON text.
 * @returns the document; unreadable text reads as running.
 */
export declare function parsePauseDocument(text: string): PauseDocument;
/**
 * Where the document lives under one harness home.
 * @param dshHome - the harness home directory.
 * @returns the absolute path of `idealize/pause.json` under it.
 */
export declare function pauseDocumentPath(dshHome: string): string;
/**
 * Where a project without a notes folder keeps its pause notes: IDEalize's own
 * folder inside the project, which a chat's sandbox lets it write. A file is
 * needed even there, because a Codex or Kimi chat reopens with no conversation
 * after a restart and has only its note to go on (Part A, 30 Oct 2026).
 * @param cwd - the project folder.
 * @returns the folder's absolute path.
 */
export declare function fallbackNotesFolder(cwd: string): string;
/**
 * The note one agent writes when paused: its own file beside the project's
 * index, so agents pausing together never write over each other's notes.
 * @param folder - the project's notes folder.
 * @param name - the agent's name, or the chat's label.
 * @param date - the pause's ISO date (`2026-10-30`).
 * @returns the note's absolute path.
 */
export declare function pauseNotePath(folder: string, name: string, date: string): string;
/**
 * What a working agent is told when Pause is pressed.
 * @param note - the note to write, when the project keeps a notes folder.
 * @returns one line, so a terminal agent receives it whole.
 */
export declare function saveNotesLine(note: string | undefined): string;
/**
 * What a terminal agent is told after the pause has interrupted it mid-run.
 * The interrupt can land in the middle of a step, so the agent checks what
 * finished before it writes anything down.
 * @param note - the note to write, when the project keeps a notes folder.
 * @returns one line, so a terminal agent receives it whole.
 */
export declare function wrapUpLine(note: string | undefined): string;
/**
 * What a paused agent is told when Resume is pressed. The note leads, because
 * a terminal agent may come back with no conversation at all.
 * @param chat - the paused chat.
 * @param unread - how many notes reached its inbox meanwhile.
 * @returns one line, so a terminal agent receives it whole.
 */
export declare function carryOnLine(chat: Pick<PausedChat, 'note' | 'saved'>, unread: number): string;
/** The document on disk: read once at start, written atomically and in order. */
export declare class PauseFile {
    #private;
    readonly path: string;
    /** @param path - the document's absolute path. */
    constructor(path: string);
    /**
     * Read the stored document; a missing or unreadable file reads as running.
     * Synchronous, so the pause holds from the first moment the host runs.
     * @returns the document.
     */
    load(): PauseDocument;
    /**
     * Queue one write of the document.
     * @param document - the document to store.
     * @returns once this write has landed.
     */
    save(document: PauseDocument): Promise<void>;
}
/** The document store a controller writes through; {@link PauseFile} on a real host. */
export interface PauseStore {
    load(): PauseDocument;
    save(document: PauseDocument): Promise<void>;
}
/** The pause: one document, three actions, and the reads the windows make. */
export declare class PauseController {
    #private;
    private readonly world;
    private readonly store;
    /**
     * @param world - the host the pause acts on.
     * @param store - where the document persists.
     */
    constructor(world: PauseWorld, store: PauseStore);
    /**
     * Whether agent work is held: anything but running.
     * @returns true from Pause until Resume.
     */
    held(): boolean;
    /**
     * The pause as the windows show it.
     * @returns the phase, the paused chats and the counts.
     */
    snapshot(): Promise<PauseSnapshot>;
    /**
     * Hear every change of the pause.
     * @param listener - called after each change lands.
     * @returns a function that stops the listening.
     */
    onChange(listener: () => void): () => void;
    /**
     * Pause every agent: each working one is told to save its notes and stop.
     * Nothing to do while already pausing or paused.
     * @returns the pause after the press.
     */
    pause(): Promise<PauseSnapshot>;
    /**
     * Cut the wait: interrupt every agent still writing its notes. Its chat is
     * kept, and Resume tells it to carry on from where it stopped.
     * @returns the pause after the press.
     */
    stopNow(): Promise<PauseSnapshot>;
    /**
     * Resume every paused agent and release what the pause held. A terminal
     * chat with no shell open is owed its line, typed when its shell opens, and
     * named in the result so the window can open it.
     * @returns the pause after the press, and the shells the window should open.
     */
    resume(): Promise<PauseSnapshot & {
        open: ShellToOpen[];
    }>;
    /**
     * A chat's terminal opened: type the line Resume owes it, if any.
     * @param sessionId - the chat whose shell opened.
     */
    opened(sessionId: string): void;
}
//# sourceMappingURL=pause.d.ts.map