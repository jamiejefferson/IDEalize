/**
 * The command surface's durable state: per-session mailboxes, the piece
 * ladder (rungs), status labels, each chat's own note line, roles, and the
 * names spawn gave its children. One JSON document under the harness home;
 * writes are atomic (temp file + rename) and serialised, so a burst of
 * `send`s cannot interleave half-written documents.
 */
import type { CommMessage, CommRung } from './wire.ts';
/**
 * Roles the addressing aliases resolve through; the lead role was retired for
 * the group chat (JJ, 1 Sep). `project-agent` coordinates one project folder
 * and is found by that folder; `studio-agent` coordinates the Studio itself,
 * spans every project, and is found by the role alone — there is one.
 */
export type CommRole = 'project-agent' | 'studio-agent';
/** The persisted document. */
export interface CommState {
    mailboxes: Record<string, CommMessage[]>;
    rungs: Record<string, CommRung>;
    statuses: Record<string, string>;
    roles: Record<string, CommRole>;
    names: Record<string, string>;
    /** Project folder → name-pool index. */
    pools: Record<string, number>;
    /** Session → its brief-derived or user-given task title, for sessions the surface named. */
    titles: Record<string, string>;
}
/**
 * Where the document lives under one harness home.
 * @param dshHome - the harness home directory.
 * @returns the absolute path of `idealize/comm.json` under it.
 */
export declare function commStorePath(dshHome: string): string;
/**
 * Parse a stored document, dropping unknown or malformed sections rather than refusing the file.
 * @param text - the document's JSON text.
 * @returns the state; unparseable text yields the empty state.
 */
export declare function parseCommState(text: string): CommState;
/** The durable document's in-memory copy: reads are synchronous after `load()`, mutations resolve when their atomic write lands. */
export declare class CommStore {
    readonly path: string;
    private state;
    private loaded;
    private chain;
    constructor(path: string);
    /** Read the document once; a missing file is an empty state. */
    load(): Promise<void>;
    /** Mutate the state and queue an atomic write; resolves when the write lands. */
    private mutate;
    /**
     * Queue a message on one session's mailbox.
     * @param sessionId - the recipient session.
     * @param message - the message to append.
     */
    deliver(sessionId: string, message: CommMessage): Promise<void>;
    /**
     * Read a mailbox without clearing it.
     * @param sessionId - the mailbox's session.
     * @returns a copy of the queued messages, oldest first; empty for an unknown session.
     */
    peek(sessionId: string): CommMessage[];
    /**
     * Unread count for one session.
     * @param sessionId - the mailbox's session.
     * @returns the queued message count, 0 for an unknown session.
     */
    unread(sessionId: string): number;
    /**
     * Read and clear a mailbox.
     * @param sessionId - the mailbox's session.
     * @returns the messages that were queued, oldest first; an empty mailbox writes nothing.
     */
    drain(sessionId: string): Promise<CommMessage[]>;
    /**
     * Record a session's piece-ladder rung.
     * @param sessionId - the reporting session.
     * @param rung - the rung record.
     */
    setRung(sessionId: string, rung: CommRung): Promise<void>;
    /**
     * Every recorded rung, for the board.
     * @returns the rungs in insertion order.
     */
    rungs(): CommRung[];
    /**
     * Set or clear a session's status label.
     * @param sessionId - the session.
     * @param status - the label; undefined clears it.
     */
    setStatus(sessionId: string, status: string | undefined): Promise<void>;
    /**
     * A session's status label.
     * @param sessionId - the session.
     * @returns the label, or undefined when none is set.
     */
    status(sessionId: string): string | undefined;
    /**
     * Assign or clear a session's role.
     * @param sessionId - the session.
     * @param role - the role; undefined clears it.
     */
    setRole(sessionId: string, role: CommRole | undefined): Promise<void>;
    /**
     * A session's role.
     * @param sessionId - the session.
     * @returns the role, or undefined for an ordinary chat.
     */
    role(sessionId: string): CommRole | undefined;
    /**
     * Every session holding a role, for alias resolution.
     * @returns a copy of the session→role map.
     */
    roles(): Record<string, CommRole>;
    /**
     * Record the name a session was given.
     * @param sessionId - the session.
     * @param name - the drawn name.
     */
    setName(sessionId: string, name: string): Promise<void>;
    /**
     * The name a session was given.
     * @param sessionId - the session.
     * @returns the name, or undefined when the session was never named.
     */
    name(sessionId: string): string | undefined;
    /**
     * Every name currently held, for collision-free drawing.
     * @returns a fresh set of the held names.
     */
    takenNames(): Set<string>;
    /**
     * Record which name pool a project draws from.
     * @param projectPath - the project's canonical folder.
     * @param pool - the pool index.
     */
    setPool(projectPath: string, pool: number): Promise<void>;
    /**
     * Every project's recorded pool.
     * @returns a copy of the project→pool map.
     */
    pools(): Record<string, number>;
    /**
     * Record a session's task title.
     * @param sessionId - the session.
     * @param title - the brief-derived or user-given title.
     */
    setTitle(sessionId: string, title: string): Promise<void>;
    /**
     * A session's recorded task title.
     * @param sessionId - the session.
     * @returns the title, or undefined when the surface never named it.
     */
    title(sessionId: string): string | undefined;
}
//# sourceMappingURL=store.d.ts.map