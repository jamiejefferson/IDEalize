/**
 * Agent naming: a project takes one of the twelve pools on its first chat and
 * every chat in it draws a random unused name from that pool. Pure functions
 * over the store's view of what is taken; the service owns persistence.
 */
/**
 * The pool a project should draw from: its recorded pool, else the least-used
 * pool so projects spread across the twelve before any pool repeats.
 * @param projectPath - the project's canonical folder.
 * @param pools - every project's recorded pool index.
 * @returns the pool index in `[0, NAME_POOLS.length)`.
 */
export declare function poolFor(projectPath: string, pools: Readonly<Record<string, number>>): number;
/**
 * Draw an unused name from a pool, spilling into the following pools when one
 * is exhausted; with all 496 taken, a numbered form of a name from the home
 * pool keeps the chat addressable.
 * @param pool - the project's pool index.
 * @param taken - every name currently held by a session.
 * @param random - a [0,1) source; injected so tests are deterministic.
 * @returns a name absent from `taken`.
 */
export declare function pickName(pool: number, taken: ReadonlySet<string>, random?: () => number): string;
//# sourceMappingURL=names.d.ts.map