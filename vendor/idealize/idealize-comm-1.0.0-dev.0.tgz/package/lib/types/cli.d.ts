#!/usr/bin/env node
/**
 * `idealize` — the command-line face of the command surface. Parses V0's
 * command grammar, posts one request to the host, prints the response in
 * V0's text shapes (or `--json`). Identity comes from the harness's
 * `DSH_SESSION_ID` (else V0's `IDEALIZE_SESSION_ID`); the host origin from
 * `DSH_IDEALIZE_HOST`, else `IDEALIZE_HOST`, else `<DSH_HOME>/idealize/comm-host.json`.
 */
export {};
//# sourceMappingURL=cli.d.ts.map