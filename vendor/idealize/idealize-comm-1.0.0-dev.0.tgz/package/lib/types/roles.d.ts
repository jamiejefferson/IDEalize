/**
 * The agent roles: which Activity Agent (preset) carries each, the seeding of
 * those presets into the user's preset root, and the role guide (a skill
 * shipped with this package) a chat on one receives. The lead-agent role was
 * retired (JJ, 1 Sep) in favour of the group chat on the Studio timeline.
 *
 * Two roles coordinate, at different altitudes. `project-agent` runs one
 * project folder and is found by that folder. `studio-agent` runs the Studio
 * itself: it takes every untagged Studio post and works through the project
 * coordinators, and it is found by the role alone because there is one.
 */
import type { CommRole } from './store.ts';
/** The settings-backed mapping from a preset id to each coordinator role. */
export interface RoleConfig {
    /** The preset id that carries the project-coordinator role. */
    projectAgentPreset: string;
    /** The preset id that carries the Studio-coordinator role. */
    studioAgentPreset: string;
}
/** The mapping in force when the settings section names no preset. */
export declare const DEFAULT_ROLE_CONFIG: RoleConfig;
/** The task label a role's chat carries instead of a brief-derived title. */
export declare const ROLE_TITLES: Readonly<Record<CommRole, string>>;
/**
 * The role a preset id carries under the current mapping.
 * @param presetId - the session's preset id, undefined for a session with none.
 * @param config - the current preset→role mapping.
 * @returns the role, or undefined for an ordinary chat.
 */
export declare function roleOfPreset(presetId: string | undefined, config: RoleConfig): CommRole | undefined;
/** The opening turn a role chat starts on; a chat with no turn stays a hidden blank. */
export declare const ROLE_OPENING: Readonly<Record<CommRole, string>>;
/**
 * The preset id that carries a role.
 * @param role - the role to look up.
 * @param config - the current preset→role mapping.
 * @returns the mapped preset id.
 */
export declare function presetOfRole(role: CommRole, config: RoleConfig): string;
/**
 * The package's bundled skills directory (`skills/<role>/SKILL.md`, one level above both `src/` and `lib/`).
 * @returns the absolute directory path.
 */
export declare function skillsDir(): string;
/**
 * The role guide's body, frontmatter stripped.
 * @param role - the role whose `SKILL.md` is read.
 * @param dir - the skills directory; defaults to the bundled one.
 * @returns the trimmed guide text, or undefined when the file is missing or unreadable.
 */
export declare function roleGuide(role: CommRole, dir?: string): Promise<string | undefined>;
/**
 * Replace (or prepend) the persona row in a composition, textually: the
 * loader's YAML dialect carries `!!js` tags that a plain parser rejects, and
 * every other row must reach the new file byte-for-byte.
 * @param composition - the template composition text.
 * @param role - the role whose persona replaces the template's.
 * @returns the rewritten composition text.
 */
export declare function withRolePersona(composition: string, role: CommRole): string;
/**
 * Write a role preset next to the others, derived from a template
 * composition (the deployment's default preset) with the persona row replaced.
 * Existing presets are never overwritten: the user's edits to the
 * personalisation prompt are theirs.
 * @param root - the user preset root directory.
 * @param id - the preset id, which names its directory under `root`.
 * @param role - the role whose persona and metadata the preset carries.
 * @param templateComposition - the template composition text (the default preset's `agent.cordis.yml`).
 * @returns true when the preset was created; false when one already existed and was left alone.
 */
export declare function seedRolePreset(root: string, id: string, role: CommRole, templateComposition: string): Promise<boolean>;
//# sourceMappingURL=roles.d.ts.map