/**
 * Folder access probes for the first-run orientation and the workspace-alias
 * seam. A probe answers whether IDEalize can actually use a folder — it
 * exists, is a directory, lists, and accepts a file write — and, when it
 * cannot, explains why in a plain sentence the setup overlay shows verbatim
 * (SET-04).
 * @module @idealize/setup/probe
 */
/**
 * Access verdict for one probed folder. `ok` means the folder exists, is a
 * directory, and passed both the read and the write probe; every other state
 * names the first failed check.
 */
export type AliasAccessState = 'ok' | 'missing' | 'not-a-directory' | 'unreadable' | 'unwritable';
/** One probe's verdict; `reason` is present exactly when `state` is not `ok`. */
export interface FolderProbe {
    /** The access verdict. */
    state: AliasAccessState;
    /** Plain-language explanation of the failure, shown to the user verbatim. */
    reason?: string;
}
/**
 * Probe one folder: absolute path, exists, is a directory, lists (read), and
 * accepts creating and deleting a throwaway dotfile (write). Stops at the
 * first failed check and explains it plainly.
 * @param path - the folder to probe, expected absolute.
 * @returns the verdict with a plain-language reason on failure.
 */
export declare function probeFolder(path: string): Promise<FolderProbe>;
//# sourceMappingURL=probe.d.ts.map