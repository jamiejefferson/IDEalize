/**
 * The weekly documentation review, offered at setup (JJ, 16 Nov 2026): the
 * bundled `vault-review` skill, the `idealize-vault-review` settings section
 * (folders to skip, folders never to edit, and the calendar entry the person
 * accepted), the calendar entry itself, and the check that stops the review's
 * chat writing into a never-edit folder.
 *
 * Nothing is scheduled until the person accepts. Accepting saves one weekly
 * task in `@idealize/cron`, Monday 08:00 in the host's zone, whose workspace is
 * the documentation folder and whose instructions name the skill and carry the
 * two folder lists. A changed list or a changed documentation folder rewrites
 * the entry's instructions and workspace.
 *
 * @module @idealize/setup/review
 */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import type { Schedule } from '@idealize/cron';
/** The settings namespace the weekly review owns. */
export declare const REVIEW_SETTINGS_NAMESPACE = "idealize-vault-review";
/** The name the bundled skill registers under, as its `SKILL.md` frontmatter states it. */
export declare const REVIEW_SKILL_NAME = "vault-review";
/** The provider name the bundled skills register under. */
export declare const BUNDLED_SKILLS_PROVIDER_NAME = "idealize-bundled";
/** The calendar entry's title. */
export declare const REVIEW_TASK_NAME = "Weekly documentation review";
/** The entry's time of day, in the host's zone. */
export declare const REVIEW_TIME = "08:00";
/** The entry's weekday: Monday (0 = Sunday). */
export declare const REVIEW_DAY = 1;
/** Folders the review never edits when the person has listed none: the chat transcripts IDEalize writes. */
export declare const DEFAULT_NEVER_EDIT_FOLDERS: readonly string[];
/** The durable `idealize-vault-review` section. */
export interface ReviewSettings {
    /**
     * Folders the review neither reads nor reports on, relative to the documentation folder. A rule that starts with
     * {@link ANY_DEPTH} matches at any depth.
     */
    skipFolders?: string[];
    /**
     * Folders the review may read and never change, written the same way. Absent means
     * {@link DEFAULT_NEVER_EDIT_FOLDERS}; an empty list means none.
     */
    neverEditFolders?: string[];
    /** The calendar entry the person accepted; absent until they accept. */
    taskId?: string;
}
/** Runtime schema for {@link ReviewSettings}. */
export declare const ReviewSettingsSchema: z<ReviewSettings>;
/** The two folder lists with their defaults applied. */
export interface ReviewFolders {
    /** Folders the review skips. */
    skipFolders: readonly string[];
    /** Folders the review never edits. */
    neverEditFolders: readonly string[];
}
/** The marker that makes a folder rule match at any depth: two asterisks and a slash, before the folder's name. */
export declare const ANY_DEPTH = "**/";
/**
 * Why one folder rule cannot be used.
 * @param rule - the rule as stored.
 * @returns a plain sentence, or undefined when the rule is usable.
 */
export declare function folderRuleProblem(rule: string): string | undefined;
/**
 * Apply the defaults to a stored section.
 * @param settings - the stored section.
 * @returns the two lists, each rule tidied and empty rules dropped.
 */
export declare function resolveReviewFolders(settings: ReviewSettings): ReviewFolders;
/**
 * The first rule that covers one file. A rule covers every file inside its
 * folder; a rule that starts with {@link ANY_DEPTH} covers a folder of that name at any depth. Names compare
 * without regard to case, because the default macOS file system does.
 * @param relativePath - the file's path relative to the documentation folder, `/`-separated.
 * @param rules - the folder rules.
 * @returns the covering rule as written, or undefined when none covers the file.
 */
export declare function matchingFolderRule(relativePath: string, rules: readonly string[]): string | undefined;
/**
 * The instructions the calendar entry sends at each run.
 * @param folders - the two folder lists.
 * @returns the message: which skill to follow, and the settings for the run.
 */
export declare function reviewPrompt(folders: ReviewFolders): string;
/**
 * The schedule the offer proposes.
 * @param timeZone - the host's IANA zone.
 * @returns Monday at 08:00 in that zone, every week.
 */
export declare function reviewSchedule(timeZone: string): Schedule;
/**
 * The directory holding the skills this package ships (`skills/<name>/SKILL.md`, one level above both `src/` and `lib/`).
 * @returns the absolute directory path.
 */
export declare function bundledSkillsDir(): string;
/** The weekly review as the setup flow shows it. */
export interface ReviewOffer {
    /** The documentation folder the review runs in; absent until one is chosen. */
    folder?: string;
    /** The schedule: the accepted entry's own, else the one the offer proposes. */
    schedule: Schedule;
    /** Whether the person accepted and the calendar still holds the entry. */
    accepted: boolean;
    /** Whether the accepted entry is switched on. */
    enabled: boolean;
    /** The folders the review skips. */
    skipFolders: readonly string[];
    /** The folders the review never edits. */
    neverEditFolders: readonly string[];
}
/**
 * The weekly review's offer and its limits. One instance per setup plugin,
 * held by the plugin body: the route and the documentation-folder write are
 * its only callers, so it is no Cordis service.
 *
 * - {@link offer} reads; nothing is scheduled by reading.
 * - {@link accept} is the only call that creates the calendar entry.
 * - {@link sync} keeps an accepted entry's instructions and workspace in step
 *   with the settings and the documentation folder.
 * - While the entry's chat runs, a `write` or `edit` tool call on a file inside
 *   a never-edit folder is refused before the file is touched.
 */
export declare class WeeklyReview {
    private readonly ctx;
    private scope;
    /** The running review chats and the folder each runs in, by calendar entry id. */
    private readonly runs;
    /**
     * @param ctx - the plugin context; the settings section registers when a
     * settings provider is composed and detaches with it, and every listener
     * is released with the context.
     */
    constructor(ctx: Context);
    /** The current section, `{}` while no settings provider is composed. */
    private section;
    /**
     * The two folder lists with their defaults applied.
     * @returns the lists the next run's instructions carry.
     */
    folders(): ReviewFolders;
    /** The accepted calendar entry, or undefined when none was accepted or it has since been deleted. */
    private task;
    /**
     * The offer as it stands.
     * @returns the folder, the schedule, whether the person accepted, and the folder lists.
     */
    offer(): Promise<ReviewOffer>;
    /**
     * The person accepts the offer: save the weekly entry, switched on, with the
     * documentation folder as its workspace. Accepting again switches an entry
     * the person had turned off back on and keeps the time they gave it.
     * @returns the offer after the write.
     * @throws a plain sentence when no documentation folder is chosen, the calendar is not composed, or the calendar refuses the folder.
     */
    accept(): Promise<ReviewOffer>;
    /**
     * Bring an accepted entry's instructions and workspace in step with the
     * settings and the documentation folder. Does nothing before the person
     * accepts, or when nothing differs. A refusal from the calendar is logged:
     * the entry keeps what it had.
     */
    sync(): Promise<void>;
    /**
     * Refuse a `write` or `edit` from the review's chat on a file inside a
     * never-edit folder. Every other chat, and every file outside the
     * documentation folder, passes: the sandbox confines the review's chat to
     * the folder.
     * @throws a sentence the model reads as the tool's failure.
     */
    private assertEditable;
}
/**
 * Install the weekly review on a plugin context: its settings section, its
 * listeners and, while a skill registry is composed, the provider that
 * registers the bundled `vault-review` skill.
 * @param ctx - host plugin context.
 * @returns the review the plugin body's route and folder write call.
 */
export declare function installWeeklyReview(ctx: Context): WeeklyReview;
//# sourceMappingURL=review.d.ts.map