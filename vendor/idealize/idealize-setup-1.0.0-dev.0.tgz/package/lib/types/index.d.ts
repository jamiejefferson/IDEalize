/**
 * @idealize/setup — first-run setup, host half: the `idealize-setup` settings
 * section (component seeds + the two captured folders), the workspace-alias
 * seam (`ctx.workspaceAliases`), and the `/idealize/setup` routes.
 *
 * First-run captures exactly two folders (SET-02, JJ's revision of OQ-01):
 * the PROJECTS ROOT — the folder holding every project — and the
 * DOCUMENTATION folder (the vault). The current project is not asked as a
 * folder: it is created or selected UNDER the projects root through
 * `ctx.workspaceRegistry`. Orientation probes both folders (stat + read +
 * write) and explains failures in plain sentences (SET-04); on success it
 * stores the aliases, seeds `@idealize/doc-policy`'s `idealize-docs` section
 * and `@idealize/vault`'s `idealize-vault` section, and kicks the
 * documentation scan (SET-06).
 *
 * Routes (loopback-fenced; mutations demand the `x-idealize-auth` header):
 * - `GET  /idealize/setup/state` — component seeds + live-probed aliases.
 * - `POST /idealize/setup/orientation` — `{projectsFolder, documentationFolder,
 *   projectName?}`: probe, persist, seed, scan, and create the first project.
 * - `POST /idealize/setup/alias` — `{name, path}`: the later Reconnect flow's
 *   alias mutation; re-probes and re-seeds the dependent section.
 *
 * @module @idealize/setup
 */
import { Context, Service } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import type { WorkspaceId } from '@deepseek-ai/dsh-workspace';
import type { AliasAccessState } from './probe.ts';
export { probeFolder } from './probe.ts';
export type { AliasAccessState, FolderProbe } from './probe.ts';
/** Cordis plugin name. */
export declare const name = "idealize-setup";
/** The settings namespace both halves share. */
export declare const SETUP_SETTINGS_NAMESPACE = "idealize-setup";
/**
 * The durable `idealize-setup` section: one seed per setup component (flat,
 * so the browser half can mark its own component done with a single-field
 * write that cannot clobber a sibling) plus the captured folder aliases.
 */
export interface SetupSettings {
    /** True once the orientation component stored both folders. */
    orientationDone?: boolean;
    /** When orientation completed (ISO). */
    orientationAt?: string;
    /** True once the model-connection component completed or was skipped. */
    modelsDone?: boolean;
    /** The captured folders, by alias name. */
    aliases?: {
        /** The folder holding ALL projects; the current project lives under it. */
        projectsRoot?: string;
        /** The documentation folder (the user's vault). */
        documentation?: string;
        /** The skills folder: one subfolder per skill, each holding a SKILL.md. */
        skills?: string;
    };
}
/** Runtime schema for {@link SetupSettings}. */
export declare const SetupSettingsSchema: z<SetupSettings>;
/**
 * The alias names the seam resolves: the two orientation folders (JJ's OQ-01
 * revision) plus the skills folder (JJ, 15 Sep 2026), which orientation never
 * asks for and only the alias route captures.
 */
export type WorkspaceAliasName = 'projectsRoot' | 'documentation' | 'skills';
/** Every alias name, for wire validation and iteration. */
export declare const WORKSPACE_ALIAS_NAMES: readonly WorkspaceAliasName[];
/**
 * One resolved alias: the stored path plus its live-probed access state.
 * `reason` is present exactly when `accessState` is not `ok` and is a plain
 * sentence fit to show the user verbatim.
 */
export interface WorkspaceAlias {
    /** Which alias this is. */
    name: WorkspaceAliasName;
    /** The stored absolute path. */
    path: string;
    /** Live probe verdict for the stored path. */
    accessState: AliasAccessState;
    /** Plain-language failure explanation; absent when `accessState` is `ok`. */
    reason?: string;
}
/**
 * An alias write refused because the folder failed its probe. Carries the
 * probe verdict and the plain-language reason so the Reconnect flow can show
 * both without re-probing.
 */
export declare class AliasProbeError extends Error {
    readonly alias: WorkspaceAliasName;
    readonly path: string;
    readonly accessState: AliasAccessState;
    /**
     * @param alias - the alias being written.
     * @param path - the refused path.
     * @param accessState - the probe verdict (never `ok`).
     * @param reason - the plain-language explanation, used as the message.
     */
    constructor(alias: WorkspaceAliasName, path: string, accessState: AliasAccessState, reason: string);
}
/** What `POST /idealize/setup/orientation` carries (SET-02 + the first project). */
export interface OrientationRequest {
    /** The projects root: the folder that holds every project. */
    projectsFolder: string;
    /** The documentation folder (the vault). */
    documentationFolder: string;
    /**
     * Optional first-project name, created as a directory under the projects
     * root and registered as a workspace. One path segment; omitted skips
     * project creation (an existing project is selected in the client).
     */
    projectName?: string;
}
/** One refused orientation field with its plain-language reason (SET-04). */
export interface OrientationFailure {
    /** Which request field failed. */
    field: 'projectsFolder' | 'documentationFolder' | 'projectName';
    /** Plain-language explanation, shown to the user verbatim. */
    reason: string;
    /** The probe verdict, for the two folder fields. */
    accessState?: AliasAccessState;
}
/**
 * Orientation outcome: either everything persisted (with the created first
 * project when one was requested), or the per-field failures and nothing
 * persisted.
 */
export type OrientationResult = {
    ok: true;
    project?: {
        workspaceId: WorkspaceId;
        path: string;
    };
} | {
    ok: false;
    failures: OrientationFailure[];
};
/** Component seeds + live-probed aliases, as `GET /idealize/setup/state` reports. */
export interface SetupState {
    /** Per-component completion seeds. */
    components: {
        /** The orientation component (folders captured). */
        orientation: {
            done: boolean;
            at?: string;
        };
        /** The model-connection component (completed or skipped). */
        models: {
            done: boolean;
        };
    };
    /** The stored aliases with their live access state; absent until captured. */
    aliases: {
        projectsRoot?: WorkspaceAlias;
        documentation?: WorkspaceAlias;
        skills?: WorkspaceAlias;
    };
}
declare module '@deepseek-ai/cordis' {
    interface Context {
        workspaceAliases: WorkspaceAliases;
    }
}
/**
 * The workspace-alias seam (`ctx.workspaceAliases`) plus the orientation
 * flow behind the `/idealize/setup` routes.
 *
 * Contract for consumers (the Files tabs, the Reconnect flow):
 * - {@link resolve} never throws for a known alias: an unset alias returns
 *   `undefined`, a set-but-broken one returns its stored path with a non-`ok`
 *   `accessState` and a plain `reason` — render the path with a Reconnect
 *   affordance rather than dropping it.
 * - {@link set} validates before it persists: a failing folder rejects with
 *   {@link AliasProbeError} and stores nothing, so a stored alias was valid
 *   at the moment it was written (it may still die later — resolve re-probes
 *   on every call).
 * - Writing `documentation` re-seeds `@idealize/doc-policy`'s folder and
 *   re-scans; writing `projectsRoot` re-seeds `@idealize/vault`'s root.
 *   A missing dependent settings section fails loud naming the plugin.
 */
export declare class WorkspaceAliases extends Service {
    private scope;
    /**
     * @param ctx - the plugin context; the settings section registers when a
     * settings provider is composed and detaches with it.
     */
    constructor(ctx: Context);
    /** The current section, `{}` while no settings provider is composed. */
    private section;
    /** The owner scope; writing without a settings provider fails loud. */
    private requireScope;
    /**
     * Resolve one alias to its stored path and live-probed access state.
     * @param aliasName - which alias to resolve.
     * @returns the alias with its probe verdict, or `undefined` while unset.
     */
    resolve(aliasName: WorkspaceAliasName): Promise<WorkspaceAlias | undefined>;
    /**
     * Point one alias at a folder: probe it, persist it, and re-seed the
     * dependent settings section (the Reconnect flow's write path).
     * @param aliasName - which alias to write.
     * @param path - absolute folder path.
     * @returns the stored alias (`accessState` is `ok` by construction).
     * @throws {AliasProbeError} when the folder fails its probe; nothing is stored.
     */
    set(aliasName: WorkspaceAliasName, path: string): Promise<WorkspaceAlias>;
    /**
     * Component seeds + live-probed aliases for the state route and, later,
     * the settings surface.
     * @returns the current setup state.
     */
    state(): Promise<SetupState>;
    /**
     * The orientation component (SET-02/04/06): probe both folders, create and
     * register the first project under the projects root when a name is given,
     * persist the aliases + the orientation seed, seed the documentation and
     * vault sections, and kick the documentation scan. Field failures return in
     * `failures` with nothing persisted; a missing dependent plugin throws.
     * @param request - the two folders and the optional first-project name.
     * @returns the outcome; on `ok` the created project when one was requested.
     */
    orient(request: OrientationRequest): Promise<OrientationResult>;
    /**
     * Re-seed the settings section that depends on one alias, failing loud when
     * its owning plugin is not composed; a `documentation` write also awaits a
     * documentation scan so the vault is scaffolded before the caller proceeds
     * (SET-06). Scan failures are logged, never thrown: the alias write stood.
     */
    private seed;
}
/**
 * Validate one orientation body at the wire boundary.
 * @param body - the parsed JSON object.
 * @returns the request, or an error line naming the offending field.
 */
export declare function parseOrientationRequest(body: Record<string, unknown>): OrientationRequest | {
    error: string;
};
/**
 * Plugin body: the `ctx.workspaceAliases` service plus the `/idealize/setup`
 * routes while a web server is composed.
 * @param ctx - host plugin context.
 */
export declare function apply(ctx: Context): void;
//# sourceMappingURL=index.d.ts.map