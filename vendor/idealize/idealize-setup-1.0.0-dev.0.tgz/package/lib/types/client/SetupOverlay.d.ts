import type { InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { SnapshotStore } from '@deepseek-ai/dsh-client-runtime/client';
import type { SetupStage } from './stage.ts';
/** The overlay's store state: which step shows (`null` renders nothing). */
export interface SetupViewState {
    /** The visible step. */
    stage: SetupStage;
}
/** One orientation failure as the host route reports it (plain `reason`). */
export interface OrientationFailureLike {
    field: 'projectsFolder' | 'documentationFolder' | 'projectName';
    reason: string;
}
/** What the orientation step submits. */
export interface OrientationForm {
    projectsFolder: string;
    documentationFolder: string;
    projectName: string;
}
/** The submit outcome the card renders: field failures or a transport error. */
export type SubmitOutcome = {
    ok: true;
} | {
    ok: false;
    failures?: OrientationFailureLike[];
    error?: string;
};
/** Registration-side face. */
export interface SetupInjected {
    hooks: {
        /** The step state. */
        view: SnapshotStore<SetupViewState>;
    };
    /** Open the Host directory picker; null when cancelled or unavailable. */
    pickDirectory: () => Promise<string | null>;
    /** Submit the orientation step; advances the flow itself on success. */
    submitOrientation: (form: OrientationForm) => Promise<SubmitOutcome>;
    /** Open the model sign-in surface in a new tab. */
    openSignin: () => void;
    /** Finish (or skip) the model step: persist the seed and end the flow. */
    finishModels: () => void;
}
export type SetupOverlayProps = PropsRuntime<'shell.overlay'> & PropsLocale<'idealize-setup'> & InjectFace<SetupInjected>;
export declare function SetupOverlay({ useView, pickDirectory, submitOrientation, openSignin, finishModels, t }: SetupOverlayProps): import("react").JSX.Element | null;
//# sourceMappingURL=SetupOverlay.d.ts.map