/**
 * IDEalize first-run setup, browser half. One occupant on the frame's
 * shell.overlay seat renders the setup card, gated by the `idealize-setup`
 * settings seed exactly as the tour is gated by `hasSeenTour`. The flow runs
 * BEFORE the showcase tour: a `ctx.tour.holdFirstRun()` hold is taken at
 * plugin start and released when the flow ends (or was already complete), so
 * the tour fires as the flow's final step through its own first-run trigger.
 *
 * Steps: orientation (the projects root + the documentation vault, picked
 * through the Host directory picker or typed, submitted to
 * `POST /idealize/setup/orientation`, failures shown verbatim), then the
 * skippable model-connection step over the existing `/idealize/signin`
 * surface (SET-07).
 */
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
import { type SetupKey } from './locales.ts';
export { deriveStage } from './stage.ts';
export type { SetupSeedLike, SetupStage } from './stage.ts';
export { SetupOverlay } from './SetupOverlay.tsx';
export type { OrientationForm, SetupInjected, SetupViewState, SubmitOutcome } from './SetupOverlay.tsx';
export type { SetupKey } from './locales.ts';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** The setup overlay's copy. */
        'idealize-setup': SetupKey;
    }
}
/** Required services. */
export declare const inject: string[];
/**
 * Client plugin body: the gate over the settings seed, the overlay occupant,
 * and the tour hold that sequences setup before the showcase.
 * @param ctx - client root context.
 */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map