/** `idealize-setup` namespace dictionaries: the first-run setup overlay. */
/** Simplified Chinese dictionary (the key-set source of truth). */
export declare const zh: {
    'setup.title': string;
    'orientation.intro': string;
    'orientation.projects.label': string;
    'orientation.projects.hint': string;
    'orientation.docs.label': string;
    'orientation.docs.hint': string;
    'orientation.choose': string;
    'orientation.notChosen': string;
    'orientation.manual': string;
    'orientation.manual.placeholder': string;
    'orientation.project.label': string;
    'orientation.project.hint': string;
    'orientation.project.default': string;
    'orientation.continue': string;
    'orientation.busy': string;
    'orientation.generalError': string;
    'models.title': string;
    'models.body': string;
    'models.open': string;
    'models.continue': string;
    'models.skip': string;
};
/** English dictionary. */
export declare const en: Record<SetupKey, string>;
/** The namespace's key set. */
export type SetupKey = keyof typeof zh;
//# sourceMappingURL=locales.d.ts.map