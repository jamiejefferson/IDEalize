/**
 * Pure derivation of the setup flow's opening stage from the durable seed —
 * kept dependency-free so the gate logic is testable without the overlay.
 * @module @idealize/setup/client/stage
 */
/** The seed fields the gate reads (the host half owns the full schema). */
export interface SetupSeedLike {
    /** True once orientation stored both folders. */
    orientationDone?: boolean;
    /** True once the model-connection step completed or was skipped. */
    modelsDone?: boolean;
}
/** Which step the overlay opens on; `null` renders nothing. */
export type SetupStage = 'orientation' | 'models' | null;
/**
 * Decide the opening stage from the stored seed: an incomplete orientation
 * always comes first, a completed one falls through to the model step, and a
 * fully seeded section shows nothing.
 * @param value - the resolved `idealize-setup` section, or undefined before
 * the section exists.
 * @returns the stage to open on.
 */
export declare function deriveStage(value: SetupSeedLike | undefined): SetupStage;
//# sourceMappingURL=stage.d.ts.map